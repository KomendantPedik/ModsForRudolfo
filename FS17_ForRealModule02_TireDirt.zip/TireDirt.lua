--
-- TireDirt
--
--
-- @author GIANTS Software
-- @date 15/10/2016
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

TireDirt = {};
TireDirt.sendNumBits = 7;
TireDirt.wheelMinDirtDelta = 1.0 / (2^TireDirt.sendNumBits - 1);

function TireDirt.prerequisitesPresent(specializations)
    return true;
end

function TireDirt:load(savegame)
    self.setDirtAmount  = Utils.overwrittenFunction(self.setDirtAmount, TireDirt.setDirtAmount);

    self.dirtDurationWheels = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.washable#dirtDurationWheels"), 0.75) * 60 * 1000;
    if self.dirtDurationWheels ~= 0 then
        self.dirtDurationWheels = 1 / self.dirtDurationWheels;
    end
    self.washDurationWheels = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.washable#washDurationWheels"), 1.00) * 60 * 1000;
    if self.washDurationWheels ~= 0 then
        self.washDurationWheels = 1 / self.washDurationWheels;
    end

    self.wheelMinimumDirtAmount = 0.6;

    self.washableWheelsDirtyFlag = self:getNextDirtyFlag();

    if savegame ~= nil then
        for i,wheel in pairs(self.wheels) do
            local dirtAmount = getXMLFloat(savegame.xmlFile, string.format("%s.wheelDirt#wheel%d", savegame.key, i));
            if dirtAmount ~= nil then
                wheel.washableDirtAmount = dirtAmount;
            end
        end
    end
end

function TireDirt:postLoad(savegame)
    for i,wheel in pairs(self.wheels) do
        wheel.washableNodes = {};

        local node = wheel.repr;
        if wheel.linkNode ~= wheel.driveNode then
            node = wheel.linkNode;
        else
            if wheel.repr ~= wheel.driveNode then
                node = wheel.driveNode;
            end
        end

        Utils.getNodesByShaderParam(node, "RDT", wheel.washableNodes);
    end

    if self.crawlers ~= nil then
        for _,crawler in pairs(self.crawlers) do
            if crawler.speedRefWheel ~= nil then
                local wheel = crawler.speedRefWheel;
                if crawler.node ~= nil then
                    Utils.getNodesByShaderParam(crawler.node, "RDT", wheel.washableNodes);
                end
                if crawler.rotatingParts ~= nil then
                    for _,rotatingPart in pairs(crawler.rotatingParts) do
                        Utils.getNodesByShaderParam(rotatingPart.node, "RDT", wheel.washableNodes);
                    end
                end
            elseif crawler.speedRefNode ~= nil then
                -- use nearest wheel
                local minDistWheel;
                local minDist = math.huge;

                for _,wheel in pairs(self.wheels) do
                    local x,y,z = localToLocal(crawler.speedRefNode, wheel.driveNode, 0,0,0);
                    local dist = Utils.vector3Length(x,y,z);
                    if dist < minDist then
                        minDist = dist;
                        minDistWheel = wheel;
                    end
                end

                if minDistWheel ~= nil then
                    if crawler.node ~= nil then
                        Utils.getNodesByShaderParam(crawler.node, "RDT", minDistWheel.washableNodes);
                    end
                    if crawler.rotatingParts ~= nil then
                        for _,rotatingPart in pairs(crawler.rotatingParts) do
                            Utils.getNodesByShaderParam(rotatingPart.node, "RDT", minDistWheel.washableNodes);
                        end
                    end
                end
            end
        end
    end

    -- load speedRotatingParts, if they reference a physical wheel
    if self.speedRotatingParts ~= nil then
        for _,speedRotatingPart in pairs(self.speedRotatingParts) do
            if speedRotatingPart.wheel ~= nil then
                local wheel = speedRotatingPart.wheel;

                if speedRotatingPart.repr ~= nil then
                    Utils.getNodesByShaderParam(speedRotatingPart.repr, "RDT", wheel.washableNodes);
                end
                if speedRotatingPart.shaderNode ~= nil then
                    Utils.getNodesByShaderParam(speedRotatingPart.shaderNode, "RDT", wheel.washableNodes);
                end
                if speedRotatingPart.driveNode ~= nil then
                    Utils.getNodesByShaderParam(speedRotatingPart.driveNode, "RDT", wheel.washableNodes);
                end

            end
        end
    end


    --
    for _,wheel in pairs(self.wheels) do
        if wheel.washableDirtAmount ~= nil then
            for _, node in pairs(wheel.washableNodes) do
                local x,_,z,w = getShaderParameter(node, "RDT");
                setShaderParameter(node, "RDT", x, wheel.washableDirtAmount, z, w, false);
            end
            wheel.washableDirtAmountSend = wheel.washableDirtAmount;
        else
            wheel.washableDirtAmount = 0;
            wheel.washableDirtAmountSend = 0;
        end
    end

    for _,wheel in pairs(self.wheels) do
        for _,node in pairs(wheel.washableNodes) do
            self.washableNodes[node] = nil;
        end
    end
end

function TireDirt:getSaveAttributesAndNodes(nodeIdent)
    local attributes = '';
    local nodes = nodeIdent .. "<wheelDirt";
    for i,wheel in pairs(self.wheels) do
        nodes = nodes .. string.format(' wheel%d="%f"', i, wheel.washableDirtAmount);
    end
    nodes = nodes .. "/>";
    return attributes, nodes;
end

function TireDirt:delete()
end

function TireDirt:mouseEvent(posX, posY, isDown, isUp, button)
end

function TireDirt:keyEvent(unicode, sym, modifier, isDown)
end

function TireDirt:readStream(streamId, connection)
    for _,wheel in pairs(self.wheels) do
        local dirtAmount = streamReadUIntN(streamId, TireDirt.sendNumBits) / (2^TireDirt.sendNumBits - 1);
        wheel.washableDirtAmount = dirtAmount;
        for _, node in pairs(wheel.washableNodes) do
            local x,_,z,w = getShaderParameter(node, "RDT");
            setShaderParameter(node, "RDT", x, wheel.washableDirtAmount, z, w, false);
        end
    end
end

function TireDirt:writeStream(streamId, connection)
    for _,wheel in pairs(self.wheels) do
        streamWriteUIntN(streamId, wheel.washableDirtAmount * (2^TireDirt.sendNumBits - 1), TireDirt.sendNumBits);
    end
end

function TireDirt:readUpdateStream(streamId, timestamp, connection)
    if connection:getIsServer() then
        local dirty = streamReadBool(streamId);
        if dirty then
            for _,wheel in pairs(self.wheels) do
                local dirtAmount = streamReadUIntN(streamId, TireDirt.sendNumBits) / (2^TireDirt.sendNumBits - 1);
                if math.abs(wheel.washableDirtAmount - dirtAmount) > TireDirt.wheelMinDirtDelta then
                    wheel.washableDirtAmount = dirtAmount;
                    for _, node in pairs(wheel.washableNodes) do
                        local x,_,z,w = getShaderParameter(node, "RDT");
                        setShaderParameter(node, "RDT", x, wheel.washableDirtAmount, z, w, false);
                    end
                end
            end
        end
    end
end

function TireDirt:writeUpdateStream(streamId, connection, dirtyMask)
    if not connection:getIsServer() then
        if streamWriteBool(streamId, bitAND(dirtyMask, self.washableWheelsDirtyFlag) ~= 0) then
            for _,wheel in pairs(self.wheels) do
                streamWriteUIntN(streamId, wheel.washableDirtAmount * (2^TireDirt.sendNumBits - 1), TireDirt.sendNumBits);
            end
        end
    end
end

function TireDirt:update(dt)
end

function TireDirt:updateTick(dt)
    if not self.isServer then
        return;
    end

    local lastSpeed = self:getLastSpeed();
    local active = self:getIsActive() or self.isActive;

    if lastSpeed > 1 and active then

        local fieldMultiplier = 1;
        if self:getIsOnField() then
            fieldMultiplier = 2;
        end

        local cleaningMultiplier = self:getLastSpeed() / 20;
        local minDirt = 0.5 * self.dirtAmount;

        for _,wheel in pairs(self.wheels) do

            local dirtTarget = math.max(minDirt, wheel.lastColor[4]);
            if wheel.contact == Vehicle.WHEEL_OBJ_CONTACT then
                dirtTarget = minDirt;
            elseif wheel.contact == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT then
                dirtTarget = wheel.washableDirtAmount;
            else
                -- check for grass
                local fruitDesc = FruitUtil.fruitIndexToDesc[FruitUtil.FRUITTYPE_GRASS];
                local ids = g_currentMission.fruits[FruitUtil.FRUITTYPE_GRASS];

                if fruitDesc ~= nil and ids ~= nil then
                    local width = 0.5 * wheel.width;
                    local length = 0.5 * wheel.width;
                    local x0,_,z0 = localToWorld(wheel.node, wheel.positionX + width, wheel.positionY, wheel.positionZ - length);
                    local x1,_,z1 = localToWorld(wheel.node, wheel.positionX - width, wheel.positionY, wheel.positionZ - length);
                    local x2,_,z2 = localToWorld(wheel.node, wheel.positionX + width, wheel.positionY, wheel.positionZ + length);
                    local x, z, widthX, widthZ, heightX, heightZ = Utils.getXZWidthAndHeight(nil, x0,z0, x1,z1, x2,z2);
                    local _, area, _ = getDensityParallelogram(ids.id, x,z, widthX,widthZ, heightX,heightZ, 0, g_currentMission.numFruitStateChannels);
                    if area > 0 then
                        dirtTarget = self.wheelMinimumDirtAmount;
                    end
                end
            end

            if dirtTarget > wheel.washableDirtAmount then
                wheel.washableDirtAmount = math.min(dirtTarget, wheel.washableDirtAmount + (dt*self.dirtDurationWheels*fieldMultiplier));
            elseif dirtTarget < wheel.washableDirtAmount then
                if wheel.washableDirtAmount > self.wheelMinimumDirtAmount then
                    wheel.washableDirtAmount = math.max(self.wheelMinimumDirtAmount, wheel.washableDirtAmount - (dt*self.washDurationWheels*cleaningMultiplier));
                end
            end

            if math.abs(wheel.washableDirtAmountSend - wheel.washableDirtAmount) > TireDirt.wheelMinDirtDelta then
                self:raiseDirtyFlags(self.washableWheelsDirtyFlag);
                for _,node in pairs(wheel.washableNodes) do
                    local x,_,z,w = getShaderParameter(node, "RDT");
                    setShaderParameter(node, "RDT", x, wheel.washableDirtAmount, z, w, false);
                end
            end

        end
    end
end

function TireDirt:draw()
end

function TireDirt:setDirtAmount(superFunc, dirtAmount, force)

    local oldDirtAmount = self.dirtAmount;
    if superFunc ~= nil then
      superFunc(self, dirtAmount, force);
    end

    local dirtDiff = self.dirtAmount - oldDirtAmount;
    if oldDirtAmount == 0 then
        dirtDiff = dirtAmount;
    end

    if dirtDiff < 0 then
        for _,wheel in pairs(self.wheels) do
            wheel.washableDirtAmount = Utils.clamp(wheel.washableDirtAmount + dirtDiff, 0, 1);
            for _,node in pairs(wheel.washableNodes) do
                local x,_,z,w = getShaderParameter(node, "RDT");
                setShaderParameter(node, "RDT", x, wheel.washableDirtAmount, z, w, false);
            end
        end
        self:raiseDirtyFlags(self.washableWheelsDirtyFlag);
    end
end