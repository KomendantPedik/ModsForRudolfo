--
-- TireDirt Registration
--
--
-- @author GIANTS Software
-- @date 15/10/2016
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

RegistrationHelper_FRM02_TD = {};
RegistrationHelper_FRM02_TD.isLoaded = false;

if SpecializationUtil.specializations['tireDirt'] == nil then
    SpecializationUtil.registerSpecialization('tireDirt', 'TireDirt', g_currentModDirectory .. 'TireDirt.lua')
    RegistrationHelper_FRM02_TD.isLoaded = false;
end

function RegistrationHelper_FRM02_TD:loadMap(name)
    if not g_currentMission.registrationHelper_FRM02_TD_isLoaded then
        if not RegistrationHelper_FRM02_TD.isLoaded then
            self:register();
        end
        g_currentMission.registrationHelper_FRM02_TD_isLoaded = true
    else
        print("Error: ForRealModule02_TireDirt has been loaded already!");
    end
end

function RegistrationHelper_FRM02_TD:deleteMap()
    g_currentMission.registrationHelper_FRM02_TD_isLoaded = nil
end

function RegistrationHelper_FRM02_TD:keyEvent(unicode, sym, modifier, isDown)
end

function RegistrationHelper_FRM02_TD:mouseEvent(posX, posY, isDown, isUp, button)
end

function RegistrationHelper_FRM02_TD:update(dt)
end

function RegistrationHelper_FRM02_TD:draw()
end

function RegistrationHelper_FRM02_TD:register()
    for k, vehicle in pairs(VehicleTypeUtil.vehicleTypes) do
        if vehicle ~= nil then
            table.insert(vehicle.specializations, SpecializationUtil.getSpecialization("tireDirt"))
        end
    end
    RegistrationHelper_FRM02_TD.isLoaded = true
end

addModEventListener(RegistrationHelper_FRM02_TD)