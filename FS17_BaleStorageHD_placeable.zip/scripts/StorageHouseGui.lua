--[[

Copyright (C) GtX (Andy), 2017

Interface: 1.5.1.0 b1580

Author: GtX
Date: 20.10.2017

Support: http://ls-modcompany.com

History:

CLOSED BETA-1 @ 20.10.2017
CLOSED BETA-2 @ 02.11.2017 (Added GUI button to allow multiple objects to be spawned without closing menu. Added warning when spawn area is full with vehicle description and image.)

Version: 1.0.0.0 - Release Edition @ 01.12.2017
Version: 1.0.1.0 - Release Edition @ 20.01.2018 (Small change to alignment of some text. Disable fillType scroll when Mod is a single product shed.)

Important:
This script and supporting scripts (StorageHouse.lua & StorageHouseGui.xml) may be included in any mods or maps.
No changes are to be made to any of the scripts or GUI xml without permission from GtX @ http://ls-modcompany.com

NOTES: This lua must be used as part of the StorageHouse.lua.
	   The storageHouseGUI.xml must also be included. All script should be located in the following folder.  [  /scripts   ]

	#####	The following minimum items must be included in your modDesc for the GUI to work error free.   #####

	<l10n>

		<text name="input_StorageHouse_Menu">
			<en>Open Storage Menu</en>
			<de>Speichermenü öffnen</de>
			<fr>Ouvrir le menu de stockage</fr>
			<it>Apri menù deposito</it>
			<es>Abrir menú de almacenamiento</es>
		</text>

		<text name="gui_spawnProtectionHeader">
			<en>Spawn Area Blocked!</en>
			<de>Rückzugsgebiet blockiert!</de>
			<fr>Zone de retraite bloquée!</fr>
			<it>Area di spawn bloccata!</it>
			<es>Area de retirada bloqueada!</es>
		</text>
		
		<text name="gui_spawnProtectionText">
			<en>Please remove %s from %s spawning area.</en>
			<de>Please remove %s from %s spawning area.</de>
			<fr>Supprimez%s de la zone de paiement%s.</fr>
			<it>Rimuovi %s dall'area di spawn della %s.</it>
			<es>Saque %s del área de retirada de %s.</es>
		</text>

	</l10n>

	<inputBindings>
		<input name="StorageHouse_Menu" category="ONFOOT" key1="KEY_r" key2="" device="1" button="BUTTON_11" mouse="" visible="true" />
	</inputBindings>
--]]

StorageHouseGui = {}

local StorageHouseGui_mt = Class(StorageHouseGui, YesNoDialog)

function StorageHouseGui:new(target, custom_mt)
    if custom_mt == nil then
        custom_mt = StorageHouseGui_mt
    end
    local self = YesNoDialog:new(target, custom_mt)

    self.selectedObject = nil
    self.positiveButton = false
	self.negitiveButton = false
	self.okButton = false
	self.numObjects = nil
	self.storeInfo = nil

    return self
end

function StorageHouseGui:onOpen(element)
    StorageHouseGui:superClass().onOpen(self, element)
end

function StorageHouseGui:setInformation(objectInformation, storage, freeSpawnCheck, protection)
	self.objectInformation = objectInformation
	self.storage = storage
	self.freeSpawnCheck = freeSpawnCheck
	self.protection = protection
    self.displayedItem = {}
	self.numObjects = 0
	self.spawnProtectData = nil
	self.storeInfo = nil

    local objectList = {}

    for _,object in pairs(objectInformation) do
		local fillTypeStr = object.objectFillType
		local fillType = FillUtil.fillTypeNameToInt[fillTypeStr]
        local name = object.uiNameId
        table.insert(objectList, name)
        table.insert(self.displayedItem, fillType)
    end
	
	self.spawnNormal:setVisible(true)
	self.spawnBlocked:setVisible(false)

	self.objectSelection:setTexts(objectList)
    self.objectSelection:setState(1, true)
	
	-- Version: 1.0.1.0
	if table.getn(self.displayedItem) <= 1 then		
		self.objectSelection:setDisabled(true)
	else
		self.objectSelection:setDisabled(false)
	end

end

function StorageHouseGui:scrollObjectSelection(state)

	self.storeInfo = nil
	self.numObjects = 0
	self.selectedObject = self.displayedItem[state]
	self.spawnNormal:setVisible(true)
	self.spawnBlocked:setVisible(false)

	local objectName = self.objectInformation[self.selectedObject].uiNameId
	local imageFilename = self.objectInformation[self.selectedObject].uiImageId
	if self.protection ~= nil then
		self.spawnProtectData = self.protection[self.selectedObject].vehicle
	end

	if self.spawnProtectData ~= nil then
		self.storeInfo = StoreItemsUtil.storeItemsByXMLFilename[self.spawnProtectData.configFileName:lower()];
		if self.storeInfo ~= nil then
			imageFilename = self.storeInfo.imageActive
			self.protectHeader:setText(g_i18n:getText "gui_spawnProtectionHeader")
			self.protectText:setText(string.format(g_i18n:getText "gui_spawnProtectionText", self.storeInfo.brand.." "..self.storeInfo.name, objectName))
			self.spawnNormal:setVisible(false)
			self.spawnBlocked:setVisible(true)
		end
	end

	self.dialogImage:setImageFilename(imageFilename)
	self:updateGui()

end

function StorageHouseGui:updateGui()

	self:addButtonOff(false)
	self:removeButtonOff(false)
	self:okButtonOff(false)

	if self.objectInformation ~= nil then
        local objectData = self.objectInformation[self.selectedObject]
		local itemsStored = table.getn(self.storage[self.selectedObject].storedItems)
		local numberOfNodes = self.freeSpawnCheck[self.selectedObject]
		local unitType = g_i18n:getText("unit_liter")
		local objectType = objectData.unitType
		local objectCapacity = 0
		local spawnLimit = nil

        if itemsStored <= 0 then
            self:addButtonOff(true)
			self:removeButtonOff(true)
        end

		if numberOfNodes <= 0 or self.storeInfo ~= nil then
			self.spawnAreaFull:setVisible(true)
			self:addButtonOff(true)
			self:removeButtonOff(true)
		else
			self.spawnAreaFull:setVisible(false)
		end

		if self.numObjects <= 0 then
			self:okButtonOff(true)
			self:removeButtonOff(true)
		end

		if numberOfNodes < itemsStored then
			spawnLimit = numberOfNodes

			if self.numObjects >= numberOfNodes then
				self:addButtonOff(true)
			end
		else
			spawnLimit = itemsStored

			if self.numObjects >= itemsStored then
				self:addButtonOff(true)
			end
		end

		if objectData.objectFillType == "treeSaplings" then
			unitType = "saplings"
		end

		for object, fillLevel in pairs(self.storage[self.selectedObject].storedItems) do
			objectCapacity = fillLevel
		end

		local storageCapacity = self.storage[self.selectedObject].capacity
		local objectsStored = string.format("%d %s", g_i18n:getFluid(Utils.getNoNil(itemsStored,0)), objectType)
		local objectfillLevel = string.format("%d %s", g_i18n:getFluid(Utils.getNoNil(objectCapacity,0)), unitType)
		local maxObjectStorage = string.format("%d %s", g_i18n:getFluid(Utils.getNoNil(storageCapacity,0)), objectType)
		local spawnAreaInfo = string.format("%d  /  %s", g_i18n:getFluid(Utils.getNoNil(self.numObjects,0)), numberOfNodes)

		self.storedObjects:setText(objectsStored)
		self.objectSize:setText(objectfillLevel)
		self.objectMaxStorage:setText(maxObjectStorage)
		self.spawnInfo:setText(spawnAreaInfo)

	end
end

function StorageHouseGui:onClickActivate()
	StorageHouseGui:superClass().onClickActivate(self);

    if not self.okButton then
		self:doCallback(self.selectedObject, self.numObjects)
	else
		return
	end
end

function StorageHouseGui:objectsToSpawn(increase)
	local itemsStored = table.getn(self.storage[self.selectedObject].storedItems)
	local numberOfNodes = self.freeSpawnCheck[self.selectedObject]
	local spawnLimit = nil

	if numberOfNodes < itemsStored then
		spawnLimit = numberOfNodes
	else
		spawnLimit = itemsStored
	end

	if increase then
        self.numObjects = math.min(self.numObjects + 1, spawnLimit)
    else
        self.numObjects = math.max(self.numObjects - 1, 0)
    end

    self:updateGui()
end

function StorageHouseGui:update(dt)
    StorageHouseGui:superClass().update(self, dt)

	if Input.isMouseButtonPressed(Input.MOUSE_BUTTON_WHEEL_UP) then
        self:objectsToSpawn(true)
    elseif Input.isMouseButtonPressed(Input.MOUSE_BUTTON_WHEEL_DOWN) then
        self:objectsToSpawn(false)
    end
end

function StorageHouseGui:doCallback(value, count)
    self:close()	
    if self.callback ~= nil then
        if self.target ~= nil then
            self.callback(self.target, value, count)
        else
            print("ERROR: [StorageHouseGui.lua]  Target is missing.")
        end
    end
end

function StorageHouseGui:loadCallback(callback, target)
    self.callback = callback
    self.target = target
end

function StorageHouseGui:onClickAdd()
	if not self.positiveButton then
		self:objectsToSpawn(true)
	else
		return
	end
end

function StorageHouseGui:onClickRemove()
	if not self.negitiveButton then
		self:objectsToSpawn(false)
	else
		return
	end
end

function StorageHouseGui:onClickOk()
end;

function StorageHouseGui:onClickBack()
	StorageHouseGui:superClass().onClickBack(self)
end

function StorageHouseGui:addButtonOff(argument)
    self.positiveButton = argument
	self.addButton:setDisabled(argument)
end

function StorageHouseGui:removeButtonOff(argument)
    self.negitiveButton = argument
	self.removeButton:setDisabled(argument)
end

function StorageHouseGui:okButtonOff(argument)
    self.okButton = argument
    self.yesButton:setDisabled(argument)
end

function StorageHouseGui:scrollButtonOff(argument)
    self.scrollLeft:setDisabled(argument)
	self.scrollRight:setDisabled(argument)
end