﻿--[[

Copyright (C) GtX (Andy), 2017

Interface: 1.5.1.0 b1580

Author: GtX (LS-Modcompany)
Date: 16.10.2017

Contributors:
I would like to give a big thankyou to the following people for supporting me when I had questions and also allowing me to use parts of their scripts as reference.

Kevink98 (LS-Modcompany)  -  Placeable/GE scripting reference and use, general help.
Rahkiin (Realismus Modding) - read/write Multiplayer help and general suggestions.


Support only at: http://ls-modcompany.com


History:
CLOSED BETA-1 @ 16.10.2017
CLOSED BETA-2 @ 02.11.2017 (Added the ability to spawn from .xml, individual storage amounts can now be set.)
CLOSED BETA-3 @ 26.11.2017 (Script rewrite to allow bales to be stored separate so Seasons bales with reduced sizes will be stored and returned the same way. Also good for Ultima Bales of different sizes.

Version: 1.0.0.0 - @ 01.12.2017  (Release Edition)
Version: 1.0.1.0 - @ 20.01.2018  (Add new Event for object adding/removing to lower data that needs to be synced in Multiplayer, Fix 'FillType Name' in warning message, small adjustment to GUI screen,
								  added option to limit Bale Size, added option to reduce bale detection radius at spawn "1" is recommended but can be reduced if needed for smaller objects,
								  Improvement to Displays and Visibility Nodes to stop unneeded updating of unchanged fillTypes, Fix for UAL delivery in Multiplayer.)
Version: 1.0.2.0 - @ 02.03.2018	 (Fix random Multiplayer error when a large object storage limit is set. Tested a working with up to 500 Objects as recommended,
								  Small optimization change)

Important:
This script and supporting scripts (storageHouseGui.lua & storageHouseGui.xml) may be included in any mods or maps.
No changes are to be made to any of the scripts or GUI xml without permission from GtX @ http://ls-modcompany.com

Please Note:
Some items need to be loaded using an xml. This can be done by adding the 'loadFromXML' attribute and using the xml path instead of the i3d.

--]]

local function get_i18n(name)
	return g_i18n:hasText(name) and g_i18n:getText(name) or name
end

StorageHouse = {}
local ModDir = g_currentModDirectory
StorageHouse_mt = nil

source(Utils.getFilename("scripts/StorageHouseGui.lua", ModDir))

local nBeginn, nEnde = string.find(ModDir,"placeable")

if nBeginn then
	StorageHouse_mt = Class(StorageHouse, Placeable)
else
	StorageHouse.RunAsGE = true
	StorageHouse_mt = Class(StorageHouse, Object)
end

InitObjectClass(StorageHouse, "StorageHouse")

function StorageHouse.onCreate(id)

	local object = StorageHouse:new(g_server ~= nil, g_client ~= nil)

	g_currentMission:addOnCreateLoadedObject(object)
	if object:load(id) then
		g_currentMission:addOnCreateLoadedObjectToSave(object)
        object:register(true)
    else
        object:delete()
    end

end

function StorageHouse:new(isServer, isClient, customMt)

	local mt = customMt
    if mt == nil then
        mt = StorageHouse_mt
    end

	local self = {}
	if StorageHouse.RunAsGE then
		self = Object:new(isServer, isClient, mt)
	else
		self = Placeable:new(isServer, isClient, mt)
		registerObjectClassName(self, "StorageHouse")
	end

	return self

end

function StorageHouse:load(xmlFilename, x,y,z, rx,ry,rz, initRandom)

	if StorageHouse.RunAsGE then
		self.saveId = getUserAttribute(xmlFilename,"saveId")
		if self.saveId == nil then
			self.saveId = "StorageHouse_"..getName(xmlFilename)
		end
	end

	if not self.RunAsGE then
		if not StorageHouse:superClass().load(self, xmlFilename, x,y,z, rx,ry,rz, initRandom) then
			return false
		end
		return true
	else
		self.nodeId = xmlFilename
		if not self:finalizePlacement() then
			return false
		end
	end

	return true

end

function StorageHouse:finalizePlacement(x, y, z, rx, ry, rz, initRandom)

	if not self.RunAsGE then
		StorageHouse:superClass().finalizePlacement(self)
	end

	self.menuKeyCounter = -1

	self.objectStorageName = Utils.getNoNil(get_i18n(getUserAttribute(self.nodeId,"storageName")),get_i18n(getName(self.nodeId)))

	local TriggerMarkers = getUserAttribute(self.nodeId, "triggerMarkers")
	if TriggerMarkers ~= nil then
		self.storageTriggerMarkers = Utils.indexToObject(self.nodeId, TriggerMarkers)
	end

	self.baleStorage = Utils.getNoNil(getUserAttribute(self.nodeId, "isBaleStorage"), false) -- Bales or Pallet storage?

	self.roundBaleStorage = Utils.getNoNil(getUserAttribute(self.nodeId, "roundBaleStorage"), false) --If Bales, then round or square?

	self.objectIsaBale = false
	if self.baleStorage then
		self.objectIsaBale = true

		-- If attributes are not used then any bale size will be accepted.
		self.acceptBaleWidth = tonumber(getUserAttribute(self.nodeId, "onlyBaleWidth")) -- SQUARE / ROUND
		self.acceptBaleHeight = tonumber(getUserAttribute(self.nodeId, "onlyBaleHeight")) -- SQUARE
		self.acceptBaleDiameter = tonumber(getUserAttribute(self.nodeId, "onlyBaleDiameter")) -- SQUARE / ROUND
		self.acceptBaleLength = tonumber(getUserAttribute(self.nodeId, "onlyBaleLength")) -- SQUARE

		if self.roundBaleStorage then
			if self.acceptBaleWidth ~= nil and self.acceptBaleDiameter ~= nil then
				self.limitBaleSize = true
			else
				self.limitBaleSize = false
			end
		else
			if self.acceptBaleWidth ~= nil and self.acceptBaleHeight ~= nil and self.acceptBaleLength ~= nil then
				self.limitBaleSize = true
			else
				self.limitBaleSize = false
			end
		end
	end

	local InputIndex = getUserAttribute(self.nodeId, "inputTriggerIndex")
	local InputTriggerId = Utils.indexToObject(self.nodeId,InputIndex)
	local ObjectData = getUserAttribute(self.nodeId, "objectData")
	local ObjectDataId = Utils.indexToObject(self.nodeId,ObjectData)
	local BuildingSetup = getUserAttribute(self.nodeId, "buildingSetup")
	local BuildingSetupId = Utils.indexToObject(self.nodeId, BuildingSetup)
	local StorageId = getUserAttribute(self.nodeId, "storageCapacity")
	local PlayerIndex = getUserAttribute(self.nodeId, "playerTriggerIndex")
	local PlayerTriggerId = Utils.indexToObject(self.nodeId,PlayerIndex)
	local languageType = getUserAttribute(self.nodeId, "languageNodes")  -- Nodes can be set (en, de, jp, pl, cz, fr, es, ru, it, pt, hu, nl, cs, ct, br, tr, ro, kr) and will be displayed dependent on the users set language.
	local languageTypeId = Utils.indexToObject(self.nodeId,languageType) -- English (en) must be set as a minimum if this function is used.


	if InputTriggerId and InputTriggerId ~= 0 then
		self.objectTriggerId = InputTriggerId
		removeTrigger(self.objectTriggerId)
		addTrigger(self.objectTriggerId , "InputTriggerCallback", self)
	else
		print("WARNING: [ StorageHouse.lua ] Attribute 'inputIndex' is missing at " ..getName(self.nodeId).. ". This must be set")
	end


    if StorageId ~= nil then
		self.storage = {}
        local types = Utils.splitString(" ", StorageId)
		for i=1, #types, 2 do
			local fillType = FillUtil.fillTypeNameToInt[types[i]]
			local capacity = tonumber(types[i+1])
			local storedItems = {}
			self.storage[fillType] = {storedItems=storedItems, capacity=capacity}
			if capacity > 500 then
				print("WARNING: [ StorageHouse.lua ] Exceeding ( 500 ) objects per fillType is not recommended.  Building: " ..getName(self.nodeId).."  FillType: "..types[i].."  Capacity: "..capacity)
			end
		end
	else
		print("WARNING: [ StorageHouse.lua ] 'Storage Attribute' is missing at " ..getName(self.nodeId).. ". This must be set with values in the following format. ( straw 50 dryGrass_windrow 90 )")
    end


	if ObjectDataId and ObjectDataId ~= 0 then
		self.objectData = {}
		local childCount = getNumOfChildren(ObjectDataId)
		for i=1, childCount do
			local objectInfo = getChildAt(ObjectDataId, i-1)

			if getUserAttribute(objectInfo, "fillType") ~= nil then
				local objectFillType = getUserAttribute(objectInfo, "fillType")
				local fillTypeIndex = FillUtil.fillTypeNameToInt[objectFillType]
				local fillTypeDesc = FillUtil.fillTypeIndexToDesc[fillTypeIndex]
				local uiNameId = Utils.getNoNil(get_i18n(getUserAttribute(objectInfo, "objectName")),fillTypeDesc.nameI18N)
				local uiImageId = fillTypeDesc.hudOverlayFilename
				local uiImageIndex = getUserAttribute(objectInfo,"objectImage")
				if uiImageIndex and uiImageIndex ~= 0 then
					uiImageId = Utils.getFilename(uiImageIndex, ModDir)
				end
				local unitType = Utils.getNoNil(get_i18n(getUserAttribute(objectInfo, "UiUnitType")),g_i18n:getText("unit_pieces"))
				local loadFromXML = Utils.getNoNil(getUserAttribute(objectInfo, "loadFromXML"), false)
				if self.baleStorage then
					if loadFromXML then
						print("ERROR: [ StorageHouse.lua ] Loading bales from XML in '" ..self.objectStorageName.. "' (" ..objectFillType.. ") is not possible! Please set 'loadFromXML' attribute to false and set an (i3d) path instead.")
					end
				end
				local objectFilename = getUserAttribute(objectInfo, "objectFilename")
				objectFilename = Utils.getFilename(objectFilename, ModDir)


				self.objectData[fillTypeIndex] = {unitType=unitType, objectFillType=objectFillType, loadFromXML=loadFromXML, uiImageId=uiImageId, uiNameId=uiNameId, objectFilename=objectFilename}
			else
				print("WARNING: [ StorageHouse.lua ] Attribute 'fillType' is missing at " ..getName(objectInfo).. ".")
			end
		end
	else
		print("WARNING: [ StorageHouse.lua ] Attribute 'objectIndex' is missing at " ..getName(self.nodeId).. ". This must be set")
	end


	if BuildingSetupId and BuildingSetupId ~= 0 then
		local childCount = getNumOfChildren(BuildingSetupId)

		local spawnerLoaded = false
		local protectionLoaded = false
		local visNodesLoaded = false
		local objectDisplayLoaded = false
		local fillDisplayLoaded = false
		local spaceDisplayLoaded = false
		local sizeDisplayLoaded = false

		for i=1, childCount do
			local fillTypeChild = getChildAt(BuildingSetupId, i-1)
			local fillTypeName = getUserAttribute(fillTypeChild, "fillType")
			local fillType = FillUtil.fillTypeNameToInt[fillTypeName]

			if self.storage[fillType] ~= nil then
				local Spawners = getUserAttribute(fillTypeChild, "objectSpawners")
				if Spawners ~= nil then
					local SpawnersId = Utils.indexToObject(fillTypeChild, Spawners)
					if not spawnerLoaded then
						self.objectSpawner = {}
						self.spawnerDistance = {}
						spawnerLoaded = true
					end
					self.objectSpawner[fillType] = {}
					local spawnLocations = getNumOfChildren(SpawnersId)
					if spawnLocations > 0 then
						local spawnDistance = Utils.getNoNil(getUserAttribute(SpawnersId, "nodeDistance"), 1)
						if spawnDistance >= 0.1 then
							self.spawnerDistance[fillType] = spawnDistance
						else
							self.spawnerDistance[fillType] = 1
						end
						for sl=1, spawnLocations do
							local node = getChildAt(SpawnersId, sl-1)
							table.insert(self.objectSpawner[fillType], node)
						end
					else
						print ("ERROR: [ StorageHouse.lua ] A minimum of one spawnNode must be set at " ..getName(SpawnersId).. "!")
					end
				else
					print ("ERROR: [ StorageHouse.lua ] Attribute 'objectSpawners' must be set at " ..getName(BuildingSetupId).. "!")
				end

				local SpawnProtect = getUserAttribute(fillTypeChild, "spawnProtection")
				if SpawnProtect ~= nil then
					local SpawnProtectId = Utils.indexToObject(fillTypeChild, SpawnProtect)
					if not protectionLoaded then
						self.spawnProtection = {}
						protectionLoaded = true
					end
					self.spawnProtection[fillType] = {}
					local trigger = SpawnProtectId
					local vehicle = nil
					local inRange = {}
					addTrigger(trigger, "ProtectionTriggerCallback", self)

					self.spawnProtection[fillType] = {trigger=trigger, vehicle=vehicle, inRange=inRange}
				end

				local VisNodes = getUserAttribute(fillTypeChild, "visibilityNodes")
				if VisNodes ~= nil then
					local VisNodesId = Utils.indexToObject(fillTypeChild,VisNodes)
					if not visNodesLoaded then
						self.VisNodes = {}
						visNodesLoaded = true
					end
					self.VisNodes[fillType] = {}
					local numberNodes = getNumOfChildren(VisNodesId)
					if numberNodes > 0 then
						for i=1, numberNodes do
							local visNode = getChildAt(VisNodesId, i-1)
							local rigidBody = getRigidBodyType(visNode)
							setVisibility(visNode, false)
							setRigidBodyType(visNode,"NoRigidBody")
							local node = {}
							node.visNode = visNode
							node.rigidBody = rigidBody
							table.insert(self.VisNodes[fillType], node)
						end
					end
				end

				local DisplayIndex = getUserAttribute(fillTypeChild, "displaysIndex")
				if DisplayIndex ~= nil then

					local DisplayId = Utils.indexToObject(fillTypeChild,DisplayIndex)

					local objectDisplay = getChild(DisplayId,"objectCount")
					if objectDisplay and objectDisplay ~= 0 then
						if not objectDisplayLoaded then
							self.objectDisplay = {}
							objectDisplayLoaded = true
						end
						self.objectDisplay[fillType] = {}
						self.objectDisplay[fillType].node = objectDisplay
						Utils.setNumberShaderByValue(self.objectDisplay[fillType].node, math.floor(table.getn(self.storage[fillType].storedItems)), 0, true)
					end

					local fillDisplay = getChild(DisplayId,"fillLevel")
					if fillDisplay and fillDisplay ~= 0 then
						if not fillDisplayLoaded then
							self.fillDisplay = {}
							fillDisplayLoaded = true
						end
						self.fillDisplay[fillType] = {}
						self.fillDisplay[fillType].node = fillDisplay
						local storedLitres = self:getStoredLitres(fillType)
						Utils.setNumberShaderByValue(self.fillDisplay[fillType].node, math.floor(storedLitres), 0, true)
					end

					local spaceDisplay = getChild(DisplayId,"remainingSpace")
					if spaceDisplay and spaceDisplay ~= 0 then
						if not spaceDisplayLoaded then
							self.spaceDisplay = {}
							spaceDisplayLoaded = true
						end
						self.spaceDisplay[fillType] = {}
						self.spaceDisplay[fillType].node = spaceDisplay
						Utils.setNumberShaderByValue(self.spaceDisplay[fillType].node, math.floor(self.storage[fillType].capacity - table.getn(self.storage[fillType].storedItems)), 0, true)
					end

					local sizeDisplay = getChild(DisplayId,"objectSize")
					if sizeDisplay and sizeDisplay ~= 0 then
						if not sizeDisplayLoaded then
							self.sizeDisplay = {}
							sizeDisplayLoaded = true
						end
						self.sizeDisplay[fillType] = {}
						self.sizeDisplay[fillType].node = sizeDisplay
						local objectCapacity = self:nextObjectCapacity(fillType)
						Utils.setNumberShaderByValue(self.sizeDisplay[fillType].node, math.floor(objectCapacity), 0, true)
					end

					if self.objectDisplay == nil and self.fillDisplay == nil and self.spaceDisplay == nil and self.sizeDisplay == nil then
						print("WARNING: [ StorageHouse.lua ] No Display Type has been set at " ..getName(DisplayId).. ". Please remove 'displayIndex' attribute or set: 'objectCount'  or  'fillLevel'  or  'remainingSpace'  or  'objectSize' ")
					end

				end
			end
		end
	else
		print ("ERROR: [ StorageHouse.lua ] Attribute 'buildingSetup' is missing at " ..getName(self.nodeId).. "This must be set and Attribute 'objectSpawners' must be set inside each fillType{name} Transform Group.")
	end


	if languageTypeId and languageTypeId ~= 0 then
		local languageType = {}
		local langId = getNumOfChildren(languageTypeId)
		for lt=1,langId do
			local language = getName(getChildAt(languageTypeId,lt-1))
			languageType[language] = {}
			languageType[language].node = getChildAt(languageTypeId,lt-1)
			setVisibility(languageType[language].node, false)
		end

		if languageType ~= nil then
			local englishBase = "en"
			if languageType[englishBase] ~= nil then
				if languageType[g_languageShort] ~= nil then
					setVisibility(languageType[g_languageShort].node, true)
				else
					setVisibility(languageType[englishBase].node, true)
				end
			else
				setVisibility(languageTypeId, false)
				print("ERROR: [ StorageHouse.lua ] English(en) node must be set as a backup for all other languages not set as transform groups under the Attribute 'languageNodes'  -  All items hidden!!")
			end
		end
	end

	if PlayerTriggerId and PlayerTriggerId ~= 0 then
		self.playerTrigger = PlayerTriggerId
		addTrigger(self.playerTrigger,"PlayerTriggerCallback",self)
	else
		print("WARNING: [ StorageHouse.lua ] Attribute 'playerTriggerIndex' is missing at " ..self.nodeId.. ". This must be set")
	end

	if self.RunAsGE then
		g_currentMission:addNodeObject(self.nodeId, self)
	end

	self.StorageHouseDirtyFlag = self:getNextDirtyFlag()

	return true

end

function StorageHouse:loadFromAttributesAndNodes(xmlFile, key)
	if not self.RunAsGE and not StorageHouse:superClass().loadFromAttributesAndNodes(self, xmlFile, key, resetVehicles) then
		return false
	end

    local i = 0
    while true do
        local objectKey = string.format(key .. ".savedObjects(%d)", i)
        if not hasXMLProperty(xmlFile, objectKey) then
            break
        end
        local fillTypeStr = getXMLString(xmlFile, objectKey.."#fillType")
        local fillType = FillUtil.fillTypeNameToInt[fillTypeStr]
		local fillLevels = getXMLString(xmlFile, objectKey .. "#fillLevels")
        if fillLevels ~= nil then
			local items = Utils.splitString(" ", fillLevels)
            if self.storage[fillType] ~= nil then
				for f=1,#items do
					if f <= self.storage[fillType].capacity then
						local fillLevel=tonumber(items[f])
						table.insert(self.storage[fillType].storedItems, fillLevel)
					else
						print("INFO: [StorageHouse.lua] Save game has been changed. Number of objects set for "..self.objectStorageName.." exceeds storage capacity. ["..fillTypeStr.."] FillLevel set to "..self.storage[fillType].capacity)
						break
					end
					f = f + 1
				end
			end
        end

        i = i + 1
    end

	self:updateVisNodes()
	self:updateDisplays()

    return true

end

function StorageHouse:getSaveAttributesAndNodes(nodeIdent)
    local attributes = ""
    local nodes = ""

	if not self.RunAsGE then
		attributes, nodes = StorageHouse:superClass().getSaveAttributesAndNodes(self, nodeIdent)
	end

	local n = 0
	for fillType, objects in pairs(self.storage) do
		if n > 0 then
			nodes = nodes.."\n"
		end
		local fillTypeName = FillUtil.fillTypeIntToName[fillType]
		local fillLevels = ""
		if objects.storedItems ~= 0 then
			local j = 0
			for _, level in pairs(objects.storedItems) do
				if j > 0 then
					fillLevels = fillLevels .. " "
				end
				fillLevels = fillLevels .. level
				j = j + 1
			end
			fillLevels = 'fillLevels="'..fillLevels..'"'
		end

		nodes = nodes..nodeIdent..'<savedObjects fillType="'..fillTypeName..'" '..fillLevels..' />'

		n = n + 1
	end

	return attributes, nodes

end

function StorageHouse:deleteMap()
	self:delete()
end

function StorageHouse:delete()
	unregisterObjectClassName(self)
	g_currentMission:removeOnCreateLoadedObjectToSave(self)

	if self.playerTrigger then
		removeTrigger(self.playerTrigger)
	end

	if self.objectTriggerId then
		removeTrigger(self.objectTriggerId)
	end

	if self.spawnProtection ~= nil then
		for fillType, group in pairs(self.spawnProtection) do
			if group.trigger then
				removeTrigger(group.trigger)
			end

		end
	end

	if not self.RunAsGE then
		StorageHouse:superClass().delete(self)
	end

end

function tableLength(table)
    local count = 0

    for _ in pairs(table) do
        count = count + 1
    end

    return count
end

function StorageHouse:readStream(streamId, connection)
	StorageHouse:superClass().readStream(self, streamId, connection)

	self.storage = {}

	local n = streamReadInt16(streamId)
	for i = 1, n do
		local fillTyp = streamReadInt8(streamId)
		local capacity = streamReadInt16(streamId)

		local storedItems = {}
		local m = streamReadInt16(streamId)
		for j = 1, m do
			table.insert(storedItems, streamReadFloat32(streamId))
		end

		self.storage[fillTyp] = {storedItems=storedItems, capacity=capacity}
	end

	self:updateVisNodes()
	self:updateDisplays()

end

function StorageHouse:writeStream(streamId, connection)
	StorageHouse:superClass().writeStream(self, streamId, connection)

	local n = tableLength(self.storage)
	streamWriteInt16(streamId, n)

	for fillTyp, item in pairs(self.storage) do
		streamWriteInt8(streamId, fillTyp)
		streamWriteInt16(streamId, item.capacity)

		local m = table.getn(item.storedItems)
		streamWriteInt16(streamId, m)

		for j = 1, m do
			streamWriteFloat32(streamId, item.storedItems[j])
		end
	end

end

function StorageHouse:readUpdateStream(streamId, timestamp, connection)
    StorageHouse:superClass().readUpdateStream(self, streamId, timestamp, connection)
end

function StorageHouse:writeUpdateStream(streamId, connection, dirtyMask)
    StorageHouse:superClass().writeUpdateStream(self, streamId, connection, dirtyMask)
end

function StorageHouse:update(dt)

	if self.menuKeyCounter > 0 then
		self.menuKeyCounter = self.menuKeyCounter - 1
	end

	if self.playerInTrigger then
		if self.menuKeyCounter <= 0 then
			g_currentMission:addHelpButtonText(get_i18n("input_StorageHouse_Menu"), InputBinding.StorageHouse_Menu)
			if InputBinding.hasEvent(InputBinding.StorageHouse_Menu) then
				if g_storageHouseGui == nil then
					g_storageHouseGui = StorageHouseGui:new()
					g_gui:loadGui(ModDir .. "scripts/StorageHouseGui.xml", "StorageHouseGui", g_storageHouseGui)
				end

				self:onActivateObject()
			end
		end

		if g_currentMission.controlledVehicle ~= nil then
			self.playerInTrigger = false
		end
	end

end

function StorageHouse:updateTick(dt)
	if g_gameSettings ~= nil then
		if self.storageTriggerMarkers ~= nil then
			setVisibility(self.storageTriggerMarkers, g_gameSettings:getValue("showTriggerMarker"))
		end
	end
end

function StorageHouse:updateVisNodes(fillType)

	if self.VisNodes ~= nil then
		if fillType ~= nil then
			local itemsStored = table.getn(self.storage[fillType].storedItems)
			local nodeCount = table.getn(self.VisNodes[fillType])
			local visibleNodes = math.ceil((nodeCount*itemsStored)/self.storage[fillType].capacity)
			for i=1, nodeCount, 1 do
				setVisibility(self.VisNodes[fillType][i].visNode, i <= visibleNodes)
				setRigidBodyType(self.VisNodes[fillType][i].visNode, i <= visibleNodes and self.VisNodes[fillType][i].rigidBody or "NoRigidBody")
			end
		else
			for fType, nodes in pairs(self.VisNodes) do
				local itemsStored = table.getn(self.storage[fType].storedItems)
				local visibleNodes = math.ceil((#nodes*itemsStored)/self.storage[fType].capacity)
				for i=1, #nodes do
					setVisibility(nodes[i].visNode, i <= visibleNodes)
					setRigidBodyType(nodes[i].visNode, i <= visibleNodes and nodes[i].rigidBody or "NoRigidBody")
				end
			end
		end
	end

end

function StorageHouse:updateDisplays(fillType)

	if self.objectDisplay ~= nil then
		if fillType ~= nil then
			Utils.setNumberShaderByValue(self.objectDisplay[fillType].node, math.floor(table.getn(self.storage[fillType].storedItems)), 0, true)
		else
			for typInt,_ in pairs(self.objectDisplay) do
				Utils.setNumberShaderByValue(self.objectDisplay[typInt].node, math.floor(table.getn(self.storage[typInt].storedItems)), 0, true)
			end
		end
	end

	if self.fillDisplay ~= nil then
		if fillType ~= nil then
			local storedLitres = self:getStoredLitres(fillType)
			Utils.setNumberShaderByValue(self.fillDisplay[fillType].node, math.floor(storedLitres), 0, true)
		else
			for typInt,_ in pairs(self.fillDisplay) do
				local storedLitres = self:getStoredLitres(typInt)
				Utils.setNumberShaderByValue(self.fillDisplay[typInt].node, math.floor(storedLitres), 0, true)
			end
		end
	end

	if self.spaceDisplay ~= nil then
		if fillType ~= nil then
			Utils.setNumberShaderByValue(self.spaceDisplay[fillType].node, math.floor(self.storage[fillType].capacity - table.getn(self.storage[fillType].storedItems)), 0, true)
		else
			for typInt,_ in pairs(self.spaceDisplay) do
				Utils.setNumberShaderByValue(self.spaceDisplay[typInt].node, math.floor(self.storage[typInt].capacity - table.getn(self.storage[typInt].storedItems)), 0, true)
			end
		end
	end

	if self.sizeDisplay ~= nil then
		if fillType ~= nil then
			local objectCapacity = self:nextObjectCapacity(fillType)
			Utils.setNumberShaderByValue(self.sizeDisplay[fillType].node, math.floor(objectCapacity), 0, true)
		else
			for typInt,_ in pairs(self.sizeDisplay) do
				local objectCapacity = self:nextObjectCapacity(typInt)
				Utils.setNumberShaderByValue(self.sizeDisplay[typInt].node, math.floor(objectCapacity), 0, true)
			end
		end
	end

end

function StorageHouse:onActivateObject()

	local gui = g_gui:showDialog("StorageHouseGui")
	local freeSpawns = self:numFreeSpawnPlaces()
	local protection = nil
	if self.spawnProtection ~= nil then
		protection = self.spawnProtection
	end

	if gui ~= nil then
		gui.target:setTitle(self:getStationName())
		gui.target:setInformation(self.objectData, self.storage, freeSpawns, protection)
		gui.target:loadCallback(self.callbackSorting, self)
	end

end

function StorageHouse:callbackSorting(itemType, count)

	local availableItems = table.getn(self.storage[itemType].storedItems)

	--NOTE: Delay the time until user can open menu again. This is only in MP and is to allow the server time to sync to all players so the menu data is correct.
	if g_currentMission.missionDynamicInfo.isMultiplayer then
		self.menuKeyCounter = 100
		-- print("Counter Set - "..self.menuKeyCounter)
	end

	if itemType ~= nil and itemType ~= FillUtil.FILLTYPE_UNKNOWN then
		if count ~= 0 then
			if count <= availableItems then
				if g_currentMission:getIsServer() then
					self:spawnItem(itemType, count)
				else
					g_client:getServerConnection():sendEvent( StorageHouseSpawnEvent:new(self, itemType, count) )
				end
			else
				if g_currentMission:getIsServer() then
					self:spawnItem(itemType, availableItems)
				else
					g_client:getServerConnection():sendEvent( StorageHouseSpawnEvent:new(self, itemType, availableItems) )
				end
			end
		end
	end

end

function StorageHouse:PlayerTriggerCallback(triggerId, otherId, onEnter, onLeave, onStay)

	if (g_currentMission.controlPlayer and g_currentMission.player and otherId == g_currentMission.player.rootNode) then
		if (onEnter) then
            self.playerInTrigger = true
        elseif (onLeave) then
            self.playerInTrigger = false
        end
	end

end

function StorageHouse:InputTriggerCallback(triggerId, otherId, onEnter, onLeave, onStay, otherShapeId)
	local object = g_currentMission:getNodeObject(otherShapeId)

	if onEnter and object ~= nil then
		if self.isServer then
			local objectAccepted = false
			local objectSizeAccepted = false

			if self.baleStorage then
				if object.isa ~= nil and object:isa(Bale) then

					if self.limitBaleSize then
						if self.roundBaleStorage then
							local baleWidth = tonumber(getUserAttribute(otherShapeId, "baleWidth"))
							local baleDiameter = tonumber(getUserAttribute(otherShapeId, "baleDiameter"))

							if baleWidth == self.acceptBaleWidth and baleDiameter == self.acceptBaleDiameter then
								objectSizeAccepted = true
							else
								g_currentMission:showBlinkingWarning(string.format(g_i18n:getText "warning_notAcceptedHere", "Size"))
							end
						else
							local baleWidth = tonumber(getUserAttribute(otherShapeId, "baleWidth"))
							local baleHeight = tonumber(getUserAttribute(otherShapeId, "baleHeight"))
							local baleLength = tonumber(getUserAttribute(otherShapeId, "baleLength"))

							if baleWidth == self.acceptBaleWidth and baleHeight == self.acceptBaleHeight and baleLength == self.acceptBaleLength then
								objectSizeAccepted = true
							else
								g_currentMission:showBlinkingWarning(string.format(g_i18n:getText "warning_notAcceptedHere", "Size"))
							end
						end

					else
						objectSizeAccepted = true
					end

					if objectSizeAccepted then
						local isRoundbale = Utils.getNoNil(getUserAttribute(otherShapeId, "isRoundbale"), false)
						if self.roundBaleStorage and isRoundbale then
							objectAccepted = true
						elseif self.roundBaleStorage and not isRoundbale then
							g_currentMission:showBlinkingWarning(string.format(g_i18n:getText "warning_notAcceptedHere", g_i18n:getText "fillType_squareBale"))
						end
						if not self.roundBaleStorage and not isRoundbale then
							objectAccepted = true
						elseif not self.roundBaleStorage and isRoundbale then
							g_currentMission:showBlinkingWarning(string.format(g_i18n:getText "warning_notAcceptedHere", g_i18n:getText "fillType_roundBale"))
						end
					end
				elseif object.isa ~= nil and object:isa(FillablePallet) then
					g_currentMission:showBlinkingWarning(string.format(g_i18n:getText "warning_notAcceptedHere", g_i18n:getText "category_pallets"))
				end
			end

			if not self.baleStorage then
				if object.isa ~= nil and object:isa(FillablePallet) then
					objectAccepted = true
				elseif object ~= nil and object.isa ~= nil and object:isa(Bale) then
					g_currentMission:showBlinkingWarning(g_i18n:getText "warning_baleNotSupported")
				end
			end

			if objectAccepted then
				local haveSpace = false
				local objectFillType = object:getFillType()
				local objectFillLevel = object:getFillLevel()
				local baleHouseSpace = self:getFreeCapacity(objectFillType)
				local fillTypeDesc = FillUtil.fillTypeIndexToDesc[objectFillType]

				if self.objectData[objectFillType] ~= nil then
					if baleHouseSpace > 0 then
						haveSpace = true
					else
						g_currentMission:showBlinkingWarning(string.format(g_i18n:getText "warning_noMoreFreeCapacity", fillTypeDesc.nameI18N))
					end
				else
					g_currentMission:showBlinkingWarning(string.format(g_i18n:getText "warning_notAcceptedHere", fillTypeDesc.nameI18N))
				end

				if haveSpace then
					self:setStoredObjects(objectFillLevel, objectFillType, false)
					object:delete()
				end

			end
		end
    end

end

--NOTE: Like 'TreePlanter.lua pallet search
function StorageHouse:spawnPlaces(itemType)

	local freeSpace = nil
	local group = self.objectSpawner[itemType]
	local setDistance = self.spawnerDistance[itemType]

	for i=1, table.getn(group) do
		local singleNode = group[i]
		local nx, ny, nz = getWorldTranslation(singleNode)
		local itemsToSave = g_currentMission.itemsToSave
		local spaceFree = true

		if itemsToSave then
			for _,item in pairs(itemsToSave) do
				local object = item.item
				if object:isa(self:getStorageType()) then -- Will only look for building 'object type'. Trying to save resources. Players should not put other objects in spawn I do not think. :-)
					local ox, oy, oz = getWorldTranslation(object.nodeId)
					local distance = Utils.vector3Length(nx-ox, ny-oy, nz-oz)

					if distance < setDistance then
						spaceFree = false
					end
				end
			end
		end

		if spaceFree then
			freeSpace = singleNode
			break
		end

	end

	return freeSpace

end

--NOTE: Spawn the correct object.
function StorageHouse:spawnItem(itemType, count)

	for c = 1, count do
		if self.isServer then
			local placeToSpawn = self:spawnPlaces(itemType)
			if placeToSpawn then
				local objectData = self.objectData[itemType]
				local x,y,z = getWorldTranslation(placeToSpawn)
				local rx,ry,rz = getWorldRotation(placeToSpawn)
				local objectCapacity = self:nextObjectCapacity(itemType)
				if self.objectIsaBale then
					local bale = Bale:new(self.isServer, self.isClient)
					bale:load(objectData.objectFilename, x,y,z, rx,ry,rz, objectCapacity)
					bale:register()
					if itemType == FillUtil.FILLTYPE_SILAGE then
						bale:setWrappingState(1)
					end
					bale.fillType = itemType
					self:setStoredObjects(0, itemType, false)
				end

				if not self.objectIsaBale then
					if not objectData.loadFromXML then
						local pallet = FillablePallet:new(self.isServer, self.isClient)
						if pallet:load(objectData.objectFilename, x,y,z, rx,ry,rz) then
							pallet:register()
							pallet:setFillLevel(objectCapacity, false)
							pallet.fillType = itemType
							self:setStoredObjects(0, itemType, false)
						else
							pallet:delete()
						end
					else
						local itemXmlFile = loadXMLFile("tempObjectXML", objectData.objectFilename)
						local itemClassName = Utils.getNoNil(getXMLString(itemXmlFile, "object.className"), "")
						local filenameToLoad = Utils.convertFromNetworkFilename(getXMLString(itemXmlFile, "object.filename"))
						local class = _G[itemClassName]
						if class ~= nil and filenameToLoad ~= nil then
							local item = class:new(self.isServer, self.isClient)
							filenameToLoad = Utils.getFilename(filenameToLoad, g_currentMission.baseDirectory)
							if item:load(filenameToLoad, x,y,z, rx,ry,rz, objectData.objectFilename) then
								item:register()
								item:setFillLevel(objectCapacity, false)
								self:setStoredObjects(0, itemType, false)
							else
								item:delete()
								item = nil
							end
						else
							print("ERROR: [ StorageHouse.lua ] Unknown Class ( "..tostring(itemClassName).." ) in "..tostring(objectData.objectFilename)..". You can not do this. Class must be registered first!")
						end

						if itemXmlFile ~= nil then
							delete(itemXmlFile)
						end

					end
				end
			end
		end
	end
end

function StorageHouse:setStoredObjects(fillLevel, fillType, noEventSend)
	StorageHouseStoreEvent.sendEvent(self, fillLevel, fillType, noEventSend)

    if fillLevel > 0 then
		table.insert(self.storage[fillType].storedItems, fillLevel)
	else
		table.remove(self.storage[fillType].storedItems)
	end

	self:updateVisNodes(fillType)
	self:updateDisplays(fillType)
end

--NOTE: Search only for vehicles in the triggers.
function StorageHouse:ProtectionTriggerCallback(triggerId, otherId, onEnter, onLeave, onStay, otherShapeId)

	if otherShapeId ~= nil and (onEnter or onLeave) then
		for fillType, group in pairs(self.spawnProtection) do
			if group.trigger == triggerId then
				local vehicleInRange = group.inRange

				if onEnter then
					vehicleInRange[otherShapeId] = true
				elseif onLeave then
					vehicleInRange[otherShapeId] = nil
				end
				self:protectionState()
			end
		end
    end

end

function StorageHouse:protectionState()

    for fillType, group in pairs(self.spawnProtection) do

		group.vehicle = nil
		local vehicleInRange = group.inRange

		for vehicleId, inRange in pairs(vehicleInRange) do
			if inRange ~= nil then
				group.vehicle = g_currentMission.nodeToVehicle[vehicleId]
				if group.vehicle ~= nil then
					break
				end
			end
			vehicleInRange[vehicleId] = nil
		end

	end

end

--NOTE: Count all ObjectType spawn areas.
function StorageHouse:numFreeSpawnPlaces()

	local freePlaceCount = {}

	for fillType, group in pairs(self.objectSpawner) do
		local numFreePlaces = 0
		for i=1, table.getn(group) do
			local singleNode = group[i]
			local nx, ny, nz = getWorldTranslation(singleNode)
			local itemsToSave = g_currentMission.itemsToSave
			local spaceFree = true

			if itemsToSave then
				for _,item in pairs(itemsToSave) do
					local object = item.item
					if object:isa(self:getStorageType()) then
						local ox, oy, oz = getWorldTranslation(object.nodeId)
						local distance = Utils.vector3Length(nx-ox, ny-oy, nz-oz)

						if distance < self.spawnerDistance[fillType] then
							spaceFree = false
						end
					end
				end
			end

			if spaceFree then
				numFreePlaces = numFreePlaces + 1
			end

			freePlaceCount[fillType] = numFreePlaces

		end

	end

	return freePlaceCount

end

function StorageHouse:getStationName()
	return self.objectStorageName
end

function StorageHouse:getStorageType()

	if self.baleStorage then
		return Bale
	else
		return FillablePallet
	end

end

function StorageHouse:getStoredLitres(fillType)

    local storedLitres = 0

	if self.storage[fillType] ~= nil then
		for k,v in pairs(self.storage[fillType].storedItems) do
			storedLitres = storedLitres + v
		end
	end

    return storedLitres

end

function StorageHouse:getFreeCapacity(objectType)

    if self.storage[objectType] ~= nil then
        return math.max(self.storage[objectType].capacity - table.getn(self.storage[objectType].storedItems, 0))
    end

    return 0

end

function StorageHouse:nextObjectCapacity(fillType)

	local objectCapacity = 0
	if self.storage[fillType] ~= nil then
		for k,v in pairs(self.storage[fillType].storedItems) do
			objectCapacity = v
		end
	end

    return objectCapacity

end

if StorageHouse.RunAsGE then
	g_onCreateUtil.addOnCreateFunction("StorageHouse", StorageHouse.onCreate)
else
	registerPlaceableType("StorageHouse", StorageHouse)
end

function StorageHouse:mouseEvent(posX, posY, isDown, isUp, button)
end

function StorageHouse:keyEvent(unicode, sym, modifier, isDown)
end

function StorageHouse:draw()
end

-- SPAWNING EVENT
StorageHouseSpawnEvent = {}
StorageHouseSpawnEvent_mt = Class(StorageHouseSpawnEvent, Event)
InitEventClass(StorageHouseSpawnEvent, "StorageHouseSpawnEvent")

function StorageHouseSpawnEvent:emptyNew()
	local self = Event:new(StorageHouseSpawnEvent_mt)
    return self
end

function StorageHouseSpawnEvent:new(object, item, count)
	local self = StorageHouseSpawnEvent:emptyNew()
	self.object = object
	self.item = item
	self.count = count
	return self
end

function StorageHouseSpawnEvent:readStream(streamId, connection)
	local object = readNetworkNodeObject(streamId)
	local item = streamReadInt8(streamId)
	local count = streamReadInt16(streamId)

	if object ~= nil then
		if g_server ~= nil then
			object:spawnItem(item, count)
		end
	end
end

function StorageHouseSpawnEvent:writeStream(streamId, connection)
	writeNetworkNodeObject(streamId, self.object)
	streamWriteInt8(streamId, self.item)
	streamWriteInt16(streamId, self.count)
end

-- ADD/REMOVE OBJECTS EVENT
-- New for 1.0.1.0 (This method will transfer much less data each time a single object is added or removed).
StorageHouseStoreEvent = {}
StorageHouseStoreEvent_mt = Class(StorageHouseStoreEvent, Event)
InitEventClass(StorageHouseStoreEvent, "StorageHouseStoreEvent")

function StorageHouseStoreEvent:emptyNew()
	local self = Event:new(StorageHouseStoreEvent_mt)
    return self
end

function StorageHouseStoreEvent:new(building, fillLevel, fillType)
	local self = StorageHouseStoreEvent:emptyNew()
	self.building = building
	self.fillLevel = fillLevel
	self.fillType = fillType
	return self
end

function StorageHouseStoreEvent:readStream(streamId, connection)
	self.building = readNetworkNodeObject(streamId)
	self.fillLevel = streamReadInt16(streamId)
	self.fillType = streamReadInt8(streamId)
	self:run(connection)
end

function StorageHouseStoreEvent:writeStream(streamId, connection)
	writeNetworkNodeObject(streamId, self.building)
	streamWriteInt16(streamId, self.fillLevel)
	streamWriteInt8(streamId, self.fillType)
end

function StorageHouseStoreEvent:run(connection)
    if self.building ~= nil then
        self.building:setStoredObjects(self.fillLevel, self.fillType, true)
    end

    if not connection:getIsServer() then
        g_server:broadcastEvent(StorageHouseStoreEvent:new(self.building, self.fillLevel, self.fillType), nil, connection, self.building)
    end
end

function StorageHouseStoreEvent.sendEvent(building, fillLevel, fillType, noEventSend)
    if noEventSend == nil or noEventSend == false then
		if g_server ~= nil then
			g_server:broadcastEvent(StorageHouseStoreEvent:new(building, fillLevel, fillType), nil, nil, building)
		else
			g_client:getServerConnection():sendEvent(StorageHouseStoreEvent:new(building, fillLevel, fillType))
		end
    end
end