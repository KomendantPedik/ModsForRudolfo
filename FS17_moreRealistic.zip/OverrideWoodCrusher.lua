﻿--------------------------------------------------------------------------------------------------------------------------------
-- add working power to get different power consumption when actually "crushing" trees
-- load new mr parameters
-- problem encontered in base game = the "splitShape" function may split a tree in 2, but sometimes, if one (or both) of the part to be created are too "small", they are not created => in such case, we lose woodchips 
-- for small trees (especially diameter), it can mean losing as much as 100% of the woodchip (the tree disappears in the woodcrusher, but we can't hear the crushing sound and no woodchip get out of it)
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrLoad = function(self)	

	if not self.mrIsMrVehicle then
		return
	end	

	self.mrWoodCrusherWorkingPowerMin = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#crushingPtoPowerMin"), 0) -- KW
	self.mrWoodCrusherWorkingPowerMax = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#crushingPtoPowerMax"), 0) -- KW
	self.mrWoodCrusherWorkingPowerAmplitude = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#crushingPtoPowerAmplitude"), 0.5) --  0.5 means an amplitude from 50% less up to 50% more (0.5 to 1.5 factor)
	self.mrCrushingPerformanceFactor = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#performanceFactor"), 1) -- performance indice. the greater, the faster the crusher to handle big tree
	self.getConsumedPtoTorque = WoodCrusher.mrGetConsumedPtoTorque
	
	self.mrCrushMinVolume = 0.005 --5 liters
	self.mrCrushMinLen = 0.2 --20 cm	
	self.mrCrushMinDiameter = 0.1 --10 cm  if smaller, crush the whole remaining part (the "splitShape" function will not create a new shape if too small anyway)
	
	self.mrNewSplitShapeAbove = false	
	self.mrNewSplitShapeBelow = false
	
	self.mrWoodCrusherTempFillLevel = 0			
			
	self.mrGetCrushingTime = WoodCrusher.mrGetCrushingTime
	
	
	self.mrWoodCrusherDownForceAreaY = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#downForceAreaY"), 1)
	self.mrWoodCrusherDownForceAreaZ = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#downForceAreaZ"), 1)
	
	self.mrCrushingTimeMin = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#crushMinTime"), 500) --0.5s
	self.mrCrushingTimeMax = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#crushMaxTime"), 8000) --0.5s
	
	if self.mrCrushingTimeMax<=self.mrCrushingTimeMin then
		RealisticUtils.printWarning("WoodCrusher.mrLoad","crushMaxTime must be greater than crushMinTime. MaxTime="..tostring(self.mrCrushingTimeMax) .." - MinTime="..tostring(self.mrCrushingTimeMin), true)
		self.mrCrushingTimeMax = self.mrCrushingTimeMin+100		
	end
	
	self.mrWoodCrusherMoveTriggerTractionForce = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#moveTriggerTractionForce"), 0)
	self.mrWoodCrusherMoveTriggerTractionForcePosition = {Utils.getVectorFromString(Utils.getNoNil(getXMLString(self.xmlFile, "vehicle.moreRealistic.woodCrusher#moveTriggerTractionForcePosition"), "0 0 0"))}
	self.mrWoodCrusherMoveTriggerTractionForceUseDirectionX = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.woodCrusher#moveTriggerTractionForceUseDirectionX"), false) --default = Z direction toward the cutter unit
	self.mrWoodCrusherMoveTriggerTractionForceUseOppositeDirection = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.woodCrusher#moveTriggerTractionForceUseOppositeDirection"), false) --positive direction toward the cutter unit
	self.mrWoodCrusherMoveTriggerTractionForceMaxPullingDistance = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#moveTriggerTractionForceMaxPullingDistance"), 2)
	
	self.mrMaxCrushingTimeForNextCrush = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#maxCrushingTimeForNextCrush"), 500)
	
	self.mrTurnOffTimerMaxTime = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodCrusher#turnOffTimerMaxTime"), 10000) --10s
	
	self.mrWoodCrusherTractionForceNodes = {}
	self.mrWoodCrusherLastPtoRpmFactor = 1
	
	--local node = Utils.indexToObject(self.components, "0>5|6|0")
	--print("test node = " .. tostring(node))
	
	--self:removeFromPhysics()
	--for _,node in pairs(self.woodCrusherMoveColNodes) do
	
		--setIsCompoundChild(node, true)
		--setRotation(node, 0, math.rad(90),0)
         --print("test move col node =" .. tostring(node))
	--end
	--self:addToPhysics()
	
	
end
WoodCrusher.load = Utils.appendedFunction(WoodCrusher.load, WoodCrusher.mrLoad)




--------------------------------------------------------------------------------------------------------------------------------
-- pto torque depends on the working state ("crushing" or not "crushing")
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower
			if self.crushingTime > 0 then
				--self.crushingTime close to self.mrCrushingTimeMin => power close to self.mrWoodCrusherWorkingPowerMin
				--self.crushingTime close to self.mrCrushingTimeMax => power close to self.mrWoodCrusherWorkingPowerMax
				
				if self.crushingTime<=self.mrCrushingTimeMin then
					totalPower = totalPower + self.mrWoodCrusherWorkingPowerMin
				elseif self.crushingTime>=self.mrCrushingTimeMax then
					totalPower = totalPower + self.mrWoodCrusherWorkingPowerMax
				else
					local timeFx = (self.crushingTime-self.mrCrushingTimeMin)/(self.mrCrushingTimeMax-self.mrCrushingTimeMin)
					totalPower = totalPower + RealisticUtils.linearFx(timeFx, self.mrWoodCrusherWorkingPowerMin, self.mrWoodCrusherWorkingPowerMax)					
				end
				
				--20171208 - remove this line - remaining of debug/test ?
				--totalPower = totalPower + self.mrWoodCrusherWorkingPowerMin + (self.mrWoodCrusherWorkingPowerMax-self.mrWoodCrusherWorkingPowerMin)
				
				-- add some random power amplitude
				-- amplitude = mrWoodCrusherWorkingPowerAmplitude => 0.5 means an amplitude from 50% less up to 50% more (0.5 to 1.5 factor)
				if self.mrWoodCrusherWorkingPowerAmplitude>0 then
					totalPower = math.max(0, 1 + self.mrWoodCrusherWorkingPowerAmplitude * (1-2*math.random())) * totalPower;
					--print("total power applied = " .. tostring(totalPower))
				end
			end			
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end

--------------------------------------------------------------------------------------------------------------------------------
-- varying crushing time
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrCrushSplitShape = function(self, superFunc, shape)

	if not self.mrIsMrVehicle then
		return superFunc(self, shape)
	end	

    local splitType = SplitUtil.splitTypes[getSplitType(shape)]
    if splitType ~= nil and splitType.woodChipsPerLiter > 0 then
        local volume = Utils.getNoNil(getVolume(shape), 0)
		--print(tostring(g_currentMission.time) .. " test WoodCrusher crushSplitShape - shape="..tostring(shape) .. " - volume = " .. tostring(1000*volume))
        delete(shape)        
		self.crushingTime = self:mrGetCrushingTime(volume)
        self:onCrushedSplitShape(splitType, volume)
    end
	
end
WoodCrusher.crushSplitShape = Utils.overwrittenFunction(WoodCrusher.crushSplitShape, WoodCrusher.mrCrushSplitShape)


--------------------------------------------------------------------------------------------------------------------------------
-- when running the motor automatically, add the "WheelsUtil.updateWheelsPhysics" so that the engine rpm / torque in use are updated
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrUpdateTick = function(self, superFunc, dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end	

    if self:getIsTurnedOn() then
        if self:getCapacity() <= 0 then
            self.lastLostFillLevel = self:getUnitFillLevel(self.woodCrusher.fillUnitIndex)
			--print("test WoodCrusher.mrUpdateTick - turning off woodcrusher unit ? lastLostFillLevel="..tostring(self.lastLostFillLevel))
            if self.lastLostFillLevel>0 then
                self:setUnitFillLevel(self.woodCrusher.fillUnitIndex, 0, FillUtil.FILLTYPE_WOODCHIPS, true, self.fillVolumeUnloadInfos[self.woodCrusher.unloadInfoIndex])				
            end			
        end
        WoodCrusher.updateTickWoodCrusher(self, dt)
	else		
		self.lastLostFillLevel = 0 --20170906 -- self.lastLostFillLevel is used by "overloading" but not reset when "consumed" ! => we have to reset it each "tick" whatever the situation		
    end
    -- turn on/off automatically
    if self.isServer then
        if g_currentMission.missionInfo.automaticMotorStartEnabled then
            if self.woodCrusherTurnOnAutomatically and self.setIsTurnedOn ~= nil then
                if next(self.woodCrusherMoveTriggerNodes) ~= nil then
					local isTurnedOnAllowed2 = false
					
					--check if attacher vehicle can turn on the crusher (example : car or truck)
					if self.attacherVehicle ~= nil then
						local implement = self.attacherVehicle:getImplementByObject(self)
						if implement ~= nil then
							if implement.jointDescIndex ~= nil then
								if self.attacherVehicle.attacherJoints[implement.jointDescIndex] ~= nil then
									if self.attacherVehicle.attacherJoints[implement.jointDescIndex].canTurnOnImplement then
										isTurnedOnAllowed2 = true
									end
								end
							end
						end
					end
								
								
					local isTurnedOnAllowed = self:getIsTurnedOnAllowed(true)
                    if self.getIsMotorStarted ~= nil then
                        if not self:getIsMotorStarted() then
                            self:startMotor()
                        end						
                    else						
                        if self.attacherVehicle ~= nil and isTurnedOnAllowed2 then
                            if self.attacherVehicle.getIsMotorStarted ~= nil then
                                if not self.attacherVehicle:getIsMotorStarted() then
                                    self.attacherVehicle:startMotor()
                                end
                            end
                        end
                    end;
                    
                    if self.attacherVehicle == nil and self.getIsMotorStarted == nil then
                        isTurnedOnAllowed = false
                    end
					if self.attacherVehicle ~= nil and isTurnedOnAllowed2==false then
						isTurnedOnAllowed = false
					end					
					
                    if not self.isControlled and not self:getIsTurnedOn() and isTurnedOnAllowed then
                        self:setIsTurnedOn(true)
                    end
                    self.turnOffTimer = self.mrTurnOffTimerMaxTime
                else -- no more wood to crush
                    if self:getIsTurnedOn() then
                        if self.turnOffTimer == nil then
                            self.turnOffTimer = self.mrTurnOffTimerMaxTime
                        end
						--print(tostring(g_currentMission.time) .. " - turnOffTimer=" .. tostring(self.turnOffTimer))
						self.turnOffTimer = self.turnOffTimer - dt
                        --if self.getIsMotorStarted ~= nil then
                        --    self.motor:updateMotorRpm(dt)
                        --end
                        if self.turnOffTimer < 0 then
                            local rootAttacherVehicle = self:getRootAttacherVehicle()
                            if not rootAttacherVehicle.isControlled then
                                if self.getIsMotorStarted ~= nil then
                                    if self:getIsMotorStarted() then
                                        self:stopMotor()
                                    end	
								elseif self.attacherVehicle ~= nil then --MR : stop the tractor too is needed
									if self.attacherVehicle.getIsMotorStarted ~= nil then
										if self.attacherVehicle:getIsMotorStarted() then
											self.attacherVehicle:stopMotor()
										end	
									end
                                end
                                self:setIsTurnedOn(false)
                            end
                        end
                    end
                end
            end
        end --automatic motor start enabled
		
		--MR : update the engine rpm/torque in use
		-- update ptoRpmFactor
		self.mrWoodCrusherLastPtoRpmFactor = 1
		if self.getIsMotorStarted ~= nil then -- wood crusher with own motor to drive the crusher
			if self:getIsMotorStarted() then
				if self.motor~=nil and self.powerConsumer~=nil and self.powerConsumer.ptoRpm>0 then
					self.mrWoodCrusherLastPtoRpmFactor = self.motor.lastRealMotorRpm/(self.motor.ptoMotorRpmRatio*self.powerConsumer.ptoRpm)
				end				
				if not self.isControlled then
					WheelsUtil.updateWheelsPhysics(self, dt, 0, 0, true, self.requiredDriveMode)					
				end
			end
		elseif self.attacherVehicle ~= nil then			
			if self.attacherVehicle.mrIsMrVehicle and self.attacherVehicle.getIsMotorStarted ~= nil then -- wood crusher requiring the tractot motor to work
				if self.attacherVehicle:getIsMotorStarted() then
					if self.attacherVehicle.motor~=nil and self.powerConsumer~=nil and self.powerConsumer.ptoRpm>0 then
						self.mrWoodCrusherLastPtoRpmFactor = self.attacherVehicle.motor.lastRealMotorRpm/(self.attacherVehicle.motor.ptoMotorRpmRatio*self.powerConsumer.ptoRpm)
					end	
					if not self.attacherVehicle.isControlled then
						WheelsUtil.updateWheelsPhysics(self.attacherVehicle, dt, 0, 0, true, self.attacherVehicle.requiredDriveMode)
					end
				end
			end
		end			
		
    end --self.isServer
end
WoodCrusher.updateTick = Utils.overwrittenFunction(WoodCrusher.updateTick, WoodCrusher.mrUpdateTick)






--------------------------------------------------------------------------------------------------------------------------------
-- 1. manage the tempFillLevel to "pipe" unloading flow
-- 2. trying not to lose woodchips with smaller trees
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrUpdateTickWoodCrusher = function(self, superFunc, dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end		

    if self.isServer then
	
		--add some crushingTime if the motor driving the crusher is struggling (not enough rpm)		
		if self.crushingTime>0 and self.mrWoodCrusherLastPtoRpmFactor<0.95 then
			self.crushingTime = self.crushingTime + 2*(1-self.mrWoodCrusherLastPtoRpmFactor)*dt
			--print(tostring(g_currentMission.time) .. " - woodcrusher ptoRpmFactor=" .. tostring(self.mrWoodCrusherLastPtoRpmFactor) .." - new crushing time = " .. tostring(self.crushingTime))
		end
	
		--print(tostring(g_currentMission.time) .. " - temp fill level = " .. tostring(self.mrWoodCrusherTempFillLevel))
		if self.mrWoodCrusherTempFillLevel>0 then
			self.turnOffTimer = self.mrTurnOffTimerMaxTime --wait for the woodcrusher to be empty (of woodchips) before shutting it down
			--empty the temporary fill level
			local litersToUnload = self.mrWoodCrusherTempFillLevel
			if self.crushingTime>100 then				
				local prevTempFillLevel = self.mrWoodCrusherTempFillLevel
				self.mrWoodCrusherTempFillLevel = math.max(0, self.mrWoodCrusherTempFillLevel - self.mrWoodCrusherTempFillLevel * dt / self.crushingTime)
				litersToUnload = prevTempFillLevel-self.mrWoodCrusherTempFillLevel
			else
				self.mrWoodCrusherTempFillLevel = 0
			end	
			local newFillLevel = self:getUnitFillLevel(self.woodCrusher.fillUnitIndex) + litersToUnload
			self:setFillLevel(newFillLevel, FillUtil.FILLTYPE_WOODCHIPS, false, self.fillVolumeLoadInfos[self.woodCrusher.loadInfoIndex])
			--print("test WoodCrusher.mrUpdateTickWoodCrusher - setting new fill level="..tostring(newFillLevel))
		end
	
        if self.woodCrusherCutNode ~= nil and next(self.woodCrusherMoveTriggerNodes) ~= nil and self.crushingTime<self.mrMaxCrushingTimeForNextCrush and self.mrWoodCrusherLastPtoRpmFactor>0.95 then
            local x,y,z = getWorldTranslation(self.woodCrusherCutNode);
            local nx,ny,nz = localDirectionToWorld(self.woodCrusherCutNode, 1,0,0)
            local yx,yy,yz = localDirectionToWorld(self.woodCrusherCutNode, 0,1,0)
            for id in pairs(self.woodCrusherMoveTriggerNodes) do
			
				if not entityExists(id) then
					self.woodCrusherMoveTriggerNodes[id] = nil
				else
			
					local crushShape = false
					
					local shapeVolume = Utils.getNoNil(getVolume(id), 0) -- m3
					
					if shapeVolume<=self.mrCrushMinVolume then --if volume too small, crush the "shape"
						crushShape = true
						--print(tostring(g_currentMission.time) .. " - shapeVolume too small. " .. tostring(shapeVolume))
					else
						--lenAbove = part we want to crush
						--lenBelow = remaining part
						local lenBelow, lenAbove = getSplitShapePlaneExtents(id, x,y,z, nx,ny,nz)
						if lenAbove ~= nil and lenBelow ~= nil then			
							--print(tostring(g_currentMission.time) .. " test plane extents - id="..tostring(id) .." - lenBelow="..tostring(lenBelow) .. " - lenAbove="..tostring(lenAbove) .." - total len="..tostring(lenBelow+lenAbove))
							if lenBelow<=self.mrCrushMinLen then --if remaining shape is too small, crush the "shape"
								--print(tostring(g_currentMission.time) .. " - lenBelow too small. " .. tostring(lenBelow))
								crushShape = true
							elseif lenAbove>self.mrCrushMinLen then
							
								--check size (diameter)
								local length, width, height, numConvexes, numAttachments = getSplitShapeStats(id)
								
								--print(tostring(g_currentMission.time) .. " - sizeX="..tostring(sizeX) .. " - sizeY="..tostring(sizeY).." - sizeZ="..tostring(sizeZ))
								
								local minDiameter = math.min(width, height)
								if minDiameter<=self.mrCrushMinDiameter then
									--print(tostring(g_currentMission.time) .. " - minDiameter too small. " .. tostring(minDiameter))
									crushShape = true
								else							
									--check if sufficient volume/len for the part to crush
									
									--if lenAboveEstimatedVolume>=self.mrCrushMinVolume then
									if lenAbove>self.mrCrushMinLen then
									
										local lenAboveEstimatedVolume = lenAbove*3.1416*(0.5*minDiameter)^2
									
										--print(tostring(g_currentMission.time) .. " - test splitShape before - id="..tostring(id).." - entityexists=" .. tostring(entityExists(id)) .. " - estimated crushed shape volume=" .. tostring(lenAboveEstimatedVolume) .. " -current shape volume="..tostring(shapeVolume*1000))
										
										self.mrNewSplitShapeAbove = false
										self.mrNewSplitShapeBelow = false
										local splitType = SplitUtil.splitTypes[getSplitType(id)]
										
										local minY = splitShape(id, x,y,z, nx,ny,nz, yx,yy,yz, self.woodCrusherCutSizeY, self.woodCrusherCutSizeZ, "woodCrusherSplitShapeCallback", self);
										--local minY = splitShape(id, x,y,z, nx,ny,nz, yx,yy,yz, 0.4, 0.4, "woodCrusherSplitShapeCallback", self);
										
										if minY ~= nil then --minY ~=nil means the tree has been split in 2, and so, the current tree id is not valid anymore (2 new entities created at split time)
										
											--splitShape callbacks are not asynchronous
											--and so, since the callback has access to the "self", we can check how much volume we "removed"
											local lostVolume = 0
											
											if self.mrNewSplitShapeAbove==false and self.mrNewSplitShapeBelow==false then
												--the splitShape deleted the shape but didn't create any new shape
												lostVolume = shapeVolume
											elseif self.mrNewSplitShapeAbove==false then
												--the splitShape deleted the shape but only created a new shape for the remaining part (the shape that should be crushed was not created)
												lostVolume = lenAboveEstimatedVolume
											elseif self.mrNewSplitShapeBelow==false then
												--the splitShape deleted the shape but only created a new shape for the part to crushed (the remaining shape is not present anymore)
												lostVolume = shapeVolume-lenAboveEstimatedVolume
											end
											
											if lostVolume>0 then			
												--print("test - lostVolume=" .. tostring(lostVolume) .. " - self="..tostring(self))
												self.crushingTime = self:mrGetCrushingTime(lostVolume)
												if splitType~=nil then
													self:onCrushedSplitShape(splitType, lostVolume)
												end
											end
											
											
											--print(tostring(g_currentMission.time) .. " - test splitShape after - id="..tostring(id).." - entityexists=" .. tostring(entityExists(id)) .. " - lostVolume="..tostring(lostVolume*1000))
										
											self.woodCrusherMoveTriggerNodes[id] = nil;
										end
									end
								end
							end
						end
					end
					
					if crushShape then
						self.woodCrusherMoveTriggerNodes[id] = nil;
						self:crushSplitShape(id);
					end
				end
				
            end
        end
    end
    if self.crushingTime > 0 then
        self.crushingTime = self.crushingTime - dt
        self.workFadeTime = math.min(self.maxWorkFadeTime, self.workFadeTime + dt)
    else
        self.workFadeTime = math.max(0, self.workFadeTime - dt)
    end;
    if self.isClient and self.woodCrusherParticleSystems ~= nil then
        for _,ps in pairs(self.woodCrusherParticleSystems) do
            ParticleUtil.setEmittingState(ps, self.crushingTime > 0 )
        end
    end;
    if self.isClient then
        if self.sampleWoodCrusherWork ~= nil then
            local volume = self.sampleWoodCrusherWork.volume * self.workFadeTime/self.maxWorkFadeTime
            SoundUtil.setSampleVolume(self.sampleWoodCrusherWork, volume)
        end
        if self.getIsActiveForSound ~= nil and self:getIsActiveForSound() then
            if not SoundUtil.isSamplePlaying(self.sampleWoodCrusherStart, 1.8*dt) then --and not self.use3DSound then
                SoundUtil.playSample(self.sampleWoodCrusherIdle, 0, 0, nil)
                SoundUtil.playSample(self.sampleWoodCrusherWork, 0, 0, nil)
            end
            SoundUtil.stop3DSample(self.sampleWoodCrusherIdle)
            SoundUtil.stop3DSample(self.sampleWoodCrusherWork)
        else
            SoundUtil.play3DSample(self.sampleWoodCrusherIdle)
            SoundUtil.play3DSample(self.sampleWoodCrusherWork)
        end
    end
	
end
WoodCrusher.updateTickWoodCrusher = Utils.overwrittenFunction(WoodCrusher.updateTickWoodCrusher, WoodCrusher.mrUpdateTickWoodCrusher)

--------------------------------------------------------------------------------------------------------------------------------
-- we want to know if there was 2 shapes created after "splitShape" or only one (or even nothing left)
-- purpose = not losing woodchips with smaller trees
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.woodCrusherSplitShapeCallback = function(self, shape, isBelow, isAbove, minY, maxY, minZ, maxZ)
	if not isBelow then
        self.woodCrusherCrushNodes[shape] = shape;
    end		
	if isAbove then
		self.mrNewSplitShapeAbove = true
	end
	if isBelow then
		self.mrNewSplitShapeBelow = true
	end	
	--print(tostring(g_currentMission.time) .. " - test callback - shape="..tostring(shape) .." - isBelow="..tostring(isBelow).." - isAbove="..tostring(isAbove).. " -miny="..tostring(minY).." - maxY="..tostring(maxY).." -minz="..tostring(minZ).." - maxz="..tostring(maxZ) )   
	
end


--------------------------------------------------------------------------------------------------------------------------------
-- varying crush time to refrain the crusher from crushing a whole tree in a few seconds
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrGetCrushingTime = function(self, volume)
	local crushTime = Utils.clamp(volume * 1000 * 500 / self.mrCrushingPerformanceFactor, self.mrCrushingTimeMin, self.mrCrushingTimeMax)	
	crushTime = math.max(self.crushingTime, crushTime)
	--print("test - crushTime = " .. tostring(crushTime))
	return crushTime
end

--------------------------------------------------------------------------------------------------------------------------------
-- make use of a "temp fill level" to flatten the woodchip projection
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrOnCrushedSplitShape = function(self, superFunc, splitType, volume)    
	if not self.mrIsMrVehicle then
		return superFunc(self, splitType, volume)
	end	
	self.mrWoodCrusherTempFillLevel = self.mrWoodCrusherTempFillLevel + volume*1000*splitType.woodChipsPerLiter
end
WoodCrusher.onCrushedSplitShape = Utils.overwrittenFunction(WoodCrusher.onCrushedSplitShape, WoodCrusher.mrOnCrushedSplitShape)


--------------------------------------------------------------------------------------------------------------------------------
-- modified downforce
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrUpdateWoodCrusher = function(self, superFunc, dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end
    
	if self.isServer then
	
		--crush the shape "marked" to be crushed
        for node in pairs(self.woodCrusherCrushNodes) do
            self:crushSplitShape(node)
            self.woodCrusherCrushNodes[node] = nil
            self.woodCrusherMoveTriggerNodes[node] = nil
        end
		
		--remove the unecessary tractionForceNodes		
		for id in pairs(self.mrWoodCrusherTractionForceNodes) do
            if self.woodCrusherMoveTriggerNodes[id]==nil then
				self.mrWoodCrusherTractionForceNodes[id] = nil
			end
        end
        
		
        local maxTreeSizeY = 0
		
		
        for id in pairs(self.woodCrusherMoveTriggerNodes) do
			--remove all shapes that do not exist anymore (split by a hand chainsaw, for example)
            if not entityExists(id) then
                self.woodCrusherMoveTriggerNodes[id] = nil
				self.mrWoodCrusherTractionForceNodes[id] = nil
            else 
				--apply additionnal traction force if required
				--only if the cutter can actually cut a new piece of wood (if already busy, no force applied)
				
				if self.mrWoodCrusherMoveTriggerTractionForce>0 and self.crushingTime<(self.mrMaxCrushingTimeForNextCrush+200) then
				
					if Vehicle.debugRendering then
						--draw center point of shape id
						local cx, cy, cz = getCenterOfMass(id)
						local dx,dy,dz = localToWorld(id, cx, cy, cz)
						local dx2,dy2,dz2 = localToWorld(id, cx, cy+1, cz)
						drawDebugLine(dx,dy,dz, 0,1,0, dx2,dy2,dz2, 0, 0.5, 0.5)						
					end	
					
					local vx,vy,vz = getLinearVelocity(id)
                    local lvx,_,_ = worldDirectionToLocal(self.woodCrusherCutNode, vx,vy,vz) -- woodCrusherCutNode has always its x direction toward the cutter
					if lvx < self.woodCrusherMoveVelocityZ then	
					
						local mass = getMass(id)
						if mass~=nil then
					
							--check if a woodCrusherTractionForceNodes exist, otherwise, create a new one
							if self.mrWoodCrusherTractionForceNodes[id]==nil then
								WoodCrusher.mrCreateTractionForceNode(self, id)
							end
							
							if self.mrWoodCrusherTractionForceNodes[id]~=nil then
							
								local localPosX = self.mrWoodCrusherMoveTriggerTractionForcePosition[1]
								local localPosY = self.mrWoodCrusherMoveTriggerTractionForcePosition[2]
								local localPosZ = self.mrWoodCrusherMoveTriggerTractionForcePosition[3]	
								
								--position of the application point in the main component coordinate system
								local wx1, wy1, wz1 = localToWorld(self.components[1].node, localPosX, localPosY, localPosZ)
								local wx2, wy2, wz2 = localToWorld(id, self.mrWoodCrusherTractionForceNodes[id].forcePositionX, self.mrWoodCrusherTractionForceNodes[id].forcePositionY, self.mrWoodCrusherTractionForceNodes[id].forcePositionZ)
								
								
								--distance between tractionForce position and force application position on the tree log
								local distance = Utils.vector3Length(wx1-wx2, wy1-wy2, wz1-wz2)
								
								local fDirX, fDirY, fDirZ
								if distance>0.2 then --min 20 cm
									fDirX = (wx1-wx2)/distance
									fDirY = (wy1-wy2)/distance
									fDirZ = (wz1-wz2)/distance
								else
									local direction = 1
									if self.mrWoodCrusherMoveTriggerTractionForceUseOppositeDirection then
										direction = -1
									end
									if self.mrWoodCrusherMoveTriggerTractionForceUseDirectionX then
										fDirX, fDirY, fDirZ = localDirectionToWorld(self.components[1].node, direction,0,0)
									else
										fDirX, fDirY, fDirZ = localDirectionToWorld(self.components[1].node, 0,0,direction)
									end
								end
								
								local tractionForce = self.mrWoodCrusherMoveTriggerTractionForce
								if self.woodCrusherMoveVelocityZ>0 then
									tractionForce = tractionForce * math.abs((self.woodCrusherMoveVelocityZ-lvx)/self.woodCrusherMoveVelocityZ)
								end						
								tractionForce = math.min(tractionForce, mass*9.81)								
								addForce(id, tractionForce*fDirX, tractionForce*fDirY, tractionForce*fDirZ, wx2, wy2, wz2, false)
								
								if Vehicle.debugRendering then
									--display the applied force
									local mtX, mtY, mtZ = localToWorld(id, self.mrWoodCrusherTractionForceNodes[id].forcePositionX, self.mrWoodCrusherTractionForceNodes[id].forcePositionY, self.mrWoodCrusherTractionForceNodes[id].forcePositionZ)
									drawDebugLine(wx2, wy2, wz2, 1,0,0, wx2+tractionForce*fDirX, wy2+tractionForce*fDirY, wz2+tractionForce*fDirY, 1,0,1)
								end
							end -- self.mrWoodCrusherTractionForceNodes[id]==nil
						end -- mass is nil						
					end --lvx already sufficient
				end
				
				
				--apply a down force from the main drum if required
                if self.woodCrusherDownForceNode ~= nil then				
				
                    local x,y,z = getWorldTranslation(self.woodCrusherDownForceNode);
                    local nx,ny,nz = localDirectionToWorld(self.woodCrusherDownForceNode, 1,0,0)
                    local yx,yy,yz = localDirectionToWorld(self.woodCrusherDownForceNode, 0,1,0)
					--local minY,maxY, minZ,maxZ = testSplitShape(id, x,y,z, nx,ny,nz, yx,yy,yz, self.woodCrusherCutSizeY, self.woodCrusherCutSizeZ);
                    local minY,maxY, minZ,maxZ = testSplitShape(id, x,y,z, nx,ny,nz, yx,yy,yz, self.mrWoodCrusherDownForceAreaY, self.mrWoodCrusherDownForceAreaZ)
					
                    if minY ~= nil then
                        local cx,cy,cz = localToWorld(self.woodCrusherDownForceNode, 0, (minY+maxY)*0.5, (minZ+maxZ)*0.5);
						--local cx,cy,cz = localToWorld(self.woodCrusherDownForceNode, 0, 0, (minZ+maxZ)*0.5)
                        --local downX,downY,downZ = localDirectionToWorld(self.woodCrusherDownForceNode, 0,-self.woodCrusherDownForce,0);
						
						--limit the down force to the mass of the tree to avoid small trees being projected
						local mass = getMass(id)
						local downForce = self.woodCrusherDownForce
						if mass~=nil then
							downForce = math.min(downForce, mass*9.81)
						end
						
						--scale the force function of the minY value => the closer to the "floor", the smaller the force applied
						downForce = downForce * math.min(1, math.max(0, minY))
						
						local downX,downY,downZ = localDirectionToWorld(self.woodCrusherDownForceNode, 0,-downForce,0)
						addForce(id, downX, downY, downZ, cx,cy,cz, false)
                        if self.woodCrusherMainDrumRefNode ~= nil then
                            maxTreeSizeY = math.max(maxTreeSizeY, maxY)
                        end;
                    end					
					
                end
            end
        end
		
		--move the main drum depending on the max "shape" size being crushed
        if self.woodCrusherMainDrumRefNode ~= nil then
			local x,y,z = getTranslation(self.woodCrusherMainDrumRefNode)
			local targetY = 0
            if maxTreeSizeY > 0 then
                local a,b,c = localToWorld(self.woodCrusherDownForceNode, 0, maxTreeSizeY, 0)
                _, targetY, _ = worldToLocal(getParent(self.woodCrusherMainDrumRefNode), a,b,c)
            end;
            if targetY > y then
                y = math.min(y + 0.0003*dt, targetY)
            else
                y = math.max(y - 0.0003*dt, targetY)
            end
            setTranslation(self.woodCrusherMainDrumRefNode, x,y,z)
        end
		
		
    end
end
WoodCrusher.updateWoodCrusher = Utils.overwrittenFunction(WoodCrusher.updateWoodCrusher, WoodCrusher.mrUpdateWoodCrusher)


--------------------------------------------------------------------------------------------------------------------------------
-- fill the woodCrusherTractionForceNodes corresponding to the shapeId 
--(we want to determine the best "ends" of the log to apply the traction force to
--------------------------------------------------------------------------------------------------------------------------------
WoodCrusher.mrCreateTractionForceNode = function(self, shapeId)
	
	--test splitShape at several location, starting from the woodCrusherDownForceNode 
	local x,y,z = getWorldTranslation(self.woodCrusherDownForceNode)
	local nx,ny,nz = localDirectionToWorld(self.woodCrusherDownForceNode, 1,0,0)
	local yx,yy,yz = localDirectionToWorld(self.woodCrusherDownForceNode, 0,1,0)	
	local minY,maxY, minZ,maxZ = testSplitShape(shapeId, x,y,z, nx,ny,nz, yx,yy,yz, self.mrWoodCrusherDownForceAreaY, self.mrWoodCrusherDownForceAreaZ)
	
	local cx,cy,cz
	if minY ~= nil then
		cx,cy,cz = localToLocal(self.woodCrusherDownForceNode, shapeId, 0, (minY+maxY)*0.5, (minZ+maxZ)*0.5)
	else
		local offset = 0.25
		while true do
			local x,y,z = localToWorld(self.woodCrusherDownForceNode, -offset, 0, 0)
			local minY,maxY, minZ,maxZ = testSplitShape(shapeId, x,y,z, nx,ny,nz, yx,yy,yz, self.mrWoodCrusherDownForceAreaY, self.mrWoodCrusherDownForceAreaZ)
			if minY ~= nil then
				cx,cy,cz = localToLocal(self.woodCrusherDownForceNode, shapeId, -offset, minY, (minZ+maxZ)*0.5)
				break
			end
			offset = offset + 0.25
			if offset>self.mrWoodCrusherMoveTriggerTractionForceMaxPullingDistance then
				break
			end
		end
	end
	
	if cx~=nil then
		self.mrWoodCrusherTractionForceNodes[shapeId] = {}
		self.mrWoodCrusherTractionForceNodes[shapeId].forcePositionX = cx
		self.mrWoodCrusherTractionForceNodes[shapeId].forcePositionY = cy
		self.mrWoodCrusherTractionForceNodes[shapeId].forcePositionZ = cz
	end
	
end