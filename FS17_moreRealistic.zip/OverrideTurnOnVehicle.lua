﻿--************************************************************************************************************************************************************
-- similar to powerConsumer for turnedOn vehicle without powerconsumer specialization (example : Holmer terra Felis)
TurnOnVehicle.mrPostLoad = function(self)	

	if not self.mrIsMrVehicle then
		return;			
	end;	
	--if self.powerConsumer==nil then 20180316 - override powerConsumer if present. Required for the Ropa Maus (ropa DLC) to work
		self.turnOnVehicle.mrNeededPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.turnOnVehicle#neededPtoPower"), 0);
		self.turnOnVehicle.mrNeededPtoRpm = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.turnOnVehicle#ptoRpm"), 540);
		self.turnOnVehicle.mrAdditionalPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.turnOnVehicle#additionalPtoPower"), 0);
		self.turnOnVehicle.mrAdditionalPtoPowerTrigger = getXMLString(self.xmlFile, "vehicle.moreRealistic.turnOnVehicle#additionalPtoPowerTrigger");
		if self.turnOnVehicle.mrNeededPtoPower + self.turnOnVehicle.mrAdditionalPtoPower>0 then			
			self.getConsumedPtoTorque = TurnOnVehicle.mrGetConsumedPtoTorque;
			self.getPtoRpm = TurnOnVehicle.mrGetPtoRpm;
		end;		
	--end;
	
end;
TurnOnVehicle.postLoad = Utils.appendedFunction(TurnOnVehicle.postLoad, TurnOnVehicle.mrPostLoad)

--************************************************************************************************************************************************************
-- return neededPtoPower when self is turnedOn
TurnOnVehicle.mrGetConsumedPtoTorque = function(self)

	local power = 0;
	
	if self:getIsTurnedOn() then        		
		power =  self.turnOnVehicle.mrNeededPtoPower;       
    end;
	
	--additional power
	if self.turnOnVehicle.mrAdditionalPtoPower>0 then
		--check condition
		if self.turnOnVehicle.mrAdditionalPtoPowerTrigger~=nil then
			if self.turnOnVehicle.mrAdditionalPtoPowerTrigger=="overload" then -- example = Holmer Terra Felis (missing PowerConsumer spec)
				if self.overloading~=nil and self.overloading.didOverload then
					power = power + self.turnOnVehicle.mrAdditionalPtoPower;
				end;
			end;
		end;
	end;

    if power>0 then
        local rpm = self.turnOnVehicle.mrNeededPtoRpm;
        if rpm > 1 then			
            return power / (rpm*math.pi/30);
        end;
    end;
	
    return 0;
end


--************************************************************************************************************************************************************
-- return self.turnOnVehicle.mrNeededPtoRpm
TurnOnVehicle.mrGetPtoRpm = function(self)
    if self:getIsTurnedOn() then
        return self.turnOnVehicle.mrNeededPtoRpm;
    end
    return 0;
end