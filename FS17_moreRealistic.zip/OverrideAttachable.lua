﻿
--************************************************************************************************************************************************************	
----20171207 - we want to keep a trace of the "forced" value
Attachable.mrLoad = function(self, savegame)
	
	if not self.mrIsMrVehicle then
		return;
	end;

	self.mrAttachableBrakeForced = true; --when loading the game, we want the brakes applied
	self.mrAttachableNeedInitBrakes = true;
	
	--20171218 - at init time, self.brakeForce should not be 0, otherwise, the implement can move freely before the "setWheelShapeProps" is called for the first time (it seems there is a not documented script that already calls the function with the "self.brakeForce" value)
	self.mrBrakeForceGen = self.brakeForce;
	self.brakeForce = 100;
	
end
Attachable.load = Utils.appendedFunction(Attachable.load, Attachable.mrLoad);


--************************************************************************************************************************************************************	
--move the update of the wheelshape to the "postupdate" function so that it has the lastest values
--manage the "mrRotCopyAttacherVehicle"
Attachable.mrUpdate = function(self, superFunc, dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt);
	end;
	
	if self:getIsActive() then
		if self.updateSteeringAxleAngle then
			local baseVehicle = self:getSteeringAxleBaseVehicle()
			if baseVehicle ~= nil and (self.movingDirection >= 0 or self.steeringAxleUpdateBackwards) then	
				if self:getLastSpeed()>self.steeringAxleAngleScaleEnd then
					self.steeringAxleTargetAngle = 0;
				else
					local yRot = Utils.getYRotationBetweenNodes(self.steeringAxleNode, baseVehicle.steeringAxleNode);
					
					
					
					--we want to know if the attachable is attached to the front or the rear of the baseVehicle
					local _,_,dirZ = localToLocal(self.attacherJoint.node, baseVehicle.steeringAxleNode, 0, 0, 0)					
					if dirZ>0 then
						if yRot > 0 then
							yRot = yRot - 3.14;
						else
							yRot = yRot + 3.14;
						end;
					end
					
					--[[
					local _,_,dirZ = localDirectionToLocal(baseVehicle.steeringAxleNode, self.steeringAxleNode, 0, 0, 1)
					if dirZ<0 then
						if yRot > 0 then
							yRot = yRot - 3.14;
						else
							yRot = yRot + 3.14;
						end;
					end--]]
					--print("test getYRotationBetweenNodes - yRot= " .. tostring(yRot))
					
					--if math.abs(yRot) > 1.57 then
					--[[
					if math.abs(yRot) > 2.356 then -- allow more than 90° angle between trailer and tractor (example : semi trailer)
						if yRot > 0 then
							yRot = yRot - 3.14;
						else
							yRot = yRot + 3.14;
						end;
					end;--]]
					local startSpeed = self.steeringAxleAngleScaleStart;
					local endSpeed = self.steeringAxleAngleScaleEnd;
					local scale = Utils.clamp(1 + (self:getLastSpeed()-startSpeed)/(startSpeed-endSpeed),0, 1);
					self.steeringAxleTargetAngle = yRot*scale;
				end
			else--if self:getLastSpeed() > 0.2 then
				self.steeringAxleTargetAngle = 0;
			end

			--20170708 - only update if "forced steering axle" (==self.steeringAxleUpdateBackwards) or enough speed
			if self.steeringAxleUpdateBackwards or self:getLastSpeed() > 0.5 then --getLastSpeed = km/h				
				local dir = Utils.sign(self.steeringAxleTargetAngle-self.steeringAxleAngle);
				if dir == 1 then
					self.steeringAxleAngle = math.min(self.steeringAxleAngle + dir*dt*self.steeringAxleAngleSpeed, self.steeringAxleTargetAngle);
				else
					self.steeringAxleAngle = math.max(self.steeringAxleAngle + dir*dt*self.steeringAxleAngleSpeed, self.steeringAxleTargetAngle);
				end
			end
		end
				
	end
	
end
Attachable.update = Utils.overwrittenFunction(Attachable.update, Attachable.mrUpdate);


--************************************************************************************************************************************************************	
--correct brakeForce function of wheel radius
Attachable.postUpdate = function(self, dt)
	
	--if self.mrIsMrVehicle and self:getIsActive() then
	if self.mrIsMrVehicle and (self.mrAttachableNeedInitBrakes or self:getIsActive()) then
		if self.firstTimeRun and self.updateWheels and self.isServer and self.isAddedToPhysics then		
			--print(tostring(g_currentMission.time) .. " postUpdate for : " .. self.configFileName .. " - debugTime=" .. tostring(self.debugTime));
			--Attachable.mrBrakeWheels(self, self.brakeForce*self.brakePedal, false);		
			--20171207 - keep the "forced" value
			Attachable.mrBrakeWheels(self, self.brakeForce*self.brakePedal, self.mrAttachableBrakeForced);
		end
		
		--if not self.debugTime then self.debugTime = 0 end;
		--self.debugTime = self.debugTime + dt;
		
	end

end



--************************************************************************************************************************************************************	
--call "mrBrakeWheels"
Attachable.mrOnBrake = function(self, superFunc, brakePedal, forced)
	
	if not self.mrIsMrVehicle then
		return superFunc(self, brakePedal, forced);
	end;
	
	--20171207 - keep the "forced" value
	--forced = forced or self.attachTime==0;
	self.mrAttachableBrakeForced = forced;
	
	--print(tostring(g_currentMission.time) .. " onbrake for "..self.configFileName .. " - brakePedal="..tostring(brakePedal) .. " - forced="..tostring(forced).. " - debugTime=" .. tostring(self.debugTime));

	--do not brake for the first 2 seconds after attaching, to allow balancing of the difference between the attacher joints
	--20170121 not recommended when loading a game. Indeed, the trailer/tractor set can be parked in a slope and so, if the trailer does not brake when loaded, the tractor + trailer set can roll down the slope during 2s	
	--if self.attachTime==0 or self.attachTime+2000 < g_currentMission.time or forced then
	if self.attachTime+2000 < g_currentMission.time or forced then
		self.brakePedal = brakePedal;		
		--print(tostring(g_currentMission.time) .. " onbrake for "..self.configFileName .. " - brakePedal="..tostring(brakePedal) .. " - forced="..tostring(forced).. " - isAddedToPhysics=" .. tostring(self.isAddedToPhysics));
		
		if self.isServer and self.isAddedToPhysics and forced then --20170315 - only call mrBrakeWheels	if "forced==true" (otherwise, this is the "Attachable.mrUpdate" function that takes care of that
			Attachable.mrBrakeWheels(self, self.brakeForce*brakePedal, forced);
		end
	end
	
	for _,implement in pairs(self.attachedImplements) do
		if implement.object ~= nil then
			implement.object:onBrake(brakePedal, forced);
		end
	end
	
end
Attachable.onBrake = Utils.overwrittenFunction(Attachable.onBrake, Attachable.mrOnBrake);

--************************************************************************************************************************************************************	
--call "mrBrakeWheels"
Attachable.mrOnReleaseBrake = function(self, superFunc)
	
	if not self.mrIsMrVehicle then
		return superFunc(self);
	end;
	
	--print(tostring(g_currentMission.time) .. " onreleasebrake for "..self.configFileName.. " - debugTime=" .. tostring(self.debugTime));

	self.brakePedal = 0;
	--20170315 - no need to call the "mrBrakeWheels" function since the "Attachable.mrUpdate" already takes care of that
	--if self.isServer and self.isAddedToPhysics then
		--for _,wheel in pairs(self.wheels) do			
			--setWheelShapeProps(wheel.node, wheel.wheelShape, 0, 0, wheel.steeringAngle, wheel.rotationDamping);
			--Attachable.mrBrakeWheels(self, 0, false);
		--end
	--end
	for _,implement in pairs(self.attachedImplements) do
		if implement.object ~= nil then
			implement.object:onReleaseBrake();
		end
	end
end
Attachable.onReleaseBrake = Utils.overwrittenFunction(Attachable.onReleaseBrake, Attachable.mrOnReleaseBrake);


--************************************************************************************************************************************************************	
--correct brakeForce function of wheel radius
Attachable.mrBrakeWheels = function(self, brakeForce, forced)

	--20170812 - do not run this function when the vehicle is not attached and is both a drivable and an attachable vehicle
	--example : JENZ BA725D woodCrusher
	if self.isDrivable and self.attacherVehicle==nil then
		return
	end
	
	if self.mrAttachableNeedInitBrakes then
		--reset brakeForce to its genuine value		
		self.brakeForce = self.mrBrakeForceGen;
		brakeForce = self.mrBrakeForceGen;
		self.mrAttachableNeedInitBrakes = false; -- brakes have been engaged once
	end	
	
	--forced == true means the tool is detached from the tractor and so, "mrBrakeWheels" will not be called again until the tool is attached to a tractor
	
	--print(tostring(g_currentMission.time) .. " - mrBrakeWheels - brakeForce=" .. tostring(brakeForce) .. " - forced=" .. tostring(forced) .. " for : " .. self.configFileName);

	for _,wheel in pairs(self.wheels) do --need to brake when detaching an implement otherwise, since the implement is not active anymore, the "update" function does not brake the wheels.		
	
		if wheel.mrNotAWheel then
			local steeringAngle = 0
			if wheel.mrAttachableRotationRootVehicleDependantValue~=0 then
				local rootVehicle = self:getRootAttacherVehicle()
				if rootVehicle.rotatedTime~=nil then
					local rotPercent = 0
					if rootVehicle.rotatedTime~=0 then
						if rootVehicle.maxRotTime>0 then
							rotPercent = rootVehicle.rotatedTime/rootVehicle.maxRotTime
						end
					elseif  rootVehicle.minRotTime~=0 then
						rotPercent = rootVehicle.rotatedTime/rootVehicle.minRotTime
					end
					steeringAngle = rotPercent * wheel.mrAttachableRotationRootVehicleDependantValue
				end
			end
			if forced then
				setWheelShapeProps(wheel.node, wheel.wheelShape, 0, 0.1, steeringAngle, 0.1 * wheel.mass);--wheel.rotationDamping);
			else
				--print(" mrNotAWheel - forced = false, hasGroundContact="..tostring(wheel.hasGroundContact).." - mass="..tostring(wheel.mass) .. " - damping="..tostring(wheel.rotationDamping));
				local damping = wheel.rotationDamping;
				if not wheel.hasGroundContact and damping==0 then					
					damping = 0.03 * wheel.mass;							
					--print("------------- new damping="..tostring(damping));
				end
				setWheelShapeProps(wheel.node, wheel.wheelShape, 0, 0, steeringAngle, damping);--wheel.rotationDamping);	
			end
		else
	
			local rotDamping = wheel.rotationDamping;			
			local finalBrakeForce = brakeForce*wheel.brakeFactor*wheel.radius*1.5 --20170522 - "boost" brakeforce, necessary to keep something right since we change the "lateral/longitudinal" system by adding a custom lateral force in V0.2.XX
			
			--print("test finalbrakeForce = " .. tostring(finalBrakeForce));
			
			if finalBrakeForce>0 then			
				--20170308 - limit brake force according to weight on the wheel
				--finalBrakeForce = Utils.clamp(1.1*wheel.mrLastTireLoad*wheel.radius/math.max(1, wheel.mrLastFrictionFx)^0.5, 0.1*finalBrakeForce, finalBrakeForce);
				if not forced then
					--finalBrakeForce = Utils.clamp(1.1*wheel.mrLastTireLoad*wheel.radius/Utils.clamp(wheel.mrLastFrictionFx, 1, 1.6), 0.1*finalBrakeForce, finalBrakeForce);	
					
					--20170621 - "remove" the mrAdditionnalFrictionFx to keep a realistic braking distance
					finalBrakeForce = Utils.clamp(0.75*wheel.mrLastTireLoad*wheel.radius/wheel.mrAdditionnalFrictionFx, 0.1*finalBrakeForce, finalBrakeForce);	--20170524 - no more "mrLastFrictionFx"
					
					--20170906 - check the "incline"
					
				end
			else -- final brake force == 0
				--print("test 2 - finalBrakeForce==0 but hasGroundContact="..tostring(wheel.hasGroundContact) .. " - forced="..tostring(forced));
				if forced then --implement detached from the tractor, adding some "rolling resistance" to fake wheels like cultivator rollbars or weeder tines ?
					--20170305 - add damping to wheels to avoid "infinite" rolling of the attachable when detached (useful for "attachable" with all the weight on wheels that are not braked)						
					finalBrakeForce = 0.2*wheel.radius*math.sqrt(wheel.spring);					
					--print("test - rotdamping - wheel mass="..tostring(wheel.mass) .. " - finalBrakeForce=" .. tostring(finalBrakeForce));
				elseif not wheel.hasGroundContact and rotDamping==0 then
					rotDamping = 0.03 * wheel.mass; --20170215 - takes into account wheel mass (same time to reach 0 rotSpeed whatever the mass of the wheel)					
				end		
			end
			
			
			
			--simulate rolling resistance at still
			--[[ 2017 01 10 no need since we are using the small steeringAngle to stabilize lateral slip of wheels
			if finalBrakeForce==0 then
				local wheelGroundSpd = math.abs(wheel.mrLastWheelSpeed*wheel.radius);
				if wheelGroundSpd<0.2 then --0.2 = 0.72kph
					--finalBrakeForce = wheel.mrLastTireLoad * wheel.mrCurrentRollingResistance*wheel.radius*math.min(1, 2-10*wheelGroundSpd);
					rotDamping = rotDamping + 1*wheel.mrCurrentRollingResistance*math.min(1, 1-5*wheelGroundSpd)/wheel.radius;
				end
				
			--else
				--"remove" the mrWheelsFrictionFactor benefit from the braking force
				--finalBrakeForce = finalBrakeForce*wheel.brakeFactor*wheel.radius / self.mrWheelsFrictionFactor;
			end
			--]]
			
			--when running at relatively high speed, if all wheels are aligned (tractor and trailer), the lateral slip should be 0, but in such a case, the lateral force would be 0 too (like driving on ice)
			--and so, the base game engine uses a value of 0.35 or -0.35 when the lateral slip should be 0
			--this is a major problem since if the slip becomes 0.01, it can keep going from 0.01 to 0.35 which means poor lateral friction/great lateral friction.
			--when the trailer is featured with 4 wheels or more, this can (and will) cause (especially visible with high load and high speed) the trailer to rotate against its y axis, making the tractor backward axle sustaining a great lateral force (if the tractor is too light, it will slip laterally on its backward axle)
			local steeringAngle = wheel.steeringAngle;
			--[[if wheel.steeringAxleScale==0 and steeringAngle==0 and not wheel.mrNotAWheel then		
				if wheel.positionX>0 then				
					steeringAngle = 0;--0.03;				
				else				
					steeringAngle = 0;---0.03;				
				end
			end--]]
			if steeringAngle==0 then
				steeringAngle = wheel.mrStabilizingSteeringAngle;
			end					
						
			--print("test 3 - finalBrakeForce=" ..tostring(finalBrakeForce));
			setWheelShapeProps(wheel.node, wheel.wheelShape, 0, finalBrakeForce, steeringAngle, rotDamping);
			
		end
		
	end
end



--MR : fix bug with upperRotationOffset not "zero" for trailer/semitrailer
Attachable.mrLoadInputAttacherJoint = function(self, superFunc1, superFunc, xmlFile, key, inputAttacherJoint, index)	

	local result = superFunc1(self, superFunc, xmlFile, key, inputAttacherJoint, index);

	if result==true then
		--print("test - mr vehicle = " .. tostring(self.mrIsMrVehicle) .. " - hard attch=" .. tostring(inputAttacherJoint.hardAttach));
		if self.mrIsMrVehicle and not inputAttacherJoint.hardAttach then
			--we want default value for inputAttacherJoint.upperRotationOffset = 0 for joint_type = trailer, trailerlow or semitrailer			
			if inputAttacherJoint.jointType == AttacherJoints.JOINTTYPE_TRAILER or inputAttacherJoint.jointType == AttacherJoints.JOINTTYPE_TRAILERLOW  or inputAttacherJoint.jointType == AttacherJoints.JOINTTYPE_SEMITRAILER then
				inputAttacherJoint.upperRotationOffset = math.rad(Utils.getNoNil(getXMLFloat(xmlFile, key .. "#upperRotationOffset"), 0));
			end			
		end
	end
	
	return result;
	
end
Attachable.loadInputAttacherJoint = Utils.overwrittenFunction(Attachable.loadInputAttacherJoint, Attachable.mrLoadInputAttacherJoint);



