﻿
PowerConsumer.MR_CUTIVATOR_DRAFT_REDUCED_FACTOR = 0.7 -- takes into account the fact there are more rolling resistance on already worked ground





--************************************************************************************************************************************************************	
--MR : load the forceNodeCOM parameter if present
PowerConsumer.mrLoadPowerSetup = function(self, xmlFile)

	--20170907 - with "MR", neededPtoPower = pto power needed to start (launch) the tool
	--but there is also a "noLoadPtoPower" value to replace the old neededPtoPower function
	self.powerConsumer.mrNoLoadPtoPower = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer#mrNoLoadPtoPower"), self.powerConsumer.neededPtoPower); -- in kW at ptoRpm
	
	--20171217 - specific force increasing "slope"
	-- example : gessner Single row planter => if we keep the 1kph max force "curve", when starting to move, the small "press" wheel is rotating backward ! (the "component" is too light to handle such a high force)
	self.powerConsumer.mrSpeedForMaxForce = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer#mrSpeedForMaxForce"), 1.1); -- kph
	self.powerConsumer.mrSpeedForMaxForce = self.powerConsumer.mrSpeedForMaxForce/3.6; -- meters per second
	
	--apply the force directly to the attacherVehicle (tractor) instead of the implement component (forceNode)
	--can be useful for "light" implement with high force (only for "fully mounted implement)
	--Example : gessner Single row planter
	self.powerConsumer.mrApplyForceToAttacherVehicle = Utils.getNoNil(getXMLBool(xmlFile, "vehicle.powerConsumer#mrApplyForceToAttacherVehicle"), false); -- kph
	
	if self.powerConsumer.forceNode then
		local x, y, z = Utils.getVectorFromString(getXMLString(xmlFile, "vehicle.powerConsumer#forceNodeCOM"));
		if x == nil or y == nil or z == nil then
			x,y,z = getCenterOfMass(self.powerConsumer.forceNode);		
		end
		self.powerConsumer.forceNodeCOM = {};
		self.powerConsumer.forceNodeCOM.x = x;
		self.powerConsumer.forceNodeCOM.y = y;
		self.powerConsumer.forceNodeCOM.z = z;	
		
		self.powerConsumer.mrExistingForcePerLoadedTon = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer#mrExistingForcePerLoadedTon"), 0);
		
		local workingWidthAnimationName = getXMLString(xmlFile, "vehicle.powerConsumer.mrWorkingWidthAnimation#animName");
		if workingWidthAnimationName then
			self.powerConsumer.mrWorkingWidthAnimation = {};
			self.powerConsumer.mrWorkingWidthAnimation.animName = workingWidthAnimationName;
			self.powerConsumer.mrWorkingWidthAnimation.startForceFactor = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer.mrWorkingWidthAnimation#startForceFactor"),1);
			self.powerConsumer.mrWorkingWidthAnimation.endForceFactor = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer.mrWorkingWidthAnimation#endForceFactor"),1);
		end
		
	end;
	
	--loading extended PTO power settings	
	local basePower = getXMLFloat(xmlFile, "vehicle.powerConsumer.mrWorkingPtoPower#basePower");
	if basePower~=nil and basePower>0 then
		self.powerConsumer.mrWorkingPtoPower = {};
		self.powerConsumer.mrWorkingPtoPower.basePower = basePower;
		self.powerConsumer.mrWorkingPtoPower.speedFactor = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer.mrWorkingPtoPower#speedFactor"),0);
		self.powerConsumer.mrWorkingPtoPower.speedFactorStartingSpeed = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer.mrWorkingPtoPower#speedFactorStartingSpeed"),0);
		self.powerConsumer.mrWorkingPtoPower.lastWorkingPtoPower = 0;
	end
	
	--loading mrLimitedPowerWhenAnotherCultivator
	local limitForceFactor = getXMLFloat(xmlFile, "vehicle.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator#limitForceFactor");
	local limitPtoTorqueFactor = getXMLFloat(xmlFile, "vehicle.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator#limitPtoTorqueFactor");
	if limitForceFactor~=nil or limitPtoTorqueFactor~=nil then
		self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator = {};
		self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.limitForceFactor = limitForceFactor;
		self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.limitPtoTorqueFactor = limitPtoTorqueFactor;
		self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.cultivatorPresent = false;
	end
	
	--20171201 - example case = Krone Premos from Straw Addon
	--loading fillingDependantTool => watch the filling speed of the tank to limit the tool speed and update the PTO power consumed
	local ptoKwConsumedPerTonPerHour = getXMLFloat(xmlFile, "vehicle.moreRealistic.fillingDependantTool#ptoKwConsumedPerTonPerHour");
	local maxLitersPerHour = getXMLFloat(xmlFile, "vehicle.moreRealistic.fillingDependantTool#maxLitersPerHour");
	if ptoKwConsumedPerTonPerHour~=nil or maxLitersPerHour~=nil then		
		self.powerConsumer.mrFillingDependantTool = {};
		self.powerConsumer.mrFillingDependantTool.ptoKwConsumedPerTonPerHour = ptoKwConsumedPerTonPerHour;
		self.powerConsumer.mrFillingDependantTool.maxLitersPerHour = maxLitersPerHour;
		self.powerConsumer.mrFillingDependantTool.fillUnitIndex = Utils.getNoNil(getXMLInt(self.xmlFile, "vehicle.moreRealistic.fillingDependantTool#fillUnitIndex"), 1);
		self.powerConsumer.mrFillingDependantTool.lastTime = 0;
		self.powerConsumer.mrFillingDependantTool.lastFillLevel = 0;	
		self.powerConsumer.mrFillingDependantTool.currentAvgFillingSpeed = 0;
		self.powerConsumer.mrFillingDependantTool.lastPower = 0;
		self.powerConsumer.mrFillingDependantTool.lastTonsPerHour = 0;
	end
	
	--self.powerConsumer.mrLastForceApplied = 0;
	self.mrAreaDependantPtoPower = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer#areaDependantPtoPower"), 0);
	self.powerConsumer.mrLoweredMaxForce = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer#loweredMaxForce"), 0); -- example : grimme SE260
	self.powerConsumer.mrSprayingForceFactor = Utils.getNoNil(getXMLFloat(xmlFile, "vehicle.powerConsumer#mrSprayingForceFactor"), 1); -- example : zunhammer zunidisc
	
	self.powerConsumer.mrCurrentSprayingForceFactor = 1;
	--self.mrAvgCutterArea = 0;
	self.powerConsumer.mrPtoPowerActive = false;
	
	--20180117 - draftForceFactor, modified by the map (mrGameplay mod)
	self.powerConsumer.mrSoilDraftForceFx = Utils.getNoNil(g_currentMission.mrGameplaySoilDraftForceFactor, 1);


end
PowerConsumer.loadPowerSetup = Utils.appendedFunction(PowerConsumer.loadPowerSetup, PowerConsumer.mrLoadPowerSetup);



--************************************************************************************************************************************************************	
--MR : a little more force as the speed increase to help tractor stabilize speed and better reflect reality
PowerConsumer.mrUpdate = function(self, superFunc, dt)
	
	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end;	
	
	if not self.isServer then
		return;
	end
	
	--20171201 - add debug info of "mrFillingDependantTool"
	if Vehicle.debugRendering then		
		if self:getIsActiveForInput() then	
			if self.powerConsumer.mrFillingDependantTool~=nil then		
				local basePower = 0;
				local dependantPower = 0;				
				if self.powerConsumer.mrPtoPowerActive then
					basePower = self.powerConsumer.mrNoLoadPtoPower;
					dependantPower = self.powerConsumer.mrFillingDependantTool.lastPower;
				end;
				local total = basePower + dependantPower;
				str = string.format("PTO power=> base=%.0f KW dependant=%.0f KW tonsPerHour=%.1f", basePower, dependantPower, self.powerConsumer.mrFillingDependantTool.lastTonsPerHour);
				renderText(0.6, 0.79, getCorrectTextSize(0.02), str);
			end;
		end;
	end;
	

	if not (self.powerConsumer.forceNode ~= nil and (0<self.powerConsumer.maxForce or 0<self.powerConsumer.mrLoweredMaxForce)) then
		return
	end
	
	if not self:getIsActive() then
		return
	end
	
	--reset linearDamping
	setLinearDamping(self.powerConsumer.forceNode, 0)		
	local multiplier = self:getPowerMultiplier()
	
	if multiplier==0 then
		return
	end			
	
	local force = 0
	local maxForce = self.powerConsumer.maxForce
	if self:isLowered(false) then
		maxForce = maxForce + self.powerConsumer.mrLoweredMaxForce
	end
	
	--20180117 - takes into accoutn draftForce factor depending o nthe ground type (map dependant, modified by mr gameplay)
	maxForce = maxForce * self.powerConsumer.mrSoilDraftForceFx
	
	--20170603 - take into account mrSprayingForceFactor
	-- can reduce max force to 0
	if self.sprayer~=nil then
		if self.isSprayerSpeedLimitActive and self.sprayer.mrHasSpray then
			self.powerConsumer.mrCurrentSprayingForceFactor = self.powerConsumer.mrSprayingForceFactor	
		else
			--zunhammer zunidisc = we want to avoid applying the max powerconsumer force when raising the zunidisc from the zunhammer tanker
			if self.powerConsumer.mrCurrentSprayingForceFactor>1 then
				self.powerConsumer.mrCurrentSprayingForceFactor = math.max(1, self.powerConsumer.mrCurrentSprayingForceFactor - dt/5000)
			else
				self.powerConsumer.mrCurrentSprayingForceFactor = math.min(1, self.powerConsumer.mrCurrentSprayingForceFactor + dt/5000)
			end
			
		end
		
		maxForce = maxForce * self.powerConsumer.mrCurrentSprayingForceFactor
	end
	
	if maxForce<=0 then
		return
	end				
			
	if Vehicle.debugRendering then
		self.mrDebugPowerConsumerLastForce = 0;
	end						
					
	local spd = self.lastSpeedReal*1000;
	if self.attacherVehicle and spd<2 then -- 2 = 7.2kph
		spd = math.min(spd, self.attacherVehicle.lastSpeedReal*1000)
	end
					
	--20170807 - taking into account "mrLimitedPowerWhenCombinedWithCultivator"
	if self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator then				
		if self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.cultivatorPresent then
			if self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.limitForceFactor~=nil then
				maxForce = maxForce * self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.limitForceFactor
			end
		end
	end
				

	--apply some damping at very low speed to compensate the 'lack of force' (we can't apply maxforce right at the beginning, otherwise, the implement could pull the tractor backward)
	local fnMass = getMass(self.powerConsumer.forceNode)
	local fnDampingFx = math.max(0, 1-3.33*spd) -- no more damping at 0.3m/s (1.08kph)
	local damping = 0
	if fnMass>0 then
		damping = math.min(0.5, 0.1*fnDampingFx*maxForce/fnMass)					
		setLinearDamping(self.powerConsumer.forceNode, damping)
	end
					
					
	local vx, vy, vz = getLinearVelocity(self.powerConsumer.forceNode)	
	if vx==nil or vy==nil or vz==nil then				
		RealisticUtils.printWarning("PowerConsumer.mrUpdate", "getLinearVelocity has returned a nil value. Check 'forceDirNode' for " .. tostring(self.configFileName), true)
		return
	end		
					
	local forceNodeSpd = Utils.vector3Length(vx, vy, vz)

	--20171217 - check spd too 
	--if forceNodeSpd>0.06 then --0.06=0.216kph
	if spd>0.06 and forceNodeSpd>0.06 then --0.06=0.216kph
	
		--check animation working width force factor
		if self.powerConsumer.mrWorkingWidthAnimation then
			local currentAnimTime = self:getAnimationTime(self.powerConsumer.mrWorkingWidthAnimation.animName);
			maxForce = maxForce * Utils.lerp(self.powerConsumer.mrWorkingWidthAnimation.startForceFactor, self.powerConsumer.mrWorkingWidthAnimation.endForceFactor, currentAnimTime);							
			--print("currentWidthAnimTime = "..tostring(currentAnimTime) .. " - fx = " .. tostring(Utils.lerp(self.powerConsumer.mrWorkingWidthAnimation.startForceFactor, self.powerConsumer.mrWorkingWidthAnimation.endForceFactor, currentAnimTime)));
		end						
		
		if self.currentMass and self.emptyMass then
			maxForce = maxForce - self.powerConsumer.mrExistingForcePerLoadedTon * (self.currentMass-self.emptyMass);
		end
		
		--if this implement is a cultivator or sowing machine with direct seeding capability, check the ground in front of the workAreas => if already cultivated or ploughed => reduced draft force
		if SpecializationUtil.hasSpecialization(Cultivator, self.specializations) then
			local scalingFactor = PowerConsumer.mrGetDraftScalingFactor(self, WorkArea.AREATYPE_CULTIVATOR)	
			maxForce = maxForce * scalingFactor
		elseif self.useDirectPlanting then								
			local scalingFactor = PowerConsumer.mrGetDraftScalingFactor(self, WorkArea.AREATYPE_SOWINGMACHINE)
			maxForce = maxForce * scalingFactor
		end
	
		--problem : when lowering the tool (tractor at still), the powerconsumerForce is applied to the tool (direction mostly upward since the tool is going down)
		--this can cause weird behavior and visual
		--solution : only apply the resistance force when the "3pt hitch" is not in movement
		
		--local frictionForce = self.powerConsumer.forceFactor * spd * self.powerConsumer.totalMass / (dt/1000);
		if self.movingDirection ~= self.powerConsumer.forceDir then
			--apply less force in reverse (tool not working)							
			force = 0.25 * maxForce * spd;
		else						
			--frictionForce = self.powerConsumer.forceFactor * spd * 3.6 * self.powerConsumer.maxForce; -- max force at 1kph if forceFactor==1
			force = maxForce * (1 + 0.03*spd); --10% more draft at 12kph					
			
			if Vehicle.debugRendering then
				if PowerConsumer.mrDebugForce then
					force = PowerConsumer.mrDebugForce;
				end
			end
			
		end	

		
		
		--force = math.min(frictionForce, force);
		if self.powerConsumer.mrSpeedForMaxForce>0 then
			force = math.min(1, spd/self.powerConsumer.mrSpeedForMaxForce) * force -- max force at 0.3m/s (1.08kph)
		end
		
		--print("test powerconsumer force - spd="..tostring(spd*3.6).." - force = " .. tostring(force))
		

		--if force>self.powerConsumer.mrLastForceApplied then
			--force = math.min(force, self.powerConsumer.mrLastForceApplied + maxForce * dt/1500); -- 1.5s to get maxForce
			--force = math.min(force, self.powerConsumer.mrLastForceApplied + maxForce * dt/500); --500ms to get max force - 20170515 - induce too much "lag" for some implement when lowering them (time between the implement touch the ground and the tractor engine reving up
			--force = self.powerConsumer.mrLastForceApplied * 0.99 + force * 0.01;
		--end
	
							
		
		
		--20171217 - apply force directly to attacher vehicle
		if self.powerConsumer.mrApplyForceToAttacherVehicle and self.attacherVehicle~=nil and self.attacherVehicle.mrComponentForResistance~=nil then			
			local vehicleNode = self.attacherVehicle.mrComponentForResistance.node;
			local x,y,z = localToLocal(self.powerConsumer.forceNode, vehicleNode, self.powerConsumer.forceNodeCOM.x,self.powerConsumer.forceNodeCOM.y,self.powerConsumer.forceNodeCOM.z)
			addForce(vehicleNode, -force*vx/forceNodeSpd,-force*vy/forceNodeSpd,-force*vz/forceNodeSpd, x,y,z, true);			
		else
			--print("test power consumer - vx="..tostring(vx).." - vy="..tostring(vy).." - vz="..tostring(vz) .." - forceNodeSpd="..tostring(forceNodeSpd))
			addForce(self.powerConsumer.forceNode, -force*vx/forceNodeSpd,-force*vy/forceNodeSpd,-force*vz/forceNodeSpd, self.powerConsumer.forceNodeCOM.x,self.powerConsumer.forceNodeCOM.y,self.powerConsumer.forceNodeCOM.z, true);			
		end

			
	end -- check forceNodespeed
	
	if Vehicle.debugRendering then
		self.mrDebugPowerConsumerLastForce = force
		if self:getIsActiveForInput() then
			--local str = string.format("frictionForce=%.2f maxForce=%.2f -> current force=%.2f", frictionForce, maxForce, force)
			local str = string.format("damping=%.2f maxForce=%.2f -> current force=%.2f", damping, maxForce, force)
			renderText(0.68, 0.85, getCorrectTextSize(0.02), str)
			--20170806 - add self.powerConsumer.mrWorkingPtoPower info
			local baseWorking = 0
			local currentWorking = 0
			if self.powerConsumer.mrWorkingPtoPower then
				baseWorking = self.powerConsumer.mrWorkingPtoPower.basePower
				currentWorking = self.powerConsumer.mrWorkingPtoPower.lastWorkingPtoPower
			end
			local total = currentWorking
			if self.powerConsumer.mrPtoPowerActive then
				total = total + self.powerConsumer.mrNoLoadPtoPower
			end
			str = string.format("PTO power=> base=%.0f baseWorking=%.0f currentWorking=%.0f -> total=%.0f", self.powerConsumer.mrNoLoadPtoPower, baseWorking, currentWorking, total)
			renderText(0.6, 0.82, getCorrectTextSize(0.02), str)
		end
	end	

	
end
PowerConsumer.update = Utils.overwrittenFunction(PowerConsumer.update, PowerConsumer.mrUpdate);

--************************************************************************************************************************************************************	
--MR : update the presence of another cultivator for mrLimitedPowerWhenCombinedWithCultivator
PowerConsumer.mrUpdateTick = function(self, dt)
	if not self.mrIsMrVehicle then
		return
	end
	if self.isServer and self:getIsActive() then
		--update the presence of another implement (with cultivator specialization)
		if self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator~=nil then
			--parse all other implements attached to the tractor				
			self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.cultivatorPresent = false
			local mainVehicle = RealisticUtils.getMainAttacherVehicle(self)
			if mainVehicle~=nil then
				self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.cultivatorPresent = PowerConsumer.mrCheckCultivators(mainVehicle, self)
			end
			--print(tostring(g_currentMission.time) .. " test - cultivatorPresent = " .. tostring(self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.cultivatorPresent))			
		end
		
		--update the current filling speed		
		if self.powerConsumer.mrFillingDependantTool~=nil then
			local newFillLevel = self:getUnitFillLevel(self.powerConsumer.mrFillingDependantTool.fillUnitIndex);
			local deltaLevel = math.max(0, newFillLevel - self.powerConsumer.mrFillingDependantTool.lastFillLevel); --liters
			local deltaTime = math.max(dt, g_currentMission.time - self.powerConsumer.mrFillingDependantTool.lastTime)/1000; --seconds
			self.powerConsumer.mrFillingDependantTool.lastTime = g_currentMission.time;
			self.powerConsumer.mrFillingDependantTool.lastFillLevel = newFillLevel;			
			self.powerConsumer.mrFillingDependantTool.currentAvgFillingSpeed = 0.99*self.powerConsumer.mrFillingDependantTool.currentAvgFillingSpeed + 0.01*deltaLevel/deltaTime;			
		end
		
	end
end
PowerConsumer.updateTick = Utils.appendedFunction(PowerConsumer.updateTick, PowerConsumer.mrUpdateTick)


--************************************************************************************************************************************************************	
--MR : check the presence of a cultivator implement in all the vehicle of the current "combination" (tractor + all implements attached together)
PowerConsumer.mrCheckCultivators = function(mainAttacherVehicle, excludedVehicle)

	--print("checking " .. tostring(mainAttacherVehicle) .. " config=" .. tostring(mainAttacherVehicle.configFileName) .. " - lastCultivatorArea=" .. tostring(mainAttacherVehicle.lastCultivatorArea))

	if mainAttacherVehicle~=excludedVehicle and mainAttacherVehicle.lastCultivatorArea~=nil then -- this is not the exluded vehicle and this is a cultivator
		return true
	end

	-- check attached implements recursively
	if mainAttacherVehicle.attachedImplements~=nil then
		for _, implement in pairs(mainAttacherVehicle.attachedImplements) do
			if PowerConsumer.mrCheckCultivators(implement.object, excludedVehicle) then
				return true
			end
		end
	end	
	
	return false

end



--************************************************************************************************************************************************************	
--MR : this function is called directly by the "wheelsUtils" class, even if the implement does not use the "powerConsumer" class
--since "trailer" don't use the "powerConsumer", we have to check the "tipping rpm" needed here
function PowerConsumer.mrGetMaxPtoRpm(self, superFunc)

	if not self.mrIsMrVehicle then
		return superFunc(self);
	end

    local rpm = 0;
    if self.getPtoRpm ~= nil then
        rpm = self:getPtoRpm();
	end
	
	--check if this is a trailer tipping
	if rpm==0 and self.mrTrailer and self.mrTrailer.useTippingPtoPower then
		if self.mrTrailer.isUnloading then
			rpm = 540 --always 540 for trailers
		end
	end
    
    -- get pto rpm recursively
    for _, implement in pairs(self.attachedImplements) do
        rpm = math.max(rpm, PowerConsumer.getMaxPtoRpm(implement.object));
    end
    return rpm;
end
PowerConsumer.getMaxPtoRpm = Utils.overwrittenFunction(PowerConsumer.getMaxPtoRpm, PowerConsumer.mrGetMaxPtoRpm);


--************************************************************************************************************************************************************	
--MR : this function is called directly by the "vehicleMotor" class, even if the implement does not use the "powerConsumer" class
--since "trailer" don't use the "powerConsumer", we have to check the "tipping power" here
PowerConsumer.mrGetTotalConsumedPtoTorque = function(self, superFunc, excludeVehicle)

	if not self.mrIsMrVehicle then
		return superFunc(self, excludeVehicle);
	end

    local torque = 0;
	
	
    if self.getConsumedPtoTorque ~= nil and self.getPtoRpm ~= nil and self ~= excludeVehicle then		
        torque = self:getConsumedPtoTorque();			
    end
	
	--if self.isEntered and excludeVehicle==nil then
	--	print("test PowerConsumer.mrGetTotalConsumedPtoTorque - vehicle torque = " .. tostring(torque))
	--end
	
	if self.mrTrailer and self.mrTrailer.useTippingPtoPower and self.mrTrailer.isUnloading then			
		local tippingPower = self.mrTrailer.unloadingPtoPower
		if self.tipState == Trailer.TIPSTATE_OPENING then
			tippingPower = tippingPower + self.mrTrailer.openingPtoPower			
		end
		if tippingPower>0 then
			torque = torque + tippingPower / (540*math.pi/30) --always 540 for trailer
		end
	end
    -- get implements torque recursively
    for _, implement in pairs(self.attachedImplements) do
        torque = torque + PowerConsumer.getTotalConsumedPtoTorque(implement.object, excludeVehicle);
		--if self.isEntered and excludeVehicle==nil then
		--	print("test PowerConsumer.mrGetTotalConsumedPtoTorque - implement torque = " .. tostring(PowerConsumer.getTotalConsumedPtoTorque(implement.object, excludeVehicle)))
		--end
    end
	
	
	
    return torque
end
PowerConsumer.getTotalConsumedPtoTorque = Utils.overwrittenFunction(PowerConsumer.getTotalConsumedPtoTorque, PowerConsumer.mrGetTotalConsumedPtoTorque);

--************************************************************************************************************************************************************	
--MR : add power function of "load" of the implement
PowerConsumer.mrGetConsumedPtoTorque=function(self, superFunc)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end
	
	self.powerConsumer.mrPtoPowerActive = false;	
	
	
	if self:getDoConsumePtoPower() then		
	
		local rpm = self.powerConsumer.ptoRpm
		if rpm > 0.001 then
			self.powerConsumer.mrPtoPowerActive = true;
			local totalPower = self.powerConsumer.mrNoLoadPtoPower;

			--20170806 - taking into account self.powerConsumer.mrWorkingPtoPower (example  : for power harrows)
			if self.powerConsumer.mrWorkingPtoPower then
				local workingPtoPower = self.powerConsumer.mrWorkingPtoPower.basePower * (1 + math.max(0, self.lastSpeedReal*3600-self.powerConsumer.mrWorkingPtoPower.speedFactorStartingSpeed)*self.powerConsumer.mrWorkingPtoPower.speedFactor)
				self.powerConsumer.mrWorkingPtoPower.lastWorkingPtoPower = workingPtoPower
				totalPower = totalPower + workingPtoPower		
			end	
			
			--20170807 - taking into account "mrLimitedPowerWhenCombinedWithCultivator"
			if self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator then				
				if self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.cultivatorPresent then
					if self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.limitPtoTorqueFactor~=nil then
						totalPower = totalPower * self.powerConsumer.mrLimitedPowerWhenCombinedWithCultivator.limitPtoTorqueFactor
					end
				end
			end			
			
			--20171201 - taking into account mrFillingDependantTool.ptoKwConsumedPerTonPerHour
			if self.powerConsumer.mrFillingDependantTool~=nil then
				if self.powerConsumer.mrFillingDependantTool.ptoKwConsumedPerTonPerHour~=nil then
					local fillType = self:getUnitFillType(self.powerConsumer.mrFillingDependantTool.fillUnitIndex);
					if fillType~=FillUtil.FILLTYPE_UNKNOWN then
						local density = FillUtil.fillTypeIndexToDesc[fillType].massPerLiter; -- tons per liter
						local currentTonsPerHour = self.powerConsumer.mrFillingDependantTool.currentAvgFillingSpeed * density * 3600;
						self.powerConsumer.mrFillingDependantTool.lastTonsPerHour = currentTonsPerHour
						self.powerConsumer.mrFillingDependantTool.lastPower = self.powerConsumer.mrFillingDependantTool.ptoKwConsumedPerTonPerHour * currentTonsPerHour;
						totalPower = totalPower + self.powerConsumer.mrFillingDependantTool.lastPower;
					end
				end
			end		

			--print(tostring(g_currentMission.time) .. " - totalPower = "..tostring(totalPower))
			
			return totalPower/(rpm*math.pi/30)
		end
	end	
	
	return 0
end
PowerConsumer.getConsumedPtoTorque = Utils.overwrittenFunction(PowerConsumer.getConsumedPtoTorque, PowerConsumer.mrGetConsumedPtoTorque)


--************************************************************************************************************************************************************	
--MR : less draft force required when working on ploughed or already cultivated area
PowerConsumer.mrGetDraftScalingFactor = function(self, areaType)
	--in front of the active work areas
	local typedWorkAreas = self:getTypedWorkAreas(areaType)	
	local checkDir = self.powerConsumer.forceDir
	if self.movingDirection ~= 0 then
		checkDir = self.movingDirection
	end
	local numAreasScalingFactor = 0
	local sumAreasScalingFactor = 0
	
	for _, workArea in pairs(typedWorkAreas) do
		if PowerConsumer.mrIsWorkAreaActive(workArea) then
			
			local scalingFactor = 1
			numAreasScalingFactor = numAreasScalingFactor + workArea.refNode.chargeValue
			
			--sometimes, the start and width are at the back of the tool, and the height is at the front (example : Horsch terrano 4fx)
			local x,y,z = getTranslation(workArea.start)
			local x1,y1,z1 = getTranslation(workArea.width)
			local x2,y2,z2 = getTranslation(workArea.height)
			
			local maxX = math.max(math.max(x, x1),x2)
			local minX = math.min(math.min(x, x1),x2)			
			local maxZ = math.max(math.max(z, z1),z2)	
			local minZ = math.min(math.min(z, z1),z2)
			local areaLen = math.abs(maxZ-minZ)
			
			--local areaMaxHeight = math.max(math.max(math.abs(z-z1), math.abs(z-z2)), math.abs(z1-z2))
			--local wx, wy, wz = localToWorld(self.components[1].node, (x+x1+x2)/3, (y+y1+y2)/3, ((z+z1+z2)/3) + (areaMaxHeight*0.5 + 1)*checkDir) -- check 1m in front of the working area
			local wx, wy, wz = localToWorld(self.components[1].node, (maxX+minX)/2, (y+y1)/2, (maxZ+minZ)/2 + (areaLen*0.5 + 1)*checkDir) -- check 1m in front of the working area
						
			--RealisticUtils.drawPoint(workArea.start, false)
			--RealisticUtils.drawPoint(workArea.width, false)
			--RealisticUtils.drawPoint(workArea.height, false)
			
			--RealisticUtils.drawPoint2(self.components[1].node, wx, wy, wz)
			
			--draftFactor1 = middle of the workArea
			local draftFactor1 = PowerConsumer.mrGetCultivatingDraftScalingFactor(wx, wy, wz)
			if draftFactor1<1 then
				--check another point to be sure this is not a ridge marker "plough" effect
				local wx, wy, wz = localToWorld(self.components[1].node, 0.9*maxX, (y+y1)/2, (maxZ+minZ)/2 + (areaLen*0.5 + 1)*checkDir) -- check 1m in front of the working area, 90% on one side		
				--RealisticUtils.drawPoint2(self.components[1].node, wx, wy, wz)
				--draftFactor2 = one side of the workArea
				local draftFactor2 = PowerConsumer.mrGetCultivatingDraftScalingFactor(wx, wy, wz)
				if draftFactor2<1 then
					 scalingFactor = 0.5*(draftFactor1+draftFactor2)
				end
			end
			
			sumAreasScalingFactor = sumAreasScalingFactor + scalingFactor*workArea.refNode.chargeValue
			
		end
	end
	
	if numAreasScalingFactor>0 then
		return sumAreasScalingFactor/numAreasScalingFactor
	else
		return 1
	end
	
end


PowerConsumer.mrIsWorkAreaActive = function(workArea)
	
	if workArea.refNode~=nil and workArea.refNode.isActive then
		return workArea.refNode.chargeValue>0
	end		
	
	return false
	
end

--************************************************************************************************************************************************************	
--MR : return MR_CUTIVATOR_DRAFT_REDUCED_FACTOR if the given world point is above a cultivated or ploughed area
PowerConsumer.mrGetCultivatingDraftScalingFactor = function(worldX, worlY, worldZ)

	local densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailId, worldX, worlY, worldZ)
	if densityBits>0 then
		--check ground type
		local fieldType = bitAND(densityBits, 7)  -- 0000000000000111 = 7 = we want to keep the 3 first bits only		
		if fieldType==FruitUtil.GROUND_TYPE_PLOUGH or fieldType==FruitUtil.GROUND_TYPE_CULTIVATOR then
			return PowerConsumer.MR_CUTIVATOR_DRAFT_REDUCED_FACTOR
		elseif fieldType==FruitUtil.GROUND_TYPE_SOWING or fieldType==FruitUtil.GROUND_TYPE_SOWING_WIDTH then --3 or 4
			--seeded -- when the ground is has just been seeded, we also got the "bonus" when cultivating (useful when seeding with a direct seeder implement => in case the check point is above an already sown area from the previous pass)
			
			--we want to access the "fruit_density.gdm" file and check what kind of "seeded" surface we are on								
			local fruitTerrainDetailId = getTerrainDetailByName(g_currentMission.terrainRootNode, "wheat") -- wheat or any other fruit = we get the same "getDensityAtWorldPos" result
			local densityBits = getDensityAtWorldPos(fruitTerrainDetailId, worldX, worlY, worldZ)
			--g_currentMission.numFruitDensityMapChannels -- total "density" bits
			--g_currentMission.numFruitStateChannels -- number of bits for the "grow state"
			local startBit = g_currentMission.numFruitDensityMapChannels-g_currentMission.numFruitStateChannels
			local maskNum = RealisticUtils.getBitMask(startBit, g_currentMission.numFruitDensityMapChannels-1)
			local fruitGrowState = bitAND(densityBits, maskNum) -- base map=> numFruitDensityMapChannels=8 and numFruitStateChannels=4 11110000 = 240
			fruitGrowState = fruitGrowState / (2^startBit)
				
			--fruitGrowState starts at 1 value when just sown
			if fruitGrowState==1 then
				return PowerConsumer.MR_CUTIVATOR_DRAFT_REDUCED_FACTOR
			end
			
		end
	end	
	return 1
	
end





addConsoleCommand("mrsetPowerConsumerForce", "Set the value of PowerConsumer.mrDebugForce", "consoleCommandSetForce", PowerConsumer);
PowerConsumer.consoleCommandSetForce = function(unusedSelf, value)
	if value and tonumber(value) then
		PowerConsumer.mrDebugForce = value;
		return "PowerConsumer.consoleCommandSetForce - value=" .. tostring(value);
	end
	return "PowerConsumer.consoleCommandSetForce - no valid value typed as a parameter";
end








