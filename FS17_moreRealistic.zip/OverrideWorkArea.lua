﻿--************************************************************************************************************************************************************	
--MR : fix bug, charge values were not added, and so, only the charge value from the last groundreference node active was taken into account
WorkArea.mrGetPowerMultiplier = function(self, superFunc1, superFunc)

	if not self.mrIsMrVehicle then
		return superFunc1(self, dt);
	end;

	local powerMultiplier = 1;
	if superFunc ~= nil then
		powerMultiplier = superFunc(self);
	end
	if #self.groundReferenceNodes > 0 then
		local chargeValue = 0;
		for _, refNode in pairs(self.groundReferenceNodes) do
			if refNode.isActive then
				--chargeValue = refNode.chargeValue;
				chargeValue = chargeValue + refNode.chargeValue;				
			end;
		end;
		--print("test powerMultiplier - " ..tostring(powerMultiplier) .. " - chargeValueTotal="..tostring(chargeValue) .. " - result="..tostring(powerMultiplier * chargeValue));
		powerMultiplier = powerMultiplier * chargeValue;		
	end;
	return powerMultiplier;
end;
WorkArea.getPowerMultiplier = Utils.overwrittenFunction(WorkArea.getPowerMultiplier, WorkArea.mrGetPowerMultiplier);