﻿------------------------------------------------------------------------------------------------------------------------------------
--[[

	calling order
	
	1. Vehicle:new
	2. Vehicle:load
	3. all specialization preload
	4. Utils.loadSharedI3DFile
	5. self:loadFinished

--]]
------------------------------------------------------------------------------------------------------------------------------------




Vehicle.mrDebugForcesRendering = false

addConsoleCommand("debugf", "Toggles the debug rendering of the traction forces applied to vehicles", "Vehicle.mrConsoleCommandToggleDebugForceRendering", nil);
Vehicle.mrConsoleCommandToggleDebugForceRendering = function(unusedSelf, value)
	if Vehicle.mrDebugForcesRendering then
		Vehicle.mrDebugForcesRendering = false
	else
		Vehicle.mrDebugForcesRendering = true
	end
	return "Vehicle.mrConsoleCommandToggleDebugForceRendering - value=" .. tostring(Vehicle.mrDebugForcesRendering)
end

Vehicle.mrCanDisplayDebug = function(self)
	if Vehicle.debugRendering and self.isClient and self.isActive then
		if (self.attacherVehicle~=nil and self.attacherVehicle.isEntered and self.isSelected) or (self.isEntered and self.selectedImplement==nil) then
			return true
		end
	end
	return false			
end


---------------------------------------------------------------------------------------------------------------------------
--mr : manage changing vehicletype at load time
Vehicle.mrLoad = function(self, superFunc, vehicleData, asyncCallbackFunction, asyncCallbackObject, asyncCallbackArguments)
	--print("test Vehicle.mrLoad - vehicle typeName = " .. tostring(vehicleData.typeName))
	if RealisticUtils.defaultVehiclesModifiedData[vehicleData.filename] then
		if RealisticUtils.defaultVehiclesModifiedData[vehicleData.filename].newVehicleTypeName~=nil then
			--20170825 - check if "deepCultivator" (Seasons) specialization is present => do not allow changing to "pdlc_kuhnPack.subsoiler" in such case
			local noChangeAllowed = false				
			if RealisticUtils.defaultVehiclesModifiedData[vehicleData.filename].newVehicleTypeName=="pdlc_kuhnPack.subsoiler"  then
				if RealisticUtils.hasSpecialization(vehicleData.typeName, "deepCultivator") then
					noChangeAllowed = true
				end
			end			
			--print("test Vehicle.mrLoad - vehicle typeName = " .. tostring(vehicleData.typeName) .. " - new type name=" .. tostring(RealisticUtils.defaultVehiclesModifiedData[vehicleData.filename].newVehicleTypeName))
			if not noChangeAllowed then
				vehicleData.typeName = RealisticUtils.defaultVehiclesModifiedData[vehicleData.filename].newVehicleTypeName			
			end
		end
	end
	return superFunc(self, vehicleData, asyncCallbackFunction, asyncCallbackObject, asyncCallbackArguments)
end
Vehicle.load = Utils.overwrittenFunction(Vehicle.load, Vehicle.mrLoad)



Vehicle.mrLoadFinished = function(self, superfunc, i3dNode, arguments)

	Vehicle.mrLoadFinished1(self, i3dNode, arguments)
	
	local result = superfunc(self, i3dNode, arguments)
	
	Vehicle.mrLoadFinished2(self, i3dNode, arguments)
	
	return result
	
end
Vehicle.loadFinished = Utils.overwrittenFunction(Vehicle.loadFinished, Vehicle.mrLoadFinished);

--************************************************************************************************************************************************************
--** before loadFinished - use mr vehicle xml file instead of the one from the game files
Vehicle.mrLoadFinished1 = function(self, i3dNode, arguments)

	self.mrIsMrVehicle = false
	self.mrConfigFileName = RealisticUtils.getVehicleMrConfigFileName(self.configFileName) -- nil value = no MR file found
		
	if self.mrConfigFileName~=nil then
		delete(self.xmlFile)
		self.xmlFile = loadXMLFile("TempConfig", self.mrConfigFileName)
		self.mrIsMrVehicle = true
	end
	
	if hasXMLProperty(self.xmlFile, "vehicle.moreRealistic") then
		local defaultValue = true;	--default value when the "moreRealistic" is present
		self.mrIsMrVehicle = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic#isMrVehicle"), defaultValue)		
	end
	
	
	
	if self.mrIsMrVehicle then
		self.mrUseCarPhysics = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic#useCarPhysics"), false)
		self.loadWheelDataFromXML = Vehicle.mrLoadWheelDataFromXML
		self.updateWheelTireFriction = Vehicle.mrUpdateWheelTireFriction
		--self.mrWheelShapesLastCreatedTime = 100000
	end	
	
end


--************************************************************************************************************************************************************
--load mr parameters - after loadFinished
Vehicle.mrLoadFinished2 = function(self, i3dNode, arguments)

	local dragArea = 3.5 --default drag area value	
	

	if self.mrIsMrVehicle then
		--load "mr" xml file if present
		if self.mrConfigFileName~=nil then		
			self.xmlFile = loadXMLFile("TempConfig", self.mrConfigFileName)
		else
			self.xmlFile = loadXMLFile("TempConfig", self.configFileName)
		end
				
		self.mrUseMrTransmission = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic#useMrTransmission"), false)
		
		dragArea = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.dragArea#value"), dragArea)
		local overridedTrailerArea = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.overridedTrailerArea#value"), 0)
		
		
		local indexOfComponentToApplyResistancesTo = Utils.getNoNil(getXMLInt(self.xmlFile, "vehicle.moreRealistic.componentToApplyResistancesTo#index"), 1)
		
		self.mrComponentForResistance = {}
		if self.components[indexOfComponentToApplyResistancesTo]==nil then
			RealisticUtils.printWarning("Vehicle.mrLoadFinished2", "Wrong 'componentToApplyResistancesTo index' in xml file of the vehicle. Index="..tostring(indexOfComponentToApplyResistancesTo), false)
			indexOfComponentToApplyResistancesTo = 1
		end
		
		self.mrComponentForResistance.node = self.components[indexOfComponentToApplyResistancesTo].node
		
		local px, py, pz = Utils.getVectorFromString(getXMLString(self.xmlFile, "vehicle.moreRealistic.componentToApplyResistancesTo#forceNodeCOM"));
		if px == nil or py == nil or pz == nil then
			px, py, pz = getCenterOfMass(self.mrComponentForResistance.node)
			--py = py - 0.4
			--20170619
			py = 0
		end		
		self.mrComponentForResistance.forcePosition = {x=px, y=py, z=pz}

		Vehicle.mrLoadAdditionnalLateralForcesSettings(self)
		
						
		if self.motor and self.mrUseMrTransmission then
			
			self.motor.mrIsMrMotor = true
			self.motor.rotInertiaFx = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#rotInertiaFx"), 1); --the lower, the quicker the axle can gain speed		
			
			--local dampingRateFx = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#dampingRateFx"), 1);	-- 1 = base scale for an diesel engine
			--self.motor.dampingRate = dampingRateFx * self.motor.mrMaxTorque/225; -- NOTE : final "dampingRate" = rotInertia * dampingRate, so always tune the rotInertia before the dampingRate. NOTE2 : damping not useful anymore
			
			self.motor.mrMinSpeed = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#minSpeed"), 2)/3.6; --kph in the xml file, m/s in the lua
			self.motor.minSpeed = self.motor.mrMinSpeed*3.6;
			if self.cruiseControl then self.cruiseControl.minSpeed = self.motor.mrMinSpeed*3.6; end;
			
			self.motor.mrTransmissionEfficiency = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#transmissionEfficiency"), 0.87);			
			self.motor.mrEngineBrakeRpm = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#engineBrakeRpm"), 250 + self.motor.maxRpm);	
			self.motor.mrAccPedalRegulateTorque = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.engine#accPedalRegulateTorque"), false);	
			self.motor.mrIdleEngineRpm = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#idleEngineRpm"), self.motor.minRpm);			
			self.motor.mrBrakingForceFx = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#engineBrakeForceFx"), 1);
			self.motor.mrTransmissionReactivity  = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#transmissionReactivity"), 1);
			self.motor.mrMinRpmAllowedWithLoad = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#minRpmAllowedWithLoad"), self.motor.mrMinRpmAllowedWithLoad);			
			self.motor.mrEngineBrakeNotLinkedToPTO = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.engine#engineBrakeNotLinkedToPTO"), false);
			self.motor.mrEngineTorqueForTransmissionHasPriority = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.engine#engineTorqueForTransmissionHasPriority"), false);
			
			self.motor.mrRpmRange = self.motor.maxRpm - self.motor.mrIdleEngineRpm;
			self.motor.mrEngineBrakingForce = self.motor.mrBrakingForceFx * self.motor.mrMaxPower * 10 / self.motor.mrEngineBrakeRpm;
			
			self.motor.mrMaxPowerRpm = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#maxPowerRpm"), self.motor.mrMaxPowerRpm);
			
			self.motor.mrMaxEngineTorqueForTransmission = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#maxEngineTorqueForTransmission"), 99999);
			
			
			--------------------------------------------------------------------------------------------------------
			-- overwritten function			
			self.motor.mrUpdateVehicleProps = VehicleMotor.mrUpdateVehicleProps;
			--------------------------------------------------------------------------------------------------------
			
			local defaultFuelUsage = 0.2717; -- default fuel usage (in Liter per Hour per KW):  20L/Hour for 100 PTO Hp (73.6KW)
			local fuelUsageFactor = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.engine#fuelUsageFactor"), 1);
			self.mrFuelUsage = defaultFuelUsage * fuelUsageFactor / (60*60*1000); -- from l/KW/h to l/KW/ms		

			self.mrLastBrakePedal = 1;
			self.mrSAGBtryInversionFailed = false;
			self.mrSAGBtryInversion = false;
			self.mrLastNotZeroAccDir = 0
			
		end
		
		--mr parameters		
		
		--debug param
		self.mrDebugNoForces = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.debug#noForces"), false)
			

		self.mrNeededPtoRpmWhenControlled = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic#neededPtoRpmWhenControlled"), 0)
		self.mrAdditionalLateralForcesScale = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic#additionalLateralForcesScale"), 1)
		self.mrGetNeededPtoRpmWhenControlled = Vehicle.mrGetNeededPtoRpmWhenControlled		
		
		self.mrNeedEngineRunningForTorque = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic#needEngineRunningForTorque"), false)
		
		--20171223 - terrain Response Ploughing Effect Depth Limiter
		self.mrTerrainResponsePloughingEffectDepthLimit = getXMLFloat(self.xmlFile, "vehicle.moreRealistic.terrainResponse#ploughingEffectDepth")
		
		self.mrManageWheelsFriction = Vehicle.mrManageWheelsFriction;
		self.mrRollingResistanceS = 0;
		self.mrAvgWheelSlip = 0;		
		self.mrWheelsFrictionFactor = 1;	
		self.mrTotalWeightOnTires = 0;
		self.mrAvgWheelGroundFrictionCoeff = 0;
		self.mrAvgDrivenWheelsSpeed = 0;
		self.mrTotalxDriveDiff = 0; --store the total difference between each update of the wheels graphics
		self.mrVehicleIsStill = true; --updated by wheelUtils.updateWheelsGraphics
		self.mrDragArea = dragArea;	
		self.mrOverridedTrailerArea = overridedTrailerArea;
		self.mrIsBraking = true;
		self.mrLastWantedAcc = 0;
		self.mrLastDt = 1000/60;
		self.mrUseMrTransmissionFrameCount = 0;
		self.mrUseMrTransmissionFrameCountLimit = 5
		self.mrLastWheelsSlip = 0
		self.mrNeedPowerTimeLeft = 0
		
		self.mrWheelShapesValid = false --can be useful when we call "getWheelshapeXXX" function right after the wheelshape is created ("hardAttach" implement)
		self.mrNeedCreateWheel = false; --20171221 - as soon as the "needCreate" flag is true for one wheel of the vehicle, we have to call the updateWheelBaseFunction
		
		self.mrGenuineSpeedLimit = self.speedLimit;
		
		self.mrLastTotalTiresLoad = 0
		
		--20171209 - we want to update the wheels graphics at loading time (to get correct tire deformation and wheel position)
		self.mrWheelsGraphicsInitialized = false;
		self.mrWheelsGraphicsInitializing = false;
		self.mrWheelGraphicsInitCount = 0;
		
		--20170622 - mrAi
		self.mrAi = {}
		self.mrAi.lastSpeedLimit = 0
		
		local wheelNum = 0;
		local i=0;
		for _, wheel in pairs(self.wheels) do
			i = i + 1;
			wheel.mrNum = i;						
			wheel.mrNormalizedTorqueRatio = Vehicle.mrComputeWheelFinalTorqueRatio(self, wheel);
			if wheel.mrNormalizedTorqueRatio~=1 then
				wheelNum = wheelNum + 1;
			end
			wheel.mrTotalContactWidth = Vehicle.mrGetWheelTotalContactWidth(wheel);
			wheel.mrLastDeformation = 0;
		end
		
		self.mrWheelsNum = i;
		
		if wheelNum>0 then
			for _, wheel in pairs(self.wheels) do				
				if wheel.mrNormalizedTorqueRatio~=1 then
					wheel.mrNormalizedTorqueRatio = wheel.mrNormalizedTorqueRatio * wheelNum;
				end
			end
		end
		
		Vehicle.mrUpdateWheelsIsDriven(self);	
		
		--20170825 - allow us to draw some point while in game (especially useful when converting DLC vehicle => draw center of mass point or component origin)
		RealisticUtils.loadDebugData(self, self.xmlFile)
		
	
		delete(self.xmlFile);
		self.xmlFile = nil;		
		
	end
	
end;


--************************************************************************************************************************************************************
-- allow us to specify a different mass for a "component" than what is set in the i3d file
-- load and set "mrSetMass" value
Vehicle.mrLoadComponentFromXML = function(self, superfunc, component, xmlFile, key, rootPosition, i)

	local result = superfunc(self, component, xmlFile, key, rootPosition, i);
	if result then
		local wantedMass = getXMLFloat(xmlFile, key .. "#mrSetMass");
		if wantedMass~=nil and wantedMass~=0 then
			setMass(component.node, wantedMass);
		end
		return true
	end
	return false;
	
end
Vehicle.loadComponentFromXML = Utils.overwrittenFunction(Vehicle.loadComponentFromXML, Vehicle.mrLoadComponentFromXML);


--************************************************************************************************************************************************************
-- allow us to specify a "zRotationXOffset " in the vehicle xml file
-- example = "brent avalanche"
function Vehicle.mrLoadComponentJointFromXML(self, superfunc, jointDesc, xmlFile, key, componentJointI, jointNode, index1, index2)
	local result = superfunc(self, jointDesc, xmlFile, key, componentJointI, jointNode, index1, index2)
	if result then
		local zRotationXOffset = getXMLFloat(xmlFile, key .. "#mrZRotationXOffset")
		if zRotationXOffset~=nil then
			--print("test new zRotationXOffset = " .. tostring(zRotationXOffset))
			jointDesc.zRotationXOffset = zRotationXOffset
		end
		return true
	end
	return false
end
Vehicle.loadComponentJointFromXML = Utils.overwrittenFunction(Vehicle.loadComponentJointFromXML, Vehicle.mrLoadComponentJointFromXML);

--************************************************************************************************************************************************************
--** 20171102 - split mrUpdate in 2 function (prepended and appended) to handle patch 1.5
--************************************************************************************************************************************************************

Vehicle.mrUpdate1 = function(self, dt)
	
	if not self.mrIsMrVehicle then
		return;
	end	
	
	--20170825 - display debug data if required
	if self.mrDebugData then
		if self.mrDebugData.points then
			for node,_ in pairs(self.mrDebugData.points) do								
				RealisticUtils.drawPoint(node, false, self.mrDebugData.points[node].translation)				
			end			
		end
		if self.mrDebugData.comPoints then
			for node,_ in pairs(self.mrDebugData.comPoints) do
				RealisticUtils.drawPoint(node, true)
			end			
		end
	end		
	
	--20170503 - store last dt in case we need it in a function without dt passed as an input parameter
	self.mrLastDt = dt;
	
	--20171209 - we want to "refresh" wheels graphics one time at loading time
	if self.mrWheelsGraphicsInitializing then		
		self.mrWheelGraphicsInitCount = self.mrWheelGraphicsInitCount + 1;
		if self.mrWheelGraphicsInitCount>2 then --we need 2 calls to the "WheelsUtil.updateWheelsGraphics" function because of the "wheel.updateWheel" toggle
			self.mrWheelsGraphicsInitializing = false;
			self.mrWheelsGraphicsInitialized = true;
			self.updateWheelsTime = 0;
		else
			self.updateWheelsTime = 9999;
		end;
	end;
	
end;
Vehicle.update = Utils.prependedFunction(Vehicle.update, Vehicle.mrUpdate1);


--************************************************************************************************************************************************************
-- add rolling resistance and air resistance (drag)
--20171102 - split mrUpdate in 2 function (prepended and appended) to handle patch 1.5
Vehicle.mrUpdate2 = function(self, dt)	

	if not self.mrIsMrVehicle then
		return;
	end;
	
	--print(tostring(g_currentMission.time) .. " update2")
	
	--print("test updateWheelsTime = " .. tostring(self.updateWheelsTime) .. " - dt="..tostring(dt))
	self.updateWheelsTime = math.max(0, self.updateWheelsTime); -- default update function = remove dt each time => on a dedicated server, the value could go too "low" (very very high negative number = crash after some time ?)
	
	if self.isActive then
		self.updateWheelsTime = 6000 --override the default 3000 value
	end
	if self.isServer and self.firstTimeRun and self.updateWheelsTime>0 then	
		self:mrManageWheelsFriction(dt);
	end;
	
	if self.isServer and self.isAddedToPhysics and self.mrWheelShapesValid then --20170520 - check if wheelshapes are ok
		if self.updateWheelsTime > 0 then
			if self.firstTimeRun then
				for i,wheel in ipairs(self.wheels) do
					wheel.mrLastA = 0;
					local isOnField = false;
					wheelSpeed = getWheelShapeAxleSpeed(wheel.node, wheel.wheelShape);			
					if self.mrVehicleIsStill then wheelSpeed=0; end;
					wheel.mrLastWheelSpeed = wheelSpeed;	

					local densityBits = 0
					if wheel.contact == Vehicle.WHEEL_GROUND_CONTACT then
						local wx, wy, wz = wheel.netInfo.x, wheel.netInfo.y, wheel.netInfo.z;
						wy = wy - wheel.radius;
						wx = wx + wheel.xOffset;
						wx, wy, wz = localToWorld(wheel.node, wx,wy,wz);
						densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailId, wx, wy, wz);
						wheel.mrLastTerrainDensityBits = densityBits
						isOnField = densityBits ~= 0;
						wheel.mrLastA = wheel.lastColor[4];
					elseif wheel.contact == Vehicle.WHEEL_GROUND_HEIGHT_CONTACT then
						--20170616 - when driving on grass windrow or other "heigh_type", we don't want to get the same friction as on the road. And so, we are using the "field" friction table
						isOnField = true;						
					end;
					wheel.mrIsOnField = isOnField;
				end;
			end;
		end;
	end;		

		
	if self.isServer then
		--if not self.hasStopped and self.firstTimeRun and self.movingDirection ~= 0 and self.isActive then 
		
		--if self.mrVehicleIsStill then
		--	print(tostring(g_currentMission.time) .. " - vehicle is still = " .. self.configFileName);
		--end
		
		--20170801 - we have to check the vehicle is not onto another vehicle (example : harvester on a low loader trailer)
		-- check wheel speed for that
		
		if not self.mrVehicleIsStill and self.dynamicMountObject==nil then
			
			local spd = self.lastSpeedReal*1000; -- meter per second			
			local avgSlip = 0;			
			local totalResistanceForce = 0;
			local airResistance = 0;
			local totalSlippingResistance = 0;
			local totalWheelRollingResistance = 0;				
			
			if spd>0.1 then --Vehicle.mrGetVehicleIsRolling(self) then --0.1 = 0.36kph
				--local totalWheelSlip = 0;
				--local totalWheelSlipNumWheels = 0;							
				for _,wheel in ipairs(self.wheels) do
					if wheel.hasGroundContact and not wheel.mrNotAWheel then
						--add rolling resistance function of load on the tire					
						local wRes = wheel.mrLastTireLoad * wheel.mrCurrentRollingResistance;
						--print("test - mrLastTireLoad = "..tostring(wheel.mrLastTireLoad) .. " - mrCurrentRollingResistance="..tostring(wheel.mrCurrentRollingResistance) .. " - width="..tostring(wheel.mrTotalContactWidth));
						totalWheelRollingResistance = totalWheelRollingResistance + wRes;
						--only for "motorized" vehicles
						if self.motorizedNode~=nil then							
							--slipping resistance when wheel "dig" into the ground
							if wheel.mrRealLongSlip>0.1 and wheel.mrLastTireLoad>0 then --only if slip>10%
							--if wheel.mrSlippingResistanceEnabled and wheel.mrLastTireLoad>0 then
								totalSlippingResistance = totalSlippingResistance + wRes * 4 * (wheel.mrRealLongSlip-0.1) * math.max(0, 1 -20*wheel.mrTotalContactWidth*wheel.radius/wheel.mrLastTireLoad);--factor function of wheel width and radius (the wider the wheel, the smaller the slipping resistance. The taller the wheel, the smaller the slipping resistance)
								--totalSlippingResistance = totalSlippingResistance + wRes * 4 * wheel.mrRealLongSlip * math.max(0, 1 -20*wheel.mrTotalContactWidth*wheel.radius/wheel.mrLastTireLoad);
							end
							--totalWheelSlip = totalWheelSlip + wheel.mrLastLongSlip;
							--totalWheelSlipNumWheels = totalWheelSlipNumWheels + 1;
						end;						
					end;
				end;
				--if totalWheelSlipNumWheels>0 then
				--	avgSlip = totalWheelSlip/totalWheelSlipNumWheels;				
				--end				
			end;			
			--self.mrAvgWheelSlip = self.mrAvgWheelSlip*0.95 + avgSlip*0.05;
			
			--add air resistance only if not attached to another vehicle or "mounted" onto a "dynamicMountAttacher" vehicle
			if spd>4 and self.attacherVehicle==nil then				
				-- SCx = S multiply Cx where S= 2d surface of the vehicle (front view) and Cx = drag coefficient (1 is a good approximation for a farming vehicle)
				-- good approximation for farming vehicle = 0.85 x width x height
				-- example : tractor 2.5m width and 3m high => 0.85 x 2.5 x 3 = 6.375
				--english term = "drag area"				
				airResistance = 0.00061*RealisticUtils.getDragArea(self)*spd^2; -- 0.5 * uAir * dragArea * spd^2  (uAir = 1.22)
			end
			
			--smooth wheelRollingResistance	
			--20170317 - fix bug : self.mrRollingResistanceS was never 0, and so, a force (even minimal) was always apply to the vehicle = vehicle never still
			if totalWheelRollingResistance==0 then
				self.mrRollingResistanceS = 0;
			else
				self.mrRollingResistanceS = 0.99 * self.mrRollingResistanceS + 0.01 * totalWheelRollingResistance;
			end
			
			local totalResistanceForce = airResistance + self.mrRollingResistanceS + totalSlippingResistance;
						
			if Vehicle.debugRendering and not self.attacherVehicle and spd>0.1 then
				if RealisticUtils.mrDebugValue3 then
					totalResistanceForce = tonumber(RealisticUtils.mrDebugValue3);
				end
			end;			
			
			if totalResistanceForce>0 then
				--20170514 - cap the 'totalResistanceForce' to avoid unstability in some 'extrem' case (vehicle flying in the air ?)
				totalResistanceForce = math.min(1000, totalResistanceForce)
				--local px,py,pz = getCenterOfMass(self.components[1].node);
				local px = self.mrComponentForResistance.forcePosition.x
				local py = self.mrComponentForResistance.forcePosition.y
				local pz = self.mrComponentForResistance.forcePosition.z
				if spd>0.3 then --0.3 = 1.08
					local vx, vy, vz = getLinearVelocity(self.mrComponentForResistance.node);				
					if vx==nil or vy==nil or vz==nil then				
						RealisticUtils.printWarning("Vehicle.mrUpdate2", "getLinearVelocity has returned a nil value. Check " .. tostring(self.configFileName), true);				
					else									
						local spd = Utils.vector3Length(vx, vy, vz)
						if spd>0.3 then -- 20170514 - security check against 0 divide
							if not self.mrDebugNoForces then
								addForce(self.mrComponentForResistance.node, -totalResistanceForce*vx/spd,-totalResistanceForce*vy/spd,-totalResistanceForce*vz/spd, px,py,pz, true);	
							end
							--print("adding force : " .. tostring(self.configFileName) .. " - rr value = " .. tostring(totalWheelRollingResistance) .. " - air res="..tostring(airResistance) .. " - slip res="..tostring(totalSlippingResistance))
						end
					end
				else
					local dx,dy,dz = localDirectionToWorld(self.components[1].node, 0, 0, -totalResistanceForce*self.movingDirection);					
					if not self.mrDebugNoForces then
						addForce(self.mrComponentForResistance.node, dx,dy,dz, px,py,pz, true);	
					end
				end
			end;
			
			if Vehicle.mrCanDisplayDebug(self) then	
				renderText(0.35, 0.55, getCorrectTextSize(0.02), string.format("Rolling resistance force: %1.2f", self.mrRollingResistanceS));
				renderText(0.35, 0.53, getCorrectTextSize(0.02), string.format("Air resistance force: %1.2f", airResistance));
				renderText(0.35, 0.51, getCorrectTextSize(0.02), string.format("Slipping Resistance force: %1.2f", totalSlippingResistance));
				self.mrDebugLastTotalResistance = totalResistanceForce;
			end
			
		end;
		
		if Vehicle.mrCanDisplayDebug(self) then	

			
		
			local selectedIsMR = true
			if self.selectedImplement ~= nil and self.selectedImplement.object ~= nil then
				--MR : display total mass on the wheels
				Vehicle.drawDebugMassOnTheWheels(self.selectedImplement.object);
				selectedIsMR = self.selectedImplement.object.mrIsMrVehicle
			else
				Vehicle.drawDebugMassOnTheWheels(self);
			end;
			
			--display if the vehicle is mr
			renderText(0.70, 0.53, getCorrectTextSize(0.02), string.format("Selected vehicle is MR (for the game engine) = %s", selectedIsMR))
			
			--display the vehicle DIRT level
			local dirtAmountTxt = "not washable"
			if self.dirtAmount~=nil then
				dirtAmountTxt = tostring(self.dirtAmount)
			end
			renderText(0.70, 0.56, getCorrectTextSize(0.02), "Dirt level = " .. dirtAmountTxt)
			
			if self.motor~=nil then
			
				--display if the MR transmission is used or not
				renderText(0.70, 0.47, getCorrectTextSize(0.02), string.format("MR transmission = %s", self.mrUseMrTransmission))
				
				if self.mrDebugLastAccPedal==nil then self.mrDebugLastAccPedal = 0; end;
				renderText(0.70, 0.50, getCorrectTextSize(0.02), string.format("Acc: %1.2f", self.mrDebugLastAccPedal));
				
				if self:getIsActiveForInput() then	
					
					--measure stopping distance		
					--init variables
					if self.mrDebugMovedDistance == nil then self.mrDebugMovedDistance = 0;	end;
					if self.mrDebugReadyForStoppingDistance == nil then self.mrDebugReadyForStoppingDistance = true; end;
					
					local distance = 0;
					if self.mrDebugReadyForStoppingDistance==false and self.lastSpeedReal*3600<0.1 then
						--vehicle stopped, compute distance and reset data
						self.mrDebugMovedDistance = self.mrDebugMovedDistance + self.lastMovedDistance;			
						self.mrDebugReadyForStoppingDistance = true;
					elseif self.mrDebugReadyForStoppingDistance then
						if self.axisForward>=0 and self.cruiseControl.state ~= Drivable.CRUISECONTROL_STATE_ACTIVE and self.lastSpeedReal*3600>1 then
							--start measuring
							self.mrDebugReadyForStoppingDistance = false;
							self.mrDebugMovedDistance = 0;
						end;
					else
						--already measuring distance
						self.mrDebugMovedDistance = self.mrDebugMovedDistance + self.lastMovedDistance;
					end;
					renderText(0.34, 0.61, getCorrectTextSize(0.02), string.format("Braking distance = %.1fm", self.mrDebugMovedDistance));
					
					
					--measure 0-100kph and 0-40kph times
					--init variables
					if self.DebugTimeStartTime == nil then self.DebugTimeStartTime = 0;	end;				
					
					if math.abs(self.axisForward)<0.01 and self.lastSpeedReal*3600<0.1 then
						--ready to measure time
						self.DebugTimeStartTime = g_currentMission.time;
						self.mrDebug40Time = nil;
						self.mrDebug100Time = nil;
					else					
						if self.mrDebug40Time == nil and self.lastSpeedReal*3600>=40 then
							self.mrDebug40Time = g_currentMission.time-self.DebugTimeStartTime;
						elseif self.mrDebug100Time == nil and self.lastSpeedReal*3600>=100 then
							self.mrDebug100Time = g_currentMission.time-self.DebugTimeStartTime;
						end
					end
					renderText(0.34, 0.63, getCorrectTextSize(0.02), string.format("Acc times 0 to 40/100kph = %2.2f/%2.2f", Utils.getNoNil(self.mrDebug40Time, 0)/1000,Utils.getNoNil(self.mrDebug100Time, 0)/1000));
					
					
					--show the current environment ground wetness
					renderText(0.2, 0.63, getCorrectTextSize(0.02), string.format("Ground wetness: %1.2f", g_currentMission.environment.groundWetness));
					
					--show if the brake are applyied
					renderText(0.2, 0.61, getCorrectTextSize(0.02), string.format("Brake: %s", tostring(self.mrIsBraking)));

					--display the average wheel slip
					renderText(0.2, 0.57, getCorrectTextSize(0.02), string.format("Avg Slip: %3.1f%%", 100*self.mrAvgWheelSlip));
					
					--display the last engine output power delivered
					local lastEngineOutputPower = self.motor.equalizedMotorRpm*math.pi/30*self.motor.mrLastEngineOutputTorque; -- KW
					
					renderText(0.2, 0.55, getCorrectTextSize(0.02), string.format("Engine Output Power\n(equivalent PTO power) :\n%3.0fKW/%3.0fHp", lastEngineOutputPower, lastEngineOutputPower/0.7355));
						
					
					if self.motor then
						renderText(0.135, 0.585, getCorrectTextSize(0.02), string.format("MR: %3.1f", self.motor.mrLastDummyGearRatio));
					end
					
				end
				
			end
			
		end -- can display debug

	end--end self.isServer
	
	Vehicle.mrPostUpdate(self, dt);
	
end;
Vehicle.update = Utils.appendedFunction(Vehicle.update, Vehicle.mrUpdate2);

--run after update function
Vehicle.mrPostUpdate = function(self, dt)
		
		
	--if not self.mrWheelsGraphicsInitialized then
	--	print("test mrPostUpdate - self.time="..tostring(self.time) .. " self.isAddedToPhysics="..tostring(self.isAddedToPhysics) .." self.updateWheelsTime="..tostring(self.updateWheelsTime) .." self.firstTimeRun="..tostring(self.firstTimeRun) .. " - self.mrWheelsGraphicsInitializing="..tostring(self.mrWheelsGraphicsInitializing))
	--end	
		
	--create physical wheels if required
	if self.isServer and self.isAddedToPhysics then
		--if self.updateWheelsTime > 0 then
		if self.mrNeedCreateWheel then		
			self.mrNeedCreateWheel = false;			
			for i,wheel in ipairs(self.wheels) do
				if wheel.mrNeedCreate then
					wheel.mrNeedCreate = false;						
					Vehicle.updateWheelBase(self, wheel, true); --allowedToCreate = true									
				end;
			end;	
		end;
	end;
	
	
	--if not self.isEntered then
		--print(tostring(g_currentMission.time) .. "test mrPostUpdate - self.time="..tostring(self.time) .. " test")
	--	for i,wheel in ipairs(self.wheels) do
	--		setWheelShapeProps(wheel.node, wheel.wheelShape, 0, 10000, 0, 0)		
	--	end;
	--end;
		
	--20171209 - we want to "refresh" wheels graphics one time at loading time	
	if not self.mrWheelsGraphicsInitialized and not self.mrWheelsGraphicsInitializing then
		self.mrWheelsGraphicsInitializing = true;
		self.mrWheelGraphicsInitCount = 0;
	end;

	self.mrWheelShapesValid = true; -- this should be the last thing run for a vehicle during a game loop
		
end;


--************************************************************************************************************************************************************
--add support for "$mr" tag when loading a wheel xml file
Vehicle.mrLoadWheelDataFromXML = function(self, wheel, xmlFilename, wheelConfigIndex, isLeft, isRealWheel, xRotOffset)
	
	--MR MODIFICATION
	--check if we want to load the wheel xml file from the "moreRealistic" folder	
	--local xmlFilename = Utils.getFilename(xmlFilename, self.baseDirectory);
	local xmlFilename = RealisticUtils.getFilename(xmlFilename, self.baseDirectory);
	--END MR MODIFICATION
	----------------------------------------------------------------------------------------	
	local xmlFile = loadXMLFile("TempConfig", xmlFilename);	

	if xmlFile ~= nil then
		local i = 0;
		local wheelConfigFound = false
		while true do
			local configKey = string.format("wheel.configurations.configuration(%d)", i)
			if not hasXMLProperty(xmlFile, configKey) then
				break;
			end;
			if getXMLString(xmlFile, configKey.."#index") == wheelConfigIndex then
				wheelConfigFound = true

				local key = "indexLeft"
				if not isLeft then
					key = "indexRight"
				end
				wheel.isLeft = isLeft

				wheel.tireFilename = getXMLString(xmlFile, configKey..".tire#filename")
				wheel.tireIndex = Utils.getNoNil(getXMLString(xmlFile, configKey..".tire#"..key), "0|0")
				wheel.outerRimFilename = getXMLString(xmlFile, configKey..".outerRim#filename")
				wheel.outerRimIndex = Utils.getNoNil(getXMLString(xmlFile, configKey..".outerRim#index"), "0|0")
				wheel.outerRimWidthAndDiam = Utils.getVectorNFromString(getXMLString(xmlFile, configKey..".outerRim#widthAndDiam"), 2)
				wheel.outerRimScale = Utils.getVectorNFromString(Utils.getNoNil(getXMLString(xmlFile, configKey..".outerRim#scale"), "1 1 1"), 3)
				wheel.innerRimFilename = getXMLString(xmlFile, configKey..".innerRim#filename")
				wheel.innerRimIndex = Utils.getNoNil(getXMLString(xmlFile, configKey..".innerRim#"..key), "0|0")
				wheel.innerRimWidthAndDiam = Utils.getVectorNFromString(getXMLString(xmlFile, configKey..".innerRim#widthAndDiam"), 2)
				wheel.innerRimOffset = Utils.getNoNil(getXMLFloat(xmlFile, configKey..".innerRim#offset"), 0)
				wheel.innerRimScale = Utils.getVectorNFromString(Utils.getNoNil(getXMLString(xmlFile, configKey..".innerRim#scale"), "1 1 1"), 3)
				wheel.hubFilename = getXMLString(xmlFile, configKey..".hub#filename")
				wheel.hubIndex = Utils.getNoNil(getXMLString(xmlFile, configKey..".hub#"..key), "0|0")
				wheel.hubOffset = Utils.getNoNil(getXMLFloat(xmlFile, configKey..".hub#offset"), 0)
				wheel.hubScale = Utils.getVectorNFromString(Utils.getNoNil(getXMLString(xmlFile, configKey..".hub#scale"), "1 1 1"), 3)
				wheel.hubWidthAndDiam = Utils.getVectorNFromString(getXMLString(xmlFile, configKey..".hub#widthAndDiam"), 2)
				wheel.additionalFilename = getXMLString(xmlFile, configKey..".additional#filename")
				wheel.additionalIndex = Utils.getNoNil(getXMLString(xmlFile, configKey..".additional#"..key), "0|0")
				wheel.additionalOffset = Utils.getNoNil(getXMLFloat(xmlFile, configKey..".additional#offset"), 0)
				wheel.additionalScale = Utils.getVectorNFromString(Utils.getNoNil(getXMLString(xmlFile, configKey..".additional#scale"), "1 1 1"), 3)
				wheel.additionalMass = Utils.getNoNil(getXMLFloat(xmlFile, configKey..".additional#mass"), 0)
				wheel.additionalWidthAndDiam = Utils.getVectorNFromString(getXMLString(xmlFile, configKey..".additional#widthAndDiam"), 2)
				break;
			end
			i = i + 1;
		end

		if not wheelConfigFound then
			print("Error: wheelConfigIndex '" .. wheelConfigIndex .. "' not found in '" .. xmlFilename .. "'")
			return
		end

		wheel.radius = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.size#radius"), 0.5);
		wheel.width = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.size#width"), wheel.radius * 0.8);
		wheel.xOffset = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.size#xOffset"), 0);
		wheel.maxDeformation = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.size#maxDeformation"), 0);

		wheel.mass = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.physics#mass"), wheel.mass) + wheel.additionalMass
		wheel.maxLongStiffness = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.physics#maxLongStiffness"), wheel.maxLongStiffness); -- [t / rad]
		wheel.maxLatStiffness = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.physics#maxLatStiffness"), wheel.maxLatStiffness); -- xml is ratio to restLoad [1/rad], final value is [t / rad]

		wheel.smoothGroundRadius = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.physics#smoothGroundRadius"), math.max(0.6, wheel.width*0.75));

		if isRealWheel then
			--20171108 - do not load friction scale from wheel xml file anymore
			--since patch 1.5, some default wheels have more than the default "2" value (2.5, 3 or 4 values => this is not "MR" compliant)
			--wheel.frictionScale = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.physics#frictionScale"), wheel.frictionScale);			
			local wheelXmlFrictionScale = getXMLFloat(xmlFile, "wheel.physics#frictionScale");
			if wheelXmlFrictionScale~=nil then
				wheel.frictionScale = 2
			end;
			
			local tireTypeName = getXMLString(xmlFile, "wheel.tire#type");
			if tireTypeName ~= nil then
				local tireType = WheelsUtil.getTireType(tireTypeName);
				if tireType ~= nil then
					wheel.tireType = tireType;
				else
					print("Warning: Failed to find tire type '"..tireTypeName.."'.");
				end
			end;

			wheel.maxLatStiffnessLoad = Utils.getNoNil(getXMLFloat(xmlFile, "wheel.physics#maxLatStiffnessLoad"), wheel.maxLatStiffnessLoad); -- xml is ratio to restLoad, final value is [t]
		end;

		wheel.tireTrackAtlasIndex = Utils.getNoNil(getXMLInt(xmlFile, "wheel.tire#atlasIndex"), 0);

		local loadWheelPart = function(wheel, parent, name, filename, index, offset, widthAndDiam, scale)
			if filename == nil then
				return
			end
			local i3dNode = Utils.loadSharedI3DFile(filename, self.baseDirectory, false, false, false);
			if i3dNode ~= 0 then
				wheel[name] = Utils.indexToObject(i3dNode, index);
				link(parent, wheel[name]);
				delete(i3dNode);

				if offset ~= 0 then
					local dir = 1
					if not wheel.isLeft then
						dir = -1
					end
					setTranslation(wheel[name], offset*dir, 0, 0)
				end
				if scale ~= nil then
					setScale(wheel[name], scale[1], scale[2], scale[3])
				end
				if widthAndDiam ~= nil then
					if getHasShaderParameter(wheel[name], "widthAndDiam") then
						setShaderParameter(wheel[name], "widthAndDiam", widthAndDiam[1], widthAndDiam[2], 0, 0, false)
					end
				end
			end;
		end

		loadWheelPart(wheel, wheel.linkNode,  "wheelTire",       wheel.tireFilename,       wheel.tireIndex,       0,                      nil,                          nil)
		loadWheelPart(wheel, wheel.wheelTire, "wheelOuterRim",   wheel.outerRimFilename,   wheel.outerRimIndex,   0,                      wheel.outerRimWidthAndDiam,   wheel.outerRimScale)
		loadWheelPart(wheel, wheel.wheelTire, "wheelInnerRim",   wheel.innerRimFilename,   wheel.innerRimIndex,   wheel.innerRimOffset,   wheel.innerRimWidthAndDiam,   wheel.innerRimScale)
		loadWheelPart(wheel, wheel.wheelTire, "wheelHub",        wheel.hubFilename,        wheel.hubIndex,        wheel.hubOffset,        wheel.hubWidthAndDiam,        wheel.hubScale)
		loadWheelPart(wheel, wheel.wheelTire, "wheelAdditional", wheel.additionalFilename, wheel.additionalIndex, wheel.additionalOffset, wheel.additionalWidthAndDiam, wheel.additionalScale)

		setRotation(wheel.wheelTire, xRotOffset, 0, 0)

		local x, y, z, _ = getShaderParameter(wheel.wheelTire, "morphPosition");
		setShaderParameter(wheel.wheelTire, "morphPosition", x, y, z, 0, false);

		local color = Utils.getNoNil(Utils.getNoNil(wheel.color, Vehicle.getColorByConfigId(self, "rimColor", self.configurations["rimColor"])), self.rimColor);
		if color ~= nil then
			local r,g,b,a = unpack(color);
			if wheel.wheelOuterRim ~= nil then
				setShaderParameter(wheel.wheelOuterRim, "colorScale", r, g, b, a, false);
			end
			if wheel.wheelInnerRim ~= nil then
				setShaderParameter(wheel.wheelInnerRim, "colorScale", r, g, b, a, false);
			end
		end

		local additionalColor = Utils.getNoNil(wheel.additionalColor, color);
		if wheel.wheelAdditional ~= nil and additionalColor ~= nil then
			local r,g,b,a = unpack(additionalColor);
			setShaderParameter(wheel.wheelAdditional, "colorScale", r, g, b, a, false);
		end

		local wheelAxisColor = Utils.getNoNil(wheel.axisColor, self.axisColor)
		if wheelAxisColor ~= nil then
			if wheel.wheelHub ~= nil then
				local r,g,b,a = unpack(wheelAxisColor);
				setShaderParameter(wheel.wheelHub, "colorScale", r, g, b, a, false);
			end
		end

		delete(xmlFile);
	end;
	
end;

--allow us to override position of the wheelShape directly in the xml without having to modify the i3d file
--especially useful for adding "dummy" wheels to help reducing friction forces between the implement and the ground (this is far better to use the powerConsumer specialization for this purpose)
Vehicle.mrLoadDynamicWheelDataFromXML2 = function(self, xmlFile, key, wheelnamei, wheel)

	--override wheel position if specified in the xml
	wheel.positionX = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrPositionX", getXMLFloat, wheel.positionX, nil, fallbackOldKey);	
	wheel.positionY = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrPositionY", getXMLFloat, wheel.positionY, nil, fallbackOldKey);	
	wheel.positionZ = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrPositionZ", getXMLFloat, wheel.positionZ, nil, fallbackOldKey);	
	
	wheel.startPositionX = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrPositionX", getXMLFloat, wheel.startPositionX, nil, fallbackOldKey);	
	wheel.startPositionY = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrPositionY", getXMLFloat, wheel.startPositionY, nil, fallbackOldKey);	
	wheel.startPositionZ = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrPositionZ", getXMLFloat, wheel.startPositionZ, nil, fallbackOldKey);	
	
	wheel.mrNoDeformation = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrNoDeformation", getXMLBool, false, nil, fallbackOldKey);
	wheel.mrAttachableRotationRootVehicleDependantValue = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrAttachableRotationRootVehicleDependantValue", getXMLFloat, 0, nil, fallbackOldKey);
	wheel.mrAttachableRotationRootVehicleDependantValue = math.rad(wheel.mrAttachableRotationRootVehicleDependantValue) -- degree to rad
	
	wheel.mrIsDummyWheel = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrDummyWheel", getXMLBool, false, nil, fallbackOldKey);

	
	if wheel.mrIsDummyWheel then		
		
		wheel.mrDummyWheelDirectionX = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrDummyWheelDirectionX", getXMLFloat, false, nil, fallbackOldKey)
		wheel.mrDummyWheelDirectionY = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrDummyWheelDirectionY", getXMLFloat, false, nil, fallbackOldKey)
		wheel.mrDummyWheelDirectionZ = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrDummyWheelDirectionZ", getXMLFloat, false, nil, fallbackOldKey)
		
		wheel.mrDummyWheelAxleDirectionX = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrDummyWheelAxleDirectionX", getXMLFloat, false, nil, fallbackOldKey)
		wheel.mrDummyWheelAxleDirectionY = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrDummyWheelAxleDirectionY", getXMLFloat, false, nil, fallbackOldKey)
		wheel.mrDummyWheelAxleDirectionZ = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrDummyWheelAxleDirectionZ", getXMLFloat, false, nil, fallbackOldKey)
				
		wheel.createTipOcclusionArea = false
		wheel.isSynchronized = false
		wheel.mass = 0.01
		wheel.mrDummyNode = createTransformGroup("dummyWheelNode")
		
		if wheel.mrDummyWheelDirectionX then
			wheel.directionX = wheel.mrDummyWheelDirectionX
		end
		if wheel.mrDummyWheelDirectionY then
			wheel.directionY = wheel.mrDummyWheelDirectionY
		end
		if wheel.mrDummyWheelDirectionZ then
			wheel.directionZ = wheel.mrDummyWheelDirectionZ
		end		
		if wheel.mrDummyWheelAxleDirectionX then
			wheel.axleX = wheel.mrDummyWheelAxleDirectionX
		end
		if wheel.mrDummyWheelAxleDirectionY then
			wheel.axleY = wheel.mrDummyWheelAxleDirectionY
		end
		if wheel.mrDummyWheelAxleDirectionZ then
			wheel.axleZ = wheel.mrDummyWheelAxleDirectionZ
		end		
		
		--link(self.components[1].node, wheel.mrDummyNode);
		link(wheel.driveNode, wheel.mrDummyNode)
		wheel.repr = wheel.mrDummyNode
		wheel.driveNode = wheel.mrDummyNode
		wheel.linkNode = wheel.mrDummyNode	
	end
	
end
Vehicle.loadDynamicWheelDataFromXML = Utils.prependedFunction(Vehicle.loadDynamicWheelDataFromXML, Vehicle.mrLoadDynamicWheelDataFromXML2);

--************************************************************************************************************************************************************
--FIX bug in Vehicle.loadDynamicWheelDataFromXML line 906 => the tireType specified in the wheel xml file is not taken into account when there is no tiretype defined in the vehicle xml file
--add parameter "mrOffsetX"
Vehicle.mrLoadDynamicWheelDataFromXML = function(self, xmlFile, key, wheelnamei, wheel)

	if not self.mrIsMrVehicle then
		return
	end	

	local fallbackOldKey = "vehicle.wheels";	
	
	-- 1. check if there is a tireType defined in the vehicle xml file
	local tireTypeName = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#tireType", getXMLString, "notDefined", nil, fallbackOldKey);
	
	if tireTypeName=="notDefined" then	
		-- 2. check if there is a wheel xml file
		local wheelXmlFilename = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#filename", getXMLString, nil, nil, fallbackOldKey);		
		if wheelXmlFilename ~= nil and wheelXmlFilename ~= "" then 
			-- 3. check if there is a tireType defined in the wheel xml file
			local wheelConfigIndex = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#configIndex", getXMLString, "basic", nil, fallbackOldKey);
			local xmlFilename = RealisticUtils.getFilename(wheelXmlFilename, self.baseDirectory);
			local xmlFileW = loadXMLFile("TempConfig", xmlFilename);
			if xmlFileW ~= nil then			
				local tireTypeNameW = getXMLString(xmlFileW, "wheel.tire#type");				
				if tireTypeNameW ~= nil then
					local tireType = WheelsUtil.getTireType(tireTypeNameW);					
					if tireType ~= nil then
						-- 4. replace the "default" mud type by the one specified in the wheel xml file if present and valid
						--print("test - wheel.tire typename="..tostring(tireTypeNameW) .. " - old int=" .. tostring(wheel.tireType) .. " - new int="..tostring(tireType));
						wheel.tireType = tireType;						
					end;
				end;
			end;
			delete(xmlFileW);
		end;
	end;	
	
	--load default damper settings if the vehicle is mr
	--if self.mrIsMrVehicle then
		local damper = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#damper", getXMLFloat, 0, nil, fallbackOldKey);	
		
		wheel.damperCompressionLowSpeed = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#damperCompressionLowSpeed", getXMLFloat, damper, nil, fallbackOldKey);	
		wheel.damperRelaxationLowSpeed = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#damperRelaxationLowSpeed", getXMLFloat, damper, nil, fallbackOldKey);

		local defaultHighSpeedDamper = 0.25*wheel.spring 
		if self.mrUseCarPhysics then
			defaultHighSpeedDamper = wheel.damperRelaxationLowSpeed * 2
		end
		
		wheel.damperCompressionHighSpeed = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#damperCompressionHighSpeed", getXMLFloat, wheel.damperCompressionLowSpeed, nil, fallbackOldKey); --trying to reduce the effect of the "tractor jumping" when rolling on a "ridge" shape. Expecially visible when driving slowly on a "curb" in town
		wheel.damperRelaxationHighSpeed = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#damperRelaxationHighSpeed", getXMLFloat, defaultHighSpeedDamper, nil, fallbackOldKey);	
		
		--IRL damper low shaft speed = 0-2 inch/s, medium = 2-8 inch/s, high = above 8 inch/s
		--in our case, since there are no such damper settings on a tractor, we only use the "highSpeed" damper settings to reduce some limitation of the wheelshape (which is only a "raycast", not a true "circle" or "sphere")
		wheel.damperCompressionLowSpeedThreshold = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#damperCompressionLowSpeedThreshold", getXMLFloat, 1, nil, fallbackOldKey); --default game=0.1016= 4 inch /s
		wheel.damperRelaxationLowSpeedThreshold = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#damperRelaxationLowSpeedThreshold", getXMLFloat, 1, nil, fallbackOldKey); --default game=0.1524= 6 inch /s		
	--end
	
	
	--load mr wheel parameters from vehicle xml file
	wheel.mrLateralStiffnessScale = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrLateralStiffnessScale", getXMLFloat, 1, nil, fallbackOldKey);
	wheel.mrLongitudinalStiffnessScale = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrLongitudinalStiffnessScale", getXMLFloat, 1, nil, fallbackOldKey);	
	wheel.mrNotAWheel = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrNotAWheel", getXMLBool, false or wheel.mrIsDummyWheel, nil, fallbackOldKey);	
	wheel.mrPressureFx = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrPressureFx", getXMLFloat, 1, nil, fallbackOldKey);

	--20170823 - add "maxDeformation" parameter to override wheel xml file value
	local overrideMaxDeformation = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#maxDeformation", getXMLFloat, nil, nil, fallbackOldKey)	
	if overrideMaxDeformation~=nil then
		--print("overrideMaxDeformation = "..tostring(overrideMaxDeformation))
		wheel.maxDeformation = overrideMaxDeformation
	end	
	
	
	wheel.mrForcePointOffsetX = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrForcePointOffsetX", getXMLFloat, 0.5*wheel.width, nil, fallbackOldKey);	
	--20170619 - a little less 'lower' for smaller wheels (approximately the same for bigger wheels)
	--local defaultForcePointOffsetY = 0.9*wheel.radius	
	local defaultForcePointOffsetY = wheel.radius-0.2
	wheel.mrForcePointOffsetY = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrForcePointOffsetY", getXMLFloat, defaultForcePointOffsetY, nil, fallbackOldKey); -- 20170513 - increase value to get more "swinging"

	wheel.mrStabilizingSteeringAngle = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrStabilizingSteeringAngle", getXMLFloat, 0, nil, fallbackOldKey); --degree
	--degree to rad
	wheel.mrStabilizingSteeringAngle = wheel.mrStabilizingSteeringAngle * math.pi/180;
	if wheel.positionX<0 then
		wheel.mrStabilizingSteeringAngle = -wheel.mrStabilizingSteeringAngle;
	end	
	
	--20170617 - new mr parameter
	local mrOffsetX = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrOffsetX", getXMLFloat, nil, nil, fallbackOldKey)
	if mrOffsetX~=nil then
		if not wheel.isLeft then	
			mrOffsetX = -mrOffsetX
		end		
		wheel.startPositionX = wheel.startPositionX + mrOffsetX		
	end
	
	--20170705 - new mr parameter to allow to brake a wheel (even if driven) while steering
	local applySteeringBrakingForce = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrApplySteeringBrakingForce", getXMLFloat, 0, nil, fallbackOldKey)
	wheel.mrApplyBrakeDuringVehicleSteering = applySteeringBrakingForce~=0
	if wheel.mrApplyBrakeDuringVehicleSteering then		
		wheel.mrApplyBrakeDuringVehicleSteeringMaxBrakeForce = math.abs(applySteeringBrakingForce)
		wheel.mrApplyBrakeDuringVehicleSteeringLeft = applySteeringBrakingForce>0
		wheel.mrApplyBrakeDuringVehicleSteeringMaxBrakeForceReverseFx = Vehicle.getConfigurationValue(xmlFile, key, wheelnamei, "#mrApplySteeringBrakingForceReverseFx", getXMLFloat, 1, nil, fallbackOldKey)
	end
	
	--intitiate mr variables	
	wheel.mrLastWheelSpeed = 0
	wheel.mrCurrentRollingResistance = 0.02;	
	wheel.mrLastTireLoad = wheel.restLoad;
	wheel.mrLastLongSlip = 1;
	wheel.mrRealLongSlip = 1;
	wheel.mrLastLatSlip = 0.35;	
	wheel.mrAvgLongSlip = 1;
	wheel.mrLastA = 0; --see vehicle "r, g, b, a = Utils.getTireTrackColorFromDensityBits(densityBits)" or "r, g, b, a, t = getTerrainAttributesAtWorldPos(g_currentMission.terrainRootNode, wx, wy, wz, true, true, true, true, false);"
	wheel.mrIsOnField = false;
	wheel.mrLastTerrainDensityBits = 0
	--wheel.mrLastFrictionFx = 1;
	wheel.mrContactPoint = {x=0, y=0, z=0, isValid=false, lastVelocityX=0, lastVelocityY=0, lastVelocityZ=0}
	wheel.mrLastLateralForceApplied = {fx=0, fy=0, fz=0}
	wheel.mrLastVelocityAngleComparedToComponent = 0
	wheel.mrAdditionnalFrictionFx = 1
	wheel.mrLastContactNormalY = 1
	wheel.mrSnowDepthFactorS = 0	
	
end;
Vehicle.loadDynamicWheelDataFromXML = Utils.appendedFunction(Vehicle.loadDynamicWheelDataFromXML, Vehicle.mrLoadDynamicWheelDataFromXML);



----------------------------------------------------------------------------------------------------
-- 20170812 - support the "$mr" tag when loading dynamic part 
-- example : Jenz BA725D (testing dynamically loading of a new moveCollision shape with higher friction - high friction is lost in the process -> removed)
----------------------------------------------------------------------------------------------------
Vehicle.mrLoadDynamicallyPartsFromXML = function(self, superFunc, dynamicallyLoadedPart, xmlFile, key)

	if not self.mrIsMrVehicle then
		return superFunc(self, dynamicallyLoadedPart, xmlFile, key)
	end	

    local filename = getXMLString(xmlFile, key .. "#filename")
	
	--MR : support the "$mr" tag to get resources from the "morerealistic" folder
	filename = RealisticUtils.getFilename(filename, nil)
	
    if filename ~= nil then
        dynamicallyLoadedPart.filename = filename
        local i3dNode = Utils.loadSharedI3DFile(filename, self.baseDirectory, false, false, false)
        if i3dNode ~= 0 then
            local node = Utils.indexToObject(i3dNode, Utils.getNoNil(getXMLString(xmlFile, key .. "#node"), "0|0"))
            local linkNode = Utils.indexToObject(self.components, Utils.getNoNil(getXMLString(xmlFile, key .. "#linkNode"), "0>"))
            local x,y,z = Utils.getVectorFromString(getXMLString(xmlFile, key .. "#position"))
            if x ~= nil and y ~= nil and z ~= nil then
                setTranslation(node, x,y,z)
            end
            local rotX, rotY, rotZ = Utils.getVectorFromString(getXMLString(xmlFile, key .. "#rotation"))
            if rotX ~= nil and rotY ~= nil and rotZ ~= nil then
                rotX = Utils.degToRad(rotX)
                rotY = Utils.degToRad(rotY)
                rotZ = Utils.degToRad(rotZ)
                setRotation(node, rotX, rotY, rotZ)
            end;
            local shaderParameterName = getXMLString(xmlFile, key .. "#shaderParameterName")
            local x,y,z,w = Utils.getVectorFromString(getXMLString(xmlFile, key .. "#shaderParameter"))
            if shaderParameterName ~= nil and x ~= nil and y ~= nil and z ~= nil and w ~= nil then
                setShaderParameter(node, shaderParameterName, x, y, z, w, false)
            end;
			
            link(linkNode, node)
            delete(i3dNode)			
			
            return true
        end
	end
	return false
end
Vehicle.loadDynamicallyPartsFromXML = Utils.overwrittenFunction(Vehicle.loadDynamicallyPartsFromXML, Vehicle.mrLoadDynamicallyPartsFromXML);





--************************************************************************************************************************************************************
--loading the settings for the additional lateral forces (especially useful for multi-components articulated vehicles)
Vehicle.mrLoadAdditionnalLateralForcesSettings = function(self)
	--20170619 - applying wheel additionnal lateral forces to a single component	
	self.mrLateralForces = {}
	local useSingleComponent = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.lateralForces#useSingleComponent"), false)
	self.mrLateralForces.useSingleComponent = useSingleComponent
	if useSingleComponent then
		local componentIndex = Utils.getNoNil(getXMLInt(self.xmlFile, "vehicle.moreRealistic.lateralForces#componentIndex"), 1)		
		if self.components[componentIndex]==nil then
			RealisticUtils.printWarning("Vehicle.mrLoadFinished2", "Wrong 'lateralForces componentIndex' in xml file of the vehicle. 'componentIndex'="..tostring(componentIndex), false)
			componentIndex = 1
		end
		self.mrLateralForces.singleComponentNode = self.components[componentIndex].node
	end
	
end




--************************************************************************************************************************************************************
Vehicle.mrUpdateWheelTireFriction = function(self, wheel)	
	
	if self.isServer and self.isAddedToPhysics then
	
		if not self.firstTimeRun or wheel.mrNotAWheel then				
			setWheelShapeTireFriction(wheel.node, wheel.wheelShape, 10*wheel.mrLongitudinalStiffnessScale, 100*wheel.mrLateralStiffnessScale, 141*wheel.mrLateralStiffnessScale, wheel.frictionScale*0.5);		
		else
		
		
			--TEST 5
			--local longStiff = 0.707 * wheel.mrLastTireLoad
			local loadFactor = wheel.mrLastTireLoad
			if loadFactor == 0 then
				--since patch 1.5 getWheelShapeContactForce returns a 0 value when the vehicle is not active
				loadFactor = 50
			end
			local longStiff = 0.5*loadFactor*wheel.mrLongitudinalStiffnessScale
			local latStiff = loadFactor*wheel.mrLateralStiffnessScale
			local latStiffLoad = latStiff*1.5*wheel.mrLateralStiffnessScale
			local friction = wheel.tireGroundFrictionCoeff*wheel.frictionScale*0.5
			--reduce lateral stiffness managed by the base physics game engine
			--and then we compute and apply lateral force with our own mechanism (allow us to override the "capped" tireforce values because lateral and longitudinal forces share a given amount of force)
			
			
			local cheatingFrictionFx = 1
			--test for CARS
			local isCAR = self.mrUseCarPhysics
			if isCAR then
				longStiff = 20*wheel.mrLongitudinalStiffnessScale
				latStiff = 100*wheel.mrLateralStiffnessScale
				latStiffLoad = 2
				--friction function of speed
				cheatingFrictionFx = (1 + 20*self.lastSpeedReal) -- 1.66666 @120kph
			else
				--20170620 a little more friction for steered wheels
				cheatingFrictionFx = math.min(1.5, 1+0.7*math.abs(math.sin(WheelsUtil.mrGetWheelSteeringAngle(wheel)))) -- steering angle in radian (50° = 0.87266)
			end
			wheel.mrAdditionnalFrictionFx = cheatingFrictionFx			
			
			--print(tostring(g_currentMission.time) .. "test setWheelShapeTireFriction - longStiff="..tostring(longStiff))
			setWheelShapeTireFriction(wheel.node, wheel.wheelShape, longStiff, latStiff, latStiffLoad, friction*cheatingFrictionFx);	
			--setWheelShapeTireFriction(wheel.node, wheel.wheelShape, longStiff*wheel.mrLongitudinalStiffnessScale, latStiff*wheel.mrLateralStiffnessScale, 50*wheel.mrLateralStiffnessScale, wheel.tireGroundFrictionCoeff*wheel.frictionScale*0.5);	
			--if self.mrVehicleIsStill then
			--	print(tostring(g_currentMission.time) .. "test setWheelShapeTireFriction - self.time="..tostring(self.time) .. " test")
			--	setWheelShapeTireFriction(wheel.node, wheel.wheelShape, longStiff, latStiff, latStiffLoad, friction*cheatingFrictionFx);	
			--end
			
			--if wheel.hasGroundContact and wheel.mrLastTireLoad>0 and not self.mrVehicleIsStill then
			--print(tostring(g_currentMission.time) .. " - mrLastTireLoad="..tostring(self.mrLastTotalTiresLoad))
			if wheel.hasGroundContact and wheel.mrLastTireLoad>0 and self.mrLastTotalTiresLoad>0 and not self.mrVehicleIsStill then --20170818 - check mrLastTotalTiresLoad
				--local gameTime = 0;
				--if g_currentMission then gameTime = g_currentMission.time; end
				--print(tostring(gameTime) .. " - wheel.node="..tostring(wheel.node) .." - wheel.wheelShape="..tostring(wheel.wheelShape));
				--local cpx, cpy, cpz = getWheelShapeContactPoint(wheel.node, wheel.wheelShape)
				--we have to put the 'getWheelShapeContactPoint' in the 'mrManageWheelsFriction' because otherwise, we get "wheelshape" not valid warning in the log when we attach/detach a hardAttached implement
			
				if wheel.mrContactPoint.isValid and self.lastSpeedReal>0.00012 then -- 0.00012 = 0.4kph -> we don't want to try to add lateral force if the vehicle move too slowly because the velocity vector can be completely "off" in such case (not right at all)
				--get lateral slip	

				
					--20170618
					local forcePointX = wheel.mrContactPoint.x
					local forcePointY = wheel.mrContactPoint.y
					local forcePointZ = wheel.mrContactPoint.z
					local nodeToGetDataFrom = wheel.node
					local nodeToApplyForceTo = wheel.node
					if self.mrLateralForces.useSingleComponent then
						nodeToGetDataFrom = self.mrLateralForces.singleComponentNode
						nodeToApplyForceTo = self.mrLateralForces.singleComponentNode
						if nodeToApplyForceTo~=wheel.node then
							forcePointX, forcePointY, forcePointZ = getWorldTranslation(wheel.node)
						end
					end
						
					--20170514 - getVelocityAtWorldPos is not "precise" enough at low speed - too much trouble
					--and so, at "low" speed, we are using the component velocity vector
					local vx, vy, vz = getVelocityAtWorldPos(nodeToGetDataFrom, wheel.mrContactPoint.x, wheel.mrContactPoint.y, wheel.mrContactPoint.z)
					
				
					
					if vx~=nil and vy~=nil and vz~=nil then
						
						wheel.mrContactPoint.lastVelocityX = vx
						wheel.mrContactPoint.lastVelocityY = vy
						wheel.mrContactPoint.lastVelocityZ = vz						
					
						--we have to find a way to compare the velocity vector with the wheelshape current direction
						--print("test - steeringAngle = " .. tostring(wheel.steeringAngle) .. "- degree="..tostring(wheel.steeringAngle*180/math.pi))						
						local slx, sly, slz = worldDirectionToLocal(nodeToGetDataFrom, vx, vy, vz)	
						local velocityLen = Utils.vector2Length(slx, slz)						
						
						if velocityLen>0.3 then	--no need to try to apply the additionnal lateral force at low speed because the velocity vector can be completely "off" (not right at all)
						
							local getLatForce = function(angle, maxBaseForce)								
								--local force = 0.9*(1-math.exp(-5.73*math.abs(angle))) -- "resonance" problem
								--local force = math.min(math.sqrt(math.abs(angle)), 0.8) -- "resonance" problem
								--local force = math.min(2*math.abs(angle), 0.6)
								
								local force = 0.75*(1-math.exp(-8*math.abs(angle)))								
								force = force * self.mrAdditionalLateralForcesScale --20170818
								
								if isCAR then
									--20170523 - check the longitudinal slip. Lateral slip should be weaker when the longitudinal slip is high
									force = 0.4*math.min(math.abs(angle), 1.5)
									--force = force * (1-0.25*wheel.mrRealLongSlip)
									--force = 0									
								end
								
								force = math.min(maxBaseForce, force) * wheel.mrLastTireLoad * wheel.tireGroundFrictionCoeff * wheel.mrLateralStiffnessScale
								
								--at very low speed, scale the force with the velocity len because the velocity vector can be "off"
								--force = force * math.min(1, 0.5*velocityLen) 20170512 - scale the force by the vehicle speed instead of the wheel velocity length
								force = force * math.min(1, 600*self.lastSpeedReal) -- max friction at 6kph
								
								--cap the max force possible in case something is going wrong (vehicle flying in the air and 'landing' brutally ?)
								force = math.min(1000, force)
								
								return force
							end

							
							if Vehicle.mrDebugForcesRendering then
								--*** display the velocity force	
								drawDebugLine(wheel.mrContactPoint.x, wheel.mrContactPoint.y, wheel.mrContactPoint.z, 0,0,1, wheel.mrContactPoint.x+vx, wheel.mrContactPoint.y+vy, wheel.mrContactPoint.z+vz, 0,1,1)
							end	
							--local maxLateralForceScale = 1					
							
							local velocityAngleComparedToComponent = math.asin(slx/velocityLen)
							local wheelSteeringAngle = WheelsUtil.mrGetWheelSteeringAngle(wheel)
							
							
							--check wheel.axleX and wheel.axleZ
							local useForceDirZ = false --false 20170523 - give better result when "cornering" (especially with a full trailer)
							if wheel.axleX~=0 and wheel.axleZ~=0 then
								--print("wheel "..tostring(wheel.mrNum).." additionnal angle = " .. tostring(math.atan(wheel.axleZ/wheel.axleX)*180/math.pi))
								useForceDirZ = true
								wheelSteeringAngle = wheelSteeringAngle - math.atan(wheel.axleZ/wheel.axleX)
							end
							
							if isCAR then
								useForceDirZ = true
							end
							
							
							
							--if wheel.versatileYRot and self.isActive then
							--	print("test versatileYRot - velocityAngleComparedToComponent="..tostring(velocityAngleComparedToComponent*180/math.pi) .. " - steeringAngle="..tostring(wheel.steeringAngle*180/math.pi) .. " - newSteeringAngle="..tostring(wheelSteeringAngle*180/math.pi))
							--end
							
							if wheelSteeringAngle==0 then
							
								if math.abs(velocityAngleComparedToComponent)>0.01 then --0.01 = 0.573°
									
									-- 1 radian = 57.3°
									--local force = -Utils.clamp(velocityAngleComparedToComponent, -maxLateralForceScale, maxLateralForceScale) * wheel.mrLastTireLoad * wheel.tireGroundFrictionCoeff * wheel.mrLateralStiffnessScale --can be positive or negative
									local force = getLatForce(velocityAngleComparedToComponent, math.abs(slx))
									
									
									--20170514 - the 'response force' can't be greater than the velocity vector
									--force = math.min(force, math.abs(slx)*)
									force = -Utils.sign(velocityAngleComparedToComponent)*force
									
									local fx, fy, fz = localDirectionToWorld(nodeToApplyForceTo, force, 0, 0)
									
									--if self.isEntered and wheel.mrNum==1 then
									--print("wheel "..tostring(wheel.mrNum).." - velocityAngleComparedToComponent="..tostring(velocityAngleComparedToComponent*180/math.pi) .. " - fx="..tostring(fx) .. " - fy="..tostring(fy) .. " - fz="..tostring(fz))
									--end
									
									fx = (fx+wheel.mrLastLateralForceApplied.fx)/2
									fy = (fy+wheel.mrLastLateralForceApplied.fy)/2
									fz = (fz+wheel.mrLastLateralForceApplied.fz)/2
									
									if not self.mrDebugNoForces then
										addForce(nodeToApplyForceTo, fx, fy,fz, forcePointX, forcePointY, forcePointZ, false)
									end
									wheel.mrLastLateralForceApplied.fx = fx
									wheel.mrLastLateralForceApplied.fy = fy
									wheel.mrLastLateralForceApplied.fz = fz
									
									if Vehicle.mrDebugForcesRendering then
										--*** display the force applied	
										local fx, fy, fz = localDirectionToWorld(nodeToApplyForceTo, -10*velocityAngleComparedToComponent, 0, 0)
										drawDebugLine(forcePointX, forcePointY, forcePointZ, 1,0,0, forcePointX+fx, forcePointY+fy, forcePointZ+fz, 0,1,0)
										--*** display the wheel direction										
										local tx, ty, tz = localDirectionToWorld(nodeToGetDataFrom, 0, 0, 1)
										drawDebugLine(wheel.mrContactPoint.x, wheel.mrContactPoint.y, wheel.mrContactPoint.z, 1,1,0, wheel.mrContactPoint.x+tx, wheel.mrContactPoint.y+ty, wheel.mrContactPoint.z+tz, 1,0,1)
									end		
									
								end	
								
							else 
								--steering wheel	
								if slz<0 then									
									velocityAngleComparedToComponent = math.pi - velocityAngleComparedToComponent
								end
								
								--if self.isEntered then
								--print("wheel "..tostring(wheel.mrNum).." - velocityAngleComparedToComponent="..tostring(velocityAngleComparedToComponent*180/math.pi) .. " - steeringAngle="..tostring(wheel.steeringAngle*180/math.pi))
								--end
								
								local slipAngle = math.abs(wheelSteeringAngle-velocityAngleComparedToComponent) -- wheel.steeringAngle and velocityAngleComparedToComponent = Z axis as horizontal axis in the trigo circle
								if slipAngle>0.5*math.pi then
									slipAngle = math.abs(math.pi-slipAngle)
								end
									
								if slipAngle>0.01 then --0.01 = 0.573°					
									
									
									local forceDirX = math.cos(-wheelSteeringAngle)
									local forceDirZ = math.sin(-wheelSteeringAngle)									
									--compute length between the forceDir point and the velocity point
									local testLen = Utils.vector2Length(slx-forceDirX, slz-forceDirZ)
									
									--then, check again with the other forcedirX possibility
									local forceDirX2 = math.cos(-wheelSteeringAngle+math.pi)
									local forceDirZ2 = math.sin(-wheelSteeringAngle+math.pi)
									local testLen2 = Utils.vector2Length(slx-forceDirX2, slz-forceDirZ2)
									
									if Vehicle.mrDebugForcesRendering then
										--*** display the 2 forceDir possible ***
										local tx, ty, tz = localDirectionToWorld(nodeToApplyForceTo, forceDirX, 0, forceDirZ)
										drawDebugLine(wheel.mrContactPoint.x, wheel.mrContactPoint.y-0.05, wheel.mrContactPoint.z, 1,0,0, wheel.mrContactPoint.x+tx, wheel.mrContactPoint.y+ty-0.05, wheel.mrContactPoint.z+tz, 1,0,0)
										local tx, ty, tz = localDirectionToWorld(nodeToApplyForceTo, forceDirX2, 0, forceDirZ2)
										drawDebugLine(wheel.mrContactPoint.x, wheel.mrContactPoint.y-0.05, wheel.mrContactPoint.z, 1,0,0, wheel.mrContactPoint.x+tx, wheel.mrContactPoint.y+ty-0.05, wheel.mrContactPoint.z+tz, 1,0,0)
									end
									
									--if self.isEntered then
									--print("wheel "..tostring(wheel.mrNum).." - slipAngle="..tostring(slipAngle*180/math.pi) .. " - len1="..tostring(testLen).." - len2="..tostring(testLen2))
									--end
									
									--keep the longest
									if testLen2>testLen then
										forceDirX = forceDirX2
										forceDirZ = forceDirZ2 
									end
									
									--20170514 - the 'response force' can't be greater than the velocity vector
									local maxBaseForce = 0									
									if useForceDirZ then
										maxBaseForce = velocityLen
									else
										forceDirZ = 0 -- result are better without the forceDirZ
										maxBaseForce =  math.abs(slx)
									end

									--local force1 = -Utils.clamp(slipAngle, -maxLateralForceScale, maxLateralForceScale) * wheel.mrLastTireLoad * wheel.tireGroundFrictionCoeff * wheel.mrLateralStiffnessScale --can be positive or negative
									local force = getLatForce(slipAngle, maxBaseForce)
									--if self.isEntered then
										--print("wheel "..tostring(wheel.mrNum).." - slipAngle="..tostring(slipAngle*180/math.pi) .. " - force="..tostring(force))
									--end
									
									
									
									local fx, fy, fz = localDirectionToWorld(nodeToApplyForceTo, forceDirX*force, 0, forceDirZ*force)
									fx = (fx+wheel.mrLastLateralForceApplied.fx)/2
									fy = (fy+wheel.mrLastLateralForceApplied.fy)/2
									fz = (fz+wheel.mrLastLateralForceApplied.fz)/2
									if not self.mrDebugNoForces then
										addForce(nodeToApplyForceTo, fx, fy, fz, forcePointX, forcePointY, forcePointZ, false)
									end
									wheel.mrLastLateralForceApplied.fx = fx
									wheel.mrLastLateralForceApplied.fy = fy
									wheel.mrLastLateralForceApplied.fz = fz	
									
									if Vehicle.mrDebugForcesRendering then
										--*** display the force applied	
										local fx, fy, fz = localDirectionToWorld(nodeToApplyForceTo, 10*forceDirX*slipAngle, 0, 10*forceDirZ*slipAngle)
										drawDebugLine(forcePointX, forcePointY, forcePointZ, 1,0,0, forcePointX+fx, forcePointY+fy, forcePointZ+fz, 0,1,0)
										--*** display the wheel direction
										local wheelDirX = math.sin(wheelSteeringAngle)
										local wheelDirZ = math.cos(wheelSteeringAngle)
										local tx, ty, tz = localDirectionToWorld(nodeToGetDataFrom, wheelDirX, 0, wheelDirZ)
										drawDebugLine(wheel.mrContactPoint.x-tx, wheel.mrContactPoint.y-ty, wheel.mrContactPoint.z-tz, 1,1,0, wheel.mrContactPoint.x+tx, wheel.mrContactPoint.y+ty, wheel.mrContactPoint.z+tz, 1,0,1)
										
										--if self.isEntered then
										--	print("wheel "..tostring(wheel.mrNum).." - slipAngle="..tostring(slipAngle*180/math.pi))
										--end
									end									
									
								end
								
							end
						
						end					
						
					end
				end
			end
			
		end -- if not self.firstTimeRun or wheel.mrNotAWheel then	
				
	end --if self.isServer and self.isAddedToPhysics then
		
end;

--cheat the application force point for wheelshape so that we can use correct center of gravity for vehicles without having them to flip everytime they are cornering
Vehicle.mrUpdateWheelBase2 = function(self, superFunc, wheel, allowedToCreate)

	--problem to fix = when calling the "createWheelShape" function, a new physical wheel is created and its "index" is stored in the "wheel.wheelShape" parameter.
	--but the newly created wheelshape can't return any values yet (getWheelShapeXXXX function)
	--and so, we can get several "Physics: wheel shape not found" warnings in the log.txt
	--sometimes, there are no errors, because the id of the wheelshape = same id as a pending wheeshape to delete (and so, there are still data available for it)
	
	--solution = updateWheelBase should be the last thing called (after "update" has been run ?) and "self.mrWheelShapesValid = true" should be the first thing of a "loop" (update)

	if not self.mrIsMrVehicle then
		return superFunc(self, wheel);
	end;
	
	--print(tostring(g_currentMission.time) .. " test mrUpdateWheelBase2 - updateWheelsTime=" .. tostring(self.updateWheelsTime) .. "  wheelShape = " .. tostring(wheel.wheelShape) .. " - allowedToCreate="..tostring(allowedToCreate) .. " wheelnum=" .. tostring(wheel.mrNum) .. " configFile="..self.configFileName)
	
	if wheel.wheelShape==0 or allowedToCreate then		
		superFunc(self, wheel);
		if self.isServer and self.isAddedToPhysics then
			local xResult = wheel.positionX;
			if wheel.positionX>0 then
				xResult = xResult + wheel.mrForcePointOffsetX;
			else
				xResult = xResult - wheel.mrForcePointOffsetX;
			end;		
			--print("test mrUpdateWheelBase - wheel.mrForcePointOffsetX="..tostring(wheel.mrForcePointOffsetX) .. " - wheel.mrForcePointOffsetY="..tostring(wheel.mrForcePointOffsetY) .. " - resultX="..tostring(xResult) .. " - resultY="..tostring(wheel.positionY-wheel.mrForcePointOffsetY));
			--print("test mrUpdateWheelBase - wheel.node="..tostring(wheel.node) .. " - shape="..tostring(wheel.wheelShape))
			setWheelShapeForcePoint(wheel.node, wheel.wheelShape, xResult, wheel.positionY-wheel.mrForcePointOffsetY, wheel.positionZ);					
		end;
		self.mrWheelShapesValid = false;
	else
		--mark the wheel to be created in the "post update" function
		--because createWheelShape should be the last thing to do to wheels in an update loop, otherwise, there are no wheel data for "getWheelShapeXXXX" function
		--which means we can get a lot of "Physics: wheel shape not found, object..." warning messages in the log
		wheel.mrNeedCreate = true;
		self.mrNeedCreateWheel = true;
	end;
    
end;
Vehicle.updateWheelBase = Utils.overwrittenFunction(Vehicle.updateWheelBase, Vehicle.mrUpdateWheelBase2);

--************************************************************************************************************************************************************
--compute needed friction factor to achieve the desired longitudinal force
Vehicle.mrManageWheelsFriction = function(self, dt)
		
	--local frictionAdjust = 0;
	local totalMotorizedWheels = 0;	
	local totalDrivenWheelsSpeed = 0;	
	local numDrivenWheels = 0;
	local totalWheelSlip = 0;
	
	--FOR DEBUG	--		
	local sumGroundFrictionCoeff = 0;
	local totalLoadOnTires = 0;
	--END FOR DEBUG --	
	
	self.mrLastTotalTiresLoad = 0	
			
	for _,wheel in ipairs(self.wheels) do
		local wheelSpd = wheel.mrLastWheelSpeed*wheel.radius; -- m per second
		if wheel.mrIsDriven then
			totalDrivenWheelsSpeed = totalDrivenWheelsSpeed + wheelSpd;
			numDrivenWheels = numDrivenWheels + 1;
		end	
		
		wheel.mrContactPoint.isValid = false
	
		if not wheel.mrNotAWheel and wheel.hasGroundContact and self.mrWheelShapesValid then --20170520 - check wheelshapes are valid	
			--get current load on the wheel
			local tireLoad = getWheelShapeContactForce(wheel.node, wheel.wheelShape);
			if tireLoad ~= nil then	
				
				local nx,ny,nz = getWheelShapeContactNormal(wheel.node, wheel.wheelShape);
				wheel.mrLastContactNormalY = ny
				local dx,dy,dz = localDirectionToWorld(wheel.node, 0,-1,0)				
				wheel.mrLastTireLoad = math.max(0, -tireLoad*Utils.dotProduct(dx,dy,dz, nx,ny,nz)); -- 20170311 - protection to avoid negative value for the wheel load (amazone cayron for example)
				wheel.mrLastTireLoad = wheel.mrLastTireLoad + math.max(ny*9.81, 0.0) * wheel.mass; --add gravity force of tire	
			
				--20170818 - add total tire load
				self.mrLastTotalTiresLoad = self.mrLastTotalTiresLoad + wheel.mrLastTireLoad
				
				--local gameTime = 0;
				--if g_currentMission then gameTime = g_currentMission.time; end
				--print(tostring(gameTime) .. " - wheel.node="..tostring(wheel.node) .." - wheel.wheelShape="..tostring(wheel.wheelShape));
				local cpx, cpy, cpz = getWheelShapeContactPoint(wheel.node, wheel.wheelShape)
				if cpx~=nil and cpy~=nil and cpz~=nil then
					wheel.mrContactPoint.x=cpx
					wheel.mrContactPoint.y=cpy
					wheel.mrContactPoint.z=cpz
					wheel.mrContactPoint.isValid = true
				end
				
				if Vehicle.debugRendering then
					wheel.mrLastContactForce = tireLoad;
					totalLoadOnTires = totalLoadOnTires	+ tireLoad;	
				end
			else
				wheel.mrLastTireLoad = 0;
				wheel.mrLastContactForce = 0;
			end;
			
			
						
			if self.motorizedNode then	
				wheel.mrRealLongSlip = 1;
				--compute our longitudinal slip (formula = 1 - groundSpeed/wheelSpeed)
				local displaySlip = 0
								
				local absWheelSpd = math.abs(wheelSpd);
				if self.movingDirection~=0 and self.movingDirection*wheelSpd<0 then
					absWheelSpd = 0;
					if absWheelSpd>0.1 then
						displaySlip = 1
					end
				end				
				if absWheelSpd>0.1 then
					if absWheelSpd>=self.lastSpeedReal*1000 then
						wheel.mrRealLongSlip = 1 - self.lastSpeedReal*1000/absWheelSpd;
					elseif self.lastSpeedReal>0.0001 then --0.36kph
						wheel.mrRealLongSlip = 1 - absWheelSpd/(self.lastSpeedReal*1000);
					end	
					displaySlip = wheel.mrRealLongSlip
				end

				--if (wheel.tireGroundFrictionCoeff*1.2)<1 then
				--	frictionAdjust = frictionAdjust + (1.2-0.2*wheel.mrRealLongSlip^1.5);
				--else
					--frictionAdjust = frictionAdjust + 1;
				--end;	

				wheel.mrAvgLongSlip	= wheel.mrAvgLongSlip * 0.95 + wheel.mrRealLongSlip * 0.05;
				if wheel.mrIsDriven then
					totalWheelSlip = totalWheelSlip + displaySlip;			
					totalMotorizedWheels = totalMotorizedWheels + 1;
				end
				
				---------- debug ----------------
				if Vehicle.debugRendering then
					
					--update longitudinal slip
					local longSlip, latSlip
					if self.mrWheelShapesValid then
						longSlip, latSlip = getWheelShapeSlip(wheel.node, wheel.wheelShape);
					end
					if longSlip ~= nil then
						if self.lastSpeedReal<0.0001 then -- 0.36kph
							longSlip = 1;
						end;
						wheel.mrLastLongSlip = longSlip;	-- longSlip is always "positive"				
					else
						wheel.mrLastLongSlip = 1;				
					end;	

					--update lateral slip
					if latSlip ~= nil then
						wheel.mrLastLatSlip = latSlip;				
					else
						wheel.mrLastLatSlip = 0.35;				
					end;						
					
					sumGroundFrictionCoeff = sumGroundFrictionCoeff + wheel.tireGroundFrictionCoeff;										
					
				end--end debug
				
			end
			
		else
			--no contact			
			wheel.mrLastContactForce = 0;
			wheel.mrLastTireLoad = 0;	
			wheel.mrAvgLongSlip	= 0;
			wheel.mrRealLongSlip = 1;			
		end--wheel contact			
		
	end --foreach wheel
	
	--if totalMotorizedWheels>0 then
		--self.mrWheelsFrictionFactor = frictionAdjust/totalMotorizedWheels;
	--end;
	
	--more friction when speed increase to help physx engine with heavy load at "high" speed
	--[[
	self.mrWheelsFrictionFactor = 1;
	if self.lastSpeedReal>0.005 then -- 18kph
		if self.attacherVehicle then
			self.mrWheelsFrictionFactor = 1 + math.min(2, 30*(self.lastSpeedReal-0.005));
		else
			self.mrWheelsFrictionFactor = 1 + math.min(2, 60*(self.lastSpeedReal-0.005));
		end
	end--]]
	if numDrivenWheels>0 then
		self.mrAvgDrivenWheelsSpeed = totalDrivenWheelsSpeed / numDrivenWheels;
	end
	
	
	for _,wheel in ipairs(self.wheels) do
		if not wheel.mrNotAWheel then	

			--20180414 - fix for snow with Season and FS17 patch 1.5
			if self.isAddedToPhysics and self.mrWheelShapesValid then
				local contactObject, contactSubShapeIndex = getWheelShapeContactObject(wheel.node, wheel.wheelShape);					
				if contactObject == g_currentMission.terrainRootNode and contactSubShapeIndex > 0 then
					wheel.contact = Vehicle.WHEEL_GROUND_HEIGHT_CONTACT;
				end
			end
		
			if wheel.contact ~= Vehicle.WHEEL_NO_CONTACT then
				local groundType = WheelsUtil.getGroundType(wheel.mrIsOnField, wheel.contact ~= Vehicle.WHEEL_GROUND_CONTACT, wheel.mrLastA);
				--local coeff = WheelsUtil.getTireFriction(wheel.tireType, groundType, g_currentMission.environment.groundWetness);
				local coeff = WheelsUtil.mrGetTireFriction(wheel, groundType, g_currentMission.environment.groundWetness);
				--if coeff ~= wheel.tireGroundFrictionCoeff then
				wheel.tireGroundFrictionCoeff = coeff;						
				--end			
			end					
			self:updateWheelTireFriction(wheel);
			------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
		end
	end
	
	--update avg wheel slip
	if totalMotorizedWheels>0 then
		self.mrLastWheelsSlip = totalWheelSlip/totalMotorizedWheels;		
	else
		self.mrLastWheelsSlip = 0;
	end	
	
	
	
	------------------------------------------------------------------------------------------------------------------------------
	--- DEBUG
	if Vehicle.mrCanDisplayDebug(self) and self.isServer and self.motor~=nil then
		
		--update total load on tire
		self.mrTotalWeightOnTires = totalLoadOnTires;
		
		--update avg wheel slip
		if totalMotorizedWheels>0 then
			self.mrAvgWheelSlip = self.mrAvgWheelSlip*0.98 + 0.02 * totalWheelSlip/totalMotorizedWheels;	
			self.mrAvgWheelGroundFrictionCoeff = sumGroundFrictionCoeff/totalMotorizedWheels;
		else
			self.mrAvgWheelSlip = 0;
			self.mrAvgWheelGroundFrictionCoeff = 0;
		end	

		--local axlePower = self.motor.mrLastTransmissionTorque*self.motor.clutchRpm/9.5488;
		local axlePower = 0
		if self.motor.mrLastAxleTorque then
			axlePower =	self.motor.mrLastAxleTorque*self.motor.clutchRpm/9.5488
		end
		
		
		--expected slip function of TE, resistance forces, real speed and axle power
		--TE = tractive efficiency
		--Pdb = drawbar power
		--Pa = axle power
		--Fdb = drawbar force
		--Fr = resistance forces
		
		--TE = Pdb/Pa
		--Pdb = realSpd * Fdb
		--1. Fdb = Pdb / realSpd = TE*Pa / realSpd
		--2. Pa = wheelSpd * longForce => wheelSpd = Pa / longForce
		--3.longforce = Fdb + Fr
		--4. 2+3 =>  wheelSpd = Pa / (Fdb + Fr)
		--5. 4+1 => wheelSpd = Pa / [(TE * Pa / realSpd) + Fr]
		--6. Slip = 1 - realSpd / wheelSpd
		--7. 6+5 => Slip = 1 - (realSpd / Pa) * [(TE * Pa / realSpd) + Fr] = 1 - (TE + Fr * realSpd / Pa)
		
		--expected slip with Tractive Efficiency = 0.5
		local expectedSlipTE1 = 1;				
		--expected slip with Tractive Efficiency = 0.6
		local expectedSlipTE2 = 1;		
		--expected slip with Tractive Efficiency = 0.7
		local expectedSlipTE3 = 1;
		
		if axlePower>0 and self.mrDebugLastTotalResistance then
			--expected slip with Tractive Efficiency = 0.5
			expectedSlipTE1 = 1 - (0.5 + self.mrDebugLastTotalResistance*self.lastSpeedReal*1000/axlePower);					
			--expected slip with Tractive Efficiency = 0.6
			expectedSlipTE2 = 1 - (0.6 + self.mrDebugLastTotalResistance*self.lastSpeedReal*1000/axlePower);			
			--expected slip with Tractive Efficiency = 0.7
			expectedSlipTE3 = 1 - (0.7 + self.mrDebugLastTotalResistance*self.lastSpeedReal*1000/axlePower);
		end
		
		--slip = 1 - (TE + Fr*realSpd / Pa)
		--1-slip = TE + Fr*realSpd/Pa
		--TE = 1-slip - Fr*realSpd/Pa
		local TE = 0; 
		if self.mrDebugLastTotalResistance and axlePower>0 then
			TE = 1-self.mrAvgWheelSlip-self.mrDebugLastTotalResistance*self.lastSpeedReal*1000/axlePower;
		end
		
		--print(string.format("     mrWheelsFrictionFactor = %1.3f, sumLongForce=%1.3f, sumLongForceWanted=%1.3f, mrAvgWheelSlip=%1.3f",self.mrWheelsFrictionFactor,sumLongForce,sumLongForceWanted,self.mrAvgWheelSlip));
				
		--display expected slip (only ok on flat surface and if weight is perfectly dispatched on the tractor wheels according to the torqueRatio of differentials)
		local expectedSlip1 = 0;
		local expectedSlip2 = 0;
		
		if self.mrTotalWeightOnTires>0 and self.mrAvgWheelGroundFrictionCoeff>0 and self.mrDebugLastTotalResistance then
			local tractiveForce = self.mrDebugLastTotalResistance;		
			for _, implement in pairs(self.attachedImplements) do
				if implement.object and implement.object.mrDebugPowerConsumerLastForce then
					tractiveForce = tractiveForce + implement.object.mrDebugPowerConsumerLastForce;
				end
			end
			expectedSlip1 = (-1/6)*math.log(math.max(0.0024788,1-tractiveForce/(self.mrAvgWheelGroundFrictionCoeff*self.mrTotalWeightOnTires)));
			expectedSlip2 = (-1/5)*math.log(math.max(0.0024788,1-tractiveForce/(self.mrAvgWheelGroundFrictionCoeff*self.mrTotalWeightOnTires)));
		end		
		
		--display expected speed (only ok on flat surface and if weight is perfectly dispatched on the tractor wheels according to the torqueRatio of differentials)
		--P = F * Spd => axle power = tireForce * wheelSpd => wheelSpd = axlepower / tireForce
		--1 - (spd/wheel spd) = slip => spd = (1-slip)*wheel spd
		-- spd = (1-slip)*axlepower/tireforce
		
		local expectedSpd1 = 0;
		local expectedSpd2 = 0;
		if self.mrTotalWeightOnTires>0 and self.mrAvgWheelGroundFrictionCoeff>0 then
			if expectedSlip1>0 then				
				expectedSpd1 = (1-expectedSlip1)*axlePower/(self.mrTotalWeightOnTires*self.mrAvgWheelGroundFrictionCoeff*(1-math.exp(-6*expectedSlip1)));
			end
			if expectedSlip2>0 then				
				expectedSpd2 = (1-expectedSlip2)*axlePower/(self.mrTotalWeightOnTires*self.mrAvgWheelGroundFrictionCoeff*(1-math.exp(-5*expectedSlip2)));
			end
		end
		
		
		--we can use this paramter with the console commande "mrsetvalue2 value" to move the z position of the center of mass of the tractor
		if RealisticUtils.mrDebugValue2 then
			setCenterOfMass(self.components[1].node, self.components[1].centerOfMass[1], self.components[1].centerOfMass[2], self.components[1].centerOfMass[3]+tonumber(RealisticUtils.mrDebugValue2));
		end;
		
		if self.mrDebugLastExpectedSlip1==nil then self.mrDebugLastExpectedSlip1 = 0.5; end;
		self.mrDebugLastExpectedSlip1 = 0.99*self.mrDebugLastExpectedSlip1 + 0.01*expectedSlip1;
		
		if self.mrDebugLastExpectedSlip2==nil then self.mrDebugLastExpectedSlip2 = 0.5; end;
		self.mrDebugLastExpectedSlip2 = 0.99*self.mrDebugLastExpectedSlip2 + 0.01*expectedSlip2;
		
		if self.mrWheelShapesValid then
			--try to determine slope incline
			local inclinePoint1, inclinePoint2
			local slopePercent = nil
			for _,wheel in ipairs(self.wheels) do
				local cpx, cpy, cpz = getWheelShapeContactPoint(wheel.node, wheel.wheelShape)
				if cpx~=nil and cpy~=nil and cpz~=nil then
					cpx, cpy, cpz = worldToLocal(self.components[1].node, cpx, cpy, cpz)
					if inclinePoint1==nil and cpz>0 then
						cpx, cpy, cpz = localToWorld(self.components[1].node, 0, cpy, cpz)
						inclinePoint1 = {x=cpx,y=cpy,z=cpz}	
						--print("test -inclinePoint1 = " .. tostring(inclinePoint1) .. " - x="..tostring(cpx).." - y="..tostring(cpy).." - z="..tostring(cpz)) 
					elseif inclinePoint2==nil and cpz<0 then				
						cpx, cpy, cpz = localToWorld(self.components[1].node, 0, cpy, cpz)
						inclinePoint2 = {x=cpx,y=cpy,z=cpz}		
						--print("test -inclinePoint2 = " .. tostring(inclinePoint2) .. " - x="..tostring(cpx).." - y="..tostring(cpy).." - z="..tostring(cpz)) 
					end
				end
			end
			
			if inclinePoint1 and inclinePoint2 then
				local inclineHeight = math.abs(inclinePoint1.y-inclinePoint2.y)
				local inclineLength = Utils.vector2Length(inclinePoint1.x-inclinePoint2.x,inclinePoint1.z-inclinePoint2.z)
				if inclineLength>0 then
					slopePercent = 100*inclineHeight/inclineLength
					--print("test - slopePercent = "..tostring(slopePercent*100) .. " - height="..tostring(inclineHeight) .. " - length="..tostring(inclineLength))
				end
			end
			
			local slopeText = "Slope percent: no result"
			if slopePercent~=nil then
				slopeText = string.format("Slope percent: %2.1f%%", slopePercent)
			end
			renderText(0.02, 0.078, getCorrectTextSize(0.02), slopeText)
		end
		
		renderText(0.02, 0.030, getCorrectTextSize(0.02), string.format("Expected speed min/max: %2.2f/%2.2f", expectedSpd2*3.6,expectedSpd1*3.6));
		renderText(0.02, 0.046, getCorrectTextSize(0.02), string.format("Expected slip min/max : %2.2f/%2.2f", self.mrDebugLastExpectedSlip1*100,self.mrDebugLastExpectedSlip2*100));
		
		renderText(0.02, 0.062, getCorrectTextSize(0.02), string.format("Slip TE 0.5/0.6/0.7= %2.2f/%2.2f/%2.2f", expectedSlipTE1*100,expectedSlipTE2*100,expectedSlipTE3*100));
		--renderText(0.02, 0.078, getCorrectTextSize(0.02), string.format("TE (Flat surface)= %2.2f", TE));
		
		renderText(0.2, 0.59, getCorrectTextSize(0.02), string.format("tractive Efficiency (flat surface): %2.2f", TE));	
		
		renderText(0.31, 0.46, getCorrectTextSize(0.02), "Avg Slip");
		renderText(0.36, 0.46, getCorrectTextSize(0.02), "Contact");
		renderText(0.41, 0.46, getCorrectTextSize(0.02), "Weight");
		renderText(0.45, 0.46, getCorrectTextSize(0.02), "Spd");
		local i = 0;
		for _,wheel in ipairs(self.wheels) do
			i = i +1;
			local wheelGroundSpeed = 0
			if self.mrWheelShapesValid then
				wheelGroundSpeed = getWheelShapeAxleSpeed(wheel.node, wheel.wheelShape) * wheel.radius * 3.6;
			end
			if self.mrVehicleIsStill then wheelGroundSpeed=0; end
			
			local tireLoad = wheel.mrLastTireLoad
			if tireLoad==0 then
				tireLoad = WheelsUtil.mrGetTireLoad(wheel);
			end;
			
			renderText(0.31, 0.46-i*0.022, getCorrectTextSize(0.02), string.format("%4.2f", wheel.mrAvgLongSlip*100));
			renderText(0.36, 0.46-i*0.022, getCorrectTextSize(0.02), string.format("%4.2f", wheel.mrLastContactForce));
			renderText(0.41, 0.46-i*0.022, getCorrectTextSize(0.02), string.format("%4.2f", tireLoad));
			renderText(0.45, 0.46-i*0.022, getCorrectTextSize(0.02), string.format("%4.2f", wheelGroundSpeed));
		end
		
	end;--end debug rendering
				
end



--MR ****************************************************************************************************
--"hijack" this function so that we could call the "mrManageNode" just after the self.components is filled
 Vehicle.mrLoadWheelsSteeringDataFromXML = function(self, xmlFile, ackermannSteeringIndex)
	RealisticUtils.manageNodes(self, xmlFile)
 end
 Vehicle.loadWheelsSteeringDataFromXML = Utils.appendedFunction(Vehicle.loadWheelsSteeringDataFromXML, Vehicle.mrLoadWheelsSteeringDataFromXML);
 



--MR ****************************************************************************************************
--return the "torque ratio" of the wheel
Vehicle.mrComputeWheelFinalTorqueRatio = function(self, wheel)
	
	if not self.differentials then
		return 1;
	end;
	
	local getFinalTorqueRatioFromDiffIndex;
	getFinalTorqueRatioFromDiffIndex = function(self, diffIndex)		
		for i,diff in pairs(self.differentials) do
			if not diff.diffIndex1IsWheel then
				if diff.diffIndex1==diffIndex then
					return diff.torqueRatio * getFinalTorqueRatioFromDiffIndex(self, i-1);
				end
			end
			if not diff.diffIndex2IsWheel then
				if diff.diffIndex2==diffIndex then
					return (1-diff.torqueRatio) * getFinalTorqueRatioFromDiffIndex(self, i-1);
				end
			end
		end
		return 1;
	end	
	
	for i,diff in pairs(self.differentials) do
		if diff.diffIndex1IsWheel then			
			--find the vehicle wheel
			if wheel==self.wheels[diff.diffIndex1] then							
				--compute the wheel torque ratio
				return diff.torqueRatio * getFinalTorqueRatioFromDiffIndex(self, i-1);				
			end	
		end
		if diff.diffIndex2IsWheel then			
			--find the vehicle wheel
			if wheel==self.wheels[diff.diffIndex2] then							
				--compute the wheel torque ratio
				return (1-diff.torqueRatio) * getFinalTorqueRatioFromDiffIndex(self, i-1);				
			end
		end		
	end
	
	return 1;

end



--MR ****************************************************************************************************
--update the wheels "mrIsDriven" parameter
Vehicle.mrUpdateWheelsIsDriven = function(self)
	
	for _,wheel in ipairs(self.wheels) do
		wheel.mrIsDriven = false;
		if self.differentials then
			for i,diff in pairs(self.differentials) do
				if diff.diffIndex1IsWheel then
					if wheel==self.wheels[diff.diffIndex1] then
						wheel.mrIsDriven = true;
						break;
					end
				end
				if diff.diffIndex2IsWheel then
					if wheel==self.wheels[diff.diffIndex2] then
						wheel.mrIsDriven = true;
						break;
					end
				end
			end
		end
	end

end

--MR ****************************************************************************************************
--Add wheel mass to the total mass
Vehicle.mrGetTotalMass = function(self, superFunc, addAttachables, addOnlyNonWheelAttachables)
	local mass = 0;
	if self.isServer then
		for _, comp in pairs(self.components) do
			mass = mass + getMass(comp.node);
		end;
		--MR add wheel mass
		for _, wheel in pairs(self.wheels) do
			mass = mass + wheel.mass;
		end
	else
		mass = self.serverMass;
		for _,v in pairs(self.specializations) do
			if v.getAdditiveClientMass ~= nil then
				mass = mass + v.getAdditiveClientMass(self);
			end;
		end;
	end;

	if addAttachables then
		if addOnlyNonWheelAttachables == nil then
			addOnlyNonWheelAttachables = true;
		end
		for _, implement in pairs(self.attachedImplements) do
			if implement.object ~= nil and (table.getn(implement.object.wheels) == 0 or not addOnlyNonWheelAttachables) then
				mass = mass + implement.object:getTotalMass(addAttachables, addOnlyNonWheelAttachables);
			end;
		end
	end

	return mass;
end;
Vehicle.getTotalMass = Utils.overwrittenFunction(Vehicle.getTotalMass, Vehicle.mrGetTotalMass);	


--******************************************************************************
--** return wheel width + additionnal wheel width (so, for a dual 710 setup, it returns 1.42
Vehicle.mrGetWheelTotalContactWidth = function(wheel)

	local width = wheel.width;
	if wheel.additionalWheels then
		for _,w in pairs(wheel.additionalWheels) do
			width = width + w.width;
		end
	end
	if wheel.tireType==WheelsUtil.getTireType("crawler") then
		wheel.mrIsCrawler = true;
	else
		wheel.mrIsCrawler = false;
	end
	return width;
	
end

--******************************************************************************
--** return true if at least one wheel is "rolling", false otherwise
Vehicle.mrGetVehicleIsRolling = function(self)

	local isRolling = false
	for _, wheel in pairs(self.wheels) do
		if math.abs(wheel.mrLastWheelSpeed)>0.01 then
			isRolling = true
		end
	end
	return isRolling		
		
end

--MR ****************************************************************************************************
--Add wheel mass to the total mass
Vehicle.mrGetNeededPtoRpmWhenControlled = function(self)
	local neededPtoRpm  = 0
	
	if self.isControlled then
		neededPtoRpm = self.mrNeededPtoRpmWhenControlled			
	end
	for _, implement in pairs(self.attachedImplements) do
		if implement.object ~= nil and implement.object.mrGetNeededPtoRpmWhenControlled~=nil then
			neededPtoRpm = math.max(neededPtoRpm, implement.object:mrGetNeededPtoRpmWhenControlled())
		end
	end

	--print("test Vehicle.mrGetNeededPtoRpmWhenControlled - neededPtoRpm=" .. tostring(neededPtoRpm))
	
	return neededPtoRpm
end


--MR ****************************************************************************************************
--auto start/stop engine of the tractor vehicle and update motor rpm (if self.mrNeededPtoRpmWhenControlled is defined)
Vehicle.mrUpdateTick = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end	

	-- manage mrNeededPtoRpmWhenControlled
	-- turn on/off automatically
    if self.isServer and self.mrNeededPtoRpmWhenControlled>0 then
	
        if g_currentMission.missionInfo.automaticMotorStartEnabled then
            if self.isControlled then
				if self.attacherVehicle ~= nil then
					if self.attacherVehicle.getIsMotorStarted ~= nil then
						if not self.attacherVehicle:getIsMotorStarted() then
							self.attacherVehicle:startMotor()
						end
					end
				end
			else
				local rootAttacherVehicle = self:getRootAttacherVehicle()
				if not rootAttacherVehicle.isControlled then
					if self.attacherVehicle ~= nil then
						if self.attacherVehicle.getIsMotorStarted ~= nil then
							if self.attacherVehicle:getIsMotorStarted() then
								self.attacherVehicle:stopMotor()
							end	
						end
					end
				end
			end
		end   
		
		--MR : update the engine rpm/torque in use		
		if self.attacherVehicle ~= nil then			
			if self.attacherVehicle.mrIsMrVehicle and self.attacherVehicle.getIsMotorStarted ~= nil then -- vehicle requiring the tractot motor to work
				if self.attacherVehicle:getIsMotorStarted() then					
					if not self.attacherVehicle.isControlled then
						WheelsUtil.updateWheelsPhysics(self.attacherVehicle, dt, 0, 0, true, self.attacherVehicle.requiredDriveMode)
					end
				end
			end
		end			
		
    end --self.isServer
	
	
	--manage mrNeedEngineRunningForTorque
	--only if the tractor is not already controlled
	if self.isServer and self.mrNeedEngineRunningForTorque then		
		local rootAttacherVehicle = self:getRootAttacherVehicle(); --can be self or the attacher vehicle  
		if rootAttacherVehicle~=nil and rootAttacherVehicle.mrIsMrVehicle and not rootAttacherVehicle.isControlled and rootAttacherVehicle.getIsMotorStarted ~=nil then					
			local needPower = false;
			if self.powerConsumer~=nil and PowerConsumer.mrGetTotalConsumedPtoTorque(self)>0 then
				needPower = true;
				self.mrNeedPowerTimeLeft = 5000;
				--print("neededTorque =" .. tostring(PowerConsumer.mrGetTotalConsumedPtoTorque(self)))
			end
					
			-- if automaticMotorStartEnabled is true then		
			if g_currentMission.missionInfo.automaticMotorStartEnabled then
				--1. automatically starts the attacher vehicle engine if "needPower" and the engine is OFF
				if needPower and not rootAttacherVehicle:getIsMotorStarted() then
					rootAttacherVehicle:startMotor();
				--2. automatically stops the attacher vehicle engine if not "needPower" and the engine is ON
				elseif not needPower and rootAttacherVehicle:getIsMotorStarted() then
					rootAttacherVehicle:stopMotor();
				end;
			end;
			
			--update attacher vehicle if nobody already control it	
			if self.mrNeedPowerTimeLeft>0 then
				self.mrNeedPowerTimeLeft = math.max(0, self.mrNeedPowerTimeLeft - dt);
				if rootAttacherVehicle:getIsMotorStarted() then						
					WheelsUtil.updateWheelsPhysics(rootAttacherVehicle, dt, 0, 0, true, rootAttacherVehicle.requiredDriveMode);		
				end;
			end;
			
		end;
	end;	

end
Vehicle.updateTick = Utils.appendedFunction(Vehicle.updateTick, Vehicle.mrUpdateTick)


---------------------------------------------------------------------------------------------------------
-- 20170913 - fix problem with bigBud DLC => sometimes, when attaching a frontloader (hardattaching) to a tractor, the "getMotorRotationSpeed" function returns a very high "motorizedNodeClutchRadSpd" as if the wheels of the tractor were rotating very fast 
-- or as if the gearbox ratio was very high so that a little rotating speed of the wheels = a very high gearbox's inputshaft rotating speed
Vehicle.mrAddToPhysics = function(self, superFunc)
	if not self.isAddedToPhysics and self.mrIsMrVehicle then
		self.mrUseMrTransmissionFrameCount = 0
	end
	return superFunc(self)
end
Vehicle.addToPhysics = Utils.overwrittenFunction(Vehicle.addToPhysics, Vehicle.mrAddToPhysics)


Vehicle.drawDebugMassOnTheWheels = function(self)

	if table.getn(self.wheels) > 0 then
		local gravity = 9.81;
		local totalWheelLoad = 0;
		for i, wheel in ipairs(self.wheels) do
			local tireLoad
			if self.mrWheelShapesValid then
				tireLoad = getWheelShapeContactForce(wheel.node, wheel.wheelShape);
			end
			if tireLoad ~= nil then
				local nx,ny,nz = getWheelShapeContactNormal(wheel.node, wheel.wheelShape);
				local dx,dy,dz = localDirectionToWorld(wheel.node, 0,-1,0);
				tireLoad = -tireLoad*Utils.dotProduct(dx,dy,dz, nx,ny,nz);
				tireLoad = tireLoad + math.max(ny*gravity, 0.0) * wheel.mass; --add gravity force of tire
			else
				tireLoad = 0;
			end
			
			if tireLoad==0 then
				tireLoad = WheelsUtil.mrGetTireLoad(wheel);
			end;
			
			totalWheelLoad = totalWheelLoad + tireLoad;
		end
		
		renderText(0.02, 0.015, getCorrectTextSize(0.02), string.format("Total mass on wheels : %2.2f", totalWheelLoad/gravity));			

	end;

end;