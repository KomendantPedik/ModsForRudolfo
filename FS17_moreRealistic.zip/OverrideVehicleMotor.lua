﻿
VehicleMotor.MR_AI_MAX_WORKINGSPEED = 22

--************************************************************************************************************************************************************
--add mr variables
-- utils.appended function does not handle "new", so we do it the "old way"
local oldVehicleMotorNew = VehicleMotor.new
VehicleMotor.new = function(self, vehicle, minRpm, maxRpm, maxForwardSpeed, maxBackwardSpeed, torqueCurve, brakeForce, forwardGearRatio, backwardGearRatio, minForwardGearRatio, maxForwardGearRatio, minBackwardGearRatio, maxBackwardGearRatio, ptoMotorRpmRatio, rpmFadeOutRange, maxTorque, maxMotorPower, minSpeed)
	local motor = oldVehicleMotorNew(self, vehicle, minRpm, maxRpm, maxForwardSpeed, maxBackwardSpeed, torqueCurve, brakeForce, forwardGearRatio, backwardGearRatio, minForwardGearRatio, maxForwardGearRatio, minBackwardGearRatio, maxBackwardGearRatio, ptoMotorRpmRatio, rpmFadeOutRange, maxTorque, maxMotorPower, minSpeed);
		
	--at this state of the loading of the vehicle, we don't know if this is a "mr" one or not and so, we initialize the "mr" variables for all the vehicles
	
	motor.mrLastTransmissionTorque = 0;	
	motor.mrLastEqualizedMotorRpm = 0;	
	motor.mrLastEngineTorqueConsumedByPto = 0;		
	
	--------------------------------------------------------------------------------------------------------
	-- parameters whose values are loaded from "Vehicle.mrLoadFinished2"	
	motor.mrTransmissionEfficiency = 1; -- Efficiency between PTO power and Wheel Power. || 0.82 = vario fendt/MF dyna-VT, 0.87 = autocommand/cvx caseIH/new holland, 0.91=JohnDeere Direct Drive, 0.85=John Deere Autopower( ZF Eccom), 0.825=Valtra direct, 0.8-0.87=Full PowerShift, 0.82-0.95=Semi-PS, 0.87-0.9=Meca on farm vehicles, 0.93-0.98 = meca on cars/trucks
	motor.mrAccPedalRegulateTorque = false; 
	motor.mrIdleEngineRpm = motor.minRpm; 	
	motor.mrEngineBrakeRpm = motor.maxRpm; 	
	motor.mrBrakingForceFx = 1;
	motor.mrTransmissionReactivity = 1;
	motor.rotInertiaFx = 1;
	motor.mrMinRpmAllowedWithLoad = 0; --important to set this to 0 since a generic value is computed below in case no specific value is set in the xml file
	motor.mrMaxEngineTorqueForTransmission = 10000
	motor.mrEngineBrakeNotLinkedToPTO = false
	motor.mrEngineTorqueForTransmissionHasPriority = false
	--------------------------------------------------------------------------------------------------------
	
	motor.mrLastDummyEngineRpm = 0;
	motor.mrRegulatorFxS = 0;
	motor.mrLastAxleTorque = 0;
	motor.mrMovingDirection = 1;
	motor.mrLastGearRatio = 1;
	motor.mrLastDummyGearRatio = 0;
	motor.mrLastEngineOutputTorque = 0;
	motor.mrEngineNeedTorque = false;
	motor.mrEngineNeedTorqueLastTime = -100000
	motor.mrEngineNeedTorqueLastSpeed = 0
	motor.mrEngineNeedTorqueRemainingTime = 0
	
	
	
	
	motor.lastPtoRpm = motor.minRpm; -- not initialize by Giants
	--motor.mrEngineNeedMinRev = true;
	--motor.mrEngineMinRevNeeded = motor.mrIdleEngineRpm;
	
	
			
	--find max engine power rpm and max torque
	local enginePower = 0;
	local engineMaxPower = 0;
	local torque = 0;
	local maxTorque2 = 0;
	local minRpmLoaded = 0;
	 
	motor.mrMaxPowerRpm = maxRpm;
	motor.mrMaxTorqueRpm = minRpm;	
	motor.mrMaxPtoRequiredRpm = maxRpm;
	for rpm=maxRpm, minRpm, -10 do --reverse to get the higher max power rpm
		torque = torqueCurve:get(rpm);
		if torque>maxTorque2 then
			maxTorque2 = torque;
			motor.mrMaxTorqueRpm = rpm;
			minRpmLoaded = 0;
		elseif minRpmLoaded==0 and torque<0.9*maxTorque2 then
			minRpmLoaded = rpm;
		end	
		enginePower = torque * rpm *math.pi/30;
		if enginePower>engineMaxPower then
			engineMaxPower = enginePower; --KW			
		end
		if enginePower>0.9995*engineMaxPower then  -- 0.999 => if the engine has a "steady" range of max power, we want the "min rpm" of the range
			motor.mrMaxPowerRpm = rpm;	
		end		
	end;
	
	motor.mrMaxPower = engineMaxPower; --KW
	motor.mrMaxTorque = maxTorque2; --KNm
	motor.mrEngineBrakeRpm = motor.maxRpm; --modified in Vehicle.mrLoadFinished2		
	--motor.mrEngineBrakingForce = motor.mrMaxPower * 9 / motor.maxRpm; --modified in Vehicle.mrLoadFinished2 by scaling it with "mrBrakingForceFx"	
	motor.mrEngineBrakingForce = 0;
	
	if motor.mrMinRpmAllowedWithLoad==0 then
		motor.mrMinRpmAllowedWithLoad = minRpmLoaded;
	end
	
	--20170605 - compute max engine rpm when using the pto (since every engine is different, some "requiredPtoRpm" set for tools can put then engine beyond its useful rpm range)
	
	for rpm=maxRpm, minRpm, -10 do --reverse to get the higher max allowed rpm for pto work
		torque = torqueCurve:get(rpm)		
		enginePower = torque * rpm *math.pi/30
		if enginePower>0.9*engineMaxPower then
			motor.mrMaxPtoRequiredRpm = rpm
			break
		end
	end
	
	--print("testing torque curve for "..vehicle.configFileName)
	--for rpm=maxRpm, minRpm, -10 do
	--	torque = torqueCurve:get(rpm)		
	--	print("rpm="..tostring(rpm).." - torque="..tostring(torque*1000))
	--end
		
	
	return motor;
end;



VehicleMotor.mrUpdateVehicleProps = function(self, accelerationPedal, brakePedal, reverserDirection, lastSpeed, movingDirection, ptoRpmWanted, dt)

	--if the engine is not started => no need to compute all this
	if not self.vehicle:getIsMotorStarted() then
		--print(" test - engine is not running !!! " .. tostring(g_currentMission.time));
				
		self.equalizedMotorRpm = 0;--0.95 * self.mrLastEqualizedMotorRpm;
		self.mrLastDummyEngineRpm = self.equalizedMotorRpm;
		self.nonClampedMotorRpm = self.equalizedMotorRpm;
		self.mrLastEqualizedMotorRpm = self.equalizedMotorRpm;
		self:setLastRpm(self.equalizedMotorRpm);		
		
		--return axleTorque, maxRotSpeed, gearRatio, clutchTorque, rotInertia, dampingRate;
		return 0, 0, self.mrLastGearRatio, 30*self.mrMaxTorque, 1, 1;
	end




	local accPedalRegulateTorque = self.mrAccPedalRegulateTorque;
	--20170630 - accelerator pedal more precise at low acc
	--local finalAcc = accelerationPedal * reverserDirection;
	local finalAcc = 0
	if accelerationPedal>0 then
		finalAcc = (accelerationPedal^2) * reverserDirection
	elseif accelerationPedal<0 then
		finalAcc = -(accelerationPedal^2) * reverserDirection
	end
	
	
	local finalLastSpeed = lastSpeed*movingDirection;
	local regulatorFx = 1;
	local torqueConverterFx = 1;

	local dummyEngineTorque = 0; --KNm   axleTorque = torque * gearRatio
	local maxRotSpeed = 100000; -- rad, set the "engine" max rpm (the "engine" cannot go over this value, even if the tractor is pushed by a heavy trailer going downhill). So, we set this to something big not to be limited in the game.
	local gearRatio = 1; -- we are working with axle torque
	local clutchTorque = 100000; --KNm. Not useful in our case (CVT transmission, no real clutch involved). But we use it as a "torque limiter" to simulate engine braking force
	local rotInertia = 1; --limit the engine rpm raising speed
	local rotInertiaFx = 1;
	local dampingRate = 0;--we can't rely on this for engine braking
	
	local minGearRatio, maxGearRatio;
	local wantedSpeed = 0;	
	
	local motorizedNodeRadSpd = 0;
	local motorizedNodeClutchRadSpd = 0;
	local motorizedNodeLoad = 0;
	
	local maxEngineTorqueForTransmission = self.mrMaxEngineTorqueForTransmission
	
	local currentMaxSpeed = 0
	
	local speedLimit = self.speedLimit -- kph
	
	--20170605 - "cap" the max rpm wanted so that we don't put the engine beyond its "useful range"
	local requiredMotorRpm = math.min(ptoRpmWanted*self.ptoMotorRpmRatio, self.mrMaxPtoRequiredRpm)	
	
	--20170622 - limit the AI speedLimit increasing to 1kph per second
	if self.vehicle.aiIsStarted then
		if speedLimit>self.vehicle.mrAi.lastSpeedLimit then
			--various speed increase function of the target speed
			speedLimit = math.min(speedLimit, self.vehicle.mrAi.lastSpeedLimit+speedLimit*dt/15000)
		end		
		--print("test vehicle.mrAi.lastSpeedLimit : " .. tostring(speedLimit))
	end
	self.vehicle.mrAi.lastSpeedLimit = speedLimit
	
	
	
	self.mrLastEngineOutputTorque = 0;
	
	--20170606 - update clutchRpmAcc
	local lastClutchRpm = self.clutchRpm
	
	--get motorizedNode engine rpm	
	self.clutchRpm = 0;
	if not self.vehicle.mrVehicleIsStill then
		--frame count since last use of another transmission than "mr"
		if self.vehicle.mrUseMrTransmissionFrameCount==self.vehicle.mrUseMrTransmissionFrameCountLimit then -- see WheelsUtil.mrUpdateWheelsPhysics
		--if self.gearRatio==0 then --20170517 - check the "self.gearRatio" to be sure the "mrtransmission" was in use the last time (Example : in case the vehicle was controlled by courseplay = "mrTransmission" turned off)
			motorizedNodeRadSpd, motorizedNodeClutchRadSpd, motorizedNodeLoad = getMotorRotationSpeed(self.vehicle.motorizedNode);
			motorizedNodeClutchRadSpd = math.max(0, motorizedNodeClutchRadSpd); --protection in case the clutchRpm is negative (possible when driving at high speed and the vehicle has a sudden change of direction after upturning)
			self.clutchRpm = motorizedNodeClutchRadSpd * 30 / math.pi;	
			--print(tostring(g_currentMission.time) .." test mr1 - current engine rpm="..tostring(self.mrLastDummyEngineRpm).. " - self.gearRatio = " .. tostring(self.gearRatio) .. " - self.clutchRpm="..tostring(self.clutchRpm) .. " - mrUseMrTransmission="..tostring(self.vehicle.mrUseMrTransmission))		
		end		
	end
	
	self.mrClutchRpmAcc = (self.clutchRpm-lastClutchRpm)*1000/dt --rpm per s
	
	if finalAcc>0 then
		self.mrMovingDirection = 1;
	elseif finalAcc<0 then
		self.mrMovingDirection = -1;
	end
	
	if self.mrMovingDirection==-1 then
		currentMaxSpeed = self.maxBackwardSpeed		
		wantedSpeed = math.max(self.maxBackwardSpeed * finalAcc, -speedLimit/3.6); --m/s		
		gearRatio = -1;
		minGearRatio = self.minBackwardGearRatio;
		maxGearRatio = self.maxBackwardGearRatio;
		if requiredMotorRpm>0 then
			wantedSpeed = math.max(wantedSpeed, 0.14-0.1047 * requiredMotorRpm / minGearRatio); --limit wantedspeed so that we don't have to rev higher than the requiredMotorRpm
		end
	else
		currentMaxSpeed = self.maxForwardSpeed
		wantedSpeed = math.min(self.maxForwardSpeed * finalAcc, speedLimit/3.6); --m/s		
		gearRatio = 1;
		minGearRatio = self.minForwardGearRatio;
		maxGearRatio = self.maxForwardGearRatio;
		if requiredMotorRpm>0 then
			wantedSpeed = math.min(wantedSpeed, -0.14+0.1047 * requiredMotorRpm / minGearRatio); --limit wantedspeed so that we don't have to rev higher than the requiredMotorRpm
		end		
	end
	
	self.mrLastGearRatio = gearRatio;
		
	--limit the headland helper AI speed so that it doesn't oversteer too much (2.5mph = 9kph)
	if self.vehicle.aiIsStarted then
		wantedSpeed = math.min(VehicleMotor.MR_AI_MAX_WORKINGSPEED/3.6, wantedSpeed); -- limit max ai speed to 22kph (otherwise, with mowers, the ai is driving too fast when arriving to the headland => need too much distance to slow down)
		if self.vehicle.mrAiIsTurning then			
			if wantedSpeed>=0 then
				wantedSpeed = math.min(2.5, wantedSpeed);
			else
				wantedSpeed = math.max(-2.5, wantedSpeed);
			end
		end
		--print("test vehicle.mrAi wantedSpeed : " .. tostring(wantedSpeed*3.6))
		--20170622 - no more acc limitation since we are using the mrAi.lastSpeedLimit
		--if accelerationPedal>0 then
		--	accelerationPedal = math.min(0.5, accelerationPedal);
		--elseif accelerationPedal<0 then
		--	accelerationPedal = math.max(-0.5, accelerationPedal);
		--end	
	end
	
	if Vehicle.debugRendering and self.vehicle.isEntered then	
		self.vehicle.mrDebugLastAccPedal = accelerationPedal;		
	end
	
	--print("wanted speed first - " .. tostring(wantedSpeed*3.6))
	
	--20170604 - limit speed when engine is "struggling"
	if self.mrEngineNeedTorque then
		if wantedSpeed~=0 then
			if wantedSpeed>0 then
				wantedSpeed = math.min(finalLastSpeed-0.028, wantedSpeed) --0.028 = 0.1kph
			else
				wantedSpeed = math.max(finalLastSpeed+0.028, wantedSpeed)
			end
		end
		self.mrEngineNeedTorqueLastTime = g_currentMission.time
		self.mrEngineNeedTorqueLastSpeed = finalLastSpeed
	elseif wantedSpeed~=0 and g_currentMission.time<self.mrEngineNeedTorqueLastTime+10000 then -- allow some time for the engine to "recover"
		local recoverSpeed = (wantedSpeed-finalLastSpeed)/(self.mrEngineNeedTorqueLastTime+10000-g_currentMission.time)
		self.mrEngineNeedTorqueLastSpeed = self.mrEngineNeedTorqueLastSpeed+recoverSpeed*dt
		if wantedSpeed>0 then
			--self.mrEngineNeedTorqueLastSpeed = self.mrEngineNeedTorqueLastSpeed+0.28*dt/1000
			wantedSpeed = math.min(self.mrEngineNeedTorqueLastSpeed, wantedSpeed)
		else
			--self.mrEngineNeedTorqueLastSpeed = self.mrEngineNeedTorqueLastSpeed-0.28*dt/1000
			wantedSpeed = math.max(self.mrEngineNeedTorqueLastSpeed, wantedSpeed)
		end
		--if wantedSpeed>0 then
		--	wantedSpeed = math.min(finalLastSpeed+0.28*dt/1000, wantedSpeed)
		--else
		--	wantedSpeed = math.max(finalLastSpeed-0.28*dt/1000, wantedSpeed) -- 0.28*dt/1000 = 1kph per second
		--end
	end
	
	--print(tostring(g_currentMission.time) .. " - wantedSpeed="..tostring(wantedSpeed*3.6) .. " - need torque="..tostring(self.mrEngineNeedTorque) .. " - lastSpeed="..tostring(finalLastSpeed*3.6))
	
	--*************************************************************************************************************************
	--regulator - regulate on actual ground speed (not wheel speed) = radar
	--20170908 - regualte on wheel speed as well (limit wheel slip to 25%)
	local engineBraking = false;
	local engineBrakingFx = 1;	
	local engineBrakingTargetRpm = self.mrEngineBrakeRpm;
	local regulatorReferenceSpeed
	if wantedSpeed<0 then
		regulatorReferenceSpeed = math.min(finalLastSpeed, 0.8*lastClutchRpm*gearRatio*math.pi/30) -- clutchRpm * gearRatio = wheel speed in meter per second
	else
		regulatorReferenceSpeed = math.max(finalLastSpeed, 0.8*lastClutchRpm*gearRatio*math.pi/30) --0.8 = allow 25% slip max
	end
	
	--print("test last wheel speed ms-1= "..tostring(lastClutchRpm*gearRatio*math.pi/30) .." - kph="..tostring(lastClutchRpm*gearRatio*math.pi/30*3.6))
	
	if wantedSpeed>0 and regulatorReferenceSpeed>(wantedSpeed+0.01) then	-- 0.01 = 0.036 kph	
		local rRange = 0.01 + 0.45*math.min(1, self.mrLastDummyEngineRpm/self.mrMaxPowerRpm)^2;
		if regulatorReferenceSpeed>(rRange+wantedSpeed) then
			regulatorFx = 0;
			engineBraking = true;
			engineBrakingFx = math.min(1, regulatorReferenceSpeed-(rRange+wantedSpeed));
			--20180102 - take into account "accelerationPedal" for players who are using a analog device (pedals)
			--we want to avoid too much engine braking if not "asked" by the player	(slightly depressing brake pedal = asking for full engine brake power / or using the speed limiter with a low target speed)		
			if motorizedNodeClutchRadSpd<currentMaxSpeed and math.abs(accelerationPedal)<1 then --accelerationPedal==1 means a target speed is set (speed limiter)				
				engineBrakingTargetRpm = Utils.lerp(self.mrIdleEngineRpm, self.mrEngineBrakeRpm, math.min(1, motorizedNodeClutchRadSpd/currentMaxSpeed));
			end;
		else
			regulatorFx = 1-((regulatorReferenceSpeed-wantedSpeed)/rRange)^0.4; -- 100% at wanted speed / 0% at wanted speed +0.25m/s
		end		
	elseif wantedSpeed<0 and regulatorReferenceSpeed<(wantedSpeed-0.01) then		
		local rRange = 0.05 + 0.45*math.min(1, self.mrLastDummyEngineRpm/self.mrMaxPowerRpm)^2;
		if regulatorReferenceSpeed<(wantedSpeed-rRange) then
			regulatorFx = 0;
			engineBraking = true;
			--engineBrakingFx = math.max(-1, finalLastSpeed-(rRange+wantedSpeed));
			engineBrakingFx = math.min(1, -regulatorReferenceSpeed+(wantedSpeed-rRange)); --20170513 - fix reverse engine braking
			--print("test - engine braking fx = " .. tostring(engineBrakingFx))
			
			--20180102 - take into account "accelerationPedal" for players who are using a analog device (pedals)
			--we want to avoid too much engine braking if not "asked" by the player	(slightly depressing brake pedal = asking for full engine brake power / or using the speed limiter with a low target speed)		
			if motorizedNodeClutchRadSpd<currentMaxSpeed and math.abs(accelerationPedal)<1 then --accelerationPedal==1 means a target speed is set (speed limiter)				
				engineBrakingTargetRpm = Utils.lerp(self.mrIdleEngineRpm, self.mrEngineBrakeRpm, math.min(1, motorizedNodeClutchRadSpd/currentMaxSpeed));
			end;
		else
			regulatorFx = 1-((-regulatorReferenceSpeed+wantedSpeed)/rRange)^0.4; -- 100% at wanted speed / 0% at wanted speed +0.25m/s
		end		
	elseif wantedSpeed==0 then-- and math.abs(finalLastSpeed)>0.1 then
		engineBraking = true;
		--print("test - finalLastSpeed="..tostring(finalLastSpeed) .. " - self.mrMinSpeed="..tostring(self.mrMinSpeed));
		
		
		--20170120 - do not base the engine braking "lowering rpm when close to stop" on the real speed but on the wheel speed (better behavior)
		--if math.abs(finalLastSpeed)<2*self.mrMinSpeed then
		if motorizedNodeClutchRadSpd<(2*self.mrMinSpeed) then -- motorizedNodeClutchRadSpd = speed of the wheels in meter per second
			--engineBrakingTargetRpm = Utils.lerp(self.mrIdleEngineRpm, self.mrEngineBrakeRpm, math.abs(finalLastSpeed)/(2*self.mrMinSpeed)); --self.mrEngineBrakeRpm @min speed and above
			--engineBrakingFx = Utils.lerp(0.1, 1, (finalLastSpeed/(2*self.mrMinSpeed))^2);
			engineBrakingTargetRpm = Utils.lerp(self.mrIdleEngineRpm, self.mrEngineBrakeRpm, motorizedNodeClutchRadSpd/(2.5*self.mrMinSpeed)); --self.mrEngineBrakeRpm @ 2.5x min speed and above
			engineBrakingFx = Utils.lerp(0.1, 1, (motorizedNodeClutchRadSpd/(2*self.mrMinSpeed))^2);
			
			--print("test 2 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!engineBrakingTargetRpm="..tostring(engineBrakingTargetRpm).." - engineBrakingFx="..tostring(engineBrakingFx) .. "- motorizedNodeClutchRadSpd="..tostring(motorizedNodeClutchRadSpd));
		elseif brakePedal==0 then
			engineBrakingTargetRpm = Utils.lerp(self.mrIdleEngineRpm, self.mrEngineBrakeRpm, math.min(1, motorizedNodeClutchRadSpd/currentMaxSpeed))
		end
	end
	
	--smooth 	
	self.mrRegulatorFxS = 0.9*self.mrRegulatorFxS + 0.1*regulatorFx;
	
	
	--update dummy engine speed
	local dummyEngineRpm = self.mrLastDummyEngineRpm;
	
	
	local updateRpm = function(currentRpm, wantedRpm, incSpeed, dt)	

		--print(tostring(g_currentMission.time) .. " - updateRpm - currentRpm="..tostring(currentRpm) .." - wantedRpm="..tostring(wantedRpm).." - incSpeed="..tostring(incSpeed).." - dt="..tostring(dt))
		
		if self.mrEngineNeedTorque then
			wantedRpm = self.mrMaxTorqueRpm;
			incSpeed = self.mrRpmRange/6;
		elseif requiredMotorRpm>0 then
			wantedRpm = requiredMotorRpm;
			incSpeed = self.mrRpmRange/4;
		end
		if currentRpm>wantedRpm then			
			--decrease rpm
			if wantedRpm<=1.01*self.mrIdleEngineRpm then incSpeed = 2*incSpeed end --20170502 - double rpm speed to get back to idle speed
			return math.max(wantedRpm, currentRpm-incSpeed*dt/1000);
		else
			--increase rpm
			return math.min(wantedRpm, currentRpm+incSpeed*dt/1000);
		end
	end
		
	if engineBraking then
		if engineBrakingTargetRpm>self.mrLastDummyEngineRpm then
			dummyEngineRpm = updateRpm(self.mrLastDummyEngineRpm, engineBrakingTargetRpm, self.mrRpmRange/4.3, dt); -- target the engineBrakingTargetRpm				
		else --faster when trying to reduce the engine speed
			dummyEngineRpm = updateRpm(self.mrLastDummyEngineRpm, engineBrakingTargetRpm, self.mrRpmRange/1.7, dt); -- target the engineBrakingTargetRpm		
		end
	elseif dummyEngineRpm>self.mrMaxPowerRpm then --after an engine braking, we want to return back to the maxpower rpm quite fast
		dummyEngineRpm = updateRpm(self.mrLastDummyEngineRpm, self.mrMaxPowerRpm, self.mrRpmRange/1, dt);
	elseif self.mrRegulatorFxS>0.95 then
		--20170515 - take into account the vehicle acc		
		local accFx = 1
		if wantedSpeed>0 then
			accFx = 5-math.min(4, 3*self.vehicle.lastSpeedAcceleration*1000000)
		else
			accFx = 5-math.min(4, -3*self.vehicle.lastSpeedAcceleration*1000000)
		end
		accFx = math.min(5, accFx)
		--print("test - lastAcceleration=" .. tostring(self.vehicle.lastSpeedAcceleration*1000000) .. " - accFx="..tostring(accFx))
		dummyEngineRpm = updateRpm(self.mrLastDummyEngineRpm, self.mrMaxPowerRpm, (0.5 + math.abs(accelerationPedal)) * self.mrTransmissionReactivity * accFx * self.mrRpmRange/10, dt); -- target the mrMaxPowerRpm					
	elseif self.mrRegulatorFxS<0.8 then
		dummyEngineRpm = updateRpm(self.mrLastDummyEngineRpm, self.mrMinRpmAllowedWithLoad, 20+self.mrRpmRange*(0.26-0.325*self.mrRegulatorFxS), dt); -- try to lower the dummy engine rpm				
	end	
	
	
	
	
	local dummyGearRatio = maxGearRatio;
	local trueRatio = 10000;	
	if self.clutchRpm>1 then
		--print("test mr - dummyEngineRpm="..tostring(dummyEngineRpm) .. " - clutchRpm="..tostring(self.clutchRpm))
		trueRatio = dummyEngineRpm/self.clutchRpm;
		dummyGearRatio = Utils.clamp(trueRatio, minGearRatio, maxGearRatio);
		dummyEngineRpm = math.max(dummyEngineRpm, dummyGearRatio * self.clutchRpm);
		--print("test mr2 - dummyGearRatio="..tostring(dummyGearRatio) .." - dummyEngineRpm="..tostring(dummyEngineRpm))
	end
	
	if trueRatio>dummyGearRatio then
		torqueConverterFx = math.min(1.25, trueRatio/dummyGearRatio);
	end
	
	self.mrLastDummyGearRatio = dummyGearRatio;
	self.mrLastDummyEngineRpm = dummyEngineRpm;
	self.nonClampedMotorRpm = dummyEngineRpm;
	
	--print(tostring(g_currentMission.time) .. " - test dummyEngineRpm="..tostring(dummyEngineRpm))
	
	--20170517 - update the "self.gearRatio" too to know the "mrTransmission" is in use
	self.gearRatio = 0
	
	--20170205 - equalizedMotorRpm variation independant from dt (so that the engine acc or decceleration is the same for every player
	--self.equalizedMotorRpm = 0.95 * self.mrLastEqualizedMotorRpm + 0.05 * dummyEngineRpm;
	if dummyEngineRpm>self.mrLastEqualizedMotorRpm then
		self.equalizedMotorRpm = math.min(dummyEngineRpm, self.mrLastEqualizedMotorRpm+dt*self.rotInertiaFx*500); --max 500 rpm per second ?
	else
		self.equalizedMotorRpm = math.max(dummyEngineRpm, self.mrLastEqualizedMotorRpm-dt*self.rotInertiaFx*1000); --max 1000 rpm per second ?
	end
	
	self.mrLastEqualizedMotorRpm = self.equalizedMotorRpm;
	self:setLastRpm(dummyEngineRpm);
	
	--update torque
	local axleTorque = 0;
	
	
	local neededPtoTorque = PowerConsumer.getTotalConsumedPtoTorque(self.vehicle);
	--print("test vehicleMotor neededPtoTorque = " .. tostring(neededPtoTorque) .. " - ptoRpmWanted="..tostring(ptoRpmWanted))
	
	
	--print("test pto - consume torque = "..tostring(neededPtoTorque));	
	local lastTorqueConsumedByPTO = self.mrLastEngineTorqueConsumedByPto;
	self.mrLastEngineTorqueConsumedByPto = neededPtoTorque/self.ptoMotorRpmRatio;	
	
	
	if self.mrEngineNeedTorque then
		self.mrEngineNeedTorqueRemainingTime = self.mrEngineNeedTorqueRemainingTime - dt;
		if self.mrEngineNeedTorqueRemainingTime<=0 then
			self.mrEngineNeedTorque = false;
		end
	end
	
	--print("test self.mrLastEngineTorqueConsumedByPto = " .. tostring(self.mrLastEngineTorqueConsumedByPto) .. " - neededPtoTorque="..tostring(neededPtoTorque) .. " - self.ptoMotorRpmRatio="..tostring(self.ptoMotorRpmRatio));
	
	local currentEngineMaxTorque = 0;
	if engineBraking then
		dummyEngineTorque = engineBrakingFx * -self.mrEngineBrakingForce * dummyEngineRpm/self.mrEngineBrakeRpm;		
		
		if neededPtoTorque>0 then
			currentEngineMaxTorque = self.torqueCurve:get(dummyEngineRpm) * self.vehicle:mrGetCurrentBoostRatio(self.mrLastEngineTorqueConsumedByPto, motorizedNodeClutchRadSpd);
			if self.mrLastEngineTorqueConsumedByPto>=currentEngineMaxTorque then
				self.mrEngineNeedTorque = true;	
				self.mrEngineNeedTorqueRemainingTime = math.max(self.mrEngineNeedTorqueRemainingTime, 200);
			end
			self.mrLastEngineOutputTorque = math.min(currentEngineMaxTorque, self.mrLastEngineTorqueConsumedByPto);
		
			--add the torque consume by the PTO to the braking force
			if not self.mrEngineBrakeNotLinkedToPTO then
				dummyEngineTorque = dummyEngineTorque - self.mrLastEngineTorqueConsumedByPto;
			end
		end		
		
	elseif math.abs(accelerationPedal)>0 then
		currentEngineMaxTorque = self.torqueCurve:get(dummyEngineRpm) * self.vehicle:mrGetCurrentBoostRatio(self.mrLastEngineTorqueConsumedByPto, motorizedNodeClutchRadSpd);	
		--print(tostring(g_currentMission.time) .. " - currentEngineMaxTorque="..tostring(currentEngineMaxTorque))
		if accPedalRegulateTorque then
			currentEngineMaxTorque = currentEngineMaxTorque * math.abs(accelerationPedal)^0.5; --for cars. On a modern tractor, the injection with a CVT gearbox is fully electronic and not dependant of the acceleration pedal. The acceleration pedal just indicate the target speed
		end	
		
		if neededPtoTorque > 0 then		
			
			dummyEngineTorque = currentEngineMaxTorque - self.mrLastEngineTorqueConsumedByPto; --result can be negative !!! == PTO force transform into engine braking force
			if self.mrEngineBrakeNotLinkedToPTO then
				dummyEngineTorque = math.max(0, dummyEngineTorque) 
			end
			
			if dummyEngineTorque<=0.15*currentEngineMaxTorque then --we need some torque for the transmission too
				self.mrEngineNeedTorque = true;
				self.mrEngineNeedTorqueRemainingTime = math.max(self.mrEngineNeedTorqueRemainingTime, 300);			
			end
		else
			dummyEngineTorque = currentEngineMaxTorque;
		end	
		
		if self.mrEngineTorqueForTransmissionHasPriority then
			dummyEngineTorque = currentEngineMaxTorque
		end
		
		dummyEngineTorque = math.min(maxEngineTorqueForTransmission, dummyEngineTorque);
		self.mrLastEngineOutputTorque = math.max(0, dummyEngineTorque) * regulatorFx + math.min(currentEngineMaxTorque, self.mrLastEngineTorqueConsumedByPto);
		self.mrLastEngineOutputTorque = math.min(self.mrLastEngineOutputTorque, currentEngineMaxTorque)
		
	end
	
	--20171203 - takes into effect "peaks" load at the PTO
	--20171208 - compare with avg lastTorqueConsumedByPTO
	--if currentEngineMaxTorque>0 and (self.mrLastEngineTorqueConsumedByPto-lastTorqueConsumedByPTO)>0.05*currentEngineMaxTorque then
	if currentEngineMaxTorque>0 and self.mrEngineNeedTorque==false and dummyEngineRpm>=0.98*requiredMotorRpm and (self.mrLastEngineTorqueConsumedByPto-lastTorqueConsumedByPTO)>0.05*currentEngineMaxTorque then
	
		self.mrEngineNeedTorque = true;					
		--self.mrEngineNeedTorqueRemainingTime = math.max(self.mrEngineNeedTorqueRemainingTime, 1000*(self.mrLastEngineTorqueConsumedByPto-lastTorqueConsumedByPTO)/currentEngineMaxTorque);
		self.mrEngineNeedTorqueRemainingTime = math.max(self.mrEngineNeedTorqueRemainingTime, 1500*(self.mrLastEngineTorqueConsumedByPto-lastTorqueConsumedByPTO)/currentEngineMaxTorque);
	end
	
	
	--print("test pto2 - self.mrLastEngineOutputTorque="..tostring(self.mrLastEngineOutputTorque));
	--print("dummyEngineTorque = "..tostring(dummyEngineTorque) .. " - engineBraking="..tostring(engineBraking) .. " - wantedSpeed="..tostring(wantedSpeed));
	
	if dummyEngineTorque>=0 then
		--take into account the transmission efficiency
		dummyEngineTorque = regulatorFx * torqueConverterFx * dummyEngineTorque * self.mrTransmissionEfficiency;
		--transform dummy engine torque to axle torque			
		axleTorque = dummyEngineTorque * dummyGearRatio;
		
		if motorizedNodeRadSpd<motorizedNodeClutchRadSpd and dummyEngineTorque>0 then
			--limit the clutch torque and reduce the engine inertia to dampen the speed synchronisation between the motorized node engine and clutch
			clutchTorque = axleTorque;
			rotInertiaFx = 0.1;
		end
		
	else
		axleTorque = 0;
		--manage engine braking by using the clutch torque (0.3 = limiting the clutchTorque at reduced speed to adjust the engine braking force so that it sticks better to what we have in real life)
		clutchTorque = math.max(0.1, math.min(1, 0.3 * motorizedNodeClutchRadSpd) * math.abs(dummyEngineTorque * dummyGearRatio));
		--maxRotSpeed = 0; 
		--we try to keep the "motorized node engine rpm" close to the "clutch rpm" to be ready when the player accelerate again (reduced "lag" time when playing with the accelerator pedal)
		maxRotSpeed = math.max(0, motorizedNodeClutchRadSpd-0.1*self.mrBrakingForceFx); -- 1 axle rad per second = 1 meter per second (speed of the vehicle)
		--print("test clutchTorque = " .. tostring(clutchTorque) .. " - motorizedNodeClutchRadSpd="..tostring(motorizedNodeClutchRadSpd) .. "- dummyEngineTorque="..tostring(dummyEngineTorque) .. " - dummyGearRatio="..tostring(dummyGearRatio));
		
	end
	
	--decrease rotInertia when the motorizedNode rpm is lower than the clutchrpm and the torque is not null (example : accelerate phase, engine braking phase then accelerate phase again)
	--increase rotinertia at starting speed to avoid too much slipping at "launch"
	--increase rotinertia when the current speed is near the wanted speed to increase "stability" of the regulator	
	--if axleTorque~=0 and motorizedNodeRadSpd<motorizedNodeClutchRadSpd then
	--if not engineBraking and motorizedNodeRadSpd<motorizedNodeClutchRadSpd then
	--	rotInertia = 0.000001; --we want the "motorizednode rpm" to catch up with the "clutchrpm" fast enough not to slow down the vehicle
	--	maxRotSpeed = motorizedNodeClutchRadSpd;
	--elseif self.clutchRpm<10 then --10 = 3.77kph
		--rotInertia = (10-0.9*self.clutchRpm)*rotInertia; --@0kph, inertia=10, @3.6kph, inertia=1
	--elseif math.abs(wantedSpeed - finalLastSpeed)<1 then --1 = 3.6kph
	--if math.abs(wantedSpeed - finalLastSpeed)<10 then --1 = 3.6kph
		--rotInertiaFx = (10-0.9*math.abs(wantedSpeed - finalLastSpeed));
	--end	
	
	--rotInertia = math.max(0.01, rotInertiaFx * 0.01 * axleTorque);
	--rotInertia = 0.25 * self.mrMaxTorque * dummyGearRatio * rotInertiaFx;
	rotInertia = math.max(0.1, 0.1 * axleTorque * rotInertiaFx * self.rotInertiaFx);

	--simulate inertia at "launch" (don't put the full axle torque right after throttle up)
	--20170217 - take into account the accelerationPedal rather than the current engine rpm
	if axleTorque>self.mrLastAxleTorque then
	
		--20170606 - take into account the transmission inertia (especially useful when the engine is "fixed" at a given "required rpm". Avoid "infinite" acc possibility for the vehicle
		--since the gear ratio is always 1, that means 1 clutchRpm = 1 normalized wheel rpm = 0.1047m.s-1  = 0.37699 kph
		--transmission inertia + pto tool inertia
		--local transFx = Utils.clamp(0, 1, 1 - 0.37699*self.mrClutchRpmAcc/math.max(3, self.clutchRpm)) -- 10kph per second = fx 0, 0kph per second = fx 1
		
		local transFx = 1
		local targetAxleTorque = axleTorque
		
		if requiredMotorRpm>0 then
			transFx = 0.2 --limit the acc when there is a pto tool activated (we want to avoid, for axample, that a combine fully accelrate before entering the crop area = harder for the speed limiter to get a "steady" harvesting speed)
		end
		
		--if not self.mrUseCarPhysics then
			--local rpmAccFx = 0.05
			--if requiredMotorRpm>0 then
				--rpmAccFx = 0.1
			--end
			--transFx = (1 - math.min(1, rpmAccFx*self.mrClutchRpmAcc))
			transFx = transFx * (1 - 0.9*self.mrLastEngineTorqueConsumedByPto/self.mrMaxTorque)			
		--end
		
		
		if self.mrClutchRpmAcc>1 then --game is not running in "real time". If it is running at 60fps, it means that when we apply a torque of 10, it will be apply during 16.66ms. In real time, the torque applied is different each "nanosecond"
			targetAxleTorque = 0.5 * self.mrLastAxleTorque + 0.5 * targetAxleTorque
		end
	
		--local timeFx = 2000 - 1800*math.abs(accelerationPedal);
		local timeFx = 2000 - 1800*math.abs(accelerationPedal) -- slower at slow acc value
		--print("test - transFx = "..tostring(transFx) .. " - wantedTorque="..tostring(axleTorque) .. " - previous torque="..tostring(self.mrLastAxleTorque) .. " - new torque = "..tostring(self.mrLastAxleTorque + transFx * axleTorque*dt/timeFx))
		axleTorque = math.min(targetAxleTorque, self.mrLastAxleTorque + transFx * targetAxleTorque*dt/timeFx)
	end
	
	--[[
	if axleTorque>self.mrLastAxleTorque then
		--we want about 1000 at idlerpm and 200 at maxPowerRpm (1000=1s and 200=0.2s)
		local timeFx = 1000;
		--if dummyEngineRpm<=self.mrIdleEngineRpm then
		--	timeFx = 1000;
		if dummyEngineRpm>=self.mrMaxPowerRpm then
			timeFx = 200;
		elseif dummyEngineRpm>self.mrIdleEngineRpm then
			--dummyEngineRpm between idle and maxpower rpm
			timeFx = 1000 * RealisticUtils.linearFx2(dummyEngineRpm, self.mrIdleEngineRpm, self.mrMaxPowerRpm, 0.2);
		end			
		axleTorque = math.min(axleTorque, self.mrLastAxleTorque + axleTorque*dt/timeFx);
		--print("test axletorque - timeFx="..tostring(timeFx) .." - dummyEngineRpm="..tostring(dummyEngineRpm));
	end--]]
	--end
	
	self.mrLastAxleTorque = axleTorque;
	
	
	--print(string.format("%6.0f acc=%1.2f, eRpm=%4.3f, clutchRpm=%4.3f, torque=%4.4f, maxRotSpeed=%4.3f, gearRatio=%3.1f, clutchTorque=%3.1f, rotInertia=%1.2f, dampingRate=%1.2f, dummyGearRatio=%1.2f, regulator=%1.2f/%1.2f, dummyEngineRpm=%1.2f,wantedSpeed=%1.2f, finalLastSpeed=%1.2f, engineBraking=%s, vehicleIsStill=%s  ---- VehicleMotor.mrUpdateVehicleProps",g_currentMission.time,accelerationPedal,motorizedNodeRadSpd* 30 / math.pi, self.clutchRpm,axleTorque*1000,maxRotSpeed*30/math.pi, gearRatio, clutchTorque,rotInertia*1000,dampingRate*1000,dummyGearRatio,regulatorFx,self.mrRegulatorFxS,dummyEngineRpm,wantedSpeed*3.6,finalLastSpeed*3.6,tostring(engineBraking), tostring(self.vehicle.mrVehicleIsStill)));
	
	--update engine load
	self.motorLoad = axleTorque / dummyGearRatio;
	
	

	return axleTorque, maxRotSpeed, gearRatio, clutchTorque, rotInertia, dampingRate;

end