﻿--************************************************************************************************************************************************************
--** backup information on steering time (in case the articulated axis can be desactivated with crabsteering Specialization, we want to be able to use the default ackermann settings)
ArticulatedAxis.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then return end
	
	--backup the ackermann steering settings alone (without the articulated axis ON)
	self.mrArticulatedAxisBackupMaxRotTime = self.maxRotTime
	self.mrArticulatedAxisBackupMinRotTime = self.minRotTime
	self.mrArticulatedAxisBackupWheelSteeringDuration = self.wheelSteeringDuration

end
ArticulatedAxis.load = Utils.prependedFunction(ArticulatedAxis.load, ArticulatedAxis.mrLoad);

