﻿--************************************************************************************************************************************************************
--** load the specific mrWheelSteeringDuration parameter for each crab steering mode if present (useful to get a different "wheelSteeringDuration" when the articulated is locked or not)
CrabSteering.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then return end
	
	--backup the steering settings when articulatedAxis and ackermann steering are ON together
	self.mrCrabSteeringBackupMaxRotTime = self.maxRotTime
	self.mrCrabSteeringBackupMinRotTime = self.minRotTime
	self.mrCrabSteeringBackupWheelSteeringDuration = self.wheelSteeringDuration
	

end
CrabSteering.load = Utils.appendedFunction(CrabSteering.load, CrabSteering.mrLoad);


--************************************************************************************************************************************************************
--** get back to the default ackermann steering settings when the articulated axis is OFF
CrabSteering.mrUpdateSteeringAngle = function(self, superFunc, wheel, dt, steeringAngle)

	if not self.mrIsMrVehicle then return superFunc(self, wheel, dt, steeringAngle) end

	local currentMode = self.crabSteering.steeringModes[self.crabSteering.state];
	
	if currentMode~=nil then
		if currentMode.articulatedAxis ~= nil and currentMode.articulatedAxis.locked then
			self.maxRotTime = self.mrArticulatedAxisBackupMaxRotTime
			self.minRotTime = self.mrArticulatedAxisBackupMinRotTime
			self.wheelSteeringDuration = self.mrArticulatedAxisBackupWheelSteeringDuration
		else
			self.maxRotTime = self.mrCrabSteeringBackupMaxRotTime
			self.minRotTime = self.mrCrabSteeringBackupMinRotTime
			self.wheelSteeringDuration = self.mrCrabSteeringBackupWheelSteeringDuration
		end
	end
	
	return superFunc(self, wheel, dt, steeringAngle)
end
CrabSteering.updateSteeringAngle = Utils.overwrittenFunction(CrabSteering.updateSteeringAngle, CrabSteering.mrUpdateSteeringAngle);