﻿

--************************************************************************************************************************************************************
--** we can override the default mixingActiveTimerMax value
MixerWagon.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then
		return
	end
	
	local newMixingActiveTimerMax = getXMLFloat(self.xmlFile, "vehicle.moreRealistic.mixerWagon#mixingActiveTimerMax")
	if newMixingActiveTimerMax~=nil then
		self.mixingActiveTimerMax = newMixingActiveTimerMax --default hard-coded giants value = 5000
	end
	
	self.mixerWagon.mrFillMassDependantPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.mixerWagon#fillMassDependantPtoPower"), 0) -- KW per ton
	self.mixerWagon.mrUseDependantPtoPower = self.mixerWagon.mrFillMassDependantPtoPower>0
	if self.mixerWagon.mrUseDependantPtoPower then
		self.getPtoRpm = MixerWagon.mrGetPtoRpm
		self.getConsumedPtoTorque = MixerWagon.mrGetConsumedPtoTorque
		self.mrGetMassDependantPtoPower = MixerWagon.mrGetMassDependantPtoPower
	end
	self.getDoConsumePtoPower = MixerWagon.mrGetDoConsumePtoPower
	self.mrIsMixing = MixerWagon.mrIsMixing
	self.mrUpdateFillPlaneMovingEffect = MixerWagon.mrUpdateFillPlaneMovingEffect
	
	if self.isClient then
		--varying fillPlanes height
		--load default node position
		for _,fillVolume in pairs(self.fillVolumes) do
			local x,y,z = getTranslation(fillVolume.baseNode)
			fillVolume.mrBaseNodeTranslation = {x=x, y=y, z=z}
		end
		
		self.mixerWagon.mrShakingEffect = {}
		self.mixerWagon.mrShakingEffect.isActive = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.moreRealistic.mixerWagon#useShakingEffect"), true)
		self.mixerWagon.mrShakingEffect.timeToUpdate = 0
		self.mixerWagon.mrShakingEffect.refreshTime = 1500 -- 1.5s		
		self.mixerWagon.mrShakingEffect.literPerSecond = 5		
		self.mixerWagon.mrShakingEffect.shakingPoints = {}
		self.mixerWagon.mrShakingEffect.shakingPointNumber = 6 --must be an "even" number so that the visual fillLevel does not change
		
	end
	
	--fix small bug : when loading the game, if the mixer wagon is not empty, it is "mixing" for 5s (default mixingActiveTimerMax) and we can hear the sound
	self.mixingActiveTimer = 0
	self.mrActiveTimerBackup = 0
	
end
MixerWagon.load = Utils.appendedFunction(MixerWagon.load, MixerWagon.mrLoad)



--************************************************************************************************************************************************************
--do not allow mixing when no engine running
MixerWagon.mrUpdate1 = function(self, dt)
	
	if not self.mrIsMrVehicle then
		return;
	end;
	--check if engine is running
	if self.mixingActiveTimer > 0 then
		local mixingAllowed = false;
		if self.getIsMotorStarted~=nil then
			if self:getIsMotorStarted() then
				mixingAllowed = true;
			end;
		else
			local rootAttacherVehicle = self:getRootAttacherVehicle();
			if rootAttacherVehicle~=nil and rootAttacherVehicle.getIsMotorStarted~=nil then
				if rootAttacherVehicle:getIsMotorStarted() then
					mixingAllowed = true;
				end;
			end;
		end;
		if not mixingAllowed then
			self.mrActiveTimerBackup = self.mixingActiveTimer;
			self.mixingActiveTimer = 0;
		end;
	end;
	
end;
MixerWagon.update = Utils.prependedFunction(MixerWagon.update, MixerWagon.mrUpdate1)

--************************************************************************************************************************************************************
--** update shaking effect
MixerWagon.mrUpdate2 = function(self, dt)
	
	if not self.mrIsMrVehicle then
		return;
	end;
	self:mrUpdateFillPlaneMovingEffect(dt);
	
	--give back mixingActiveTimer its former value if needed
	if self.mrActiveTimerBackup>0 then
		self.mixingActiveTimer = self.mrActiveTimerBackup;
		self.mrActiveTimerBackup = 0;		
	end;
	
end;
MixerWagon.update = Utils.appendedFunction(MixerWagon.update, MixerWagon.mrUpdate2)


--************************************************************************************************************************************************************
--** stop the "mixingActiveTimer" if the wagon is unloading
--** update mass dependant pto power
MixerWagon.mrUpdateTick = function(self, dt)
		
	if not self.mrIsMrVehicle then
		return
	end
	
	if self.tipState == Trailer.TIPSTATE_OPENING or self.tipState == Trailer.TIPSTATE_OPEN then
		self.mixingActiveTimer = 0
	end	
	
end
MixerWagon.updateTick = Utils.appendedFunction(MixerWagon.updateTick, MixerWagon.mrUpdateTick)

	
--************************************************************************************************************************************************************
-- take into account the mass dependant mixing power requirement
MixerWagon.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then			
			local totalPower = self.powerConsumer.mrNoLoadPtoPower + self:mrGetMassDependantPtoPower()			
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end

--************************************************************************************************************************************************************
-- pto power when unloading too
MixerWagon.mrGetPtoRpm = function(self)
    if self:mrIsMixing() then
        return self.powerConsumer.ptoRpm
    end
    return 0
end

--************************************************************************************************************************************************************
-- pto power when unloading too
MixerWagon.mrGetDoConsumePtoPower = function(self)
	return self:mrIsMixing()	
end

--************************************************************************************************************************************************************
-- compute the mass dependant mixing power requirement
MixerWagon.mrGetMassDependantPtoPower = function(self)

	local ptoPower = 0
	if self.mixerWagon.mrUseDependantPtoPower then
		local currentFillType = self:getUnitFillType(self.mixerWagon.fillUnitIndex)
		if currentFillType~=FillUtil.FILLTYPE_UNKNOWN then
			local currentFillMass = self:getFillLevel() * FillUtil.fillTypeIndexToDesc[currentFillType].massPerLiter
			ptoPower = self.mixerWagon.mrFillMassDependantPtoPower * currentFillMass
		end
	end
	return ptoPower

end

--************************************************************************************************************************************************************
-- update the "shaking" effect of the fillplane if needed
MixerWagon.mrUpdateFillPlaneMovingEffect = function(self, dt)

	if self.isClient and self.mixerWagon.mrShakingEffect.isActive then
		if self:mrIsMixing() then
			local fillUnit = self.fillUnits[self.mixerWagon.fillUnitIndex]
			if fillUnit == nil then
				return
			end
			local fillVolume = self.fillVolumes[fillUnit.fillVolumeIndex]
			if fillVolume == nil then
				return
			end
			
			
			if g_currentMission.time>self.mixerWagon.mrShakingEffect.timeToUpdate then
				self.mixerWagon.mrShakingEffect.timeToUpdate = g_currentMission.time + self.mixerWagon.mrShakingEffect.refreshTime
				--update all the "moving point"
				for i=1, self.mixerWagon.mrShakingEffect.shakingPointNumber do
					self.mixerWagon.mrShakingEffect.shakingPoints[i] = {localToWorld(fillVolume.volume, 1.15-2.3*math.random(),100,2-4*math.random())}
				end				
			end
			
			local delta = self.mixerWagon.mrShakingEffect.literPerSecond*dt/1000 -- liters per second
			local d1x,d1y,d1z = localDirectionToWorld(fillVolume.volume, 0.2,0,0);
			local d2x,d2y,d2z = localDirectionToWorld(fillVolume.volume, 0,0,0.2);
			for i,shakingPoint in pairs(self.mixerWagon.mrShakingEffect.shakingPoints) do
				
				--print("test - i="..tostring(i) .. " - shakingPoint="..tostring(shakingPoint) .. " - shakingPoint[1]="..tostring(shakingPoint[1]) .. " - i%2="..tostring(i%2))
			
				local d = delta
				if (i%2)==0 then
					d = -delta
				end
			
				local x,y,z = shakingPoint[1], shakingPoint[2], shakingPoint[3]				
				x = x - (d1x+d2x)/2;
				y = y - (d1y+d2y)/2;
				z = z - (d1z+d2z)/2;
				fillPlaneAdd(fillVolume.volume, d, x,y,z, d1x,d1y,d1z, d2x,d2y,d2z);
			end
			
		end
	end

end


--************************************************************************************************************************************************************
-- return true if mixing rotating part are running
MixerWagon.mrIsMixing = function(self)
	return self.mixingActiveTimer > 0 or self:getIsTurnedOn() or self.tipState == Trailer.TIPSTATE_OPENING or self.tipState == Trailer.TIPSTATE_OPEN
end