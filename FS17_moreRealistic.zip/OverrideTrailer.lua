﻿

--************************************************************************************************************************************************************
--load tipping power consumption (used by PowerConsumer class)
Trailer.mrLoad = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	self.mrTrailer = {}
	self.mrTrailer.openingPtoPower  = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.trailer#openingPtoPower"), 0); -- KW
	self.mrTrailer.unloadingPtoPower  = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.trailer#unloadingPtoPower"), 0); -- KW
	self.mrTrailer.useTippingPtoPower = (self.mrTrailer.openingPtoPower + self.mrTrailer.unloadingPtoPower)>0
	self.mrTrailer.isUnloading = false
	
end
Trailer.load = Utils.appendedFunction(Trailer.load, Trailer.mrLoad)



Trailer.mrOnStartTip = function(self, tipTrigger, tipReferencePointIndex, noEventSend)
	if self.mrIsMrVehicle then
		self.mrTrailer.isUnloading = true
	end
end
Trailer.onStartTip = Utils.appendedFunction(Trailer.onStartTip, Trailer.mrOnStartTip)


Trailer.mrOnEndTip = function(self, noEventSend)
	if self.mrIsMrVehicle then
		self.mrTrailer.isUnloading = false
	end
end
Trailer.onEndTip = Utils.appendedFunction(Trailer.onEndTip, Trailer.mrOnEndTip)

	
Trailer.mrUpdateTick = function(self, dt)
	--mrNeedEngineRunningForTorque + automaticMotorStartEnabled = the engine is started automatically when required => we don't have to endTip here
	if self.isServer and self.mrNeedEngineRunningForTorque and not g_currentMission.missionInfo.automaticMotorStartEnabled and self.mrTrailer.isUnloading then
		--check engine is running, otherwise, endtip		
		local engineRunning = false;
		local rootAttacherVehicle = self:getRootAttacherVehicle(); --can be self or the attacher vehicle 
		if rootAttacherVehicle~=nil and rootAttacherVehicle.getIsMotorStarted ~= nil then
			engineRunning = rootAttacherVehicle:getIsMotorStarted();
		end;
		
		if not engineRunning then
			self:onEndTip();
		end;
	end;
end;
Trailer.updateTick = Utils.appendedFunction(Trailer.updateTick, Trailer.mrUpdateTick)



