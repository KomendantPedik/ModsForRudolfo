﻿--************************************************************************************************************************************************************
--we want to apply the correct mass to the bale (all bales = 400kgs in the base game, whatever the bale type and size or the content type or the fillLevel)
--base game = mass comes from the i3d file
--problem : base game script does not use the "setFillLevel" function for bale except in the case of the strawBlower
--and so, we have to "override" loading functions too

--value scale compared to selling "loose material"
Bale.MR_ROUNDBALE_VALUESCALE = 2
Bale.MR_LARGESQUAREBALE_VALUESCALE = 1.7
Bale.MR_SMALLSQUAREBALE_VALUESCALE = 4

-- silage bales = cheaper than whole silage -> we want players to make silage bales for cattle, not for biogas (moreover, IRL, silage bales = about the same price as hay bales)
-- in the game, silage in silos from grass or maize = same thing. And silage coming from grass bale with tarp = same thing too. IRL, we are talking of 3 different "fillTypes"
Bale.MR_SILAGEBALE_VALUESCALE = 0.6 
Bale.MR_SILAGEBALE_DENSITY = 0.25 -- can be overwritten by MR GAMEPLAY or OTHER MODs

--*******************************************************
Bale.mrSetFillLevel = function(self, fillLevel)
	Bale.mrUpdateMass(self)
end
Bale.setFillLevel = Utils.appendedFunction(Bale.setFillLevel, Bale.mrSetFillLevel)

--*******************************************************
--bale newly created = call of Bale.load
--bale loaded from a savegame = call of Bale.loadFromAttributesAndNodes
Bale.mrInit = function(self)
	--20170912 - modify bale price (we want some profitability for players baling to sell the bales. Moreover, we want bales having better value than loose material)
	--check if the mod Seasons is not already taking care of that point
	if g_seasons==nil then
		self.getValue = Utils.overwrittenFunction(self.getValue, Bale.mrGetValue)		
	end	
	Bale.mrUpdateMass(self)
end

--*******************************************************
Bale.mrLoad = function(self, i3dFilename, x,y,z, rx,ry,rz, fillLevel)	
	Bale.mrInit(self)	
end
Bale.load = Utils.appendedFunction(Bale.load, Bale.mrLoad)

--*******************************************************
Bale.mrLoadFromAttributesAndNodes = function(self, superFunc, xmlFile, key, resetVehicles)
	if superFunc(self, xmlFile, key, resetVehicles) then
		Bale.mrInit(self)
		return true
	else
		return false
	end
end
Bale.loadFromAttributesAndNodes = Utils.overwrittenFunction(Bale.loadFromAttributesAndNodes, Bale.mrLoadFromAttributesAndNodes)

--*******************************************************
Bale.mrUpdateMass = function(self)

	if self.mrResetCapacity then -- necessary to handle the FS17_BuyBales fillLevel change
		--first check if this is a roundbale or a squarebale
		if self.baleDiameter~=nil then
			self.fillLevel = 3000			
		else
			self.fillLevel = 6000
		end
		if g_currentMission.mrGameplayBalerFillLevelScaling~=nil then						
			self.fillLevel = RealisticUtils.roundNumberBaleCapacity(self.fillLevel * g_currentMission.mrGameplayBalerFillLevelScaling)			
		end
		--20170913 - no more fillLevel adjusting since we are using a different density for grass bale silage
		--[[
		if self.fillType==FillUtil.FILLTYPE_SILAGE then
			--adjust massFactor for silage bale
			local grassDensity = FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_GRASS].massPerLiter
			local silageDensity = FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_SILAGE].massPerLiter
			if silageDensity>0 then
				self.fillLevel = self.fillLevel * 0.9*grassDensity/silageDensity
			end
		end--]]
	end
	
	--make sure we are serverside
	if self.isServer then
		--make sure the bale still exists (in case it has been destroyed by a "bale destroyer" ?
		if entityExists(self.nodeId) then
			local fillLevelMass = 0
			local desc = FillUtil.fillTypeIndexToDesc[self.fillType]
			if desc ~= nil then
				local massPerLiter = desc.massPerLiter
				--20170913 - grass silage = different density than maize silage
				if self.fillType==FillUtil.FILLTYPE_SILAGE then
					massPerLiter = Bale.MR_SILAGEBALE_DENSITY * 0.001 -- ton per Liter
				end
				fillLevelMass = massPerLiter * self.fillLevel
			end		
			--print(tostring(g_currentMission.time).. " - mrUpdateMass - fillLevel = " .. tostring(self.fillLevel) .. " - density=" .. tostring(desc.massPerLiter*1000) .. " - mass="..tostring(fillLevelMass) .. " - fillType=" .. desc.name)
			
			setMass(self.nodeId, fillLevelMass)
			--20170815 - add some angularDamping
			setAngularDamping(self.nodeId, 0.1)
		end
	end
end


--*******************************************************
Bale.mrGetValue = function(self, superFunc)

	local pricePerLiter = g_currentMission.economyManager:getPricePerLiter(self.fillType)	
	--it seems baleValueScale is not really used by vanilla game or modders => remove it and apply our own "scale"
	--local balePrice = self.fillLevel * pricePerLiter * self.baleValueScale
	local balePrice = self.fillLevel * pricePerLiter
	
	if self.fillType==FillUtil.FILLTYPE_SILAGE then --silage bale
		balePrice = balePrice * Bale.MR_SILAGEBALE_VALUESCALE
	elseif self.baleDiameter~=nil then--roundbale
		balePrice = balePrice * Bale.MR_ROUNDBALE_VALUESCALE
	elseif self.baleWidth>0.7 then--largesquarebale
		balePrice = balePrice * Bale.MR_LARGESQUAREBALE_VALUESCALE
	else--other bales (small square bales)
		balePrice = balePrice * Bale.MR_SMALLSQUAREBALE_VALUESCALE
	end
	
	--print("test mrGetValue - fillLevel="..tostring(self.fillLevel) .. " - balePrice="..tostring(balePrice))
	
	return balePrice

end

