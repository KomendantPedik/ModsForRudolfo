﻿--************************************************************************************************************************************************************
--fix default pallet capacity and empty weight that were too large compared to IRL
FillablePallet.mrSetNodeId = function(self, nodeId)
	local i3dSpecificCapacity = tonumber(getUserAttribute(nodeId, "capacity"));
	--print("test pallet 1 - i3dSpecificCapacity="..tostring(i3dSpecificCapacity) .. " - name="..self.i3dFilename .. " mass="..getMass(nodeId))
	if i3dSpecificCapacity==nil then
		--print("test pallet - " .. self.i3dFilename .. " mass="..getMass(nodeId))
		--check if this is the default potatoes pallet		
		if self.i3dFilename=="data/objects/pallets/palletPotato.i3d" then
			self.capacity = 850; -- 1.35m x 0.96m x 0.65m
			setMass(nodeId, 0.05); --50kgs empty
		--check if this is the default sugarbeet pallet
		elseif self.i3dFilename=="data/objects/pallets/palletSugarBeet.i3d" then
			self.capacity = 850;
			setMass(nodeId, 0.05); --50kgs empty
		end;
	else		
		if self.i3dFilename=="data/objects/pallets/fertilizerTank.i3d" then -- default liquid fertilizer pallet
			setMass(nodeId, 0.1); --100kgs empty
		elseif self.i3dFilename=="data/objects/bigBagContainer/bigBagContainerFertilizer.i3d" then -- default solid fertilizer pallet
			setMass(nodeId, 0.075); --75kgs empty
		elseif self.i3dFilename=="data/objects/bigBagContainer/bigBagContainerSeeds.i3d" then -- default seeds pallet
			setMass(nodeId, 0.050); --50kgs empty
		elseif string.len(self.i3dFilename)>55 then
			local str=string.sub(self.i3dFilename, -51) -- 51 char from the end of the string
			--print("test pallet 2 - str = " .. str)
			if str=="platinumEdition/objects/pallets/palletSugarCane.i3d" then -- default sugarcane pallet
				setMass(nodeId, 0.050); --50kgs empty
			end;
		end;
	end;
end;
FillablePallet.setNodeId = Utils.prependedFunction(FillablePallet.setNodeId, FillablePallet.mrSetNodeId)