﻿
---------------------------------------------------------------------------------------------------
--MR : display debug data
---------------------------------------------------------------------------------------------------
Pipe.mrUpdatePipe = function(self, dt, trailer)

	if Vehicle.debugRendering then
		if trailer~=nil then
		
			--display fillAutoAimTarget point	
			RealisticUtils.drawPoint(trailer.fillAutoAimTarget.node)			
			
			--display pipe raycast node
			local x1,y2,z2 = getWorldTranslation(self.pipeRaycastNode);
			--local x,y,z = localDirectionToWorld(self.pipeRaycastNode, 1,0,0)
			--drawDebugLine(x1,y2,z2, 1,0,0, x1+x,y2+y,z2+z, 1,0,0)
			
			local x,y,z = localDirectionToWorld(self.pipeRaycastNode, 0,-self.pipeRaycastDistance ,0)
			drawDebugLine(x1,y2,z2, 0,1,1, x1+x,y2+y,z2+z, 0,1,1)

			local doAutoAiming = trailer ~= nil and entityExists(trailer.components[1].node) and self.pipeStateIsAutoAiming[self.pipeCurrentState]
			if doAutoAiming then
				for i=1, table.getn(self.pipeNodes) do          
					local pipeNode = self.pipeNodes[i]
					if pipeNode.rotationSpeeds ~= nil then
						for i=1, 3 do
							if pipeNode.autoAimXRotation and i == 1 then							
								--display pipeNode.node
								RealisticUtils.drawPoint(pipeNode.node)								
							end							                    
						end                
					end           
				end
			end -- autoaiming
			
		end -- trailer nil 
        
    end -- debugRendering
	
end
Pipe.updatePipe = Utils.appendedFunction(Pipe.updatePipe, Pipe.mrUpdatePipe)

---------------------------------------------------------------------------------------------------
--MR : load mrNoUnloadingDistanceEffect parameter
---------------------------------------------------------------------------------------------------
Pipe.mrLoad = function(self, savegame)

	local xmlEffectsPath = "vehicle.pipeEffect"
	local i = 0
	while true do
		local xmlKey = string.format("vehicle.pipeEffect.effectNode(%d)", i)
		if not hasXMLProperty(self.xmlFile, xmlKey) then
            break
		end
		
		local mrNoUnloadingDistanceEffect =  getXMLBool(self.xmlFile, xmlKey.."#mrNoUnloadingDistanceEffect")
		if mrNoUnloadingDistanceEffect~=nil then
			self.pipeEffects[i+1].mrNoUnloadingDistanceEffect = mrNoUnloadingDistanceEffect
		end
		
		i = i + 1
	end

end
Pipe.load = Utils.appendedFunction(Pipe.load, Pipe.mrLoad)


---------------------------------------------------------------------------------------------------
--MR : check mrNoUnloadingDistanceEffect parameter
--20171223 - fix bug = about 50% unloading speed on the ground compared to unloading into a trailer (problem only visible when unloading capacity is not too large)
---------------------------------------------------------------------------------------------------
Pipe.mrUpdateTick = function(self, superFunc,  dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end

    -- if a trailer was found, check (and adjust) control group of cylindered
    if self.isServer and self.hasPipe then --and self:getIsActive() then
        if self.pipeStateIsUnloading[self.pipeCurrentState] and self.trailerFound ~= 0 and self.pipeDisableManualMovement then
            if self.numControlGroups ~= nil and self.numControlGroups > 1 then
                local activeGroup = self.controlGroups[self.activeControlGroupIndex];
                if activeGroup.groupName == self.pipeControlGroupName then
                    local nextIndex = self:getNextValidControlGroupIndex();
                    if nextIndex ~= self.activeControlGroupIndex then
                        self:setActiveControlGroup(nextIndex);
                    end
                end
            end
        end
        self.pipeFoundTrailer = false;
        if not self:getOverloadingActive() then
            self:stopOverloadingDelay();
        end;
    end
    if self.isServer then
        if (self:getUnitFillLevel(self.overloading.fillUnitIndex) > 0 or self:getUnitCapacity(self.overloading.fillUnitIndex) == 0) and self.pipeStateIsUnloading[self.pipeCurrentState] then
            if self.pipeEffects ~= nil then
                if self.pipeEffects[self.groundUnloadingPipeEffect] ~= nil then
                    local controlPointY = self.pipeEffects[self.groundUnloadingPipeEffect].controlPointY;
                    local distance = self.pipeEffects[self.groundUnloadingPipeEffect].distance;
                    if controlPointY ~= nil and distance ~= nil and controlPointY ~= 0 then
                        local mCos = math.cos(controlPointY);
                        local mSin = math.sin(controlPointY);
                        local y = Utils.dotProduct(0, 0, distance, 0.0, mCos, -mSin);
                        local z = Utils.dotProduct(0, 0, distance, 0.0, mSin, mCos);
                        if self.pipeStateIsUnloading[self.pipeTargetState] then
                            local x, y, z = localToWorld(self.pipeEffects[self.groundUnloadingPipeEffect].node, 0, y, z);
                            self.groundUnloadingPosition = {x, y, z};
                        end;
                    end;
                end;
            end;
            -- do raycast
            self.trailerFound = 0;
            self.shovelTargetFound = nil;
            self.trailerFoundDistance = 0;
            if self.pipeRaycastNode ~= nil then
                local doRaycast = self.pipeStateIsUnloading[self.pipeTargetState];
                if doRaycast then
                    local x,y,z = getWorldTranslation(self.pipeRaycastNode);
                    local dx,dy,dz = localDirectionToWorld(self.pipeRaycastNode, 0,-1,0);
                    raycastAll(x, y, z, dx,dy,dz, "findTrailerRaycastCallback", self.pipeRaycastDistance, self);
                end
                if self.trailerFoundDistance == 0 then
                    self.trailerFound = 0;
                end;
                if self.targetTrailer ~= nil then
                    if self.targetTrailer.coverAnimation ~= nil then
                        if not self.targetTrailer.isCoverOpen then
                            self.trailerFound = 0;
                        end;
                    end;
                end;
            end
            if self.trailerFound ~= 0 or self.shovelTargetFound ~= nil then
                if self.dischargeToGround then
                    self:setDischargeToGround(false);
                end
            else
                if self.dischargeToGround then
                    if not self:getCanTipToGround() or (self.overloading.stopOverloadIfEmpty and (self:getUnitLastValidFillType(self.overloading.fillUnitIndex) == FillUtil.FILLTYPE_UNKNOWN or self:getUnitFillLevel(self.overloading.fillUnitIndex) == 0)) then
                        self:setDischargeToGround(false);
                    end
                end
            end
            if self.dischargeToGround then
                if self:getUnitFillLevel(self.overloading.fillUnitIndex) > 0 and not self:getOverloadingDelayIsActive() then
                    self:startOverloadingDelay();
                end;
                local node = self.pipeRaycastNode;
                if self.pipeDischargeInfoIndex ~= nil then
                    node = self.fillVolumeDischargeInfos[self.pipeDischargeInfoIndex].nodes[1].node;
                end;
                local speed = 10;
                local x,y,z = Utils.getIntersectionOfLinearMovementAndTerrain(node, speed);
                local x0,y0,z0 = getWorldTranslation(node);
                self.pipeUnloadingDistance = Utils.vector3Length(x0-x, y0-y, z0-z);
                if self.groundUnloadingPosition[1] ~= 0 then
                    x,y,z = unpack(self.groundUnloadingPosition);
                end;
                if self:getAllowDelayedUnloading() then
                    local fillType = self:getUnitLastValidFillType(self.overloading.fillUnitIndex);
                    local fillLevel = self:getUnitFillLevel(self.overloading.fillUnitIndex);
                    local deltaFill = fillLevel;
                    if self.lastLostFillLevel ~= nil then
                        deltaFill = math.max(fillLevel, self.lastLostFillLevel);
                    end
                    if self:getUnitCapacity(self.overloading.fillUnitIndex) > 0 then
                        deltaFill = math.min(deltaFill, self.overloading.capacity*dt/1000.0);
                    end
                    --self.remainingFillLevelToGround = math.min(self.remainingFillLevelToGround + deltaFill, math.max(self.overloading.capacity*dt/1000.0, TipUtil.getMinValidLiterValue(fillType)));
					--MR : when TipUtil.tipToGroundAroundLine is called twice in a row (small time between 2 calls = example : every updateTick) at the same place, it will return a dropped value of 0 the second time
					--and so, to keep our "overloading.capacity" rate, we have to keep the latest "remainingFillLevelToGround" and add it to the current self.overloading.capacity
					--Update = it seems the problem is the following : we can't drop a given number on the ground. It works with "plateau" (level) Example : 15L per 15L for soybean (you can drop, 0, 15, 30, 45 = any multiple of 15)
					--and so, if the self.overloading.capacity*dt/1000 is smaller than 15 (example 14), there is nothing drop on the ground. The next call, since we add both the remainingFillLevelToGround and the new self.overloading.capacity*dt/1000, we got 28 to drop
					--and so, there is 15 dropped on the ground
					self.remainingFillLevelToGround = math.min(self.remainingFillLevelToGround + deltaFill, TipUtil.getMinValidLiterValue(fillType) + self.overloading.capacity*dt/1000);
                    if self.remainingFillLevelToGround > 0 then
                        local infos = self.fillVolumeDischargeInfos[self.overloading.dischargeInfoIndex];
                        local dx,dy,dz;
                        if infos ~= nil then
                            dx,dy,dz = localDirectionToWorld(infos.nodes[1].node, infos.nodes[1].width,0,0);
                        else
                            dx,dy,dz = localDirectionToWorld(self.components[1].node, 0,0,0.25);
                        end
                        local sx, sy, sz = x+dx, y+dy, z+dz;
                        local ex, ey, ez = x-dx, y-dy, z-dz;
                        if self.limitDischargeToPipeHeight then
                            if infos ~= nil then
                                local _,y,_ = localToWorld(infos.nodes[1].node, infos.nodes[1].width,0,0);
                                sy = y;
                                local _,y,_ = localToWorld(infos.nodes[1].node, -infos.nodes[1].width,0,0);
                                ey = y;
                            else
                                local _,y,_ = getWorldTranslation(self.pipeRaycastNode);
                                sy = y;
                                ey = y;
                            end
                        else
                        end
                        local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, self.remainingFillLevelToGround, fillType, sx,sy,sz, ex,ey,ez, 0.1, nil, self.tipToGroundLineOffset, self.limitDischargeToPipeHeight, self.tipOcclusionAreas);
                        self.tipToGroundLineOffset = lineOffset;
						--print((g_currentMission.time) .. " self.remainingFillLevelToGround = "..tostring(self.remainingFillLevelToGround) .. " dropped="..tostring(dropped))
                        self.remainingFillLevelToGround = self.remainingFillLevelToGround - dropped;
                        self:setUnitFillLevel(self.overloading.fillUnitIndex, fillLevel - dropped, fillType, false, self.fillVolumeUnloadInfos[self.overloading.unloadInfoIndex]);
                        self.overloading.didOverload = dropped > 0;
                    end
                end;
                if not self:getCanTipToGround() or (self.overloading.stopOverloadIfEmpty and (self:getUnitLastValidFillType(self.overloading.fillUnitIndex) == FillUtil.FILLTYPE_UNKNOWN or self:getUnitFillLevel(self.overloading.fillUnitIndex) == 0)) then
                    self:setDischargeToGround(false);
                end
            elseif not self.dischargeToGround and self.overloading.isActive then
                self.pipeUnloadingDistance = self.trailerFoundDistance;
            end
        else
            self.trailerFound = 0;
            self.shovelTargetFound = nil;
            -- stop discharge to ground if pipe gets folden
            if self.dischargeToGround and (not self.pipeStateIsUnloading[self.pipeCurrentState] or (self.overloading.stopOverloadIfEmpty and (self:getUnitLastValidFillType(self.overloading.fillUnitIndex) == FillUtil.FILLTYPE_UNKNOWN or self:getUnitFillLevel(self.overloading.fillUnitIndex) == 0))) then
                self:setDischargeToGround(false);
            end
        end
    end;
    if self.isServer then
        if self.pipeUnloadingDistance ~= self.sentPipeUnloadingDistance or self.sentPipeFoundTrailer ~= self.pipeFoundTrailer then
            self:raiseDirtyFlags(self.pipeDirtyFlag);
            self.sentPipeUnloadingDistance = self.pipeUnloadingDistance;
            self.sentPipeFoundTrailer = self.pipeFoundTrailer;
        end
    end
    if self.isClient then
        self.overloading.delay.time = self.pipeBaseDelay
        if self.delayEffect ~= nil then
            self.overloading.delay.time = self.delayEffect.startDelay + (1-self.delayEffect.offset)*self.delayEffect.fadeInTime
        end
        if self:getIsActiveForInput(self) then
            if self.pipeOffsets ~= nil then
                for _, offset in pairs(self.pipeOffsets) do
                    local movingTool = offset.movingTool
                    local state = Cylindered.getMovingToolState(self, movingTool);
                    for _, effect in pairs(offset.effects) do
                        local effectState = state
                        if effect.inverted then
                            effectState = 1 - effectState
                        end
                        effect.effect:setOffset(Utils.lerp(effect.minValue, effect.maxValue, effectState))
                        if effect.adjustDelay then
                            local delay = Utils.lerp(effect.minDelay, effect.maxDelay, effectState)
                            effect.effect:setDelays(delay, delay)
                        end
                    end
                end
            end
        end
        if self:getAllowDelayEffects() and (self.pipeFoundTrailer or self.dischargeToGround or self.shovelTargetFound ~= nil) then
            self.pipeParticleDeactivateTime = g_currentMission.time + self.pipeUnloadEffectStopTime;
            local currentPipeParticleSystems = self.pipeParticleSystems[self:getUnitLastValidFillType(self.overloading.fillUnitIndex)];
            if currentPipeParticleSystems ~= self.currentPipeParticleSystems then
                if self.currentPipeParticleSystems ~= nil then
                    for _, ps in pairs(self.currentPipeParticleSystems) do
                        ParticleUtil.setEmittingState(ps, false)
                    end
                end
                self.currentPipeParticleSystems = currentPipeParticleSystems
                if self.currentPipeParticleSystems ~= nil then
                    for _, ps in pairs(self.currentPipeParticleSystems) do
                        ParticleUtil.setEmittingState(ps, true)
                    end
                end
            end
            if self.currentPipeParticleSystems ~= nil then
                for _, currentPS in pairs(self.currentPipeParticleSystems) do
                    local ps = currentPS
                    if not ps.forceFullLifespan then
                        local factor = 1+((8-self.pipeUnloadingDistance-self.pipeParticleSystemExtraDistance)/15);
                        local lifespan = ps.originalLifespan * (self.pipeUnloadingDistance+self.pipeParticleSystemExtraDistance) * factor;
                        ParticleUtil.setParticleLifespan(ps, lifespan)
                    end
                end
            end
            if self.pipeEffects ~= nil then
                EffectManager:setFillType(self.pipeEffects, self:getUnitLastValidFillType(self.overloading.fillUnitIndex))
                EffectManager:startEffects(self.pipeEffects)
				--test
				for _, effect in pairs(self.pipeEffects) do				
					effect.setUnloadingDistance = nil
				end
            end
        end
        if self.pipeEffects ~= nil then
            for _, effect in pairs(self.pipeEffects) do	
				------------------------------------------------------------------------------------------------
				-- MR = check if we don't want to apply the setUnloadingDistance effect
                --if effect.setUnloadingDistance ~= nil then	
				if not effect.mrNoUnloadingDistanceEffect and effect.setUnloadingDistance ~= nil then
					effect:setUnloadingDistance(self.pipeUnloadingDistance+self.pipeParticleSystemExtraDistance, g_currentMission.terrainRootNode)					
                end
            end;
        end
        if self.pipeParticleDeactivateTime >= 0 and self.pipeParticleDeactivateTime <= g_currentMission.time then
            self.pipeParticleDeactivateTime = -1;
            if self.currentPipeParticleSystems ~= nil then
                for _, ps in pairs(self.currentPipeParticleSystems) do
                    ParticleUtil.setEmittingState(ps, false)
                end
                self.currentPipeParticleSystems = nil;
            end
            if self.pipeEffects ~= nil then
                EffectManager:stopEffects(self.pipeEffects);
            end
        end
    end
end
Pipe.updateTick = Utils.overwrittenFunction(Pipe.updateTick, Pipe.mrUpdateTick)