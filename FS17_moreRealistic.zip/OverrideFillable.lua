﻿--************************************************************************************************************************************************************
--fix for sugarcane "seeds". Same "massPerLiter" for all seeds. We don't want to keep the default MR seeds density for Non-MR vehicle, especially when this is a sugarcane planter (large seeds capacity, but not meant to handle a product with 0.65 density)
Fillable.MR_SEEDS_BASEGAME_MASSPERLITER = 0.000175;

--------------------------------------------------------------------------------------------------------------
--MR : since trailer are not "square filled", with "mr", we can set a filling capacity different from the "DIN capacity"
Fillable.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then
		return
	end
	
	if self.fillUnits then
		local i=0;
		while true do
			local key = string.format("vehicle.fillUnits.fillUnit(%d)", i);
			if not hasXMLProperty(self.xmlFile, key) then
				break;
			end
			local fillUnitIndex = i+1;
			
			if self.fillUnits[fillUnitIndex] then		
				self.fillUnits[fillUnitIndex].mrDINcapacity = self.fillUnits[fillUnitIndex].capacity; --backup the DIN capacity
				local fillVolumeCapacity = Utils.getNoNil(getXMLFloat(self.xmlFile, key .. "#mrFillVolumeCapacity"), self.fillUnits[fillUnitIndex].capacity);--the capacity parameter = DIN capacity. Here, we want the real capacity corresponding to what we see in game when the trailer is full. (the trailer is never "squared" filled, and so, the real capcity is diffrent from the DIN capacity
				self.fillUnits[fillUnitIndex].capacity = fillVolumeCapacity;			
			end		
			i=i+1;		
		end	
	end
	
	--load the mrCOMtransWithMass parameter from the xml
	local x, y, z = Utils.getVectorFromString(getXMLString(self.xmlFile, "vehicle.fillMassNode#mrCOMtransWithMass"));
	if x ~= nil and y ~= nil and z ~= nil then
		--print("test - y="..tostring(y));
		self.mrCOMtransWithMass = {x, y ,z};
	end
	local x, y, z = Utils.getVectorFromString(getXMLString(self.xmlFile, "vehicle.fillMassNode#mrCOMtransWithMassLimitsInTon"));
	if x ~= nil and y ~= nil and z ~= nil then
		--print("test - y="..tostring(y));
		self.mrCOMtransWithMassLimitsInTon = {x, y, z};
	else
		self.mrCOMtransWithMassLimitsInTon = {999, 999, 999};
	end	
	
	self.mrFillMassComponent = nil;
	for _, component in pairs(self.components) do
		if component.node == self.fillMassNode then
			self.mrFillMassComponent = component;
			--print("test2 - self.mrFillMassComponent="..tostring(self.mrFillMassComponent) .. " - com y = "..tostring(self.mrFillMassComponent.centerOfMass[2]));
		end
	end
	self.mrLastCOMchangeMass = 0;
	
	--fillMass hud
	self.fillMassHud = VehicleHudUtils.loadHud(self, self.xmlFile, "fillMass")	
	
	self.mrLastFillNodeTotalMass = 0
	
	
end
Fillable.load = Utils.appendedFunction(Fillable.load, Fillable.mrLoad);



Fillable.mrUpdate1 = function(self, dt)
	--if the vehicle is not MR, set the vanilla game density for SEEDS (before the update takes place, and set it back to MR value after update)
	if not self.mrIsMrVehicle then
		Fillable.mrPreviousSeedsMassPerLiter = FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_SEEDS].massPerLiter;
		FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_SEEDS].massPerLiter = Fillable.MR_SEEDS_BASEGAME_MASSPERLITER;
	end;
end
Fillable.update = Utils.prependedFunction(Fillable.update, Fillable.mrUpdate1)

--------------------------------------------------------------------------------------------------------------
--replace the fillLevel mass by the one provided by "mrFillContentMass"
--example : for autostackers (baleLoaders) : we can't rely on the fillLevel, we have to compute the mass from each bale loaded
Fillable.mrUpdate2 = function(self, dt)
	
	if not self.mrIsMrVehicle then
		--set back the seeds filltype massPerLiterValue
		FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_SEEDS].massPerLiter = Fillable.mrPreviousSeedsMassPerLiter;
		return
	end

	if self.firstTimeRun and self.isServer then
		if self.fillMassNode ~= nil then
		
			local newMass = self.currentMass
			if self.mrFillContentMass~=nil then
				newMass = self.emptyMass + self.mrFillContentMass
				--print("test mrFillContentMass = " .. tostring(self.mrFillContentMass))
			end
			--check additionnal mass from other specialization
			local totalAdditionalMass = 0
			for i=1, table.getn(self.specializations) do
				if self.specializations[i].mrGetAdditionalMass~=nil then
					local additionalMass = self.specializations[i].mrGetAdditionalMass(self)
					totalAdditionalMass = totalAdditionalMass + additionalMass
				end
			end
			newMass = newMass + totalAdditionalMass
			if newMass ~= self.mrLastFillNodeTotalMass then				
				setMass(self.fillMassNode, newMass)
				self.mrLastFillNodeTotalMass = newMass
			end
			
		end
	end

end
Fillable.update = Utils.appendedFunction(Fillable.update, Fillable.mrUpdate2)





--------------------------------------------------------------------------------------------------------------
--update the center of gravity according to the current "fillLevel mass"
Fillable.mrUpdateTick = function(self, dt)
	
	if not self.mrIsMrVehicle then
		return
	end

	local contentMass = nil
	if self.isServer and not self.mrVehicleIsStill and self.fillMassNode ~= nil then
		if self.mrFillMassComponent and self.mrCOMtransWithMass then
			--check currentMass against mass when last time we set the center of mass
			if self.currentMass~=self.mrLastCOMchangeMass then	
				contentMass = Fillable.mrGetContentMass(self)
				--print("test3 - new com y = " .. self.mrFillMassComponent.centerOfMass[2]+self.mrCOMtransWithMass[2]*contentMass);
				setCenterOfMass(self.fillMassNode, self.mrFillMassComponent.centerOfMass[1]+self.mrCOMtransWithMass[1]*math.min(contentMass, self.mrCOMtransWithMassLimitsInTon[1]), self.mrFillMassComponent.centerOfMass[2]+self.mrCOMtransWithMass[2]*math.min(contentMass, self.mrCOMtransWithMassLimitsInTon[2]), self.mrFillMassComponent.centerOfMass[3]+self.mrCOMtransWithMass[3]*math.min(contentMass, self.mrCOMtransWithMassLimitsInTon[3]))
				self.mrLastCOMchangeMass = self.currentMass
			end
		end
	end	
	
	if self.isClient and self.fillMassHud~= nil then
		if contentMass==nil then
			contentMass = Fillable.mrGetContentMass(self)
		end
		VehicleHudUtils.setHudValue(self, self.fillMassHud, contentMass*1000) --kg
	end

end
Fillable.updateTick = Utils.appendedFunction(Fillable.updateTick, Fillable.mrUpdateTick);

--------------------------------------------------------------------------------------------------------------
--compute cargoMass in metric Ton
Fillable.mrGetContentMass = function(self)
	local contentMass = 0
	
	if self.mrFillContentMass~=nil then
		contentMass = self.mrFillContentMass
	else	
		for i,fillUnit in pairs(self.fillUnits) do			 
			if fillUnit.currentFillType ~= nil and fillUnit.currentFillType ~= FillUtil.FILLTYPE_UNKNOWN then
				local desc = FillUtil.fillTypeIndexToDesc[fillUnit.currentFillType]
				contentMass = contentMass + (fillUnit.fillLevel * desc.massPerLiter)
			end
		end	
	end
	return contentMass
end