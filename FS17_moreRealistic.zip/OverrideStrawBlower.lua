﻿

--************************************************************************************************************************************************************
--fix bug : strawBlowerDoorAnimationOpenSpeed depends on the "workStart" sound duration ???
StrawBlower.mrLoad = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	self.strawBlowerDoorAnimationOpenSpeed = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.strawBlowerDoor#openSpeed"), 1);
	
end
StrawBlower.load = Utils.appendedFunction(StrawBlower.load, StrawBlower.mrLoad)



--************************************************************************************************************************************************************
--fix bug : 
--step to reproduce : 
-- on goldcrest valley
-- fill the kuhn primor straw blower ith 1 or more bales
-- drive very close to the "animal straw trigger" when getting into place to blow the straw. If the bale contained into the strawblower is catched by the "trigger", the bale is deleted.
-- But the strawblower doesn't know it. And so, we can still unload the strawblower even if there is no bale visible in it. 
-- And then, once down to 0, since the strawblower tries to delete the bale object, we get this error (see log below)
--[[
Warning (Script): Unknown entity id 0 in method 'delete'.
LUA call stack:
  dataS/scripts/objects/PhysicsObject.lua (41) : delete
  dataS/scripts/objects/MountableObject.lua (47) : delete
  dataS/scripts/objects/Bale.lua (48) : delete
  dataS/scripts/vehicles/specializations/StrawBlower.lua (244) : delete
  dataS/scripts/vehicles/specializations/Trailer.lua (580) : setUnitFillLevel
  dataS/scripts/vehicles/specializations/Trailer.lua (385) : updateTipping
  dataS/scripts/vehicles/Vehicle.lua (2708) : updateTick
  dataS/scripts/network/Server.lua (68) : updateTick
  dataS/scripts/BaseMission.lua (1508) : update
  dataS/scripts/FSBaseMission.lua (2171) : update
  dataS/scripts/missions/mission00.lua (333) : update
  dataS/scripts/main.lua (1876) : update
  --]]
StrawBlower.mrUpdateTick = function(self, dt)
    if self:getIsActive() and self.isServer then
        --check the bale object has not already been destroyed by another object
		if self.currentStrawBlowerBale ~= nil then
			if not entityExists(self.currentStrawBlowerBale.nodeId) then
				--print("MR test - bale object not present - removing it from the strawblower")
				self.triggeredBales[self.currentStrawBlowerBale] = nil;				
				self.currentStrawBlowerBale = nil;					
				self:setUnitFillLevel(self.strawBlower.fillUnitIndex, 0, FillUtil.FILLTYPE_UNKNOWN, true);			
			end
		end        
    end
end
StrawBlower.updateTick = Utils.prependedFunction(StrawBlower.updateTick, StrawBlower.mrUpdateTick)

--************************************************************************************************************************************************************
--we want the straw blower to be able to process more than one bale at a time
StrawBlower.mrSetUnitFillLevel = function(self, superFunc, superFunc1, fillUnitIndex, fillLevel, fillType, force)
	local result = superFunc(self, superFunc1, fillUnitIndex, fillLevel, fillType, force);
	if self.isServer then
		if fillLevel<=0 and self.currentStrawBlowerBale == nil then
			local bale = next(self.triggeredBales);
			if bale ~= nil then								
				self:setUnitFillLevel(self.strawBlower.fillUnitIndex, bale:getFillLevel(), bale:getFillType());	
				self.currentStrawBlowerBale = bale;				
			end
		end
	end
	return result;
end
StrawBlower.setUnitFillLevel = Utils.overwrittenFunction(StrawBlower.setUnitFillLevel, StrawBlower.mrSetUnitFillLevel)

