﻿RealisticConflictModsManagement = {}



--**********************************************************
--call by RealisticGlobalListener:loadMap
function RealisticConflictModsManagement.start()

	--***********************************************************************************
	--** taking care of "ground response"
	--***********************************************************************************		
    if g_modIsLoaded["FS17_ForRealModule03_GroundResponse"] then		
		local mod1 = getfenv(0)["FS17_ForRealModule03_GroundResponse"]		
		if mod1 ~= nil and mod1.GroundResponse ~= nil then
			RealisticConflictModsManagement.mod1 = mod1
			mod1.GroundResponse.updateWheelTireFriction = Utils.overwrittenFunction(mod1.GroundResponse.updateWheelTireFriction, RealisticConflictModsManagement.updateWheelTireFriction)
			mod1.GroundResponse.updateWheelSink = Utils.overwrittenFunction(mod1.GroundResponse.updateWheelSink, RealisticConflictModsManagement.updateWheelSink)					
			RealisticConflictModsManagement.mod1PerlinNoise = {randomFrequency=0.7,persistence=0.8, numOctaves=4, randomSeed=321}				
		end
	end
	--***********************************************************************************
	
	
	--***********************************************************************************
	--** taking care of "Seasons" snow friction
	--***********************************************************************************
	if g_modIsLoaded["FS17_RM_Seasons"] then		
		local mod2 = getfenv(0)["FS17_RM_Seasons"]		
		if mod2 ~= nil and mod2.ssSnowTracks then
			--RealisticUtils.testClass("mod2.ssSnowTracks", mod2.ssSnowTracks)
			RealisticConflictModsManagement.mod2 = mod2
			mod2.ssSnowTracks.vehicleUpdateWheelTireFriction = Utils.overwrittenFunction(mod2.ssSnowTracks.vehicleUpdateWheelTireFriction, RealisticConflictModsManagement.vehicleUpdateWheelTireFriction)	
			mod2.ssSnowTracks.update = Utils.appendedFunction(mod2.ssSnowTracks.update, RealisticConflictModsManagement.mod2update)
		end
	end	

	--***********************************************************************************
	--** taking care of "FS17_BuyBales" bales fillLevel and prices
	--***********************************************************************************
	if getfenv(0)["BaleSpawner"]~=nil then
		local mod3 = getfenv(0)["BaleSpawner"]
		mod3.load = Utils.overwrittenFunction(mod3.load, RealisticConflictModsManagement.mod3load)
		--we want to override the price of the different stacks of bales too
		
		--price for roundbale straw= 3000Liters * 0.041 (price per liter) * 2 (roundbale price factor) = 246$
		--price for roundbale hay= 3000Liters * 0.048 (price per liter) * 2 (roundbale price factor) = 288$
		--price for roundbale silage= 3000Liters * 0.245 (price per liter) * 0.8 (silage bale factor)  = 588$  --no bale x2 factor for silage, additionnal 0.8 factor for silage (we want to reward player using silage bale for cattle, not for biogas)
		
		local rBaleFillLevel = 3000
		if g_currentMission.mrGameplayBalerFillLevelScaling~=nil then						
			rBaleFillLevel = RealisticUtils.roundNumberBaleCapacity(rBaleFillLevel * g_currentMission.mrGameplayBalerFillLevelScaling)			
		end				
		local price = rBaleFillLevel*FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_DRYGRASS].pricePerLiter*Bale.MR_ROUNDBALE_VALUESCALE
		RealisticConflictModsManagement.mod3SetPrice("stack_round_8_hay.xml", 8*price*2) -- x2 because we want to reward players doing their own bales for animals (cheaper to do your own bales than buying from the store)
						
		--adjust fillLevel for silage bale
		local grassDensity = FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_GRASS].massPerLiter
		local silageDensity = FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_SILAGE].massPerLiter
		local silageFillLevelFactor = 1
		if silageDensity>0 then
			silageFillLevelFactor = 0.9*grassDensity/silageDensity
		end
		price = rBaleFillLevel*FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_SILAGE].pricePerLiter*Bale.MR_SILAGEBALE_VALUESCALE*silageFillLevelFactor
		RealisticConflictModsManagement.mod3SetPrice("stack_round_8_silage.xml", 8*price*2)
		
		price = rBaleFillLevel*FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_STRAW].pricePerLiter*Bale.MR_ROUNDBALE_VALUESCALE
		RealisticConflictModsManagement.mod3SetPrice("stack_round_8_straw.xml", 8*price*2) 
				
		local sBaleFillLevel = 6000
		if g_currentMission.mrGameplayBalerFillLevelScaling~=nil then						
			sBaleFillLevel = RealisticUtils.roundNumberBaleCapacity(sBaleFillLevel * g_currentMission.mrGameplayBalerFillLevelScaling)			
		end		
		price = sBaleFillLevel*FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_DRYGRASS].pricePerLiter*Bale.MR_LARGESQUAREBALE_VALUESCALE
		RealisticConflictModsManagement.mod3SetPrice("stack_square_8_hay.xml", 8*price*2)
		
		price = sBaleFillLevel*FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_STRAW].pricePerLiter*Bale.MR_LARGESQUAREBALE_VALUESCALE
		RealisticConflictModsManagement.mod3SetPrice("stack_square_8_straw.xml", 8*price*2)				
	end
	
	
	--*************************************************************************************************
	--** taking care of "terrainControl" specialization -> embeded in some maps, but it is not MR-ready
	--** you can edit the "mrSettings.xml" file in your savegame folder to prevent MR doing this.
	--** Notice = there are a lot of different terrainControl embedded, with different effects and settings
	--*************************************************************************************************	
	if RealisticSettings.DISABLE_TERRAINCONTROL then
		--search for the TerrainControl Specialization
		local speTerrainControl;
		for speName, spe in pairs(SpecializationUtil.specializations) do
			if speName~=nil and string.find(speName, "terrainControl") then
				speTerrainControl = SpecializationUtil.getSpecialization(speName);
				break;
			end
		end	
		
		if speTerrainControl~=nil then
			--remove the terrainControl specialization for all vehicleTypes
			for vehicleTypeName, vehicleType in pairs(VehicleTypeUtil.vehicleTypes) do 
				if vehicleType ~= nil then
					local newSpeTable = {}
					for index, spe in pairs(vehicleType.specializations) do					
						if spe~=speTerrainControl then
							table.insert(newSpeTable, spe);					
						end;					
					end;
					vehicleType.specializations = newSpeTable
				end;
			end;
		end;
	end;
	--*************************************************************************************************
	
	
end



function RealisticConflictModsManagement:updateWheelTireFriction(superFunc, superFunc2, wheel)

	if not self.mrIsMrVehicle then
		return superFunc(self, superFunc2, wheel)
	else
		return Vehicle.mrUpdateWheelTireFriction(self, wheel)
	end

end

function RealisticConflictModsManagement:updateWheelSink(superFunc, dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end
	

    local speed = self:getLastSpeed();
    local detailId = g_currentMission.terrainDetailId;	

    for wheelIndex,wheel in pairs(self.wheels) do
	
		--MR 
		local doUpdateSink = false		
        local width = 0.25 * wheel.width;
        local length = 0.25 * wheel.width;

        local x0,y0,z0;
        local x1,y1,z1;
        local x2,y2,z2;

        if wheel.repr == wheel.driveNode then
            x0,y0,z0 = localToWorld(wheel.node, wheel.positionX + width, wheel.positionY, wheel.positionZ - length);
            x1,y1,z1 = localToWorld(wheel.node, wheel.positionX - width, wheel.positionY, wheel.positionZ - length);
            x2,y2,z2 = localToWorld(wheel.node, wheel.positionX + width, wheel.positionY, wheel.positionZ + length);
        else
            local x,_,z = localToLocal(wheel.driveNode, wheel.repr, 0,0,0);
            x0,y0,z0 = localToWorld(wheel.repr, x + width, 0, z - length);
            x1,y1,z1 = localToWorld(wheel.repr, x - width, 0, z - length);
            x2,y2,z2 = localToWorld(wheel.repr, x + width, 0, z + length);
        end
        local x,z, widthX,widthZ, heightX,heightZ = Utils.getXZWidthAndHeight(nil, x0,z0, x1,z1, x2,z2);

		--MR : this part is somehow "buggy". => when a wheel is driving over both a cultivated area (value = 1) and a drilled area (value = 3) => the resulting value = ploughed ! (value = 2)
		--using MR detection of the ground type instead		
		--[[
        setDensityCompareParams(detailId, "greater", 0);
        local density, area, _ = getDensityParallelogram(detailId, x,z, widthX,widthZ, heightX,heightZ, g_currentMission.terrainDetailTypeFirstChannel, g_currentMission.terrainDetailTypeNumChannels);		
        setDensityCompareParams(detailId, "greater", -1);

        local terrainValue = 0;
        if area > 0 then
            terrainValue = math.floor(density/area + 0.5);
			--print("test - terrainValue="..tostring(terrainValue) .. " - density="..tostring(density).." - area="..tostring(area))
        end
		--]]
		
		local terrainValue = 0;
		if wheel.mrLastTerrainDensityBits~=nil then
			terrainValue = bitAND(wheel.mrLastTerrainDensityBits, 7);
		end
		
        wheel.lastTerrainValue = terrainValue;

        local noiseValue = 0;
        if terrainValue > 0 then
            local xPerlin = x + 0.5*widthX + 0.5*heightX;
            local zPerlin = z + 0.5*widthZ + 0.5*heightZ;
            -- Round to 1cm to avoid sliding when not moving
            xPerlin = math.floor(xPerlin*100)*0.01;
            zPerlin = math.floor(zPerlin*100)*0.01;
            local perlinNoise = RealisticConflictModsManagement.mod1PerlinNoise;--RealisticConflictModsManagement.mod1.GroundResponse.perlinNoise;
            local noise = getPerlinNoise2D(xPerlin*perlinNoise.randomFrequency, zPerlin*perlinNoise.randomFrequency, perlinNoise.persistence, perlinNoise.numOctaves, perlinNoise.randomSeed);
            noiseValue = 0.5 * (noise + 1);
        end

        -- map noise to an asbolute value or to a certain percentage of the wheel radius?
        local maxSink = 0;
		
		--***********************************************************************************************
		--** MR own values
		--** 20170830 - revised values to take into account the "mrTotalContactWidth" reduction
		
		-- MR : take into account tire slippage
		local slipFactor = 0
		if wheel.mrIsDriven then
			local wheelSpd = wheel.mrLastWheelSpeed*wheel.radius
			if wheelSpd>0.5 and wheel.mrAvgLongSlip>0.1 then
				slipFactor = wheel.mrAvgLongSlip-0.1
				doUpdateSink = true
			end
		end
		
		local groundPressureFactor = 0.1 -- between 0.1 and 1
		--check wheel load against wheel radius and wheel width
		if wheel.mrTotalContactWidth>0 then
			if wheel.mrIsCrawler then
				groundPressureFactor = 0.0025 * wheel.mrLastTireLoad / (wheel.mrTotalContactWidth * 2)
			else
				groundPressureFactor = 0.0025 * wheel.mrLastTireLoad / (wheel.mrTotalContactWidth * 0.5 * wheel.radiusOriginal)
			end		
			groundPressureFactor = Utils.clamp(groundPressureFactor, 0.1, 2)
		end
		
		
		-- ploughing effect
        if terrainValue == 2 and wheel.oppositeWheelIndex ~= nil then
            local oppositeWheel = self.wheels[wheel.oppositeWheelIndex];
            if oppositeWheel.lastTerrainValue ~= nil and oppositeWheel.lastTerrainValue ~= 2 then
                --maxSink = maxSink * 1.3; 
				--maxSink = math.max(maxSink+0.1, 0.32) --mr - more difference 
				groundPressureFactor = 1.1
            end
        end
		
		local function getMaxSink(rollingDryDepth, rollingWetDepth, slipDryDepth, slipWetDepth)	
			local sinkDepth = rollingDryDepth * (1 - g_currentMission.environment.groundWetness) + rollingWetDepth * g_currentMission.environment.groundWetness
			sinkDepth = sinkDepth * math.min(1.5, (groundPressureFactor^0.5)) -- depth function of the groundpressure and wetness			
			sinkDepth = sinkDepth + slipDryDepth * slipFactor * (1 - g_currentMission.environment.groundWetness) -- additionnal depth coming from slippage (dry ground)
			sinkDepth = sinkDepth + slipWetDepth * slipFactor * g_currentMission.environment.groundWetness -- additionnal depth coming from slippage (wet ground)
			return sinkDepth
		end

        -- scale sink by terrain type 
		--max sink for a narrow wheel with high load
		--take into account wetness accordingly to the terrain value
		--groundPressureFactor
        if terrainValue == 1 then           -- cultivator
            maxSink = getMaxSink(0.15, 0.22, 0.10, 0.20)
        elseif terrainValue == 2 then       -- plough
			--check if there is a "self.mrTerrainResponsePloughingEffectDepthLimit" value (tractor or implement, we keep the lowest value)
			local depthLimit = 0.20
			if self.mrTerrainResponsePloughingEffectDepthLimit~=nil then
				depthLimit = math.min(depthLimit, self.mrTerrainResponsePloughingEffectDepthLimit);
			end
			local rootAttacherVehicle = self:getRootAttacherVehicle();
			if rootAttacherVehicle~=nil then
				for _, implement in pairs(rootAttacherVehicle.attachedImplements) do
					if implement.object and implement.object.mrTerrainResponsePloughingEffectDepthLimit~=nil then
						depthLimit = math.min(depthLimit, implement.object.mrTerrainResponsePloughingEffectDepthLimit);
					end;
				end;
			end;
            maxSink = getMaxSink(depthLimit, depthLimit+0.08, 0.12, 0.18)
        elseif terrainValue == 3 then       -- sowing
            maxSink = getMaxSink(0.08, 0.16, 0.12, 0.20)
        elseif terrainValue == 4 then       -- sowingWidth
            maxSink = getMaxSink(0.10, 0.18, 0.14, 0.22)
        elseif terrainValue == 5 then       -- grass
            maxSink = getMaxSink(0.04, 0.10, 0.05, 0.10)
		else --other ?
			maxSink = getMaxSink(0.04, 0.10, 0.05, 0.10)
        end
		

        -- add ground wetness (rain)
        --maxSink = maxSink * (1 + 1.5*g_currentMission.environment.groundWetness); -- more wetness effect
				
		--** end MR
		--***********************************************************************************************

        
		
		--MR : take into account wheel width => the wider the wheel, the less "bumpy" the ride
		--local maxSink = maxSink * math.min(1, math.max(0.2, 1.25 - wheel.mrTotalContactWidth))
		
		
		--[[
		-- MR : take into account tire slippage
		if wheel.mrAvgLongSlip~=nil and wheel.mrLastWheelSpeed~=nil then
			local wheelSpd = wheel.mrLastWheelSpeed*wheel.radius
			if wheelSpd>0.5 and wheel.mrAvgLongSlip>0.1 then
				maxSink = maxSink * (1 + 1.5*(wheel.mrAvgLongSlip-0.1))				
				doUpdateSink = true
			end
		end--]]
		
		

		--MR : less than 90% of wheel radius !
        --local newSink = math.min(0.9*wheel.radius, maxSink * noiseValue);		
		--local newSink = math.min(0.5*wheel.radius, maxSink * noiseValue)
		--MR : do not apply the noiseValue to the whole maxSink
		-- noise value is always around 0.5
		--local newSink = math.min(0.5*wheel.radiusOriginal, maxSink * (0.2 + 1.3 * noiseValue))
		
		--add noiseValue
		-- noise value is always around 0.5
		local newSink = 0
		if noiseValue>0 then
			newSink = math.min(0.75*wheel.radiusOriginal, maxSink * (0.5 + noiseValue))
		end
		
		--if wheel.mrAvgLongSlip~=nil then
			--print(tostring(g_currentMission.time) .. " - radius = "..tostring(wheel.radiusOriginal) .. " - maxSink="..tostring(maxSink) .. " - noiseValue="..tostring(noiseValue) .. " - newSink="..tostring(newSink) .." - groundPressureFactor="..tostring(groundPressureFactor))
		--end	
		
		
        if math.abs(newSink - wheel.sink) > 0.01 then
		
			--MR : only update when moving or wheel is turning
			doUpdateSink = doUpdateSink or self.lastSpeedReal>0.00015 -- 0.54kph			
			if doUpdateSink then
		
				--***********************************************************************************************
				--** MR = be more gentle with radius change
				if newSink>wheel.sink then
					wheel.sink = math.min(newSink, wheel.sink + 0.15 * dt/1000) --20171204 - 15 centimeters per second
				else
					wheel.sink = math.max(newSink, wheel.sink - 0.30 * dt/1000) --20171204 - 30 centimeters per second
				end
				--** end MR
				--***********************************************************************************************

				wheel.radius = wheel.radiusOriginal - wheel.sink;
				if self.isServer then
					self:updateWheelBase(wheel);
					
					--[[
					--test dynamic setting of the 3pt hitches to compensate the wheel radius diminution
					for _, implement in pairs(self.attachedImplements) do
						if implement.object ~= nil then
							local jointDesc = self.attacherJoints[implement.jointDescIndex];
							if not implement.object.isHardAttached and jointDesc.rotationNode ~= nil then
								--check if the joint is lowered
								if jointDesc.moveDown then
									--update the lowered height
									if jointDesc.mrCmmGroundResponseOrgLowerRotation==nil then
										jointDesc.mrCmmGroundResponseOrgLowerRotation=jointDesc.lowerRotation[1]
									end
									jointDesc.lowerRotation[1] = jointDesc.mrCmmGroundResponseOrgLowerRotation + math.rad(10)
									--force the update
									jointDesc.moveAlpha = jointDesc.moveAlpha - 0.001
								end
							end
						end
					end
					--]]
				end
			end
        end

		--[[
        local sinkFactor = (wheel.sink/maxSink) * (1 + (0.4 * g_currentMission.environment.groundWetness));
        local newSinkFrictionScaleFactor = (1.0 - (0.20 * sinkFactor));
        -- Only update if more than 5% change
        if math.abs(newSinkFrictionScaleFactor - wheel.sinkFrictionScaleFactor) > 0.05 then
            wheel.sinkFrictionScaleFactor = newSinkFrictionScaleFactor;
            wheel.sinkLongStiffnessFactor = (1.0 - (0.40 * sinkFactor));
            wheel.sinkLatStiffnessFactor  = (1.0 - (0.25 * sinkFactor));
            if self.isServer then
                self:updateWheelTireFriction(wheel);
            end
        end
		--]]

        -- set PS
        if self.isClient and wheel.dirtPS ~= nil then
            local enableSoilPS = false;
            if terrainValue > 0 and terrainValue < 5 then -- grass: terrainValue==5
                enableSoilPS = (speed > 1) and wheel.sink > 0;
            end

            local activePsName = "";
            if enableSoilPS then
                if g_currentMission.environment.groundWetness > 0.2 then
                    activePsName = "soilWet";
                else
                    activePsName = "soilDry";
                end
            end
            for psName,ps in pairs(wheel.dirtPS) do
                ps.isActive = psName == activePsName;
            end
            if wheel.additionalWheels ~= nil then
                for _,additionalWheel in pairs(wheel.additionalWheels) do
                    --for psName,ps in pairs(wheel.dirtPS) do
					for psName,ps in pairs(additionalWheel.dirtPS) do --20171217 - MR fix bug (missing ps for additionnal wheels)
                        ps.isActive = psName == activePsName;
                    end
                end
            end
        end
    end
end


-----------------------------------------------------------------------------
--** Seasons snowTracks vehicleUpdateWheelTireFriction -> remove specific snow friction
-----------------------------------------------------------------------------
RealisticConflictModsManagement.vehicleUpdateWheelTireFriction = function(self, superFunc, wheel)

	if not self.mrIsMrVehicle then
		superFunc(self, wheel)
	end

end

-----------------------------------------------------------------------------
--** Seasons snowTracks update -> remove linearDamping coming from applyTracks
-----------------------------------------------------------------------------
function RealisticConflictModsManagement.mod2update(self, dt)
	if self.mrIsMrVehicle then
		for _, wheel in pairs(self.wheels) do
			setLinearDamping(wheel.node, 0)
		end
	end
end




-----------------------------------------------------------------------------
--** FS17_BuyBales -> change capacity of the spawned bales to MR default values
-----------------------------------------------------------------------------
RealisticConflictModsManagement.mod3load = function(self, superFunc, _, x, y, z, rx, ry, rz, xmlFilename)
    local _, baseDirectory = getModNameAndBaseDirectory(xmlFilename)
    local xmlFile = loadXMLFile("tempObjectXML", xmlFilename)

    if xmlFile ~= nil then
        local isSpawned = true

        -- load xml parameters
        local stackI3DFilename 
        local baleParam = {}

        stackI3DFilename = Utils.getFilename(getXMLString(xmlFile, "object.filename"), baseDirectory)
        baleParam.fillLevel = Utils.getNoNil(getXMLInt(xmlFile, "object.stack#fillLevel"), 4000)		
        baleParam.isWrapped = Utils.getNoNil(getXMLBool(xmlFile, "object.stack#isWrapped"), false)
        baleParam.baleFilename = Utils.getFilename(getXMLString(xmlFile, "object.stack#baleFilename"), baseDirectory)

        -- load i3d to find bale nodes
        local stackRoot = Utils.loadSharedI3DFile(stackI3DFilename)
        local stackNode = getChildAt(stackRoot, 0)
        local stackTransform = createTransformGroup("stackTransform")

        setTranslation(stackTransform, x, y, z)
        setRotation(stackTransform, rx, ry, rz)
        link(stackTransform,stackNode)

        delete(stackRoot)

        -- spawn this stack of bales
        local spawnedBales = {}
        local i = 0
        while true do
            local key = "object.stack.bale("..tostring(i)..")"

            if not hasXMLProperty(xmlFile, key) then
                break
            elseif not g_currentMission:getCanAddLimitedObject(FSBaseMission.LIMITED_OBJECT_TYPE_BALE) then
                for _, bale in pairs(spawnedBales) do
                    bale:delete()
                end
                
                isSpawned = false
                break
            else
                local baleNode = Utils.indexToObject(stackNode,getXMLString(xmlFile, key.."#index"));
                local x, y, z = getWorldTranslation(baleNode)
                local rx, ry, rz = getWorldRotation(baleNode)

                local baleObject = Bale:new(self.isServer, self.isClient)
				
				--MR => if capacity = 4000, that means this is a vanilla game bale => let's set the correct capacity for the current game (MR or MR gameplay)
				if baleParam.fillLevel==4000 then
					--tell the mr engine to compute the correct bale capacity for the current game
					baleObject.mrResetCapacity = true -- handled in the "Bale.mrLoad" function
				end	
				
                baleObject:load(baleParam.baleFilename, x, y, z, rx, ry, rz, baleParam.fillLevel)
                baleObject:register()
                baleObject:setWrappingState(baleParam.isWrapped and 1 or 0)
                baleObject.isBuyBale = true

                table.insert(spawnedBales,baleObject)
                
                i = i + 1
            end
        end

        -- cleanup
        delete(xmlFile)
        delete(stackTransform)
        Utils.releaseSharedI3DFile(stackI3DFilename, nil, true)

        return isSpawned
    end

    return false
end

-----------------------------------------------------------------------------
--** FS17_BuyBales -> change stack price in the store
-----------------------------------------------------------------------------
RealisticConflictModsManagement.mod3SetPrice = function(xmlName, newPrice)
	local path = g_modsDirectory .. "FS17_BuyBales/" .. xmlName	
	local genuineStoreItem = StoreItemsUtil.storeItemsByXMLFilename[path:lower()]
	if genuineStoreItem~=nil then
		genuineStoreItem.price = newPrice
	end
end
