﻿--************************************************************************************************************************************************************	
--MR : we want to write in the log the measured fillvolume of the "volume shape" (in debug mode only)
-- getVolume always return 0 ??? -> useless
FillVolume.mrLoad = function(self, savegame)

	if Vehicle.debugRendering then
		if self.fillVolumes then
			for _, fillVolume in pairs(self.fillVolumes) do
				print("test fillvolume : measured volume = " .. tostring(getVolume(fillVolume.baseNode)));
			end
		end
	end

end
--FillVolume.load = Utils.appendedFunction(FillVolume.load, FillVolume.mrLoad);