﻿

--************************************************************************************************************************************************************
--MR : fix bug - allowsJointRotLimitMovement and allowsJointTransLimitMovement are not taken into account after a "smoothAttaching" of the implement
--     improve joint rot and trans limit variation (the limit get faster to the targetLimit when the implement goes up and get slower to the limit when the implement goes down)
AttacherJoints.mrUpdateTick = function(self, superFunc, dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt);
	end;

	if self:getIsActive() then
		local playHydraulicSound = false;

		for _, implement in pairs(self.attachedImplements) do
			if implement.object ~= nil then
				local jointDesc = self.attacherJoints[implement.jointDescIndex];
				if not implement.object.isHardAttached then
					if self.isServer then
						if implement.attachingIsInProgress then
							local done = true;
							for i=1,3 do
								local lastRotLimit = implement.attachingRotLimit[i];
								local lastTransLimit = implement.attachingTransLimit[i];
								implement.attachingRotLimit[i] = math.max(0, implement.attachingRotLimit[i] - implement.attachingRotLimitSpeed[i] * dt);
								implement.attachingTransLimit[i] = math.max(0, implement.attachingTransLimit[i] - implement.attachingTransLimitSpeed[i] * dt);
								if (implement.attachingRotLimit[i] > 0 or implement.attachingTransLimit[i] > 0) or (lastRotLimit > 0 or lastTransLimit > 0) then
									done = false;
								end
							end
							
							--*****************************************************************************************************************
							--MR - 20170206 - fix bug - allowsJointRotLimitMovement and allowsJointTransLimitMovement are not taken into account after a "smoothAttaching" of the implement
							if jointDesc.jointType == Vehicle.JOINTTYPE_IMPLEMENT and not jointDesc.allowsJointLimitMovement then
								for i=1, 3 do
									implement.jointRotLimit[i] = 0;
									implement.jointTransLimit[i] = 0;
									setJointRotationLimit(jointDesc.jointIndex, i-1, true, 0, 0);
									setJointTranslationLimit(jointDesc.jointIndex, i-1,true, 0, 0);
								end;
							elseif not implement.object.attacherJoint.allowsJointRotLimitMovement then
								for i=1, 3 do
									implement.jointRotLimit[i] = 0;						
									setJointRotationLimit(jointDesc.jointIndex, i-1, true, 0, 0);							
								end;
							elseif not implement.object.attacherJoint.allowsJointTransLimitMovement then
								for i=1, 3 do							
									implement.jointTransLimit[i] = 0;
									setJointTranslationLimit(jointDesc.jointIndex, i-1, true, 0, 0);							
								end;
							end								
							--end MR **********************************************************************************************************
							
							
							
							implement.attachingIsInProgress = not done;

							if done and implement.object.attacherJoint.hardAttach and self:getIsHardAttachAllowed(implement.jointDescIndex) then
								self:hardAttachImplement(implement)
							end
						end
					end
					if not implement.attachingIsInProgress then
						local jointFrameInvalid = false;
						if jointDesc.allowsLowering then
							local moveAlpha = Utils.getMovedLimitedValue(jointDesc.moveAlpha, jointDesc.lowerAlpha, jointDesc.upperAlpha, jointDesc.moveTime, dt, not jointDesc.moveDown);
							if moveAlpha ~= jointDesc.moveAlpha then
								playHydraulicSound = true;
								jointDesc.moveAlpha = moveAlpha;
								jointDesc.moveLimitAlpha = 1-(moveAlpha-jointDesc.lowerAlpha) / (jointDesc.upperAlpha-jointDesc.lowerAlpha);
								jointFrameInvalid = true;
								if jointDesc.rotationNode ~= nil then
									setRotation(jointDesc.rotationNode, Utils.vector3ArrayLerp(jointDesc.upperRotation, jointDesc.lowerRotation, jointDesc.moveAlpha));
								end
								if jointDesc.rotationNode2 ~= nil then
									setRotation(jointDesc.rotationNode2, Utils.vector3ArrayLerp(jointDesc.upperRotation2, jointDesc.lowerRotation2, jointDesc.moveAlpha));
								end
								self:updateAttacherJointRotation(jointDesc, implement.object);
							end
						end

						jointFrameInvalid = jointFrameInvalid or self:validateAttacherJoint(implement, jointDesc, dt);
						jointFrameInvalid = jointFrameInvalid or jointDesc.jointFrameInvalid;
						if jointFrameInvalid then
							jointDesc.jointFrameInvalid = false;
							if self.isServer then
								setJointFrame(jointDesc.jointIndex, 0, jointDesc.jointTransform);
							end
						end
					end
					if self.isServer then
						local force = implement.attachingIsInProgress;
						if force or (jointDesc.allowsLowering and jointDesc.allowsJointLimitMovement) then
						
							--*****************************************************************************************************************
								--MR - 20170206 - improve joint rot and trans limit variation (the limit get faster to the targetLimit when the implement goes up and get slower to the limit when the implement goes down) 
							local moveLimitAlpha = jointDesc.moveLimitAlpha;
							if not implement.attachingIsInProgress then
								moveLimitAlpha = moveLimitAlpha^2;
							end	
							--end MR **********************************************************************************************************
								
								
							if force or implement.object.attacherJoint.allowsJointRotLimitMovement then
								for i=1,3 do
									local newRotLimit = Utils.lerp( math.max(implement.attachingRotLimit[i], implement.upperRotLimit[i]), math.max(implement.attachingRotLimit[i], implement.lowerRotLimit[i]), moveLimitAlpha); --mr
									if force or math.abs(newRotLimit - implement.jointRotLimit[i]) > 0.0005 then
										local rotLimitDown = -newRotLimit;
										local rotLimitUp = newRotLimit;
										if i == 3 then
											if jointDesc.lockDownRotLimit then
												rotLimitDown = math.min(-implement.attachingRotLimit[i], 0);
											end
											if jointDesc.lockUpRotLimit then
												rotLimitUp = math.max(implement.attachingRotLimit[i], 0);
											end
										end
										setJointRotationLimit(jointDesc.jointIndex, i-1,true, rotLimitDown, rotLimitUp);
										implement.jointRotLimit[i] = newRotLimit;
									end
								end
							end

							if force or implement.object.attacherJoint.allowsJointTransLimitMovement then
								for i=1,3 do
									local newTransLimit = Utils.lerp( math.max(implement.attachingTransLimit[i], implement.upperTransLimit[i]),	math.max(implement.attachingTransLimit[i], implement.lowerTransLimit[i]), moveLimitAlpha); --mr

									if force or math.abs(newTransLimit - implement.jointTransLimit[i]) > 0.0005 then
										local transLimitDown = -newTransLimit;
										local transLimitUp = newTransLimit
										if i == 2 then
											if jointDesc.lockDownTransLimit then
												transLimitDown = math.min(-implement.attachingTransLimit[i], 0);
											end
											if jointDesc.lockUpTransLimit then
												transLimitUp = math.max(implement.attachingTransLimit[i], 0);
											end
										end

										setJointTranslationLimit(jointDesc.jointIndex, i-1, true, transLimitDown, transLimitUp);
										implement.jointTransLimit[i] = newTransLimit;
									end
								end
							end
						end
					end
				end
			end
		end

		if self:getIsActiveForSound() and self.sampleHydraulic ~= nil and self.sampleHydraulic.sample ~= nil then
			if playHydraulicSound then
				if not self.sampleHydraulic.isPlaying then
					SoundUtil.playSample(self.sampleHydraulic, 0, 0, nil);
				end
			elseif self.sampleHydraulic.isPlaying then
				SoundUtil.stopSample(self.sampleHydraulic, true);
			end
		end
	end
end
AttacherJoints.updateTick = Utils.overwrittenFunction(AttacherJoints.updateTick, AttacherJoints.mrUpdateTick)



AttacherJoints.mrLoadAttacherJointFromXML = function(self, superFunc, superFunc1, attacherJoint, xmlFile, baseName, index)

	if superFunc(self, superFunc1, attacherJoint, xmlFile, baseName, index) then	
		if attacherJoint.transNode ~= nil then
			attacherJoint.mrOffsetY = Utils.getNoNil(getXMLFloat(xmlFile, baseName.."#mrOffsetY"), 0)
			attacherJoint.transNodeOffsetY = attacherJoint.transNodeOffsetY + attacherJoint.mrOffsetY
		end		
		return true		
	else	
		return false		
	end

end
AttacherJoints.loadAttacherJointFromXML = Utils.overwrittenFunction(AttacherJoints.loadAttacherJointFromXML, AttacherJoints.mrLoadAttacherJointFromXML);


--[[
AttacherJoints.updateAttacherJointRotation = function(self, superFunc, jointDesc, object)
	    if superFunc ~= nil then
	        superFunc(self, jointDesc, object);
	    end
	
	    -- rotate attacher such that
	    local targetRot = Utils.lerp(object.attacherJoint.upperRotationOffset, object.attacherJoint.lowerRotationOffset, jointDesc.moveAlpha);
	    local curRot = Utils.lerp(jointDesc.upperRotationOffset, jointDesc.lowerRotationOffset, jointDesc.moveAlpha);
	    local rotDiff = targetRot - curRot;
	
	    setRotation(jointDesc.jointTransform, unpack(jointDesc.jointOrigRot));	
		
		print(string.format("test - uro1=%1.4f - lro1=%1.4f - uro2=%1.4f - lro2=%1.4f - moveAlpha=%1.4f - targetRot=%1.4f - curRot=%1.4f - rotDiff=%1.4f", 
		object.attacherJoint.upperRotationOffset, object.attacherJoint.lowerRotationOffset, jointDesc.upperRotationOffset, jointDesc.lowerRotationOffset, jointDesc.moveAlpha, targetRot, curRot, rotDiff));
		
	    --rotateAboutLocalAxis(jointDesc.jointTransform, rotDiff, 0, 0, 1);
	end
--]]







