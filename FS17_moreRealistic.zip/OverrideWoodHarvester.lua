﻿--************************************************************************************************************************************************************
--add rpm required and power requirement when the "head" is activated
WoodHarvester.mrLoad = function(self)	
	if not self.mrIsMrVehicle then
		return
	end

	self.mrWoodHarvesterWorkPtoRpm = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#workPtoRpm"), 0) -- 0 means the feature is turned off
	self.mrWoodHarvesterWorkPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#workPtoPower"), 0) -- KW	
	self.mrWoodHarvesterCuttingPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#cuttingPtoPower"), 0) -- KW
	self.mrWoodHarvesterLimbingPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#limbingPtoPower"), 0) -- KW
	
	--20171224 - variable "cutAttachMoveSpeed"
	self.mrWoodHarvesterLightLogMass = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#lightLogMass"), 0);
	self.mrWoodHarvesterHeavyLogMass = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#heavyLogMass"), 0);
	self.mrWoodHarvesterLightLogSpeed = getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#lightLogSpeed");
	self.mrWoodHarvesterHeavyLogSpeed = getXMLFloat(self.xmlFile, "vehicle.moreRealistic.woodHarvester#heavyLogSpeed");
	
	if self.mrWoodHarvesterLightLogSpeed==nil then
		self.mrWoodHarvesterLightLogSpeed = self.cutAttachMoveSpeed;
	else
		self.mrWoodHarvesterLightLogSpeed = self.mrWoodHarvesterLightLogSpeed/1000;
	end;
	
	if self.mrWoodHarvesterHeavyLogSpeed==nil then
		self.mrWoodHarvesterHeavyLogSpeed = self.mrWoodHarvesterLightLogSpeed;	
	else
		self.mrWoodHarvesterHeavyLogSpeed = self.mrWoodHarvesterHeavyLogSpeed/1000;
	end;
	
	if self.mrWoodHarvesterWorkPtoRpm>0 then
		self.getPtoRpm = WoodHarvester.mrGetPtoRpm
		self.getConsumedPtoTorque = WoodHarvester.mrGetConsumedPtoTorque
	end
	
end
WoodHarvester.load = Utils.appendedFunction(WoodHarvester.load, WoodHarvester.mrLoad)

--************************************************************************************************************************************************************
--no powerConsumer specialization for woodHarvester vehicle type
WoodHarvester.mrGetPtoRpm = function(self)
    if self:getIsTurnedOn() then
        return self.mrWoodHarvesterWorkPtoRpm
    end
    return 0
end

--************************************************************************************************************************************************************
--no powerConsumer specialization for woodHarvester vehicle type
WoodHarvester.mrGetConsumedPtoTorque = function(self)	
	--check if head is turned on
	if self:getIsTurnedOn() then	
		local totalPower = self.mrWoodHarvesterWorkPower
		if self.cutTimer>0 then
			totalPower = totalPower + self.mrWoodHarvesterCuttingPower
		end
		if self.attachedSplitShape ~= nil and self.isAttachedSplitShapeMoving then
			totalPower = totalPower + self.mrWoodHarvesterLimbingPower
		end 
		return totalPower / (self.mrWoodHarvesterWorkPtoRpm*math.pi/30)        
    end
    return 0
end


WoodHarvester.mrOnDelimbTree = function(self, state)
	
	if not self.mrIsMrVehicle then
		return
	end

	if self.isServer then		
		if self.attachedSplitShape ~= nil then
			if entityExists(self.attachedSplitShape) then
				--get the log weight
				local mass = getMass(self.attachedSplitShape);				
				--update the cutAttachMoveSpeed value				
				if mass<self.mrWoodHarvesterLightLogMass then
					self.cutAttachMoveSpeed = self.mrWoodHarvesterLightLogSpeed;
				elseif mass>self.mrWoodHarvesterHeavyLogMass then
					self.cutAttachMoveSpeed = self.mrWoodHarvesterHeavyLogSpeed;
				elseif self.mrWoodHarvesterHeavyLogMass==self.mrWoodHarvesterLightLogMass or self.mrWoodHarvesterLightLogSpeed==self.mrWoodHarvesterHeavyLogSpeed then -- protection
					self.cutAttachMoveSpeed = self.mrWoodHarvesterHeavyLogSpeed;
				else
					self.cutAttachMoveSpeed = RealisticUtils.linearFx3(mass, self.mrWoodHarvesterLightLogMass, self.mrWoodHarvesterHeavyLogMass, self.mrWoodHarvesterLightLogSpeed, self.mrWoodHarvesterHeavyLogSpeed);
				end;
				--print("test log mass=" .. tostring(mass) .. " - new speed = " .. tostring(self.cutAttachMoveSpeed*1000))
			end;
		end;		
	end;
	
end;
WoodHarvester.onDelimbTree = Utils.appendedFunction(WoodHarvester.onDelimbTree, WoodHarvester.mrOnDelimbTree)











