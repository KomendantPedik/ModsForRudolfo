﻿----------------------------------------------------------------------------------------------------
-- HELP LINES FOR HELP IN INGAMEMENU
----------------------------------------------------------------------------------------------------
-- Authors:  Rahkiin
--
-- Copyright (c) Realismus Modding, 2017
----------------------------------------------------------------------------------------------------

RealisticHelpLines = {}
RealisticHelpLines.modDir = g_currentModDirectory

function RealisticHelpLines.load()
	RealisticHelpLines.loadFromXML(RealisticHelpLines.modDir .. "moreRealisticHelp/helpLine.xml")
end

function RealisticHelpLines.getText(key, default)
    if g_i18n:hasText(key) then
        return g_i18n:getText(key)
    elseif default ~= nil then
        return default
    else
        return key
    end
end

function RealisticHelpLines.loadI18NIntoGlobal(key)
    g_i18n.globalI18N:setText(key, RealisticHelpLines.getText(key))
end

function RealisticHelpLines.loadFromXML(path)
    local xmlFile = loadXMLFile("helpLine", path)

    local categoryIndex = 0
    while true do
        local categoryKey = string.format("helpLines.helpLineCategory(%d)", categoryIndex)
        if not hasXMLProperty(xmlFile, categoryKey) then break end

        local category = {}
        category.title = getXMLString(xmlFile, categoryKey .. "#title")
        category.helpLines = {}

        RealisticHelpLines.loadI18NIntoGlobal(category.title)

        g_inGameMenu.helpLineCategorySelectorElement:addText(RealisticHelpLines.getText(category.title))

        local lineIndex = 0
        while true do
            local lineKey = string.format("%s.helpLine(%d)", categoryKey, lineIndex)
            if not hasXMLProperty(xmlFile, lineKey) then break end

            local helpLine = {}
            helpLine.title = getXMLString(xmlFile, lineKey .. "#title")
            helpLine.items = {}

            RealisticHelpLines.loadI18NIntoGlobal(helpLine.title)

            local itemIndex = 0
            while true do
                local itemKey = string.format("%s.item(%d)", lineKey, itemIndex)
                if not hasXMLProperty(xmlFile, itemKey) then break end

                local type = getXMLString(xmlFile, itemKey .. "#type")
                local value = getXMLString(xmlFile, itemKey .. "#value")

                if type == "text" then
                    RealisticHelpLines.loadI18NIntoGlobal(value)
                end

                if type == "image" then
                    value = RealisticHelpLines.modDir .. "moreRealisticHelp/helpLineImages/" .. value .. ".dds"
                end

                if value ~= nil and (type == "text" or type == "image") then
                    local item = {
                        type = type,
                        value = value,
                        heightScale = Utils.getNoNil(getXMLFloat(xmlFile, itemKey .. "#heightScale"), 1)
                    }

                    table.insert(helpLine.items, item)
                end

                itemIndex = itemIndex + 1
            end

            table.insert(category.helpLines, helpLine)
            lineIndex = lineIndex + 1
        end

        table.insert(g_inGameMenu.helpLineCategories, category)
        categoryIndex = categoryIndex + 1
    end

    delete(xmlFile)
end
