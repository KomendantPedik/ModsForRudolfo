﻿--************************************************************************************************************************************************************
--fix for sugarcane "seeds". Indeed, sugarcane product = very light. And the required quantity per hectare is "huge". 
--Which means sugarcane seeders have large tanks => if we apply the base "seeds" density to the content of the tank, the resulting mass is far too large compared to IRL
--Solution = 1. when the sowingMachine is not MR, we want to use the vanilla game density value. so that there is no problem when playing with non-mr vehicle filled with seeds (especially when filled with sugarcane) -> see overrideFillable lua file
--           2. for MR seeders, we check if the selected seeds is sugarcane or not (and replace the density with the one of the sugarcane)

SowingMachine.mrSetUnitFillLevel = function(self, superFunc, fillUnitIndex, fillLevel, fillType, force, fillInfo)
			
	if self.isServer and self.mrIsMrVehicle then
		self.mrFillContentMass = 0; --we want to override the base game mass computing				
		local newContentMass = 0;
		for i,fillUnit in pairs(self.fillUnits) do
			if fillUnit.currentFillType ~= nil and fillUnit.currentFillType ~= FillUtil.FILLTYPE_UNKNOWN then
				local desc = FillUtil.fillTypeIndexToDesc[fillUnit.currentFillType];
				local massPerLiter = desc.massPerLiter;
				if fillUnit.currentFillType == FillUtil.FILLTYPE_SEEDS then					
					--check if this is sugarcane or not
					local seedsFruitType = self.seeds[self.currentSeed];					
					if seedsFruitType==FruitUtil.FRUITTYPE_SUGARCANE then
						--get the sugarcane density						
						local desc = FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_SUGARCANE];
						--print("test fruitDesc = " .. tostring(desc) .. " name="..tostring(fillTypeDesc.name))
						massPerLiter = desc.massPerLiter;						
					end;
				end;					
				newContentMass = newContentMass + (fillUnit.fillLevel * massPerLiter);
			end
		end
		self.mrFillContentMass = newContentMass;	
	end;	
	
end
SowingMachine.setUnitFillLevel = Utils.appendedFunction(SowingMachine.setUnitFillLevel, SowingMachine.mrSetUnitFillLevel)