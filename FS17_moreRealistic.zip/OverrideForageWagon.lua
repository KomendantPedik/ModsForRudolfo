﻿

--************************************************************************************************************************************************************
--set the specific getConsumedPtoTorque
ForageWagon.mrLoad = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	self.forageWagon.mrInputFlowDependantPtoPower  = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.forageWagon#inputFlowDependantPtoPower"), 0); -- KW per M3 per second
	self.forageWagon.mrUseFlowDependantPtoPower = self.forageWagon.mrInputFlowDependantPtoPower>0
	
	if self.forageWagon.mrUseFlowDependantPtoPower then
		self.forageWagon.mrCurrentInputFlowDependantPower = 0
		self.getConsumedPtoTorque = ForageWagon.mrGetConsumedPtoTorque
	end
		
	self.forageWagon.mrMaxFillLiterPerSecond = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.forageWagon#maxFillLiterPerSecond"), 0) -- liters per second
	self.forageWagon.mrLastLitersProcessedTime = 0
	self.forageWagon.mrLastInputFlow = 0
	self.forageWagon.mrLastInputFlowAvg = 0	
	
	self.forageWagon.mrUseVaryingSpeedLimit = false
	if self.forageWagon.mrMaxFillLiterPerSecond>0 then
		self.forageWagon.mrUseVaryingSpeedLimit = true
		self.forageWagon.mrTargetSpeedLimit = 15
		self.forageWagon.mrMaterialBuffer = 0
	end
	
	self.processForageWagonAreas = ForageWagon.mrProcessForageWagonAreas

end
ForageWagon.load = Utils.appendedFunction(ForageWagon.load, ForageWagon.mrLoad)


--************************************************************************************************************************************************************
--update the current fill liters per second so that we can adjust the speed limit
ForageWagon.mrProcessForageWagonAreas = function(self, workAreas, fillTypes, fruitTypeFix, fruitType)	
	
	local liftingFlowSpeed = 0
	
	local totalLiters, fruitType = ForageWagon.processForageWagonAreas(self, workAreas, fillTypes, fruitTypeFix, fruitType)
	if self.forageWagon.mrUseVaryingSpeedLimit then
		self.forageWagon.mrMaterialBuffer = math.min(self.forageWagon.mrMaxFillLiterPerSecond*5, self.forageWagon.mrMaterialBuffer + totalLiters)
	end
	
	local liftingTime = g_currentMission.time - self.forageWagon.mrLastLitersProcessedTime
	
	if liftingTime>0 then
		liftingFlowSpeed = 1000 * totalLiters / liftingTime --liters per second		
	end
	
	--print("test - liftingFlowSpeed = " .. tostring(liftingFlowSpeed))
	
	--update flow dependant pto power requirement
	if self.forageWagon.mrUseFlowDependantPtoPower then
		local tickPower = self.forageWagon.mrInputFlowDependantPtoPower * liftingFlowSpeed / 1000 -- KW per M3 per Second
		--20170613 - less power at high crop flow since windrow "size" can vary a lot in FS17 
		--  3m cut width + grass not fertilized + grass not fully grown = very small windrow
		--  using the big lely 15m wide windrower + grass fully fertilized and grown = very big windrow
		tickPower = tickPower^0.9
		if tickPower>self.forageWagon.mrCurrentInputFlowDependantPower then
			self.forageWagon.mrCurrentInputFlowDependantPower = tickPower
		end
		--if tickPower>=self.forageWagon.mrCurrentInputFlowDependantPower then
		--	self.forageWagon.mrCurrentInputFlowDependantPower = 0.9*self.forageWagon.mrCurrentInputFlowDependantPower + 0.1*tickPower 
		--else
		--	self.forageWagon.mrCurrentInputFlowDependantPower = 0.98*self.forageWagon.mrCurrentInputFlowDependantPower + 0.02*tickPower 
		--end
	end
	
	self.forageWagon.mrLastLitersProcessedTime = g_currentMission.time	
	self.forageWagon.mrLastInputFlow = liftingFlowSpeed
	self.forageWagon.mrLastInputFlowAvg = 0.99 * self.forageWagon.mrLastInputFlowAvg + 0.01 * liftingFlowSpeed
	
	--update the speedLimit 	
	if false and  self.forageWagon.mrMaxFillLiterPerSecond>0 then
		if self.forageWagon.mrLastInputFlow>self.forageWagon.mrMaxFillLiterPerSecond then
			self.forageWagon.mrTargetSpeedLimit = math.max(3, self.speedLimit+1-self.forageWagon.mrLastInputFlow/self.forageWagon.mrMaxFillLiterPerSecond)
			--self.forageWagon.mrTargetSpeedLimit = math.max(3, self.speedLimit - 0.1)
		else
			--self.speedLimit = math.min(self.mrGenuineSpeedLimit, self.speedLimit+0.1)
			self.forageWagon.mrTargetSpeedLimit = math.min(self.mrGenuineSpeedLimit, self.speedLimit+1-self.forageWagon.mrLastInputFlow/self.forageWagon.mrMaxFillLiterPerSecond)
		end
	end
	
	return totalLiters, fruitType

end

--************************************************************************************************************************************************************
--pto torque depends on the material quantity / liters per minute lifted by the forage wagon
ForageWagon.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower + self.forageWagon.mrCurrentInputFlowDependantPower
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end

--************************************************************************************************************************************************************
--MR : display debug info
ForageWagon.mrUpdate=function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	if self:getIsTurnedOn() then
		self.forageWagon.mrCurrentInputFlowDependantPower = math.max(0, self.forageWagon.mrCurrentInputFlowDependantPower*(1-dt/4500)) --4.5s to lose all the flow dependant pto power
		
		--manage the material buffer
		if self.forageWagon.mrUseVaryingSpeedLimit then
			self.forageWagon.mrMaterialBuffer = math.max(0, self.forageWagon.mrMaterialBuffer-self.forageWagon.mrMaxFillLiterPerSecond*dt/1000)
			
			if self.forageWagon.mrMaterialBuffer>0.25*self.forageWagon.mrMaxFillLiterPerSecond then
				--limit the speed to avoid overfilling the buffer
				local fx = self.forageWagon.mrMaterialBuffer/self.forageWagon.mrMaxFillLiterPerSecond
				self.speedLimit = math.max(3, self.speedLimit-fx*dt/2000) --decrease at a rate of 1kph per second
			elseif self.forageWagon.mrMaterialBuffer==0 then
				self.speedLimit = math.min(self.mrGenuineSpeedLimit, self.speedLimit+(self.mrGenuineSpeedLimit*dt/10000)) -- 10s to recover full speed limit
			end
			
		end
		
		--[[
		if self.forageWagon.mrTargetSpeedLimit>self.speedLimit then
			self.speedLimit = math.min(self.forageWagon.mrTargetSpeedLimit, self.speedLimit+(self.mrGenuineSpeedLimit*dt/10000)) -- 10s to recover full speed limit
		else
			self.speedLimit = math.max(self.forageWagon.mrTargetSpeedLimit, self.speedLimit-(self.mrGenuineSpeedLimit*dt/6000)) -- 6s to lose full speed limit
		end--]]
	end
	
	if Vehicle.debugRendering and self.isServer and self:getIsTurnedOn() then
		
		local vehicle = self
		if self.attacherVehicle then
			vehicle = self.attacherVehicle
		end
		if (vehicle.isEntered and vehicle.isClient and vehicle.isControlled) or self:getIsActiveForInput()  then
			local turnedOnPtoPower = 0
			
			if self.powerConsumer then
				turnedOnPtoPower = self.powerConsumer.mrNoLoadPtoPower				 
			end
			
			local flowDependantPtoPower = 0
			if self.forageWagon.mrUseFlowDependantPtoPower then
				flowDependantPtoPower = self.forageWagon.mrCurrentInputFlowDependantPower
			end
			
			local totalPower = turnedOnPtoPower + flowDependantPtoPower
		
			local fillType = self:getUnitFillType(self.forageWagon.fillUnitIndex)
			local tonPerHour = 0
			if FillUtil.fillTypeIndexToDesc[fillType] then
				tonPerHour = FillUtil.fillTypeIndexToDesc[fillType].massPerLiter * self.forageWagon.mrLastInputFlowAvg * 3600
			end
			
			local bufferLevel=0
			if self.forageWagon.mrUseVaryingSpeedLimit then
				bufferLevel = self.forageWagon.mrMaterialBuffer
			end
		
			local str = string.format(" turnedOnPtoPower=%.1f\n inputflowDependantPtoPower=%.1f\n lastTotalPower=%.1f\n Current Speed Limit=%.1f\n Max input flow=%.0f/Avg flow=%.0f\n Avg tons per Hour=%.1f\n Buffer level=%.0f", turnedOnPtoPower, flowDependantPtoPower, totalPower, self.speedLimit,self.forageWagon.mrMaxFillLiterPerSecond,self.forageWagon.mrLastInputFlowAvg, tonPerHour, bufferLevel)
			renderText(0.74, 0.75, getCorrectTextSize(0.02), str)
		end
		
		
		
	end

end
ForageWagon.update = Utils.appendedFunction(ForageWagon.update, ForageWagon.mrUpdate)




Mower.processMowerAreas = function(self, workAreas, numWorkAreas, dropAreas, numDropAreas, remainingWindrowToDrop)
    local pickedUpWindrow = 0
    local numDropAreasUsed = 0
    local fillType = FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_GRASS]
    for i=1, numWorkAreas do
        local area = workAreas[i]
        local x0 = area.x
        local z0 = area.z
        local x1 = area.x1
        local z1 = area.z1
        local x2 = area.x2
        local z2 = area.z2
        local areaPixelsSum, _, sprayFactor, _ = Utils.cutFruitArea(FruitUtil.FRUITTYPE_GRASS, x0,z0, x1,z1, x2,z2, true, true)
        if areaPixelsSum > 0 then
            local multi = g_currentMission:getHarvestScaleMultiplier(sprayFactor, 1)
            areaPixelsSum = areaPixelsSum * multi
        end
        local pixelToSqm = g_currentMission:getFruitPixelsToSqm()
        local sqm = areaPixelsSum * pixelToSqm
        local litersChanged = sqm * FruitUtil.getFillTypeLiterPerSqm(FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_GRASS], 1)
        if area.dropArea ~= nil then
            dropAreas[area.dropArea].valueAccum = dropAreas[area.dropArea].valueAccum + litersChanged
        else
            if not area.dropWindrow then
                pickedUpWindrow = pickedUpWindrow + litersChanged
            else
                local lx_2 = 0.5*(area.x2 - area.x)
                local lz_2 = 0.5*(area.z2 - area.z)
                local sx = area.x + lx_2
                local sz = area.z + lz_2
                local ex = area.x1 + lx_2
                local ez = area.z1 + lz_2
                local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz)
                local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez)
                local toDrop = remainingWindrowToDrop + litersChanged
                local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, toDrop, fillType, sx,sy,sz, ex,ey,ez, 0, nil, self.mowerLineOffset, false, nil, false)
                self.mowerLineOffset = lineOffset
				
				print("test - remainingWindrowToDrop="..tostring(remainingWindrowToDrop) .. " - toDrop="..tostring(toDrop) .." - dropped="..tostring(dropped))
				
                --remainingWindrowToDrop = remainingWindrowToDrop + (toDrop - dropped)
				remainingWindrowToDrop = toDrop - dropped
            end
        end
    end
    local unitLength = TipUtil.densityToWorldMap
    for i=1, numDropAreas do
        local area = dropAreas[i]
        local widthX = area.x1 - area.x
        local widthZ = area.z1 - area.z
        local widthLength = Utils.vector2Length(widthX, widthZ)
        local widthLength_2 = 0.5 * widthLength
        local widthX_norm = widthX / widthLength
        local widthZ_norm = widthZ / widthLength
        local middleX = 0.5 * (area.x1 + area.x)
        local middleZ = 0.5 * (area.z1 + area.z)
        local sx = middleX + ( widthX_norm * math.max(0, widthLength_2 - unitLength) )
        local sz = middleZ + ( widthZ_norm * math.max(0, widthLength_2 - unitLength) )
        local ex = middleX - ( widthX_norm * math.max(0, widthLength_2 - unitLength) )
        local ez = middleZ - ( widthZ_norm * math.max(0, widthLength_2 - unitLength) )
        local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz)
        local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez)
        --drawDebugLine(sx,sy,sz, 1,0,0, sx,sy+2,sz, 1,0,0)
        --drawDebugLine(ex,ey,ez, 0,1,0, ex,ey+2,ez, 0,1,0)
        local toDrop = area.valueAccum
        local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, toDrop, fillType, sx,sy,sz, ex,ey,ez, 0, nil, area.mowerLineOffset, false, nil, false)
        area.mowerLineOffset = lineOffset
        area.valueAccum = area.valueAccum - dropped
        area.value = dropped
        if dropped > 0 then
            numDropAreasUsed = numDropAreasUsed + 1
        end
    end
    return numDropAreasUsed, pickedUpWindrow, remainingWindrowToDrop
end

















