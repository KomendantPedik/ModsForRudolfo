﻿

--------------------------------------------------------------------------------
-- RealisticGuiDataResponseEvent :
-- server = send the updated data to the given client
-- client = read the updated data
--------------------------------------------------------------------------------
RealisticGuiDataResponseEvent = {}
RealisticGuiDataResponseEvent_mt = Class(RealisticGuiDataResponseEvent, Event)
InitEventClass(RealisticGuiDataResponseEvent, "RealisticGuiDataResponseEvent")

function RealisticGuiDataResponseEvent:emptyNew()	
    local self = Event:new(RealisticGuiDataResponseEvent_mt);
    return self;
end;

function RealisticGuiDataResponseEvent:new(vehicle, lastWheelsSlip, lastFuelRate)
    local self = RealisticGuiDataResponseEvent:emptyNew()  
	self.vehicleId = networkGetObjectId(vehicle);
	self.lastWheelsSlip = lastWheelsSlip;
	self.lastFuelRate = lastFuelRate;
	self.mrTransmissionInUse = vehicle.mrUseMrTransmission;
    return self;
end;

------------------------------------------------------------------------------
-- called on client side after the sendEvent from the server
------------------------------------------------------------------------------
function RealisticGuiDataResponseEvent:readStream(streamId, connection) 
	local vehicleId = readNetworkNodeObjectId(streamId);
	local slip = streamReadUIntN(streamId, 7);
	local lowFuelUsage = streamReadBool(streamId);
	local fuelRate = streamReadUIntN(streamId, 10);
	
	if vehicleId~=nil then
		self.vehicle = networkGetObject(vehicleId);
		if self.vehicle~=nil then
			self.lastWheelsSlip = slip/127;
			if lowFuelUsage then
				local fuelRate = 40 * fuelRate/1023;
				if fuelRate==40 then
					fuelRate = nil;
				end
				self.lastFuelRate = fuelRate;
			else
				self.lastFuelRate = 400 * fuelRate/1023;
			end
			self:run(connection);
		end;
	end;
end;

------------------------------------------------------------------------------
-- called on server after the sendEvent
------------------------------------------------------------------------------
function RealisticGuiDataResponseEvent:writeStream(streamId, connection)	
	writeNetworkNodeObjectId(streamId, self.vehicleId);
	streamWriteUIntN(streamId, 127 * math.min(1, self.lastWheelsSlip), 7); -- max slip = 1 (100%)
	local fuelRate = self.lastFuelRate;
	local lowFuelUsage = fuelRate<40; -- more precision under 40
	
	--specific case - mr transmission not in use which means we don't want to send "wrong" value to the gui
	if not self.mrTransmissionInUse then
		lowFuelUsage = true;
	end
	
	streamWriteBool(streamId, lowFuelUsage);
	if lowFuelUsage then		
		--if mr transmission is not in use (example : CP), send a "1" value (should not be possible here) => client knows it should treat it as a "nil"
		if not self.mrTransmissionInUse then 
			fuelRate = 40;
		end
		streamWriteUIntN(streamId, 1023 * math.min(1, fuelRate/40), 10);
	else
		streamWriteUIntN(streamId, 1023 * math.min(1, fuelRate/400), 10); -- limit fuel usage to 400L/h
	end
end;

------------------------------------------------------------------------------
-- Run action on client side
-- send RealisticGuiDataResponseEvent with updated data to the client
------------------------------------------------------------------------------
function RealisticGuiDataResponseEvent:run(connection)		
	self.vehicle.mrLastWheelsSlip = self.lastWheelsSlip
	self.vehicle.mrLastFuelRate = self.lastFuelRate
end;