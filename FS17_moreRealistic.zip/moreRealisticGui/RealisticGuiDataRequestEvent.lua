﻿

--------------------------------------------------------------------------------
-- RealisticGuiDataRequestEvent :
-- client = tell the server it wants updated data for the controlled vehicle
-- server = send update data to the client
--------------------------------------------------------------------------------
RealisticGuiDataRequestEvent = {}
RealisticGuiDataRequestEvent_mt = Class(RealisticGuiDataRequestEvent, Event)
InitEventClass(RealisticGuiDataRequestEvent, "RealisticGuiDataRequestEvent")

function RealisticGuiDataRequestEvent:emptyNew()	
    local self = Event:new(RealisticGuiDataRequestEvent_mt);
    return self;
end;

function RealisticGuiDataRequestEvent:new(vehicle)	
    local self = RealisticGuiDataRequestEvent:emptyNew()  
	self.vehicleId = networkGetObjectId(vehicle);
    return self;
end;

------------------------------------------------------------------------------
-- called on server side after a sendEvent from the client
------------------------------------------------------------------------------
function RealisticGuiDataRequestEvent:readStream(streamId, connection) 
	local vehicleId = readNetworkNodeObjectId(streamId);
	if vehicleId~=nil then
		self.vehicle = networkGetObject(vehicleId);
		if self.vehicle~=nil then
			self:run(connection);
		end;
	end;
end;

------------------------------------------------------------------------------
-- called on client after the sendEvent
------------------------------------------------------------------------------
function RealisticGuiDataRequestEvent:writeStream(streamId, connection)
	 writeNetworkNodeObjectId(streamId, self.vehicleId);
end;

------------------------------------------------------------------------------
-- Run action on server side
-- send RealisticGuiDataRequestEvent with updated data to the client
------------------------------------------------------------------------------
function RealisticGuiDataRequestEvent:run(connection)	
	connection:sendEvent(RealisticGuiDataResponseEvent:new(self.vehicle, self.vehicle.mrLastWheelsSlip, self.vehicle.mrLastFuelRate));
end;