﻿RealisticGui = {}
RealisticGui.path = g_currentModDirectory .. "moreRealisticGui/";
source(RealisticGui.path.."gui/gui.lua");

RealisticGui.SAVE_FILENAME = "mrGuiSave.xml"
RealisticGui.LOADED_DATA = {}


RealisticGui.UPDATETIME_DISPLAY = 700 --ms
RealisticGui.UPDATETIME_NETWORK = 2000 --ms
RealisticGui.GUI_NETWORKUSE_ISACTIVE = true;
RealisticGui.GUI_ISACTIVE = true;	

RealisticGui.DRAWVEHICLEHUD_APPENDED = false


function RealisticGui:load(savegame)

	if not self.mrIsMrVehicle then
		return;
	end

	
	RealisticGui.stopMouse = false;

	--RealisticGui.snd_click = createSample("snd_click");
	--loadSample(RealisticGui.snd_click, Utils.getFilename("gui/snd/snd_click.wav", RealisticGui.path), false);

	
	
	local defaultPosX, defaultPosY = g_currentMission.vehicleHudBg.x, 0;
	local xPos, yPos = defaultPosX, defaultPosY
	
	-- load position of hud(s) from savegame
	if savegame ~= nil and not savegame.resetVehicles then
		--savegame.key --careerVehicles.vehicle(1)		
		local vehicleId = string.match(savegame.key, 'vehicle%((%d+)%)');		
		if vehicleId~=nil then
			vehicleId = 1+tonumber(vehicleId)	
			if RealisticGui.LOADED_DATA[vehicleId]~=nil then
				local x = RealisticGui.LOADED_DATA[vehicleId].hud1_x;--getXMLFloat(savegame.xmlFile, savegame.key.."#MR_hud1_x");
				local y = RealisticGui.LOADED_DATA[vehicleId].hud1_y;--getXMLFloat(savegame.xmlFile, savegame.key.."#MR_hud1_y");
				if x ~= nil then
					xPos = x;			
				end;
				if y ~= nil then
					yPos = y;
				end;
			end;
		end;
	end;	
	
	self.hud1 = {}
	self.hud1 = RealisticGui.container:New(xPos, yPos, true);
	self.hud1.defaultPosX = defaultPosX
	self.hud1.defaultPosY = defaultPosY
	

	local gridWidth = g_currentMission.vehicleHudBg.width/8;
	local gridHeight = g_currentMission.vehicleHudBg.y * 0.95;

	-- create grid (container [table], offset x [int], offset y [int], rows [int], columns [int], width [int], height [int] is visible [bool], is master [bool], showGrid [bool])
	self.hud1.grids.main = {};
	self.hud1.grids.main = RealisticGui.hudGrid:New(self.hud1, 0, 0, 1, 8, gridWidth, gridHeight, true, true, false);

	-- create gui elements ( grid position [int], function to call [string], parameter1, parameter2, style [string], label [string], value [], is visible [bool], [Grafik], textSize [int], textAlignment []) ]
	-- main elements
	--NewTitlebar ( gridPos [int], functionToCall [string], parameter1 [], parameter2 [], label [string], isVisible [bool], textSize [int]]

	--NewImage ( gridPos [int], offsetX [number], offsetY [number], width [number], height [number], color [{r,g,b,a}], isVisible [bool], graphic, uvs  [{u0,v0,u1,v1,u2,v2,u3,v3})

	--NewSeparator ( gridPos [int], offsetX [number], offsetY [number], color [{r,g,b,a}], style ["h" or "v"], isVisible [bool])

	--NewInteraction ( gridPos [int], offsetX [number], offsetY [number], textColor [{r,g,b,a}], functionToCall [string], parameter1, parameter2, style [string], label [string], value [], isvisible [bool], [graphics], labelTextSize [int], valueTextSize [int], textBold [bool])

	--NewText ( gridPos [int], offsetX [number], offsetY [number], color [{r,g,b,a}], label [string], value [string], isVisible [bool] , labelTextSize [int], valueTextSize [int], textBold [bool], textAlignment [])

	--NewIconText ( gridPos [int], offsetX [number], offsetY [number], color [{r,g,b,a}], value [string], valueTextSize [int], textBold [bool], isVisible [bool], graphic, uvs [{u0,v0,u1,v1,u2,v2,u3,v3}]
	self.hud1.grids.main.elements.mrSlip = RealisticGui.guiElement:NewIconText( 2, 0,0.001, {1,1,1,1}, "-.- %", 4, false, true, "slip", nil);
	self.hud1.grids.main.elements.mrFuelRate = RealisticGui.guiElement:NewIconText( 5, 0,0.001, {1,1,1,1}, "-.- l/h", 4, false, true, "fuelrate", nil);
	self.hud1.grids.main.elements.mrMoveHUD = RealisticGui.guiElement:NewInteraction( 8, 0,0, {1,1,1,1}, "drag", nil, nil, "dragArea", nil, nil, false, "hand", 1, _, false );
	
	local NETWORK_OFF = g_i18n:getText("REALISTIC_GUI_NETWORK_OFF");
	self.hud1.grids.main.elements.netOff = RealisticGui.guiElement:NewIconText( 1, 0.001,0.002 , {1,1,1,1}, NETWORK_OFF, 2, false, false, "warning", nil);
	
	--avg fuel rate
	self.hud1.grids.main.elements.mrFuelRate.avgFuelRateValue = 0;
	
	--avg slip value
	self.hud1.grids.main.elements.mrSlip.avgSlipValue = 0;
	
	
	self.hud1.grids.main.mrTimeSinceLastDisplayUpdate = 0;
	self.hud1.grids.main.mrTimeSinceLastDataUpdate = 0;
	
	if not RealisticGui.DRAWVEHICLEHUD_APPENDED then
		RealisticGui.DRAWVEHICLEHUD_APPENDED = true
		g_currentMission.drawVehicleHud = Utils.appendedFunction(g_currentMission.drawVehicleHud, RealisticGui.drawVehicleHud);
	end

	-- self.hud1.grids.main.elements.separator1 = RealisticGui.guiElement:New( 19, nil, nil, nil, "separator", nil, nil, true, "row_bg", nil);
	-- self.hud1.grids.main.elements.changeSomething = RealisticGui.guiElement:New( 20, "changeSomething", -3, 1, "plusminus", "Verschieben", 21, true, nil);
	--print('load gui done');
	
end;
Drivable.load = Utils.appendedFunction(Drivable.load, RealisticGui.load);

--[[
-- get save position of hud(s)
function RealisticGui:getSaveAttributesAndNodes(superFunc, nodeIdent)

	local attributes, nodes = superFunc(self, nodeIdent)
	if self.mrIsMrVehicle then
		if self.hud1~=nil then -- protection (but hud1 should not be nil here)			
			attributes = attributes .. ' MR_hud1_x="'..tostring(self.hud1.baseX)..'"';	
			attributes = attributes .. ' MR_hud1_y="'..tostring(self.hud1.baseY)..'" ';	
		end
	end	
    return attributes, nodes;
	
end;
Drivable.getSaveAttributesAndNodes = Utils.overwrittenFunction(Drivable.getSaveAttributesAndNodes, RealisticGui.getSaveAttributesAndNodes);	--]]														  

function RealisticGui:mouseEvent(posX, posY, isDown, isUp, button)
	if self.mrIsMrVehicle then
		self.hud1.mouseEvent(self, posX, posY, isDown, isUp, button);
	end;
end;
Drivable.mouseEvent = Utils.appendedFunction(Drivable.mouseEvent, RealisticGui.mouseEvent);															  

function RealisticGui:update(dt)
	
	if self.mrIsMrVehicle then
	
		--only refresh info if there is a player in the vehicle
		if self.isEntered and self.isClient then -- no need to run on a dedicated server (isClient = false)
					
			--disabling the network use is only possible for 'master users'
			if (g_currentMission.isMasterUser or g_currentMission:getIsServer()) and InputBinding.hasEvent(InputBinding.REALISTIC_GUI_NETWORK_USE) then
				--we want to enable/disable network use of the MR GUI (no more data update clientside)
				RealisticGui.GUI_NETWORKUSE_ISACTIVE = not RealisticGui.GUI_NETWORKUSE_ISACTIVE;
				--sent event to all other clients for them to stop asking for updated data
				RealisticGuiToggleNetworkUseEvent.sendEvent(RealisticGui.GUI_NETWORKUSE_ISACTIVE);
				RealisticGui:printNetworkUseState();
			end
			
			-- switch GUI
			if InputBinding.hasEvent(InputBinding.REALISTIC_GUI) then			
				RealisticGui.GUI_ISACTIVE = not RealisticGui.GUI_ISACTIVE;				
			end;
			
			if RealisticGui.GUI_ISACTIVE then
				self.hud1.grids.main.mrTimeSinceLastDisplayUpdate = self.hud1.grids.main.mrTimeSinceLastDisplayUpdate + dt;	
				if RealisticGui.GUI_NETWORKUSE_ISACTIVE and not self.isServer then
					self.hud1.grids.main.mrTimeSinceLastDataUpdate = self.hud1.grids.main.mrTimeSinceLastDataUpdate + dt;
				end;
			end;				
			
			-- activate Mouse and drag image					
			-- and not (g_gui:getIsGuiVisible() or g_currentMission.isPlayerFrozen or g_currentMission.inGameMessage:getIsVisible()) then
			if RealisticGui.GUI_ISACTIVE and InputBinding.isPressed(InputBinding.REALISTIC_MOUSE) then 
				if self.activeCamera.isRotatable == true then
					self.activeCamera.isRotatable = false;
					self.activeCamera.isChanged = true;
				end;
				self.hud1.grids.main.elements.mrMoveHUD.isVisible = true;
				if not RealisticGui.stopMouse then
					RealisticGui.stopMouse = true;
					InputBinding.setShowMouseCursor(true);
				end;
			else
				if self.activeCamera.isChanged == true then
					self.activeCamera.isRotatable = true;
					self.activeCamera.isChanged = false;
				end;
				self.hud1.grids.main.elements.mrMoveHUD.isVisible = false;
				if RealisticGui.stopMouse and not (g_gui:getIsGuiVisible() or g_currentMission.inGameMessage:getIsVisible()) then -- 20171121 - check no ingame screen is open	
					RealisticGui.stopMouse = false;
					InputBinding.setShowMouseCursor(false);
				end;
			end;
		end;
	end;
end
Drivable.update = Utils.appendedFunction(Drivable.update, RealisticGui.update);

--call by g_currentMission.drawVehicleHud (appended in load function, otherwise, g_currentMission is nil)
function RealisticGui:drawVehicleHud(vehicle)	

	if not vehicle.mrIsMrVehicle then
		return;
	end
	
	if RealisticGui.GUI_ISACTIVE then
	
		if not vehicle.isServer and (vehicle.hud1.grids.main.mrTimeSinceLastDataUpdate>RealisticGui.UPDATETIME_NETWORK) then
			vehicle.hud1.grids.main.mrTimeSinceLastDataUpdate = 0;			
			--ask server for updated data
			if g_client then
				g_client:getServerConnection():sendEvent(RealisticGuiDataRequestEvent:new(vehicle));
			end
		end
	
		local updateTime=vehicle.hud1.grids.main.mrTimeSinceLastDisplayUpdate>RealisticGui.UPDATETIME_DISPLAY--update once very xxx ms
		if updateTime then
			vehicle.hud1.grids.main.mrTimeSinceLastDisplayUpdate = 0
		end		
		
		local displayUpdatedData = vehicle.isServer or RealisticGui.GUI_NETWORKUSE_ISACTIVE		
		
		if displayUpdatedData then
			vehicle.hud1.grids.main.elements.netOff.isVisible = false;
			vehicle.hud1.grids.main.elements.mrFuelRate.isVisible = true;
			vehicle.hud1.grids.main.elements.mrSlip.isVisible = true;
			if vehicle.isMotorStarted then
				if vehicle.mrLastWheelsSlip == nil then		
					vehicle.hud1.grids.main.elements.mrSlip.value = "-.- %";
					vehicle.hud1.grids.main.elements.mrSlip.avgSlipValue = 0;
				else
					vehicle.hud1.grids.main.elements.mrSlip.avgSlipValue = 0.99 * vehicle.hud1.grids.main.elements.mrSlip.avgSlipValue + 1 * vehicle.mrLastWheelsSlip; --0.01 * 100			
					if updateTime then
						vehicle.hud1.grids.main.elements.mrSlip.value = string.format("%3.1f %%", vehicle.hud1.grids.main.elements.mrSlip.avgSlipValue);
					end;					
				end;
				if vehicle.mrLastFuelRate == nil or (vehicle.isServer and not vehicle.mrUseMrTransmission) then						
					vehicle.hud1.grids.main.elements.mrFuelRate.value = "-.- l/h";
					vehicle.hud1.grids.main.elements.mrFuelRate.avgFuelRateValue = 0;
				else
					vehicle.hud1.grids.main.elements.mrFuelRate.avgFuelRateValue = 0.98 * vehicle.hud1.grids.main.elements.mrFuelRate.avgFuelRateValue + 0.02 * vehicle.mrLastFuelRate;
					if updateTime then
						vehicle.hud1.grids.main.elements.mrFuelRate.value = string.format("%3.1f l/h", vehicle.hud1.grids.main.elements.mrFuelRate.avgFuelRateValue);
					end;									
				end;
			else --motor OFF
				vehicle.hud1.grids.main.elements.mrSlip.value = "-.- %";
				vehicle.hud1.grids.main.elements.mrSlip.avgSlipValue = 0;
				vehicle.hud1.grids.main.elements.mrFuelRate.value = "-.- l/h";
				vehicle.hud1.grids.main.elements.mrFuelRate.avgFuelRateValue = 0;
			end;
		else
			vehicle.hud1.grids.main.elements.mrSlip.isVisible = false;
			vehicle.hud1.grids.main.elements.mrFuelRate.isVisible = false;
			vehicle.hud1.grids.main.elements.netOff.isVisible = true;
		end;		 	
		
		vehicle.hud1.renderMe();
		
	end;	
		
end;


--------------------------------------------------------------------------------------------------------
-- synchronize data between server and client at joining time 
-- (global settings, not related to a given vehicle we can't use specialization's "writeStream" and "readStream"" function in such case)
--------------------------------------------------------------------------------------------------------
function RealisticGui:syncMpData(connection)

	if not connection:getIsServer() then
		--this is serverSide
		g_server:broadcastEvent(RealisticGuiToggleNetworkUseEvent:new(RealisticGui.GUI_NETWORKUSE_ISACTIVE), nil, nil);
	end

end
BaseMissionReadyEvent.run = Utils.appendedFunction(BaseMissionReadyEvent.run, RealisticGui.syncMpData);


--------------------------------------------------------------------------------------------------------
-- add a note in the log file to indicate when the network use has been changed
--------------------------------------------------------------------------------------------------------
function RealisticGui:printNetworkUseState()
	local stateStr = "OFF"
	if RealisticGui.GUI_NETWORKUSE_ISACTIVE then
		stateStr = "ON"
	end
	if g_currentMission.time~=nil and g_currentMission.time>0 then
		--during the game
		print("Info : " .. tostring(g_currentMission.time) .. " - RealisticGui - Network use is now " .. stateStr)
	else
		--joining time
		print("Info : joining server - RealisticGui - Network use is " .. stateStr)
	end
end



--------------------------------------------------------------------------------------------------------
-- "hijack" the FSCareerMissionInfo.saveToXML function to trigger our saving process
-- make use of the "xpcall" to catch any error and do not interrupt original game saving process 
--(CRITICAL not to lose any savegame file)
--------------------------------------------------------------------------------------------------------
function RealisticGui.saveToXML(missionInfo)	
	local status, errorMsg = xpcall(RealisticGui.saveDataToXml, RealisticGui.errorHandler);
	if not status then
		RealisticUtils.printWarning("RealisticGui.saveToXML", tostring(errorMsg), true) --tostring(errorMsg) in case something is also wrong here - errorMsg should be a string if status == false
	end
end
FSCareerMissionInfo.saveToXML = Utils.appendedFunction(FSCareerMissionInfo.saveToXML, RealisticGui.saveToXML);



--------------------------------------------------------------------------------------------------------
-- basic error handling function that returns original error and stacktrace as a string
--------------------------------------------------------------------------------------------------------
function RealisticGui.errorHandler(originalError)
	return tostring(originalError) .. "\n" .. debug.traceback()
end


--------------------------------------------------------------------------------------------------------
-- load all the saved data and fill the RealisticGui.LOADED_DATA table
-- called by the globalListener of MR
--------------------------------------------------------------------------------------------------------
function RealisticGui.loadDataFromXml()
	
	--do not load data for a server only (no use)	
	if g_client==nil then
		return
	end
	
	--do not load data if "vehicleReset" is true
	if g_currentMission.missionInfo.resetVehicles then
		return
	end	
	
	local filePath = RealisticGui.getXmlPath();
	if filePath~=nil and fileExists(filePath) then
		local xmlFile = loadXMLFile("realisticGuiSaveXml", filePath);
		if xmlFile~=nil and xmlFile~=0 then
			--parse the file
			local i = 0;
			while true do
				local vehicleXmlPath = string.format("moreRealisticGui.vehicles.vehicle(%d)", i);
				if not hasXMLProperty(xmlFile, vehicleXmlPath) then break; end;				
				local vehicleId = getXMLInt(xmlFile, vehicleXmlPath .. "#id");
				if vehicleId~=nil then
					local vehicle = {}
					vehicle.hud1_x = getXMLFloat(xmlFile, vehicleXmlPath .. "#hud1_x");
					vehicle.hud1_y = getXMLFloat(xmlFile, vehicleXmlPath .. "#hud1_y");
					RealisticGui.LOADED_DATA[vehicleId] = vehicle					
				end
				i = i + 1;
			end
			delete(xmlFile);
		end;
	end;	

end


--------------------------------------------------------------------------------------------------------
-- create xml save file and write mrGui data to it (physically)
--------------------------------------------------------------------------------------------------------
function RealisticGui.saveDataToXml()

	--do not save data for a server only (dedicated server)
	--all data are client side by the moment
	if g_client==nil then
		return
	end

	if g_currentMission~=nil and g_currentMission.vehicles~=nil then
		local filePath = RealisticGui.getXmlPath();
		if filePath~=nil then
			local xmlFile = createXMLFile("realisticGuiSaveXml", filePath, "moreRealisticGui");	--erase existing file if present	
			if xmlFile~=nil and xmlFile~=0 then				
				RealisticGui.writeDataToXmlFile(xmlFile, g_currentMission.vehicles);
				saveXMLFile(xmlFile);
				delete(xmlFile);
			end;			
		end; -- filepath nil
	end;
end;

--------------------------------------------------------------------------------------------------------
-- write mrGui data to xml save file (in memory)
--------------------------------------------------------------------------------------------------------
function RealisticGui.writeDataToXmlFile(xmlFileId, vehicles)

	local xmlKeyPath = "moreRealisticGui.vehicles.vehicle(%d)"
	local pos = 0;
	for id,vehicle in pairs(vehicles) do
		if vehicle.mrIsMrVehicle and vehicle.hud1~=nil then
			if vehicle.hud1.baseX~=nil and vehicle.hud1.baseY~=nil then			
				--check if data have been changed since loading time
				if vehicle.hud1.baseX~=vehicle.hud1.defaultPosX or vehicle.hud1.baseY~=vehicle.hud1.defaultPosY then			
					local xmlKey = string.format(xmlKeyPath, pos)
					setXMLInt(xmlFileId, xmlKey .. "#id", id);
					setXMLFloat(xmlFileId, xmlKey .. "#hud1_x", vehicle.hud1.baseX);
					setXMLFloat(xmlFileId, xmlKey .. "#hud1_y", vehicle.hud1.baseY);
					pos = pos + 1
				end;
			end;
		end;
	end;
	
end;

--------------------------------------------------------------------------------------------------------
-- return full xml path to xml save file
--------------------------------------------------------------------------------------------------------
function RealisticGui.getXmlPath()
	if g_currentMission~=nil then
		if g_currentMission.missionInfo~=nil then
			return g_currentMission.missionInfo.savegameDirectory .. "/" .. RealisticGui.SAVE_FILENAME;
		end;
	end;
	return nil;
end