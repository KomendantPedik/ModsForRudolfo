﻿--------------------------------------------------------------------------------
-- Little help to better understand MP code
--------------------------------------------------------------------------------
-- Running order of events
--
-- 1. When the action comes from the client :
--     * client side = sendEvent(local function), new, emptyNew, sendEvent(global function), writeStream
--     * server side = emptyNew, readStream, run, broadcastEvent
--     * other clients = emptyNew, readStream, run
-- 2. When the action comes from the server :
--     * server side = sendEvent(local function), new, emptyNew, broadcastEvent, writeStream
--     * client side (all clients) = emptyNew, readStream, run
--
-- to first synchronize data between server and client at join time, we have to use the functions "readStream" and "writeStream" from one specialization
-- if we are talking of general settings, this is better to "hijack" one of the vanilla game global settings synchronistion events
--   SavegameSettingsEvent
--   MissionDynamicInfoEvent
--   BaseMissionFinishedLoadingEvent
--   BaseMissionReadyEvent
--
-- See "RealisticGui:syncMpData" as an example
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- RealisticGuiToggleNetworkUseEvent :
-- client (master) = tell the server it wants to toggle the GUI network use state (ON/OFF)
-- server = tell all clients the new state
--------------------------------------------------------------------------------
RealisticGuiToggleNetworkUseEvent = {}
RealisticGuiToggleNetworkUseEvent_mt = Class(RealisticGuiToggleNetworkUseEvent, Event)
InitEventClass(RealisticGuiToggleNetworkUseEvent, "RealisticGuiToggleNetworkUseEvent")

function RealisticGuiToggleNetworkUseEvent:emptyNew()	
    local self = Event:new(RealisticGuiToggleNetworkUseEvent_mt);
    return self;
end;

function RealisticGuiToggleNetworkUseEvent:new(guiWantedNetworkUseState)	
    local self = RealisticGuiToggleNetworkUseEvent:emptyNew()  
	self.guiWantedNetworkUseState = guiWantedNetworkUseState
    return self;
end;

------------------------------------------------------------------------------
-- called on client side after a broadcastEvent from the server or called on server side after a sendEvent from the client
-- get the wanted gui network use state from the sender
------------------------------------------------------------------------------
function RealisticGuiToggleNetworkUseEvent:readStream(streamId, connection)    
	self.guiWantedNetworkUseState = streamReadBool(streamId);	
	self:run(connection);
end;

------------------------------------------------------------------------------
-- called on server side after a broadcastEvent (once per connection with client) or called on client after a sendEvent
-- send the wanted GUI network use state to the client/server define by the "connection"
------------------------------------------------------------------------------
function RealisticGuiToggleNetworkUseEvent:writeStream(streamId, connection)	
    streamWriteBool(streamId, self.guiWantedNetworkUseState);
end;

------------------------------------------------------------------------------
-- Run action on receiving side
-- server side = set the new state and send it to all clients
-- client side = update state according to what server sent
------------------------------------------------------------------------------
function RealisticGuiToggleNetworkUseEvent:run(connection)	
	RealisticGui.GUI_NETWORKUSE_ISACTIVE = self.guiWantedNetworkUseState;
	RealisticGui:printNetworkUseState();
    if not connection:getIsServer() then
		--this is serverSide
        g_server:broadcastEvent(self, false, connection, nil);
    end;
end;


------------------------------------------------------------------------------
-- if called on serverside, broadcast event from server to all clients
-- if called on clientside, send event to server (which would broadcast it to all clients in the 'run' function)
------------------------------------------------------------------------------
function RealisticGuiToggleNetworkUseEvent.sendEvent(guiNetworkUseWantedState, noEventSend)	
    if noEventSend == nil or noEventSend == false then
        if g_server ~= nil then		
            g_server:broadcastEvent(RealisticGuiToggleNetworkUseEvent:new(guiNetworkUseWantedState), nil, nil); -- server side
        else
            g_client:getServerConnection():sendEvent(RealisticGuiToggleNetworkUseEvent:new(guiNetworkUseWantedState)); -- client side
        end;
    end;
end;