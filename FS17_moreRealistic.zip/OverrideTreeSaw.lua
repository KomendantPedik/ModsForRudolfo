﻿--************************************************************************************************************************************************************
--add working power to get different power consumption when actually "splitting" tree stumps
TreeSaw.mrLoad = function(self)	

	if not self.mrIsMrVehicle then
		return
	end	

	self.treeSaw.workingPowerMin = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.TreeSaw#cuttingPtoPowerMin"), 0) -- KW
	self.treeSaw.workingPowerMax = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.TreeSaw#cuttingPtoPowerMax"), 0) -- KW
	self.treeSaw.cuttingCentimetersPerSecond = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.TreeSaw#cuttingCentimetersPerSecond"), 10)	
	self.treeSaw.minCuttingTime = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.TreeSaw#minCuttingTime"), 300) -- ms
	self.getConsumedPtoTorque = TreeSaw.mrGetConsumedPtoTorque
	
	assert(self.treeSaw.cuttingCentimetersPerSecond>0.1)
			
end
TreeSaw.load = Utils.appendedFunction(TreeSaw.load, TreeSaw.mrLoad)





--************************************************************************************************************************************************************
--pto torque depends on the working state ("splitting" or not "splitting")
TreeSaw.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower
			if self.treeSaw.isCutting then
				totalPower = totalPower + self.treeSaw.workingPowerMin + (self.treeSaw.workingPowerMax-self.treeSaw.workingPowerMin) * math.random()
			end			
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end


--************************************************************************************************************************************************************
--varying cut time function of tree size
TreeSaw.mrUpdateTick = function(self, superFunc,  dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt)
	end

    if self:getIsActive() then
        if self:getIsTurnedOn() then
            if self.treeSaw.cutNode ~= nil then
                local x,y,z = getWorldTranslation(self.treeSaw.cutNode)
                local nx,ny,nz = localDirectionToWorld(self.treeSaw.cutNode, 1,0,0)
                local yx,yy,yz = localDirectionToWorld(self.treeSaw.cutNode, 0,1,0)
                if self.treeSaw.curSplitShape == nil then
				
					--local shape, _, _, _, _ = findSplitShape(x,y,z, nx,ny,nz, yx,yy,yz, self.treeSaw.cutSizeY, self.treeSaw.cutSizeZ)
					local shape, minY, maxY, minZ, maxZ = findSplitShape(x,y,z, nx,ny,nz, yx,yy,yz, self.treeSaw.cutSizeY, self.treeSaw.cutSizeZ)
                    if shape ~= 0 then
                        self.treeSaw.curSplitShape = shape
						--MR
						local maxSize = math.max(maxY-minY, maxZ-minZ)
						--print(g_currentMission.time .. " - tree max size = " .. tostring(maxSize))
						
                        --self.treeSaw.cutTimer = self.treeSaw.cutTimerDuration						
						self.treeSaw.cutTimer = math.max(self.treeSaw.minCuttingTime, 1000*maxSize*100 / self.treeSaw.cuttingCentimetersPerSecond) --1000 = second to millisecond /// 100 = meters to centimeters
						
						--print(g_currentMission.time .. " - cutTimer = " .. tostring(self.treeSaw.cutTimer))
                    end
                end
                if self.treeSaw.curSplitShape ~= nil then
                    local minY,maxY, minZ,maxZ = testSplitShape(self.treeSaw.curSplitShape, x,y,z, nx,ny,nz, yx,yy,yz, self.treeSaw.cutSizeY, self.treeSaw.cutSizeZ)
                    if minY == nil then
                        self.treeSaw.curSplitShape = nil
                    else
                        -- check if cut would be below y=0 (tree CoSy)
                        local cutTooLow = false
                        local _,y,_ = localToLocal(self.treeSaw.cutNode, self.treeSaw.curSplitShape, 0,minY,minZ)
                        cutTooLow = cutTooLow or y < 0.01
                        local _,y,_ = localToLocal(self.treeSaw.cutNode, self.treeSaw.curSplitShape, 0,minY,maxZ)
                        cutTooLow = cutTooLow or y < 0.01
                        local _,y,_ = localToLocal(self.treeSaw.cutNode, self.treeSaw.curSplitShape, 0,maxY,minZ)
                        cutTooLow = cutTooLow or y < 0.01
                        local _,y,_ = localToLocal(self.treeSaw.cutNode, self.treeSaw.curSplitShape, 0,maxY,maxZ)
                        cutTooLow = cutTooLow or y < 0.01
                        if cutTooLow then
                            self.treeSaw.curSplitShape = nil
                        end
                    end
                end
                if self.treeSaw.curSplitShape ~= nil then
                    local lenBelow, lenAbove = getSplitShapePlaneExtents(self.treeSaw.curSplitShape, x,y,z, nx,ny,nz)
                    if lenAbove < self.treeSaw.lengthAboveThreshold or lenBelow < self.treeSaw.lengthBelowThreshold then
                        self.treeSaw.curSplitShape = nil
                    end
                end
                if self.treeSaw.curSplitShape == nil and self.treeSaw.cutTimer > -1 then
                    self.treeSaw.cutTimer = -1
                end
            end
        end
    end
end
TreeSaw.updateTick = Utils.overwrittenFunction(TreeSaw.updateTick, TreeSaw.mrUpdateTick)









