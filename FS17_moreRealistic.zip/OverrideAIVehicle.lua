﻿
--************************************************************************************************************************************************************
--MR : allow some "room" for the ai to turn in the headland
--MR vehicles can slip laterally when turning (oversteer) especially if turning quickly with a heavy implement mounted on the rear
AIVehicle.mrPostLoad = function(self, savegame)
	--20170430 check if this is a "mr" vehicle
	if not self.mrIsMrVehicle then return end

	--20170430 - check maxTurningRadius is not nil
	if self.maxTurningRadius then
		self.maxTurningRadius = 1 + self.maxTurningRadius
	end
end		
AIVehicle.postLoad = Utils.appendedFunction(AIVehicle.postLoad, AIVehicle.mrPostLoad);


--************************************************************************************************************************************************************
--MR : update the self.mrAiIsTurning parameter so that we know the ai is maneuvring in the headland
AIVehicle.mrUpdate = function(self, dt)

	--20170430 check if this is a "mr" vehicle
	if not self.mrIsMrVehicle then return end

	if self.isServer and self.aiIsStarted then			
		self.mrAiIsTurning = false
		if self.driveStrategies ~= nil and #self.driveStrategies > 0 then
			for i=1,#self.driveStrategies do
				local driveStrategy = self.driveStrategies[i]
				if driveStrategy.turnStrategies~=nil and #driveStrategy.turnStrategies>0 then
					for j=1,#driveStrategy.turnStrategies do
					--	RealisticUtils.testClass("driveStrategies=" .. tostring(i) .. " -turnStrategies=" .. tostring(j), driveStrategy.turnStrategies[j])
						if driveStrategy.turnStrategies[j].isTurning then
							self.mrAiIsTurning = true
							return
						end	
					end									
				end
			end
		end		
	end
	
end
AIVehicle.update = Utils.appendedFunction(AIVehicle.update, AIVehicle.mrUpdate)