﻿--************************************************************************************************************************************************************
--we don't want the dirtamount curve being "linear". IRL, it is quite "fast" to get some dirt, but it takes time to be fully dirty.
--we don't want rain to wash vehicle as fast as a karcher
Washable.mrUpdateTick = function(self, superFunc, dt)

	if not self.mrIsMrVehicle then
		return superFunc(self, dt);
	end

    if self.washableNodes ~= nil then
        if self.isServer then
            if g_currentMission.environment.lastRainScale > 0.1 and g_currentMission.environment.timeSinceLastRain < 30 then
                local amount = self:getDirtAmount();
                if amount > 0.5 then
                    --amount = self:getDirtAmount() - (dt/self.washDuration);
					amount = self:getDirtAmount() - (g_currentMission.environment.lastRainScale*dt/900000);--15 min = 15 * 60 * 1000 ms
                end
                self:setDirtAmount(amount);
            else
                if self:getIsActive() or self.isActive then
                    --self:setDirtAmount(self:getDirtAmount() + (dt * self.dirtDuration)*self:getDirtMultiplier()*Washable.getIntervalMultiplier());
					local currentDirtAmount = self:getDirtAmount()
					local factor = 1-(0.9*currentDirtAmount)^0.5
					self:setDirtAmount(currentDirtAmount + factor * (dt * self.dirtDuration)*self:getDirtMultiplier()*Washable.getIntervalMultiplier());					
                end
            end
        end
    end
end
Washable.updateTick = Utils.overwrittenFunction(Washable.updateTick, Washable.mrUpdateTick)