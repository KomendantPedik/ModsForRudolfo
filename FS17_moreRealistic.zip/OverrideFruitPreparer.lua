﻿--************************************************************************************************************************************************************	
--MR : load turnedOnPtoPower and areaDependantPtoPower
FruitPreparer.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then
		return;
	end
	
	self.mrIsFruitPreparer = true;
	
	self.mrFruitPreparerTurnedOnPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.fruitPreparer#turnedOnPtoPower"), 0);
	self.mrFruitPreparerAreaDependantPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.fruitPreparer#areaDependantPtoPower"), 0);
	self.mrFruitPreparerValid = false
	if self.mrFruitPreparerTurnedOnPtoPower>0 or self.mrFruitPreparerAreaDependantPtoPower>0 then
		self.mrFruitPreparerValid = true
	
		self.mrFruitPreparerLastAreaChanged = 0;
		self.mrFruitPreparerAvgAreaChanged = 0;
		self.mrFruitPreparerAreaChangedCounterTime = 0;
		self.mrFruitPreparerAreaChangedCounter = 0;		
		self.mrFruitPreparerAreaChangedCounterRefreshTime = 1000;
		self.mrFruitPreparerLastTotalPower = 0;
		self.processFruitPreparerAreas = FruitPreparer.mrProcessFruitPreparerAreas;
		
		if not SpecializationUtil.hasSpecialization(Combine, self.specializations) then
			--let the combine class manage the "consumedPtoTorque"			
			self.getConsumedPtoTorque = FruitPreparer.mrGetConsumedPtoTorque;		
		end
	end
	
end
FruitPreparer.load = Utils.appendedFunction(FruitPreparer.load, FruitPreparer.mrLoad);


--************************************************************************************************************************************************************
--MR : update avgArea worked per unit of time (per second)
 FruitPreparer.mrUpdateTick = function (self, dt)
 
	if not self.mrIsMrVehicle then
		return;
	end
 
	if 0<self.mrFruitPreparerAreaDependantPtoPower and self.getIsTurnedOn ~= nil then
		if self:getIsTurnedOn() then
			self.mrFruitPreparerAreaChangedCounter = self.mrFruitPreparerAreaChangedCounter + self.mrFruitPreparerLastAreaChanged;
			self.mrFruitPreparerAreaChangedCounterTime = self.mrFruitPreparerAreaChangedCounterTime + dt;
			if self.mrFruitPreparerAreaChangedCounterTime>self.mrFruitPreparerAreaChangedCounterRefreshTime then
				self.mrFruitPreparerAvgAreaChanged = 1000 * self.mrFruitPreparerAreaChangedCounter / self.mrFruitPreparerAreaChangedCounterTime; -- area per second
				self.mrFruitPreparerAreaChangedCounterTime = 0;
				self.mrFruitPreparerAreaChangedCounter = 0;		
			end
		else
			--reset params -- 20170905
			self.mrFruitPreparerLastTotalPower = 0
			self.mrFruitPreparerAvgAreaChanged = 0
			self.mrFruitPreparerAreaChangedCounterTime = 0
			self.mrFruitPreparerAreaChangedCounter = 0
		end
		--20170905 -- reset self.mrFruitPreparerLastAreaChanged -- indeed, when lifting the "fruitPreparer" tool at the headland, the "mrProcessFruitPreparerAreas" is not called anymore, 
		--and then, the mrFruitPreparerLastAreaChanged keeps the last value (greater than 0), which means the mrFruitPreparerAreaChangedCounter keeps increasing
		--problem not visible when we raise the tool after a few seconds (not just when the fruit are not present anymore)
		self.mrFruitPreparerLastAreaChanged = 0
	end
 
 end
 FruitPreparer.updateTick = Utils.appendedFunction(FruitPreparer.updateTick, FruitPreparer.mrUpdateTick);

--************************************************************************************************************************************************************
--MR : add AreaDependantPtoPower to TurnedOnPtoPower
--20170623 - this function can be called by "Combine.mrGetConsumedPtoTorque". And so, we have to check 
FruitPreparer.mrGetConsumedPtoTorque = function(self)
	local totalPower = 0;
	if self.mrFruitPreparerValid and self.getIsTurnedOn ~= nil and self:getIsTurnedOn() then --20170623 - check if "mrFruitPreparerValid" in case this function is called by the "combine" and the "vehicle.moreRealistic.fruitPreparer" settings are not set
		totalPower = self.mrFruitPreparerTurnedOnPtoPower;
		
		--compute area dependant power
		--if self.mrFruitPreparerLastAreaChanged==0 then
		--	self.mrFruitPreparerAvgAreaChanged = 0.995*self.mrFruitPreparerAvgAreaChanged;
		--else
		--	self.mrFruitPreparerAvgAreaChanged = 0.95 * self.mrFruitPreparerAvgAreaChanged + 0.05 * self.mrFruitPreparerLastAreaChanged;
		--end
		
		--print("test fruitprepare - avgAreaChanged = "..tostring(self.mrFruitPreparerAvgAreaChanged) .. " - lastArea = " .. tostring(self.mrFruitPreparerLastAreaChanged));
		
		totalPower = totalPower + self.mrFruitPreparerAreaDependantPtoPower * self.mrFruitPreparerAvgAreaChanged;
		if totalPower<self.mrFruitPreparerLastTotalPower then
			totalPower = math.max(totalPower, 0.999*self.mrFruitPreparerLastTotalPower)
		else
			totalPower = 0.99*self.mrFruitPreparerLastTotalPower + 0.01*totalPower
		end
		
		
		
		self.mrFruitPreparerLastTotalPower = totalPower;
		
		--print("test fruitpreparer : totalpower = "..tostring(totalPower) .. " - ptoRpm = "..tostring(self:getPtoRpm()));
		
		--2017-04-28 protection against getPtoRpm return 0 value
		local rpm = self:getPtoRpm();
		if rpm > 0.001 then		
			--print("test FruitPreparer.mrGetConsumedPtoTorque - torque = " .. tostring(totalPower * 9.5493 / rpm))
			return totalPower * 9.5493 / rpm;		--540*math.pi/30 = 56.5487
		end
	end
	return 0;	
end

--************************************************************************************************************************************************************
--MR : get the total processed area
FruitPreparer.mrProcessFruitPreparerAreas = function(self, workAreas, numWorkAreas, fruitType)
    local numAreasUsed = 0
	self.mrFruitPreparerLastAreaChanged = 0;
    for i=1, numWorkAreas do
        local x = workAreas[i].x
        local z = workAreas[i].z
        local x1 = workAreas[i].x1
        local z1 = workAreas[i].z1
        local x2 = workAreas[i].x2
        local z2 = workAreas[i].z2
        local areaChanged = 0
        if workAreas[i].hasSeparateDropArea then
            local dx = workAreas[i].dx
            local dz = workAreas[i].dz
            local dx1 = workAreas[i].dx1
            local dz1 = workAreas[i].dz1
            local dx2 = workAreas[i].dx2
            local dz2 = workAreas[i].dz2
            areaChanged = Utils.updateFruitPreparerArea(fruitType, x, z, x1, z1, x2, z2, dx, dz, dx1, dz1, dx2, dz2)
        else
            areaChanged = Utils.updateFruitPreparerArea(fruitType, x, z, x1, z1, x2, z2, x, z, x1, z1, x2, z2)
        end
        if areaChanged > 0 then
            numAreasUsed = numAreasUsed + 1
			--mr
			self.mrFruitPreparerLastAreaChanged = self.mrFruitPreparerLastAreaChanged + areaChanged;
        end
    end
    return numAreasUsed
end