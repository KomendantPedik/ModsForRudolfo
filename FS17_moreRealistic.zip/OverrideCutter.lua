﻿--************************************************************************************************************************************************************
--fix a "bug" : getIsTurnedOn is not defined for a "cutter" and so, the PowerConsumer.getMaxPtoRpm() return 0 for a combine, even if there is a ptoRpm define for the running cutter
Cutter.mrLoad = function(self)	
	if self.mrIsMrVehicle then
		self.getIsTurnedOn = Utils.overwrittenFunction(self.getIsTurnedOn, Cutter.getDoConsumePtoPower);		
	end;	
end;
Cutter.load = Utils.appendedFunction(Cutter.load, Cutter.mrLoad)