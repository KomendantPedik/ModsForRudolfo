﻿--***********************************************************************************************************************************
--** 20170913 - new "deterministic" script for groundWetness (so that we get the same wteness after saving and reloading our game)
--** with MR, the wetness is not the "moisture" of the soil => this is the wetness of the part of the ground we are rolling on (something like the first 15cm)
--** so, when the rain start, this is quite quick to get some wetness on the first centimeters of depth (surface wetness)
--** then, to get more depth wetness, it takes time, and to get total wetness, it takes a lot of time (and rain)
Environment.mrCalculateGroundWetness = function(env)

	local rain = env.currentRain

	--current rain running ?
	if rain==nil then
		rain = env.lastRain
	end	
	
	if rain~=nil then	
		--first, we need to know what is the current rain "intensity"
		if rain.mrIntensity==nil then
			rain.mrIntensity = Environment.mrGetRainIntensity(rain)
		end
		
		--protection in case other mods set a 0 intensity
		if rain.mrIntensity==0 then
			return 0
		end
		
		--second = for how long the rain has been running ?
		local duration = Environment.mrGetRainRunningDuration(env, rain) --seconds
		
		if duration>0 then		
			return Environment.mrGetWetnessFromRain(duration, rain.mrIntensity, rain.duration/1000, env.rainFadeDuration/1000, env.rainFadeDuration/1000, env.lastRainScale) --remove end fading of the rain
		end
		
	end -- no valid rain found (currentRain==nil and lastRain==nil)
		
	return 0

end

--------------------------------------------------------------------------------------------
--return a wetness factor for the current rain and current time the rain has been running
--------------------------------------------------------------------------------------------
--first "wetness stage"
--------------------------
--during rainFadeDuration, the wetness = 10% of lastRainScale (0 to 10%)
--------------------------
--second "wetness stage"
--------------------------
--heavy "hail" = in 8 minutes, the top layer is soaked (3-5cm depth) > water flows on the ground
--less intensity = more than 8 minutes (more time, but same final wetness)
--this top layer represents 30% of the wetness factor for wheels
--------------------------
--third "wetness stage"
--------------------------
--it takes time for water to penetrate the ground
--intensity slightly change the penetration rate (time to penetrate), but will change the amount of rain fallen = how deep the rain will penetrate the ground (max wetness)
Environment.mrGetWetnessFromRain = function(wantedTime, rainIntensity, rainEndTime, rainStartingFadeDuration, rainEndingFadeDuration, lastRainScale)
	
	local wetness = 0
		
	--first, get the wetness up to the rain end time
	local timeDuringRain = math.min(rainEndTime-rainEndingFadeDuration, wantedTime)
	local timeAfterRain = math.max(0, wantedTime-rainEndTime)	
	
	--Stage 1 = from 0 time to rainFadeDuration time => wetness = rainscale*0.1
	if timeDuringRain<=rainStartingFadeDuration then
		wetness = 0.1 * lastRainScale
	else
		--stage2 duration
		local secondStageDuration = 20*60 / rainIntensity --seconds	
		--stage1 + stage2
		if timeDuringRain<=(secondStageDuration+rainStartingFadeDuration) then
			wetness = 0.1 + 0.2 * (timeDuringRain-rainStartingFadeDuration)/secondStageDuration --proportionnal		
		else		
			--stage1 + stage2 + stage3
			local maxWetness = math.min(1, 0.3 + 0.35*rainIntensity)
			local pFactor = 0.004 + 0.001 * rainIntensity
			local timeS3 = timeDuringRain-rainStartingFadeDuration-secondStageDuration
			--we want 0.3 when timeS3=0
			wetness = math.min(maxWetness, pFactor*((0.3/pFactor)^2 + timeS3)^0.5) --maxintensity (2.5) => 5.8% wetness increase in 15min, 19% in 1hour, 44% in 3 hours, 62% in 5 hours	
		end
	end
	
	--then, if the wantedTime is greater than the rainEndTime, decrease the wetness
	if timeAfterRain>0 then
		local iFactor = 0.0025 + 0.001*rainIntensity
		wetness = math.max(0, wetness-iFactor*timeAfterRain^0.5) -- 30% less after 1hour, 42% after 2 hours, 52% after 3 hours, 60% after 4 hours, 67% after 5 hours, 73% after 6 hours, 79% after 7 hours, 85% after 8 hours, 90% after 9 hours, 95% after 10 hours, 99% after 11 hours
	end
	
	--print("test mrGetWetnessFromRain - wantedTime="..tostring(wantedTime) .." - rainIntensity=" .. tostring(rainIntensity) .. " - rainEndTime="..tostring(rainEndTime) .. " - wetness="..tostring(wetness))
	
	return wetness
	
end


------------------------------------------------------------------
-- return a deterministic rain intensity factor for the given rain
------------------------------------------------------------------
Environment.mrGetRainIntensity = function(rain)

	local intensity = 0

	--scale with the type of rain
	if rain.rainTypeId==Environment.RAINTYPE_HAIL then
		intensity = 2
	elseif rain.rainTypeId==Environment.RAINTYPE_RAIN then
		intensity = 1
	else
		return 0 -- "rain" event with no water or not supported (cloudy, fog, ...)
	end
	
	--add a semi-random factor by using a deterministic randomseed
	local seed = rain.startDay + rain.endDayTime + rain.duration
	math.randomseed(seed)
	
	intensity = intensity * (1.25-0.5*math.random()) -- between 75% and 125% intensity => smallest rain = 0.75 ////  biggest rain = 1.25, //// smallest hail = 1.5 //// biggest hail = 2.5

	--print("test intensity - seed="..tostring(seed) .. " - result="..tostring(intensity))
	
	return intensity

end

------------------------------------------------------------------
-- return for how long the rain has been running (seconds)
------------------------------------------------------------------
Environment.mrGetRainRunningDuration = function(env, rain)

	local duration = 24*3600*(env.currentDay-rain.startDay)
	duration = duration + (env.dayTime - rain.startDayTime)/1000
	
	--print("rain current running time = ".. tostring(duration) .." seconds - startday="..tostring(rain.startDay))
	
	return duration

end


--[[

--*****************************************************************************************
--** base game wetness system is far too fast when playing with "MR" since wetness has a great influence on rolling resistance
--** new system = rain type is taken into account (more intensity for HAIL than RAIN type)
--** then, there is also a random factor when each "rain" starts => factor between 0.4 and 1.6
--** so, when talking of a "RAINTYPE_RAIN", it can take between 40min and 1h45 to reach a 50% ground wetness
--** basically, most of the time, the player would not experience a 100% ground wetness with a normal rain (max wetness being limited by the rain intensity)
--** and when the rain event is a "RAINTYPE_HAIL", it can take between 23min to 1h to get 50% wetness
--** finally, the wetness decreasing rate is also "improved".
--** when close to 1 (100%), the wetness will lost about 0.2 points per game hour and drop to 0.02 point per hour when close to 0


--assign in RealisticGlobalListener
Environment.mrCalculateGroundWetness = function(env)

	local intensity = 0
	local updateDt = 0
	local wetness = env.groundWetness
	if env.lastRainScale>0 then
	
		intensity = env.lastRainScale
	
		--check currentRain
		if env.currentRain~=nil then	
			if env.currentRain.mrIntensityRndFx==nil then				
				env.currentRain.mrIntensityRndFx = 0.6 + math.random() --between 0.6 and 1.6 random factor for intensity
				--print(tostring(g_currentMission.time) .. " - setting random factor for current rain - fx = " .. tostring(env.currentRain.mrIntensityRndFx))				
			end	
			if env.currentRain.rainTypeId==Environment.RAINTYPE_HAIL then
				intensity = 2 * intensity
			end			
			intensity = intensity * env.currentRain.mrIntensityRndFx 
		end
	
	end		
	
	local currentGlobalTime = Environment.mrGetGlobalGameTime(env)
	if Environment.mrLastWetnessUpdateGlobalGameTime~=nil then
		updateDt = currentGlobalTime - Environment.mrLastWetnessUpdateGlobalGameTime
	end
	Environment.mrLastWetnessUpdateGlobalGameTime = currentGlobalTime	
	
	--update wetness		
	if intensity>0 then
		if wetness<1 then
			
			local maxWetness = math.min(1, 0.5+0.3*intensity)
		
			--wetness = math.min(1, wetness + 0.1*intensity*(1.8-1.6*wetness)*updateDt/3600000) --updateDt = millisecond, it is easier to "wet" the ground when it is dry than when it is already wet => take into account the current wetness
			wetness = math.min(maxWetness, wetness + intensity*(1-0.98*wetness^0.5)*updateDt/3600000)
			
			--biggest HAIL => 23min to get 50% wetness (1H10 to get 90% wetness)
			--smallest HAIL => 1H to get 50% wetness (max wetness 86%)
			--biggest RAIN => 40min to get 50% wetness (2H30 to get 90%)
			--smallest RAIN => 1H45 to get 50% wetness (max wetness = 68%)
			
		end
	elseif wetness>0 then
		--decrease wetness at a rate of 0.2 per hour when wetness is at 100% and down to 0.02 per hour when wetness get close to 0%
		wetness = math.max(0, wetness - (0.02+0.18*wetness)*updateDt/3600000)
	end
	
	return wetness	
	
end

Environment.mrGetGlobalGameTime = function(env)

	local globalGameTime = 0 --ms
	globalGameTime = env.currentDay*86400000 + env.dayTime--24*3600*1000 -- day to ms
	
	return globalGameTime

end

--]]