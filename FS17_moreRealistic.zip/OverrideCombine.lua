﻿--************************************************************************************************************************************************************	
--MR : add "self.getConsumedPtoTorque" and "self.getPtoRpm" so that the "PowerConsumer.getTotalConsumedPtoTorque" could return a value when the combine is turned on
Combine.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then
		return;
	end
	
	self.mrCombineTurnedOnPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.combine#turnedOnPtoPower"), 0);
	self.mrCombineAreaDependantPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.combine#areaDependantPtoPower"), 0);
	self.mrCombineSpeedDependantPtoPowerWhenFilling = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.combine#speedDependantPtoPowerWhenFilling"), 0);	
	self.mrCombineChopperPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.combine#chopperPtoPower"), 0);
	self.mrCombineUnloadingAugerPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.combine#unloadingAugerPtoPower"), 0);
	self.mrCombineStrawFactor = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.combine#strawFactor"), 1);
	local basePerf = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.combine#basePerf"), 99999); -- base perf Ha per Hour x100 in heavy yield wheat | good starting value = about 150 units per 100HP for a lzrge combine harvester, closer to 100 units per 100HP for a smaller one,  then adjust by trying ingame
	
	if self.mrCombineTurnedOnPtoPower>0 or self.mrCombineAreaDependantPtoPower>0 or self.mrCombineSpeedDependantPtoPowerWhenFilling>0 then
		self.getConsumedPtoTorque = Combine.mrGetConsumedPtoTorque;
		self.getPtoRpm = Combine.mrGetPtoRpm;
	end
	
	--self.mrAvgCombineCuttersArea = 0;
	
	
	self.mrCombineLimiter = {};
	self.mrCombineLimiter.totaldistance = 0;
	self.mrCombineLimiter.totalArea = 0;
	self.mrCombineLimiter.avgTime = 1500; --1.5s
	self.mrCombineLimiter.distanceForMeasuring = 3; -- 3 meters
	self.mrCombineLimiter.currentTime = 0;
	self.mrCombineLimiter.basePerfAvgArea = basePerf / 36; -- m2 per second (fully fertilized)
	self.mrCombineLimiter.currentAvgArea = 0;
	
	self.mrCombineLastTotalPower = 0;
	
	self.doCheckSpeedLimit = Utils.overwrittenFunction(self.doCheckSpeedLimit, Combine.mrDoCheckSpeedLimit);
	self.mrIsCombineSpeedLimitActive = false;
	
end
Combine.load = Utils.appendedFunction(Combine.load, Combine.mrLoad);

--************************************************************************************************************************************************************
--MR : dummy getPtoRpm function
Combine.mrGetPtoRpm = function(self)
	if (self.getIsTurnedOn ~= nil and self:getIsTurnedOn()) or (self.overloading~=nil and self.overloading.didOverload) then
		if self.powerConsumer and self.powerConsumer.ptoRpm then
			return math.max(540, self.powerConsumer.ptoRpm)
		else
			return 540
		end
	end
	return 0
end

--************************************************************************************************************************************************************
--MR : add mrCombineAreaDependantPtoPower and mrCombineChopperPtoPower to mrCombineTurnedOnPtoPower
Combine.mrGetConsumedPtoTorque = function(self)
	local totalPower = 0;
	if self.getIsTurnedOn ~= nil and self:getIsTurnedOn() then
		totalPower = self.mrCombineTurnedOnPtoPower;
		local totalAreaDependantPtoPower = self.mrCombineAreaDependantPtoPower;


		--speed dependant power (only when "filling" - mostly used by "ground" harvester = potato or sugarbeet because even if we harvest only 50% of the "cutter width", the required power remains the same - not dependant on the harvested "fruit" qty, rather dependant on the "earth" material on the various "belt" = in the cleaning system)
		if self.combineIsFilling or self.combineFillEnableTime~=nil then
			totalPower = totalPower + self.mrCombineSpeedDependantPtoPowerWhenFilling * self.lastSpeedReal*1000;
		end
			
		
		--get the mrAreaDependantPtoPower of the cutters too
		for object,_ in pairs(self.attachedCutters) do
			if object.mrAreaDependantPtoPower then
				totalAreaDependantPtoPower = totalAreaDependantPtoPower + object.mrAreaDependantPtoPower;
			end
		end
		
		if totalAreaDependantPtoPower>0 and self.mrCombineLimiter.currentAvgArea>0 then
			--totalPower = totalPower + totalAreaDependantPtoPower * self.mrAvgCombineCuttersArea^0.5;
			--totalPower = totalPower + totalAreaDependantPtoPower * 0.25 * self.mrCombineLimiter.currentAvgArea^0.5;
			local areaValue = self.mrCombineLimiter.currentAvgArea; --relative m2 per second (relative to fertilizer state and crop type)
			if areaValue>self.mrCombineLimiter.basePerfAvgArea then
				areaValue = self.mrCombineLimiter.basePerfAvgArea + (areaValue-self.mrCombineLimiter.basePerfAvgArea)^0.8; --smooth power requirement above "maxAvgArea" to avoid "stalling" the engine too often when entering the field too fast while combining
			end
			if Vehicle.debugRendering then self.mrDebugCombineLastAreaDependantPtoPower = totalAreaDependantPtoPower * 0.1 * areaValue end
			totalPower = totalPower + totalAreaDependantPtoPower * 0.1 * areaValue;
		end
		if not self.isStrawEnabled then
			totalPower = totalPower + self.mrCombineChopperPtoPower;
		end		
		
		self.mrCombineLastTotalPower = 0.99 * self.mrCombineLastTotalPower + 0.01 * totalPower;
		totalPower = self.mrCombineLastTotalPower;
		--print("test combine - total power = " .. tostring(totalPower/0.736) .. " - self.mrCombineLastTotalPower = " .. tostring(self.mrCombineLastTotalPower/0.736));
	end
	if self.overloading~=nil and self.overloading.didOverload then
		totalPower = totalPower + self.mrCombineUnloadingAugerPtoPower;
	end
	
	totalPower = totalPower / 56.5487;		--540*math.pi/30 = 56.5487
	
	--manage the power from the "fruitPreparer" too
	if self.mrIsFruitPreparer then
		totalPower = totalPower + FruitPreparer.mrGetConsumedPtoTorque(self);
	end
	
	return totalPower;
end

--************************************************************************************************************************************************************
--MR : update mrCombineLimiter.totaldistance
Combine.mrUpdate=function(self, dt)

	if not self.mrIsMrVehicle then
		return;
	end

	if self.isServer and self:getIsTurnedOn() then
		--update total move distance	
		self.mrCombineLimiter.totaldistance = self.mrCombineLimiter.totaldistance + self.lastMovedDistance;
		
		if Vehicle.debugRendering then		
			local vehicle = self
			if self.attacherVehicle then
				vehicle = self.attacherVehicle
			end
			if (vehicle.isEntered and vehicle.isClient and vehicle.isControlled) or self:getIsActiveForInput()  then
				local speedDependantPtoPowerWhenFilling = 0;
				local turnedOnPtoPower = self.mrCombineTurnedOnPtoPower;
				local chopperPtoPower = 0;
				local areaDependantPtoPower = 0;
				
				if self.combineIsFilling or self.combineFillEnableTime~=nil then
					speedDependantPtoPowerWhenFilling = self.mrCombineSpeedDependantPtoPowerWhenFilling * self.lastSpeedReal*1000;
				end				
				if not self.isStrawEnabled then
					chopperPtoPower = self.mrCombineChopperPtoPower;
				end					
				if self.mrDebugCombineLastAreaDependantPtoPower then
					areaDependantPtoPower = self.mrDebugCombineLastAreaDependantPtoPower
				end
			
				local tonPerHour = Utils.getNoNil(self.mrCombineDebugTonPerHour, 0)
			
				local str = string.format(" turnedOnPtoPower=%.1f\n speedDependantPtoPowerWhenFilling=%.1f\n chopperPtoPower=%.1f\n areaDependantPtoPower=%.1f\n lastTotalPower=%.1f\n Current Speed Limit=%.1f\n Base Perf=%.0f/Current perf=%.0f\n Ton per Hour=%.1f", turnedOnPtoPower, speedDependantPtoPowerWhenFilling, chopperPtoPower, areaDependantPtoPower, self.mrCombineLastTotalPower, self.speedLimit,self.mrCombineLimiter.basePerfAvgArea*36,self.mrCombineLimiter.currentAvgArea*36, tonPerHour);
				renderText(0.74, 0.75, getCorrectTextSize(0.02), str);
			end
		end	
		
		
	end

end
Combine.update = Utils.appendedFunction(Combine.update, Combine.mrUpdate);

--************************************************************************************************************************************************************
--MR : update mrAvgCombineCuttersArea and apply a speedlimit (limit the grain losses) function of the combine capacity and current material flow rate
Combine.mrUpdateTick=function(self, dt)
	if not self.mrIsMrVehicle then
		return;
	end	
	
	if self.isServer then		
		self.mrIsCombineSpeedLimitActive = false;
		if self:getIsTurnedOn() and self.movingDirection~=-1 and (self:isLowered(true) or self.cutterAllowCuttingWhileRaised) then	--20170427 - check lower/raise state too (especially useful for combine with cutter embedded

			--monitor avg every Xs
			self.mrCombineLimiter.totalArea = self.mrCombineLimiter.totalArea + self.lastArea;
			self.mrCombineLimiter.currentTime = self.mrCombineLimiter.currentTime + dt; --ms	
			self.mrIsCombineSpeedLimitActive = true;
			
			--20170606 - measure once a given distance has been driven/harvested
			--we want to avoid the combine to reach "high" speed before the limiter has a chance to measure the current AvgArea
			--if we rely only on the time (1.5s between each sample in our case), and we assume the combine actually start harvesting something when the 1st measure is done, the avgarea would be very low and so = no limit, then, during the next 1.5s, the combine can reach "high speed" greater than 10kph, and at 10kph, the combine drive more than 4m between each sample
			--if self.mrCombineLimiter.currentTime>self.mrCombineLimiter.avgTime then
			if self.mrCombineLimiter.currentTime>self.mrCombineLimiter.avgTime or self.mrCombineLimiter.totaldistance>self.mrCombineLimiter.distanceForMeasuring then
				local materialFx = 1;
				if self.lastValidInputFruitType ~= FruitUtil.FRUITTYPE_UNKNOWN then
					local fruitDesc = FruitUtil.fruitIndexToDesc[self.lastValidInputFruitType];
					if fruitDesc.mrMaterialQtyFx then materialFx = fruitDesc.mrMaterialQtyFx end
					
					--20170606 - compute ton per Hour
					if Vehicle.debugRendering then
						local equivalentSqmPerHour = 3600000 * self.mrCombineLimiter.totalArea * g_currentMission:getFruitPixelsToSqm() / self.mrCombineLimiter.currentTime --actually, this is not the real hectare because it is scaled by the fruit converter or fertilizer factor						
						--take into account "self.threshingScale" ???
						local fillType = self.lastCuttersOutputFillType						
						local massPerLiter = FillUtil.fillTypeIndexToDesc[fillType].massPerLiter
						self.mrCombineDebugTonPerHour = equivalentSqmPerHour * fruitDesc.literPerSqm * massPerLiter
					end
					
				end
				
				
			
				local avgArea = 500 * self.mrCombineLimiter.totalArea * materialFx * g_currentMission:getFruitPixelsToSqm() / self.mrCombineLimiter.currentTime; -- m2 per second (takes into account fertilizer state and so, since our reference capacity is with full yield, we have to multiply by 0.5
				local avgSpeed = 1000 * self.mrCombineLimiter.totaldistance / self.mrCombineLimiter.currentTime; --m/s			
				
				--20170606 - check the current increase "acceleration" for the avgArea
				local areaAcc = (avgArea - self.mrCombineLimiter.currentAvgArea)/self.mrCombineLimiter.currentTime
				
				if self.mrCombineLimiter.currentAvgArea>(0.75*self.mrCombineLimiter.basePerfAvgArea) then
					avgArea = 0.5 * self.mrCombineLimiter.currentAvgArea + 0.5 * avgArea; --small smooth					
				end	
				
				self.mrCombineLimiter.currentAvgArea = avgArea;
				
				if avgArea==0 then
					self.speedLimit = self.mrGenuineSpeedLimit;
				else	

					local maxAvgArea = self.mrCombineLimiter.basePerfAvgArea;
					local predictLimitSet = false
					--take into account the areaAcc
					if areaAcc>0 then
						--predict in 3s
						local predictAvgArea = avgArea + areaAcc*3000
						if predictAvgArea>1.5*maxAvgArea then
							self.speedLimit = math.max(2, math.min(0.95*self.speedLimit, 0.9*avgSpeed*3.6))
							predictLimitSet = true
							--print("predictAvgArea="..tostring(predictAvgArea) .. " - new speedLimit="..tostring(self.speedLimit))
						end
					end
					
					if not predictLimitSet then
						if avgArea>(1.05*maxAvgArea) then 
							--reduce speedlimit											
							self.speedLimit = math.max(2, math.min(self.speedLimit, avgSpeed*3.6) - 10 * (1 - avgArea/maxAvgArea)^2); --0.1kph step --allow 5% margin to avoid "yo-yo" effect
						elseif (3.6*avgSpeed)>self.speedLimit and avgArea<maxAvgArea then -- not limited by the engine, nor by the combine capacity
							--increase speedlimit
							self.speedLimit = math.min(self.mrGenuineSpeedLimit, self.speedLimit + 0.1 * (maxAvgArea / avgArea)^3);
						end 
					end
					
					
					
				
					--local refSpeed = 3.6*avgSpeed;
					--if avgArea>self.mrCombineLimiter.maxAvgArea then
					--local refSpeed = math.max(2, math.min(3.6*avgSpeed, self.speedLimit));
					--end
					--self.speedLimit = refSpeed * (self.mrCombineLimiter.maxAvgArea/avgArea)^0.5;		

					
					--[[
					local litersPerHour = 0;
					if self.lastValidInputFruitType ~= FruitUtil.FRUITTYPE_UNKNOWN then
						local fruitDesc = FruitUtil.fruitIndexToDesc[self.lastValidInputFruitType];
						litersPerHour = 1000*3600*self.mrCombineLimiter.totalArea*g_currentMission:getFruitPixelsToSqm() * fruitDesc.literPerSqm/self.mrCombineLimiter.currentTime;
					end
					
					
					print(string.format("test combine limiter - timeStep=%1.3f - fruit area=%1.1f - area=%1.2f - avgSpd=%1.2f - new slimit=%1.2f - maxArea=%1.2f - liters per hour=%1.0f",
					self.mrCombineLimiter.currentTime/1000,					
					self.mrCombineLimiter.totalArea,
					avgArea,
					avgSpeed*3.6,
					self.speedLimit,
					maxAvgArea,
					litersPerHour));
					--]]
					
				end
				
				--[[
				elseif avgArea<self.mrCombineLimiter.maxAvgArea then
					self.speedLimit = 3.6 * avgSpeed * self.mrCombineLimiter.maxAvgArea/avgArea;
				elseif avgArea>self.mrCombineLimiter.maxAvgArea then
					self.speedLimit = math.max(1, math.min(self.speedLimit, 3.6*avgSpeed) - 0.02 * (avgArea - self.mrCombineLimiter.maxAvgArea));
				end
				--]]
				
				
				--reset for next avg
				self.mrCombineLimiter.currentTime = 0;
				self.mrCombineLimiter.totalArea = 0;
				self.mrCombineLimiter.totaldistance = 0;
			end
		
		
			--self.mrAvgCombineCuttersArea = (1-0.0005*dt) * self.mrAvgCombineCuttersArea + 0.0005*dt*self.lastArea;
			--[[
							
			--print("test combine power consumer self.lastArea=" .. tostring(self.lastArea) .. " - self.mrAvgCombineCuttersArea="..tostring(self.mrAvgCombineCuttersArea) .. " - dt=" .. tostring(dt));
			self.mrIsCombineSpeedLimitActive = true;
			if self.mrAvgCombineCuttersArea>self.mrCombineMaxMaterialFlowRateFx then				
				--self.speedLimit = math.min(self.speedLimit, self.lastSpeedReal*3600)-dt/1000;
				self.speedLimit = self.lastSpeedReal*3600-0.5*math.min(1, self.mrAvgCombineCuttersArea-self.mrCombineMaxMaterialFlowRateFx);
			else
				--self.speedLimit = math.min(99, self.speedLimit+0.2*dt/1000);
				self.speedLimit = 99;
			end		
			--]]
			
		else
			self.speedLimit = self.mrGenuineSpeedLimit;
			self.mrCombineLimiter.currentAvgArea = 0;
			--self.mrAvgCombineCuttersArea = 0;
			self.mrCombineDebugTonPerHour = 0
		end		
	end
	
end
Combine.updateTick = Utils.appendedFunction(Combine.updateTick, Combine.mrUpdateTick);




Combine.mrDoCheckSpeedLimit = function(self, superFunc)
	local parent = false
	if superFunc ~= nil then
		parent = superFunc(self)
	end

	return parent or self.mrIsCombineSpeedLimitActive;
end




--************************************************************************************************************************************************************
--MR : fix bug = forage harvester harvest more liters per hectare than forage wagon
Combine.mrAddCutterArea = function(self, superFunc1, superFunc, cutter, area, realArea, inputFruitType, outputFillType)

	if not self.mrIsMrVehicle then
		return superFunc1(self, superFunc, cutter, area, realArea, inputFruitType, outputFillType)
	end


    if superFunc ~= nil then
        if not superFunc(self, cutter, area, realArea, inputFruitType, outputFillType) then
            return false
        end
    end
    if area > 0 and (self.lastCuttersFruitType == FruitUtil.FRUITTYPE_UNKNOWN or self.lastCuttersArea == 0 or self.lastCuttersOutputFillType == outputFillType) then
        self.lastCuttersArea = self.lastCuttersArea + area;
        self.lastCuttersOutputFillType = outputFillType;
        self.lastCuttersInputFruitType = inputFruitType;
        self.lastCuttersAreaTime = g_currentMission.time;
        if not self.chopperSwitchAvailable then
            local fruitDesc = FruitUtil.fruitIndexToDesc[inputFruitType];
			--20171215 - check "strawAsDefault" value
            --self.isStrawEnabled = not fruitDesc.hasWindrow;
			self.isStrawEnabled = false;
			if self.chopperSwitchStrawAsDefault then
				self.isStrawEnabled = fruitDesc.hasWindrow;
			end;
        end
        local litersPerSqm = 60
        local fruitDesc = FruitUtil.fruitIndexToDesc[inputFruitType];
        if fruitDesc.windrowLiterPerSqm ~= nil then
            litersPerSqm = fruitDesc.windrowLiterPerSqm
        end
		
		--20170823 - add combine strawFactor
		litersPerSqm = litersPerSqm * self.mrCombineStrawFactor
		
        self.strawBuffer[self.strawBufferFillIndex] = self.strawBuffer[self.strawBufferFillIndex] + (realArea * g_currentMission:getFruitPixelsToSqm() * litersPerSqm)
        if self.combineFillEnableTime == nil then
            self.combineFillEnableTime = g_currentMission.time + self.combineFillToggleTime;
        end
        self.combineFillDisableTime = nil;
		
		
		--fix : no need to compute the liters if the area value comes from a "fruitTypesUseWindrowed" cutter
		local newFillLevel = 0
		if cutter.fruitTypesUseWindrowed then
			local deltaFillLevel = area*self.threshingScale
			newFillLevel = self:getUnitFillLevel(self.overloading.fillUnitIndex) + deltaFillLevel		
		else
			-- 8000/1200 = 6.66 liter/meter
			-- 8000/1200 / 6 = 1.111 liter/m^2
			-- 8000/1200 / 6 / 2^2 = 0.277777 liter / density pixel (density is 4096^2, on a area of 2048m^2
			local pixelToSqm = g_currentMission:getFruitPixelsToSqm(); -- 4096px are mapped to 2048m
			local literPerSqm = 1;
			if (inputFruitType ~= FruitUtil.FRUITTYPE_UNKNOWN) then
				literPerSqm = FruitUtil.fruitIndexToDesc[inputFruitType].literPerSqm;
			end
			local sqm = area*pixelToSqm;
			local deltaFillLevel = sqm*literPerSqm*self.threshingScale;
			newFillLevel = self:getUnitFillLevel(self.overloading.fillUnitIndex) + deltaFillLevel;
			self:setWorkedHectars(self.workedHectars + Utils.areaToHa(realArea, g_currentMission:getFruitPixelsToSqm()));
		
		end	
        
        local fillType = outputFillType;        
        self:setUnitFillLevel(self.overloading.fillUnitIndex, newFillLevel, fillType, false, self.fillVolumeLoadInfos[self.overloading.loadInfoIndex]);
    end
end
Combine.addCutterArea = Utils.overwrittenFunction(Combine.addCutterArea, Combine.mrAddCutterArea);

