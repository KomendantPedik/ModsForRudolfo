﻿

--************************************************************************************************************************************************************
--set the specific getConsumedPtoTorque
Mower.mrLoad = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	self.mower.mrCuttingDependantPtoPower  = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.mower#cuttingDependantPtoPower"), 0); -- KW per liter per second
	self.mower.mrUseCuttingDependantPtoPower = self.mower.mrCuttingDependantPtoPower>0
	
	if self.mower.mrUseCuttingDependantPtoPower then
		self.mower.mrCurrentCuttingDependantPower = 0
		self.getConsumedPtoTorque = Mower.mrGetConsumedPtoTorque
		self.mower.mrCutLitersBuffer = 0
		self.mower.mrLitersPerSecondEmptyingSpeed = 0
	end
	
	self.processMowerAreas = Mower.mrProcessMowerAreas

end
Mower.load = Utils.appendedFunction(Mower.load, Mower.mrLoad)




--************************************************************************************************************************************************************
--fix the infinite "remainingWindrowToDrop" for old mowers converted from FS13 (no drop area)
--add totalLitersCut
Mower.mrProcessMowerAreas = function(self, workAreas, numWorkAreas, dropAreas, numDropAreas, remainingWindrowToDrop)
    local pickedUpWindrow = 0
    local numDropAreasUsed = 0
    local fillType = FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_GRASS]
	local totalLitersCut = 0
    for i=1, numWorkAreas do
        local area = workAreas[i]
        local x0 = area.x
        local z0 = area.z
        local x1 = area.x1
        local z1 = area.z1
        local x2 = area.x2
        local z2 = area.z2
        local areaPixelsSum, _, sprayFactor, _ = Utils.cutFruitArea(FruitUtil.FRUITTYPE_GRASS, x0,z0, x1,z1, x2,z2, true, true)
		local litersChanged = 0		
        if areaPixelsSum > 0 then
            local multi = g_currentMission:getHarvestScaleMultiplier(sprayFactor, 1)
            areaPixelsSum = areaPixelsSum * multi
			local pixelToSqm = g_currentMission:getFruitPixelsToSqm()
			local sqm = areaPixelsSum * pixelToSqm
			litersChanged = sqm * FruitUtil.getFillTypeLiterPerSqm(FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_GRASS], 1)
			totalLitersCut = totalLitersCut + litersChanged
        end
		
        if area.dropArea ~= nil then
            dropAreas[area.dropArea].valueAccum = dropAreas[area.dropArea].valueAccum + litersChanged
        else
            if not area.dropWindrow then
                pickedUpWindrow = pickedUpWindrow + litersChanged
            else
                local lx_2 = 0.5*(area.x2 - area.x)
                local lz_2 = 0.5*(area.z2 - area.z)
                local sx = area.x + lx_2
                local sz = area.z + lz_2
                local ex = area.x1 + lx_2
                local ez = area.z1 + lz_2
                local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz)
                local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez)
                local toDrop = remainingWindrowToDrop + litersChanged
                local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, toDrop, fillType, sx,sy,sz, ex,ey,ez, 0, nil, self.mowerLineOffset, false, nil, false)
                self.mowerLineOffset = lineOffset
				----------------------------------------------------------------------
				--MR
				--fix the infinite "remainingWindrowToDrop"
                --remainingWindrowToDrop = remainingWindrowToDrop + (toDrop - dropped)
				remainingWindrowToDrop = toDrop - dropped
            end
        end
    end
    local unitLength = TipUtil.densityToWorldMap
    for i=1, numDropAreas do
        local area = dropAreas[i]
        local widthX = area.x1 - area.x
        local widthZ = area.z1 - area.z
        local widthLength = Utils.vector2Length(widthX, widthZ)
        local widthLength_2 = 0.5 * widthLength
        local widthX_norm = widthX / widthLength
        local widthZ_norm = widthZ / widthLength
        local middleX = 0.5 * (area.x1 + area.x)
        local middleZ = 0.5 * (area.z1 + area.z)
        local sx = middleX + ( widthX_norm * math.max(0, widthLength_2 - unitLength) )
        local sz = middleZ + ( widthZ_norm * math.max(0, widthLength_2 - unitLength) )
        local ex = middleX - ( widthX_norm * math.max(0, widthLength_2 - unitLength) )
        local ez = middleZ - ( widthZ_norm * math.max(0, widthLength_2 - unitLength) )
        local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz)
        local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez)
        --drawDebugLine(sx,sy,sz, 1,0,0, sx,sy+2,sz, 1,0,0)
        --drawDebugLine(ex,ey,ez, 0,1,0, ex,ey+2,ez, 0,1,0)
        local toDrop = area.valueAccum
        local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, toDrop, fillType, sx,sy,sz, ex,ey,ez, 0, nil, area.mowerLineOffset, false, nil, false)
        area.mowerLineOffset = lineOffset
        area.valueAccum = area.valueAccum - dropped
        area.value = dropped
        if dropped > 0 then
            numDropAreasUsed = numDropAreasUsed + 1
        end
    end
	
	
	---------------------------------------------------------------
	--MR
	--update power consumption ?
	if self.mower.mrUseCuttingDependantPtoPower then
		self.mower.mrCutLitersBuffer = self.mower.mrCutLitersBuffer + totalLitersCut
	end
	
	
    return numDropAreasUsed, pickedUpWindrow, remainingWindrowToDrop
end



--************************************************************************************************************************************************************
--pto torque depends on the liters per second cut by the mower
Mower.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower + self.mower.mrCurrentCuttingDependantPower
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end

--************************************************************************************************************************************************************
--MR : display debug info
Mower.mrUpdate=function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	if self:getIsTurnedOn() then
	
		if self.mower.mrUseCuttingDependantPtoPower then			
			
			self.mower.mrCutLitersBuffer = math.max(0, self.mower.mrCutLitersBuffer-self.mower.mrLitersPerSecondEmptyingSpeed)
			
			--update the buffer (try to empty it. The faster we want to empty it = the more PTO power required)
			if self.mower.mrCutLitersBuffer > 2*self.mower.mrLitersPerSecondEmptyingSpeed then -- 2s
				self.mower.mrLitersPerSecondEmptyingSpeed = self.mower.mrLitersPerSecondEmptyingSpeed + dt/50 -- 20 per second
			elseif self.mower.mrCutLitersBuffer ==0 then
				self.mower.mrLitersPerSecondEmptyingSpeed = math.max(0, self.mower.mrLitersPerSecondEmptyingSpeed - dt/50) -- 20 per second
			end
			
			self.mower.mrCurrentCuttingDependantPower = self.mower.mrCuttingDependantPtoPower * self.mower.mrLitersPerSecondEmptyingSpeed
			
		end
		
	end
	
	if Vehicle.debugRendering and self.isServer and self:getIsTurnedOn() then
		
		local vehicle = self
		if self.attacherVehicle then
			vehicle = self.attacherVehicle
		end
		if (vehicle.isEntered and vehicle.isClient and vehicle.isControlled) or self:getIsActiveForInput()  then
			local turnedOnPtoPower = 0
			
			if self.powerConsumer then
				turnedOnPtoPower = self.powerConsumer.mrNoLoadPtoPower				 
			end
			
			local cuttingDependantPtoPower = 0
			local bufferLevel=0
			if self.mower.mrUseCuttingDependantPtoPower then
				cuttingDependantPtoPower = self.mower.mrCurrentCuttingDependantPower
				bufferLevel = self.mower.mrCutLitersBuffer
			end
			
			local totalPower = turnedOnPtoPower + cuttingDependantPtoPower
		
		
			local str = string.format(" turnedOnPtoPower=%.1f\n cuttingDependantPtoPower=%.1f\n lastTotalPower=%.1f\n Buffer level=%.0f", turnedOnPtoPower, cuttingDependantPtoPower, totalPower, bufferLevel)
			renderText(0.74, 0.75, getCorrectTextSize(0.02), str);
		end
		
		
		
	end

end
Mower.update = Utils.appendedFunction(Mower.update, Mower.mrUpdate);


