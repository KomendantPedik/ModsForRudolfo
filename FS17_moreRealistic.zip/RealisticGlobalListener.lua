﻿
RealisticGlobalListener = {};

addConsoleCommand("debugmode", "Toggles the debug rendering of the vehicles", "Vehicle.consoleCommandToggleDebugRendering", nil)

------------------------------------------
-- Mission00.load occurs before "loadMap"
-- Fix the peoblem with GBAddon "transmission" config dynamically added to vehicles in "loadMap"
Mission00.load1 = function(...)
	--print("//////////////////////////////////  loadEnvironment ++++++++++++++++++++++++++++++++++++++")
	-- reload all store items to take into account MR modified data
	RealisticUtils.reloadStoreDataWithMR()		
end

Mission00.load = Utils.prependedFunction(Mission00.load, Mission00.load1);

function RealisticGlobalListener:loadMap(name)	

	--print("////////////////////////// load map : " .. tostring(name))	
	
	--load mrGui and mr settings data if this is not a new game
	if g_currentMission.missionInfo.isValid then
		RealisticGui.loadDataFromXml();
		RealisticSettings.loadDataFromXml();
	end
	
	--load mr helpLines
	RealisticHelpLines.load()
	
	--manage known conflict with other mods
	RealisticConflictModsManagement.start()
	
	--fix "bug" with 'sellPriceMultiplier' and 'buyPriceMultiplier'
	-- see = https://gdn.giants-software.com/thread.php?categoryId=13&threadId=5467
	RealisticGlobalListener.fixBug1()

	--override Environment.calculateGroundWetness
	local groundWetnessAlreadyOverwritten = false
	if g_seasons~=nil then
		if g_seasons.weather~=nil then
			if g_seasons.weather.soilWaterContent~=nil then
				groundWetnessAlreadyOverwritten = true
			end
		end
	end
	if groundWetnessAlreadyOverwritten==false then
		Environment.calculateGroundWetness = Utils.overwrittenFunction(Environment.calculateGroundWetness, Environment.mrCalculateGroundWetness)
	end
	
	--override FiledJob.init
	if g_seasons==nil then
		FieldJob.init = Utils.overwrittenFunction(FieldJob.init, FieldJob.mrInit)
	end
		
end

function RealisticGlobalListener:deleteMap()    
end

function RealisticGlobalListener:mouseEvent(posX, posY, isDown, isUp, button)
end

function RealisticGlobalListener:keyEvent(unicode, sym, modifier, isDown)
end



function RealisticGlobalListener:update(dt)
end

function RealisticGlobalListener:draw()
end

--fix "bug" with 'sellPriceMultiplier' and 'buyPriceMultiplier'
-- see = https://gdn.giants-software.com/thread.php?categoryId=13&threadId=5467
function RealisticGlobalListener:fixBug1()
	--print("test difficulty settings - difficulty value = " .. tostring(g_currentMission.missionInfo.difficulty) .." - sellprice multi="..tostring(g_currentMission.missionInfo.sellPriceMultiplier) .." - buyprice multi="..tostring(g_currentMission.missionInfo.buyPriceMultiplier))

	if g_currentMission.missionInfo.difficulty==1 then --easy
		g_currentMission.missionInfo.sellPriceMultiplier = 2
		g_currentMission.missionInfo.buyPriceMultiplier = 0.5
	elseif g_currentMission.missionInfo.difficulty==2 then -- normal
		g_currentMission.missionInfo.sellPriceMultiplier = 1.5
		g_currentMission.missionInfo.buyPriceMultiplier = 0.75
	end
	
end


addModEventListener(RealisticGlobalListener);
