﻿

--************************************************************************************************************************************************************
--set the specific getConsumedPtoTorque
Windrower.mrLoad = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	self.mrRake = {}
	self.mrRake.mrRakingDependantPtoPower  = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.rake#rakingDependantPtoPower"), 0); -- KW per liter per second
	self.mrRake.mrUseRakingDependantPtoPower = self.mrRake.mrRakingDependantPtoPower>0
	
	if self.mrRake.mrUseRakingDependantPtoPower then
		self.mrRake.mrCurrentRakingDependantPower = 0
		self.getConsumedPtoTorque = Windrower.mrGetConsumedPtoTorque
		self.mrRake.mrRakedLitersBuffer = 0
		self.mrRake.mrLitersPerSecondEmptyingSpeed = 0
	end
	
	self.processWindrowerAreas = Windrower.mrProcessWindrowerAreas

end
Windrower.load = Utils.appendedFunction(Windrower.load, Windrower.mrLoad)




--************************************************************************************************************************************************************
--we want to get the liters "raked"
Windrower.mrProcessWindrowerAreas = function(self, workAreas, accumulatedWorkAreaValues, accumulatedFruitType)
    local numAreas = table.getn(workAreas);
    local fruitType = FruitUtil.FRUITTYPE_GRASS;
    local fruitTypeFix = false;
    local workAreasRet = {};
    for i=1, numAreas do
        local x0 = workAreas[i][1];
        local z0 = workAreas[i][2];
        local x1 = workAreas[i][3];
        local z1 = workAreas[i][4];
        local x2 = workAreas[i][5];
        local z2 = workAreas[i][6];
        local dx0 = workAreas[i][7];
        local dz0 = workAreas[i][8];
        local dx1 = workAreas[i][9];
        local dz1 = workAreas[i][10];
        local dx2 = workAreas[i][11];
        local dz2 = workAreas[i][12];
        -- pick up
        local hx = x2 - x0;
        local hz = z2 - z0;
        local hLength = Utils.vector2Length(hx, hz);
        local hLength_2 = 0.5 * hLength;
        local wx = x1 - x0;
        local wz = z1 - z0;
        local wLength = Utils.vector2Length(wx, wz);
        local sx = x0 + (hx * 0.5) + ((wx/wLength)*hLength_2);
        local sz = z0 + (hz * 0.5) + ((wz/wLength)*hLength_2);
        local ex = x1 + (hx * 0.5) - ((wx/wLength)*hLength_2);
        local ez = z1 + (hz * 0.5) - ((wz/wLength)*hLength_2);
        local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz);
        local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez);
        local liters = 0;
        if fruitTypeFix then
            liters = -TipUtil.tipToGroundAroundLine(self, -math.huge, FruitUtil.fruitTypeToWindrowFillType[fruitType], sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil);
        else
            -- first try dry grass to avoid wet grass destroying dry grass
            fruitType = FruitUtil.FRUITTYPE_DRYGRASS;
            liters = -TipUtil.tipToGroundAroundLine(self, -math.huge, FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_DRYGRASS], sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil);
            if liters == 0 then
                for fruitId=1, FruitUtil.NUM_FRUITTYPES do
                    if fruitId ~= FruitUtil.FRUITTYPE_DRYGRASS then
                        local ids = g_currentMission.fruits[fruitId];
                        if ids ~= nil and FruitUtil.fruitTypeToWindrowFillType[fruitId] ~= nil then
                            fruitType = fruitId;
                            liters = -TipUtil.tipToGroundAroundLine(self, -math.huge, FruitUtil.fruitTypeToWindrowFillType[fruitType], sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil);
                            if liters > 0 then
                                break;
                            end
                        end
                    end
                end
            end
        end
        if liters > 0 then
            fruitTypeFix = true;
            -- now that we removed the windrow, maybe there is some hidden drygrass to grow (set it to growth state 1 if there is some)
            if fruitType == FruitUtil.FRUITTYPE_DRYGRASS then
                Utils.switchFruitTypeArea(FruitUtil.FRUITTYPE_GRASS, FruitUtil.FRUITTYPE_DRYGRASS, x0, z0, x1, z1, x2, z2, 2);
            end
        end
        -- handle grass as drygrass and vice versa
        if fruitType == FruitUtil.FRUITTYPE_GRASS then
            liters = liters - TipUtil.tipToGroundAroundLine(self, -math.huge, FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_DRYGRASS], sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil);
        elseif fruitType == FruitUtil.FRUITTYPE_DRYGRASS then
            liters = liters - TipUtil.tipToGroundAroundLine(self, -math.huge, FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_GRASS], sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil);
        end
		
		-------------------------------------------------------------------
		--MR
		--update total liters raked
		if self.mrRake.mrUseRakingDependantPtoPower then
			--print(tostring(g_currentMission.time) .. " liters raked="..tostring(liters))
			self.mrRake.mrRakedLitersBuffer = self.mrRake.mrRakedLitersBuffer + liters
		end
		
        -- add the accumulated value
        if not fruitTypeFix or accumulatedFruitType == fruitType then
            fruitType = accumulatedFruitType;
            liters = liters + accumulatedWorkAreaValues[i];
            accumulatedWorkAreaValues[i] = 0;
        end
        if liters > 0 then
            local hx = dx2 - dx0;
            local hz = dz2 - dz0;
            local hLength = Utils.vector2Length(hx, hz);
            local hLength_2 = 0.5 * hLength;
            local wx = dx1 - dx0;
            local wz = dz1 - dz0;
            local wLength = Utils.vector2Length(wx, wz);
            local sx = dx0 + (hx * 0.5) + ((wx/wLength)*hLength_2);
            local sz = dz0 + (hz * 0.5) + ((wz/wLength)*hLength_2);
            local ex = dx1 + (hx * 0.5) - ((wx/wLength)*hLength_2);
            local ez = dz1 + (hz * 0.5) - ((wz/wLength)*hLength_2);
            local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz);
            local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez);
            local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, liters, FruitUtil.fruitTypeToWindrowFillType[fruitType], sx,sy,sz, ex,ey,ez, hLength_2, nil, self.windrowerLineOffset, false, nil, false);
            self.windrowerLineOffset = lineOffset;
            local remain = liters - dropped;
            if dropped > 0 then
                table.insert(workAreasRet, {x0,z0, x1,z1, x2,z2, dx0,dz0, dx1,dz1, dx2,dz2, liters-remain, workAreas[i][14] });
            end
            accumulatedWorkAreaValues[i] = remain;
        end
    end
    return workAreasRet, fruitType;
end



--************************************************************************************************************************************************************
--pto torque depends on the liters per second raked by the rake
Windrower.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower + self.mrRake.mrCurrentRakingDependantPower
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end

--************************************************************************************************************************************************************
--MR : display debug info
Windrower.mrUpdate=function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	if self:getIsTurnedOn() then
	
		if self.mrRake.mrUseRakingDependantPtoPower then

			--print(tostring(g_currentMission.time) .. " test Windrower - mrLitersPerSecondEmptyingSpeed = "..tostring(self.mrRake.mrLitersPerSecondEmptyingSpeed) .. " - buffer="..tostring(self.mrRake.mrRakedLitersBuffer))
			
			self.mrRake.mrRakedLitersBuffer = math.max(0, self.mrRake.mrRakedLitersBuffer-self.mrRake.mrLitersPerSecondEmptyingSpeed)
			
			--update the buffer (try to empty it. The faster we want to empty it = the more PTO power required)
			if self.mrRake.mrRakedLitersBuffer > 2*self.mrRake.mrLitersPerSecondEmptyingSpeed then -- 2s
				self.mrRake.mrLitersPerSecondEmptyingSpeed = self.mrRake.mrLitersPerSecondEmptyingSpeed + dt/50 -- 20 per second
			elseif self.mrRake.mrRakedLitersBuffer ==0 then
				self.mrRake.mrLitersPerSecondEmptyingSpeed = math.max(0, self.mrRake.mrLitersPerSecondEmptyingSpeed - dt/50) -- 20 per second
			end
			
			self.mrRake.mrCurrentRakingDependantPower = self.mrRake.mrRakingDependantPtoPower * self.mrRake.mrLitersPerSecondEmptyingSpeed
			
		end
		
	end
	
	if Vehicle.debugRendering and self.isServer and self:getIsTurnedOn() then
		
		local vehicle = self
		if self.attacherVehicle then
			vehicle = self.attacherVehicle
		end
		if (vehicle.isEntered and vehicle.isClient and vehicle.isControlled) or self:getIsActiveForInput()  then
			local turnedOnPtoPower = 0
			
			if self.powerConsumer then
				turnedOnPtoPower = self.powerConsumer.mrNoLoadPtoPower				 
			end
			
			local rakingDependantPtoPower = 0
			local bufferLevel=0
			if self.mrRake.mrUseRakingDependantPtoPower then
				rakingDependantPtoPower = self.mrRake.mrCurrentRakingDependantPower
				bufferLevel = self.mrRake.mrRakedLitersBuffer
			end
			
			local totalPower = turnedOnPtoPower + rakingDependantPtoPower
		
		
			local str = string.format(" turnedOnPtoPower=%.1f\n rakingDependantPtoPower=%.1f\n lastTotalPower=%.1f\n Buffer level=%.0f", turnedOnPtoPower, rakingDependantPtoPower, totalPower, bufferLevel)
			renderText(0.74, 0.75, getCorrectTextSize(0.02), str);
		end
		
		
		
	end

end
Windrower.update = Utils.appendedFunction(Windrower.update, Windrower.mrUpdate);


