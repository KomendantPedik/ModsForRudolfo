﻿
---------------------------------------------------------------------------------------------------
--MR : fix bug = power consumer not consistent when unloading on the ground (sometimes no power, sometimes no power, no ptoRpm 
--because didOverload can be false even if the trailer is actually unloading on the ground
---------------------------------------------------------------------------------------------------
Overloading.mrGetDoConsumePtoPower = function(self, superFunc1, superFunc2)
	
	if not self.mrIsMrVehicle then
		return superFunc1(self, superFunc2)
	end

    local doConsumePower = superFunc2(self);
	--print(tostring(g_currentMission.time) .. " test getDoConsumePtoPower - didOverload="..tostring(self.overloading.didOverload) .. " - isActive="..tostring(self.overloading.isActive) .. " - self.dischargeToGround="..tostring(self.dischargeToGround))
    --return self.overloading.didOverload or doConsumePower;
	return self.overloading.isActive or doConsumePower or self.dischargeToGround;
end
Overloading.getDoConsumePtoPower = Utils.overwrittenFunction(Overloading.getDoConsumePtoPower, Overloading.mrGetDoConsumePtoPower)



Overloading.mrGetPtoRpm = function(self, superFunc1, superFunc2)

	if not self.mrIsMrVehicle then
		return superFunc1(self, superFunc2)
	end

    local ptoRpm = 0;
    if superFunc2 ~= nil then
        ptoRpm = superFunc2(self);
    end
    --if self.overloading.didOverload and self.powerConsumer ~= nil then
	if self.powerConsumer ~= nil and (self.overloading.didOverload or self.dischargeToGround) then
        ptoRpm = math.max(ptoRpm, self.powerConsumer.ptoRpm);
    end
    return ptoRpm;
end
Overloading.getPtoRpm = Utils.overwrittenFunction(Overloading.getPtoRpm, Overloading.mrGetPtoRpm)