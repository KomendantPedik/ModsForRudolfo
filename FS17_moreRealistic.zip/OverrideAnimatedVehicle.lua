﻿--************************************************************************************************************************************************************	
--move the update of the wheelshape to the "postupdate" function so that it has the lastest values
AnimatedVehicle.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then
		return
	end
	
	--moving center of mass function of animation time
	--<movingCenterOfMass componentIndex="1" animationName="folding" startAnimCenterOfMass="0 1.4 0.2" endAnimCenterOfMass="0 1.4 -0.4" />
	self.mrHasMcom = false
	local mcomComponentIndex = getXMLInt(self.xmlFile, "vehicle.moreRealistic.movingCenterOfMass#componentIndex")
	if mcomComponentIndex~=nil then
		--check the component actually exists
		if self.components[mcomComponentIndex]==nil then
			RealisticUtils.printWarning("AnimatedVehicle.mrLoad", "Component not found for 'vehicle.moreRealistic.movingCenterOfMass'. Incorrect index=" .. tostring(mcomComponentIndex), false)
		else				
			--check anim name
			local mcomAnimName = getXMLString(self.xmlFile, "vehicle.moreRealistic.movingCenterOfMass#animationName")
			if mcomAnimName==nil then
				RealisticUtils.printWarning("AnimatedVehicle.mrLoad", "No AnimationName found for 'vehicle.moreRealistic.movingCenterOfMass'", false)
			else
				if self.animations[mcomAnimName]==nil then
					RealisticUtils.printWarning("AnimatedVehicle.mrLoad", "Incorrect AnimationName for 'vehicle.moreRealistic.movingCenterOfMass'. Value="..tostring(mcomAnimName), false)
				else
					--load start centerOfMass
					local sComX, sComY, sComZ = Utils.getVectorFromString(getXMLString(self.xmlFile, "vehicle.moreRealistic.movingCenterOfMass#startAnimCenterOfMass"))
					if sComX == nil or sComY == nil or sComZ == nil then
						RealisticUtils.printWarning("AnimatedVehicle.mrLoad", "Incorrect startAnimCenterOfMass for 'vehicle.moreRealistic.movingCenterOfMass'. Value x,y,z='"..tostring(sComX).."','"..tostring(sComY).."','"..tostring(sComZ).."'", false)
					else
						--load end centerOfMass
						local eComX, eComY, eComZ = Utils.getVectorFromString(getXMLString(self.xmlFile, "vehicle.moreRealistic.movingCenterOfMass#endAnimCenterOfMass"))
						if eComX == nil or eComY == nil or eComZ == nil then
							RealisticUtils.printWarning("AnimatedVehicle.mrLoad", "Incorrect endAnimCenterOfMass for 'vehicle.moreRealistic.movingCenterOfMass'. Value x,y,z='"..tostring(eComX).."','"..tostring(eComY).."','"..tostring(eComZ).."'", false)
						else	
							self.mrHasMcom = true
							self.mrMcom = {}
							self.mrMcom.componentIndex = mcomComponentIndex
							self.mrMcom.animationName = mcomAnimName
							self.mrMcom.startCom = {x=sComX, y=sComY, z=sComZ}
							self.mrMcom.endCom = {x=eComX, y=eComY, z=eComZ}
						end
					end
				end
			end
		end
	end
	
end
AnimatedVehicle.load = Utils.appendedFunction(AnimatedVehicle.load, AnimatedVehicle.mrLoad)





AnimatedVehicle.mrUpdateAnimation = function(self, anim, dtToUse, stopAnim)

	if not self.mrIsMrVehicle then
		return
	end

	if self.isServer and self.mrHasMcom and anim.duration>0 then
		if self.mrMcom.animationName==anim.name then
			--compute new center of mass function of anim time
			local factor = anim.currentTime/anim.duration
			local newX = Utils.lerp(self.mrMcom.startCom.x, self.mrMcom.endCom.x, factor)
			local newY = Utils.lerp(self.mrMcom.startCom.y, self.mrMcom.endCom.y, factor)
			local newZ = Utils.lerp(self.mrMcom.startCom.z, self.mrMcom.endCom.z, factor)
			
			--print("test mrUpdateAnimation - newX="..tostring(newX).." - newY="..tostring(newY).." - newZ="..tostring(newZ))
			
			setCenterOfMass(self.components[self.mrMcom.componentIndex].node, newX, newY, newZ)
		end
	end

end
AnimatedVehicle.updateAnimation = Utils.appendedFunction(AnimatedVehicle.updateAnimation, AnimatedVehicle.mrUpdateAnimation)
