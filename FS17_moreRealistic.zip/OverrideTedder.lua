﻿

--************************************************************************************************************************************************************
--set the specific getConsumedPtoTorque
Tedder.mrLoad = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	self.mrTedder = {}
	self.mrTedder.mrTeddingDependantPtoPower  = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.tedder#teddingDependantPtoPower"), 0); -- KW per liter per second
	self.mrTedder.mrUseTeddingDependantPtoPower = self.mrTedder.mrTeddingDependantPtoPower>0
	
	if self.mrTedder.mrUseTeddingDependantPtoPower then
		self.mrTedder.mrCurrentTeddingDependantPower = 0
		self.getConsumedPtoTorque = Tedder.mrGetConsumedPtoTorque
		self.mrTedder.mrTededLitersBuffer = 0
		self.mrTedder.mrLitersPerSecondEmptyingSpeed = 0
	end
	
	self.processTedderAreas = Tedder.mrProcessTedderAreas
	

end
Tedder.load = Utils.appendedFunction(Tedder.load, Tedder.mrLoad)




--************************************************************************************************************************************************************
--we want to get the liters "teded"
--fix the spreading
-- add a "lose" of grass when tedding (grass yield = 26T per Ha, which would mean about 8.45T of hay per Ha. To get something closer to IRL, we have to "lose" some material in the "drying" process (as IRL)
--with a factor 0.75, we got something like 6.3T of hay per hectare
Tedder.mrProcessTedderAreas = function(self, workAreas, accumulatedWorkAreaValues, accumulatedFruitType)
    		
	local numAreas = table.getn(workAreas);
    local retWorkAreas = {};
    for i=1, numAreas do
        local x0 = workAreas[i][1];
        local z0 = workAreas[i][2];
        local x1 = workAreas[i][3];
        local z1 = workAreas[i][4];
        local x2 = workAreas[i][5];
        local z2 = workAreas[i][6];
        local dx0 = workAreas[i][7];
        local dz0 = workAreas[i][8];
        local dx1 = workAreas[i][9];
        local dz1 = workAreas[i][10];
        local dx2 = workAreas[i][11];
        local dz2 = workAreas[i][12];
        -- pick up
        local hx = x2 - x0;
        local hz = z2 - z0;
        local hLength = Utils.vector2Length(hx, hz);
        local hLength_2 = 0.5 * hLength;
        local wx = x1 - x0;
        local wz = z1 - z0;
        local wLength = Utils.vector2Length(wx, wz);
        local sx = x0 + (hx * 0.5) + ((wx/wLength)*hLength_2);
        local sz = z0 + (hz * 0.5) + ((wz/wLength)*hLength_2);
        local ex = x1 + (hx * 0.5) - ((wx/wLength)*hLength_2);
        local ez = z1 + (hz * 0.5) - ((wz/wLength)*hLength_2);
        local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz);
        local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez);
        local fillType1 = FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_GRASS];
        local liters1 = TipUtil.tipToGroundAroundLine(self, -math.huge, fillType1, sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil);
        local fillType2 = FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_DRYGRASS];
        local liters2 = TipUtil.tipToGroundAroundLine(self, -math.huge, fillType2, sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil);
		
		--MR : some lose when converting grass to hay
        local liters = -0.75*liters1 - liters2;
        
		--MR : when tedding, we want to "spread" the grass over the entire drop area, not make windrow... droparea should be "larger" and cross each other
		-- drop
		
		--[[
        local hx = dx2 - dx0;
        local hz = dz2 - dz0;
        local hLength = Utils.vector2Length(hx, hz);
        local hLength_2 = 0.5 * hLength;
        local wx = dx1 - dx0;
        local wz = dz1 - dz0;
        local wLength = Utils.vector2Length(wx, wz);
        local sx = dx0 + (hx * 0.5) + ((wx/wLength)*hLength_2);
        local sz = dz0 + (hz * 0.5) + ((wz/wLength)*hLength_2);
        local ex = dx1 + (hx * 0.5) - ((wx/wLength)*hLength_2);
        local ez = dz1 + (hz * 0.5) - ((wz/wLength)*hLength_2);
        local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz);
        local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez);
        local toDrop = accumulatedWorkAreaValues[i] + liters;
        local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, toDrop, FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_DRYGRASS], sx,sy,sz, ex,ey,ez, hLength_2, nil, self.tedderLineOffset, false, nil, false);
		--]]
		
		local sx = 0.5*(dx0+dx2)
		local sz = 0.5*(dz0+dz2)
		local sy = 1 + getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz)
		
		--last corner of the "drop area" (corner 0 = start, corner 1 = width, corner 2 = end) 
		local dx3 = dx2 + dx1-dx0
		local dz3 = dz2 + dz1-dz0
		
		local ex = 0.5*(dx1+dx3)
		local ez = 0.5*(dz1+dz3)
		local ey = 1 + getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez)
		
		--we want 30cm wider on each side of the drop area
		local len = Utils.vector2Length(ex-sx, ez-sz)		
		if len>0 then	
			local rndOffset = 0.15 + 0.3*math.random() -- between 15 and 45cm crossing between drop area
			local diffX = rndOffset*(ex-sx)/len
			sx = sx - diffX
			ex = ex + diffX
			local diffZ = rndOffset*(ez-sz)/len
			sz = sz - diffZ
			ez = ez + diffZ
		end
		
		
		
		--print("test - sx="..tostring(sx) .. " - sy="..tostring(sy).." - sz="..tostring(sz).." - ex="..tostring(ex) .. " - ey="..tostring(ey).." - ez="..tostring(ez))
		
		local toDrop = accumulatedWorkAreaValues[i] + liters
		local dropped, lineOffset = TipUtil.tipToGroundAroundLine(self, toDrop, FruitUtil.fruitTypeToWindrowFillType[FruitUtil.FRUITTYPE_DRYGRASS], sx,sy,sz, ex,ey,ez, 10, 10, self.tedderLineOffset, false, nil, false)
		
        self.tedderLineOffset = lineOffset;
        local remain = toDrop - dropped;
        accumulatedWorkAreaValues[i] = remain;
        workAreas[i][13] = remain;
        --if liters > remain then -- MR : what ?
		if dropped>0 then
            table.insert(retWorkAreas, workAreas[i]);
        end		
		-------------------------------------------------------------------
		--MR
		--update total liters teded
		if self.mrTedder.mrUseTeddingDependantPtoPower then
			--print(tostring(g_currentMission.time) .. " liters teded="..tostring(liters))
			self.mrTedder.mrTededLitersBuffer = self.mrTedder.mrTededLitersBuffer + liters
		end
    end;
	return retWorkAreas;
    
end



--************************************************************************************************************************************************************
--pto torque depends on the liters per second teded by the tedder
Tedder.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower + self.mrTedder.mrCurrentTeddingDependantPower
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end

--************************************************************************************************************************************************************
--MR : display debug info
Tedder.mrUpdate=function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	if self:getIsTurnedOn() then
	
		if self.mrTedder.mrUseTeddingDependantPtoPower then

			--print(tostring(g_currentMission.time) .. " test Tedder - mrLitersPerSecondEmptyingSpeed = "..tostring(self.mrTedder.mrLitersPerSecondEmptyingSpeed) .. " - buffer="..tostring(self.mrTedder.mrTededLitersBuffer))
			
			self.mrTedder.mrTededLitersBuffer = math.max(0, self.mrTedder.mrTededLitersBuffer-self.mrTedder.mrLitersPerSecondEmptyingSpeed)
			
			--update the buffer (try to empty it. The faster we want to empty it = the more PTO power required)
			if self.mrTedder.mrTededLitersBuffer > 2*self.mrTedder.mrLitersPerSecondEmptyingSpeed then -- 2s
				self.mrTedder.mrLitersPerSecondEmptyingSpeed = self.mrTedder.mrLitersPerSecondEmptyingSpeed + dt/50 -- 20 per second
			elseif self.mrTedder.mrTededLitersBuffer ==0 then
				self.mrTedder.mrLitersPerSecondEmptyingSpeed = math.max(0, self.mrTedder.mrLitersPerSecondEmptyingSpeed - dt/50) -- 20 per second
			end
			
			self.mrTedder.mrCurrentTeddingDependantPower = self.mrTedder.mrTeddingDependantPtoPower * self.mrTedder.mrLitersPerSecondEmptyingSpeed
			
		end
		
	end
	
	if Vehicle.debugRendering and self.isServer and self:getIsTurnedOn() then
		
		local vehicle = self
		if self.attacherVehicle then
			vehicle = self.attacherVehicle
		end
		if (vehicle.isEntered and vehicle.isClient and vehicle.isControlled) or self:getIsActiveForInput()  then
			local turnedOnPtoPower = 0
			
			if self.powerConsumer then
				turnedOnPtoPower = self.powerConsumer.mrNoLoadPtoPower				 
			end
			
			local teddingDependantPtoPower = 0
			local bufferLevel=0
			if self.mrTedder.mrUseTeddingDependantPtoPower then
				teddingDependantPtoPower = self.mrTedder.mrCurrentTeddingDependantPower
				bufferLevel = self.mrTedder.mrTededLitersBuffer
			end
			
			local totalPower = turnedOnPtoPower + teddingDependantPtoPower
		
		
			local str = string.format(" turnedOnPtoPower=%.1f\n teddingDependantPtoPower=%.1f\n lastTotalPower=%.1f\n Buffer level=%.0f", turnedOnPtoPower, teddingDependantPtoPower, totalPower, bufferLevel)
			renderText(0.74, 0.75, getCorrectTextSize(0.02), str);
		end
		
		
		
	end

end
Tedder.update = Utils.appendedFunction(Tedder.update, Tedder.mrUpdate);


