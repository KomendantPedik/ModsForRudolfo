﻿




--************************************************************************************************************************************************************
--
BaleWrapper.mrLoad = function(self, savegame)	
	if self.mrIsMrVehicle then	
		self.mrBaleWrapper = {}
		self.mrBaleWrapper.ptoRpm = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baleWrapper#ptoRpm"), 540)
		self.mrBaleWrapper.wrappingPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baleWrapper#wrappingPtoPower"), 0)		
		
		self.mrBaleWrapper.firstUpdateRequired = true
		
		
		
		self.mrGetDoConsumeWrappingPtoPower = BaleWrapper.mrGetDoConsumeWrappingPtoPower		
		self.mrUpdateWrapperBaleMass = BaleWrapper.mrUpdateWrapperBaleMass		
		--20170913 - not needed anymore since we now keep the same fillLevel but change the density of silage grass bales
		--[[
		if g_seasons==nil then
			self.pickupWrapperBale = Utils.overwrittenFunction(self.pickupWrapperBale, BaleWrapper.mrPickupWrapperBale)
		end--]]
		
		
		--node to apply the additionnalBaleMass to
		self.mrBaleWrapper.baleMassNode = Utils.indexToObject(self.components, getXMLString(self.xmlFile, "vehicle.moreRealistic.baleWrapper#baleMassNodeIndex"))
		if self.mrBaleWrapper.baleMassNode==nil then
			self.mrBaleWrapper.baleMassNode = self.components[1].node
		end		
		self.mrBaleWrapper.baleMassNodeEmptyMass = 0
		self.mrBaleWrapper.currentBaleMass = 0		
	end
	
end
BaleWrapper.load = Utils.appendedFunction(BaleWrapper.load, BaleWrapper.mrLoad)

--************************************************************************************************************************************************************
--
BaleWrapper.mrPostLoad = function(self, savegame)
	
	if self.mrIsMrVehicle then	
		--check if the "powerConsumer" specialization is present or not
		--BaleWrapper vehicleType does not have the "powerConsumer" specialization
		--but BalerWrapper vehicleType does
		if self.getConsumedPtoTorque==nil then
			self.getConsumedPtoTorque = BaleWrapper.mrGetConsumedPtoTorque
			self.getPtoRpm = BaleWrapper.mrGetPtoRpm
		else
			self.getConsumedPtoTorque = Utils.overwrittenFunction(self.getConsumedPtoTorque, BaleWrapper.mrGetConsumedPtoTorque2)
		end
	end
	
end
BaleWrapper.postLoad = Utils.appendedFunction(BaleWrapper.postLoad, BaleWrapper.mrPostLoad)



--************************************************************************************************************************************************************
--
BaleWrapper.mrUpdate = function(self, dt)	
	if self.mrIsMrVehicle then	
		if self.firstTimeRun and self.mrBaleWrapper.firstUpdateRequired then
			self.mrBaleWrapper.baleMassNodeEmptyMass = getMass(self.mrBaleWrapper.baleMassNode)
			self:mrUpdateWrapperBaleMass()
			self.mrBaleWrapper.firstUpdateRequired = false
		end
	end
	
end
BaleWrapper.update = Utils.appendedFunction(BaleWrapper.update, BaleWrapper.mrUpdate)



--************************************************************************************************************************************************************
--update the vehicle mass when a bale is "hold" by the wrapper
BaleWrapper.mrDoStateChange = function(self, id, nearestBaleServerId)
	if self.mrIsMrVehicle then			
		if id == BaleWrapper.CHANGE_GRAB_BALE or id == BaleWrapper.CHANGE_WRAPPER_BALE_DROPPED then
			self:mrUpdateWrapperBaleMass()		
		end		
	end
end
BaleWrapper.doStateChange = Utils.appendedFunction(BaleWrapper.doStateChange, BaleWrapper.mrDoStateChange)

--************************************************************************************************************************************************************
--
BaleWrapper.mrUpdateWrapperBaleMass = function(self)
	if self.isServer and self.firstTimeRun then
		
		local baleMass = 0
		local baleServerId = self.baleGrabber.currentBale
		if baleServerId == nil then
			baleServerId = self.currentWrapper.currentBale
		end
		if baleServerId ~= nil then
			local bale = networkGetObject(baleServerId)
			if bale ~= nil then
				baleMass = getMass(bale.nodeId)
			end
		end
		--print("test - update wrapper bale mass="..tostring(baleMass))
		
		if self.fillMassNode==nil then -- this is not a fillable vehicle, and so, we have to handle the setMass
			setMass(self.mrBaleWrapper.baleMassNode, self.mrBaleWrapper.baleMassNodeEmptyMass + baleMass)
		else
			--fillable vehicle. The bale mass has to be managed by the "fillable" class
			self.mrBaleWrapper.currentBaleMass = baleMass
		end
		
		
	end --self.isServer
end

--************************************************************************************************************************************************************
BaleWrapper.mrGetConsumedPtoTorque = function(self)
	if self.mrBaleWrapper.ptoRpm>1 then
		local power = 0		
		if self:mrGetDoConsumeWrappingPtoPower() then
			power = power + self.mrBaleWrapper.wrappingPtoPower
		end
	
		return power/(self.mrBaleWrapper.ptoRpm*math.pi/30)
	end
	return 0
end

--************************************************************************************************************************************************************
-- overwritten of the current GetConsumedPtoTorque function (example : for baler-wrapper vehicle
BaleWrapper.mrGetConsumedPtoTorque2 = function(self, superFunc)
	
	local result = superFunc(self)
	result = result + BaleWrapper.mrGetConsumedPtoTorque(self)
	
	return result
end

--************************************************************************************************************************************************************
BaleWrapper.mrGetPtoRpm = function(self)
	if self:mrGetDoConsumeWrappingPtoPower() then
		return self.mrBaleWrapper.ptoRpm
	else
		return 0
	end
end

--************************************************************************************************************************************************************
BaleWrapper.mrGetDoConsumeWrappingPtoPower = function(self)
	--[[local doConsumePower = false
	
	if self.mrBaleWrapper.wrappingPtoPower>0 then
		if self.activeAnimations~=nil then		
			if next(self.activeAnimations)~=nil then
				doConsumePower = true
			end		
		end
	end
	
	return doConsumePower--]]
	return self.baleWrapperState == BaleWrapper.STATE_WRAPPER_WRAPPING_BALE
end

--************************************************************************************************************************************************************
-- call by fillable.mrUpdate
BaleWrapper.mrGetAdditionalMass = function(self)
	return self.mrBaleWrapper.currentBaleMass
end


--[[
--************************************************************************************************************************************************************
-- update fillLevel when changing a grass bale to a silage bale (not the same density = we don't want a 500kgs bale becoming a 800kgs bale magically)
function BaleWrapper.mrPickupWrapperBale(self, superFunc, bale, baleType)

	if not self.mrIsMrVehicle then	
		return superFunc(self, bale, baleType)
	end

    if baleType ~= nil and bale.i3dFilename ~= baleType.wrapperBaleFilename then
        local x,y,z = getWorldTranslation(bale.nodeId)
        local rx,ry,rz = getWorldRotation(bale.nodeId)
        local fillLevel = bale.fillLevel		
        local baleValueScale = bale.baleValueScale
				
        bale:delete()
        bale = Bale:new(self.isServer, self.isClient)
        bale:load(baleType.wrapperBaleFilename, x,y,z, rx,ry,rz, fillLevel)
        bale.baleValueScale = baleValueScale
				
		--MR : check density of current filltype compared to new filltype
		local newDensity = FillUtil.fillTypeIndexToDesc[bale.fillType].massPerLiter
		if newDensity>0 then
			--always compare with grass density, even if the original bale type was "hay"
			local grassDensity = FillUtil.fillTypeIndexToDesc[FillUtil.FILLTYPE_GRASS].massPerLiter
			bale.fillLevel = bale.fillLevel * 0.9 *  grassDensity/newDensity --0.9 factor because IRL, the grass bale can lose some weight (water) before being wrapped (and we don't want to get a very high amount of silage from grass in the game since wrapping a bale doesn't need to wait for the bale content to ferment to get silage)
		end
		
        bale:register()
    end
    -- found bale
    g_server:broadcastEvent(BaleWrapperStateEvent:new(self, BaleWrapper.CHANGE_GRAB_BALE, networkGetObjectId(bale)), true, nil, self)
	
end--]]