﻿--******************************************************************************************************************
--set the "mrUpdateFuelUsage" function
Motorized.mrLoad = function(self, savegame)

	if self.mrIsMrVehicle then
		self.mrPrevUpdateFuelUsage = self.updateFuelUsage
		self.updateFuelUsage = Motorized.mrUpdateFuelUsage
		--print("test - fuel usage=" .. self.fuelUsage)
		self.mrLastFuelRate = 0
		
		--20171209 - slip hud
		self.mrSlipHud = VehicleHudUtils.loadHud(self, self.xmlFile, "mrSlipPercent");
		
	end

end
Motorized.load = Utils.appendedFunction(Motorized.load, Motorized.mrLoad)

--******************************************************************************************************************
--load mr boost parameters if present
Motorized.mrLoadMotor = function(self, xmlFile, motorId)

	if self.mrIsMrVehicle then

		local key, motorId = Vehicle.getXMLConfigurationKey(xmlFile, motorId, "vehicle.motorConfigurations.motorConfiguration", "vehicle", "motor")
		local fallbackConfigKey = "vehicle.motorConfigurations.motorConfiguration(0)"
		local fallbackOldKey = "vehicle"
		
		self.mrBoost = {}
		self.mrBoost.ptoBoostTorqueRatio = Vehicle.getConfigurationValue(xmlFile, key, ".mrBoost", "#ptoBoostTorqueRatio", getXMLFloat, nil, fallbackConfigKey, fallbackOldKey)
		self.mrBoost.speedBoostTorqueRatio = Vehicle.getConfigurationValue(xmlFile, key, ".mrBoost", "#speedBoostTorqueRatio", getXMLFloat, nil, fallbackConfigKey, fallbackOldKey)
		self.mrBoost.speedBoostStartKph = Vehicle.getConfigurationValue(xmlFile, key, ".mrBoost", "#speedBoostStartKph", getXMLFloat, nil, fallbackConfigKey, fallbackOldKey)
		self.mrBoost.speedBoostFullKph = Vehicle.getConfigurationValue(xmlFile, key, ".mrBoost", "#speedBoostFullKph", getXMLFloat, nil, fallbackConfigKey, fallbackOldKey)
		self.mrBoost.maxBoostRatio = Vehicle.getConfigurationValue(xmlFile, key, ".mrBoost", "#maxBoostRatio", getXMLFloat, nil, fallbackConfigKey, fallbackOldKey)
		
		self.mrBoost.featurePtoBoost = (self.mrBoost.maxBoostRatio ~= nil and self.mrBoost.ptoBoostTorqueRatio~=nil)
		self.mrBoost.featureSpeedBoost = (self.mrBoost.maxBoostRatio ~= nil and self.mrBoost.speedBoostTorqueRatio~=nil and self.mrBoost.speedBoostStartKph~=nil and self.mrBoost.speedBoostFullKph~=nil)
		
		if self.mrBoost.featureSpeedBoost then			
			self.mrBoost.speedBoostStartMps = self.mrBoost.speedBoostStartKph / 3.6
			self.mrBoost.speedBoostFullMps = self.mrBoost.speedBoostFullKph / 3.6
		end
		
		self.mrGetCurrentBoostRatio = Motorized.mrGetCurrentBoostRatio
		
		self.mrAvgFuelConsumption = 0
		self.mrDisplayFuelUsageTime = 0
		
	end

end
Motorized.loadMotor = Utils.appendedFunction(Motorized.loadMotor, Motorized.mrLoadMotor);

--******************************************************************************************************************
--set more realistic fuel consumption
--stop the engine when the fuel tank is empty
--stop the engine when the vehicle is sunk into the water
Motorized.mrUpdateFuelUsage = function(self, dt)

	self.mrLastFuelRate = 0

	if not self.mrUseMrTransmission then 	
		if self.mrPrevUpdateFuelUsage~=nil then			
			return self.mrPrevUpdateFuelUsage(self, dt)
		end
		return false --this call should not happen ? it means another script is calling the "mrUpdateFuelUsage" for a vehicle without the motorized specialization (or for a vehicle that is not "mr")
	end
	
	--** realistic **-
	local fuelUsed = 0
	
	
	--print("test mrUpdateFuelUsage - self.mrUseMrTransmission="..tostring(self.mrUseMrTransmission) .." - self.isMotorStarted="..tostring(self.isMotorStarted) .." - self.motor="..tostring(self.motor) .. " - self.motor.maxMotorPower="..tostring(self.motor.maxMotorPower))
	
	if self.isMotorStarted and self.motor.mrMaxTorque>0 then		
		--MR : fuelUsage factor not taken into account (MR = realistic fuel usage = already a lot of time to empty a fuel tank)
		--local fuelUsageFactor = 1
		--if g_currentMission.missionInfo.fuelUsageLow then -- not really useful with MR mode since an avg tractor can work between 6 to 10 real hours without refueling
		--	fuelUsageFactor = 0.7
		--end		
		
		--print(tostring(g_currentMission.time) .. " motor started - equalizedMotorRpm=" .. tostring(self.motor.equalizedMotorRpm) .. " - total torque in use = " .. tostring(self.motor.mrLastEngineOutputTorque) .. " - me="..tostring(self.configFileName))
		
		local totalTorqueInUse = self.motor.mrLastEngineOutputTorque;
		--totalTorqueInUse = math.max(0.07*self.motor.mrMaxTorque, totalTorqueInUse); -- minimum fuel usage (idling) = 7% of maxtorque		
		--totalTorqueInUse = math.max(0.05*self.motor.mrMaxTorque, totalTorqueInUse); -- minimum fuel usage (idling) = 5% of maxtorque //20170419
		--20170506 - only apply minimum fuel use at idle
		if self.motor.equalizedMotorRpm<=(1.1*self.motor.mrIdleEngineRpm) then
			totalTorqueInUse = math.max(0.05*self.motor.mrMaxTorque, totalTorqueInUse)
		end
				
		--efficiency factor
		local effFx = 1
		local effTorque = 0.8*self.motor.mrMaxTorque
		--the closer to the maxTorque we are, the better the fuel efficiency (not 100% accurate, of course, but this is what we use to get some "reasonnable" approximation for this game)
		-- 0 => 1.8
		-- 0.3 => 1.2
		-- 0.8 => 1
		-- 1 => 1
		if totalTorqueInUse<0.3*effTorque then
			effFx = 1.8-2*totalTorqueInUse/effTorque;
		elseif totalTorqueInUse<effTorque then
			effFx = 1.286-0.286*totalTorqueInUse/effTorque;
		end;		
		
		--only take into account engine current power. To be more real, should take into account specific consumption of the engine (example : higher rpm and lower load = more fuel used for the same power as less engine rpm and more load)
		fuelUsed = effFx * (self.mrFuelUsage * dt) * (self.motor.equalizedMotorRpm*math.pi/30*totalTorqueInUse) --fuelusage in Liter per KW per millisecond
		
		--print("fuel usage : totalTorqueInUse="..tostring(totalTorqueInUse) .. " - pto torque=" .. tostring(self.motor.mrLastEngineTorqueConsumedByPto) .. " - engine max power(KW)="..tostring(self.motor.mrMaxPower) .. " - rpm="..tostring(self.motor.equalizedMotorRpm));
		--print(string.format("fuel usage=%1.2f, equalizedRpm=%4.0f, nonClampedRpm=%4.2f, clutchRpm=%4.2f, motorLoad=%4.2f speed=%2.2f",3600000*fuelUsed/dt,self.motor.equalizedMotorRpm,self.motor.nonClampedMotorRpm, self.motor.clutchRpm,1000*self.motor.motorLoad,self.lastSpeedReal*3600));
		
		if Vehicle.debugRendering and self.isControlled and self.isClient then --display fuel usage in Litre per hour
			if not self.mrDebugTotalFuelConsumption then self.mrDebugTotalFuelConsumption=0  end
			self.mrDebugTotalFuelConsumption = self.mrDebugTotalFuelConsumption + fuelUsed
			
			if not self.mrDebugFuelConsumptionAVG then self.mrDebugFuelConsumptionAVG=0  end
			if not self.mrDebugTotalFuelConsumptionStartTime then self.mrDebugTotalFuelConsumptionStartTime=0 end
			
			if (g_currentMission.time-self.mrDebugTotalFuelConsumptionStartTime)>3000 then
				self.mrDebugFuelConsumptionAVG = self.mrDebugTotalFuelConsumption * 1000*3600 / (g_currentMission.time-self.mrDebugTotalFuelConsumptionStartTime)
				self.mrDebugTotalFuelConsumptionStartTime = g_currentMission.time
				self.mrDebugTotalFuelConsumption = 0
			end;
		
			if not self.mrLastFuelConsumption then self.mrLastFuelConsumption=0 end
			self.mrLastFuelConsumption = 0.01 * 3600000*fuelUsed/dt + 0.99 * self.mrLastFuelConsumption
			renderText(0.2, 0.65, getCorrectTextSize(0.02), string.format("Fuel usage: %1.1f L/H", 3600000*fuelUsed/dt))
			renderText(0.34, 0.65, getCorrectTextSize(0.02), string.format("Avg  : %1.1f L/H", self.mrDebugFuelConsumptionAVG))
		end;
	
	else
	
		self.mrAvgFuelConsumption = 0
		
	end
	--** end realistic **-
	
	
	if fuelUsed > 0 then
		
		--20170707 - store the last fuel rate for other mods if needed
		self.mrLastFuelRate = fuelUsed*3600000/dt -- liters per hour
	
	    if not self:getIsHired() or not g_currentMission.missionInfo.helperBuyFuel then
	        self:setFuelFillLevel(self.fuelFillLevel-fuelUsed);
	        g_currentMission.missionStats:updateStats("fuelUsage", fuelUsed);
	    elseif self:getIsHired() and g_currentMission.missionInfo.helperBuyFuel then
	        local delta = fuelUsed * g_currentMission.economyManager:getPricePerLiter(FillUtil.FILLTYPE_FUEL)
	        g_currentMission.missionStats:updateStats("expenses", delta);
	        g_currentMission:addSharedMoney(-delta, "purchaseFuel");
			--20171203 - add fuel usage when the helper autobuy it too
			g_currentMission.missionStats:updateStats("fuelUsage", fuelUsed);
	    end
	end
	
	if self.fuelUsageHud ~= nil then
	    --VehicleHudUtils.setHudValue(self, self.fuelUsageHud, fuelUsed*1000/dt*60*60);
		self.mrAvgFuelConsumption = 0.9 * self.mrAvgFuelConsumption + fuelUsed*360000/dt; --liter per hour  (0.9*avg + 0.1*actual)
		if g_currentMission.time>self.mrDisplayFuelUsageTime then
			self.mrDisplayFuelUsageTime = g_currentMission.time + 1000; --refresh fuel usage every 1s
			VehicleHudUtils.setHudValue(self, self.fuelUsageHud, self.mrAvgFuelConsumption); -- MR 20170424 - AVG value
		end
	end
	
	--MR edit = stop the engine when the vehicle is "sunk" into the water or when the fuel tank is empty
	if self.isMotorStarted and (self.isBroken or self.fuelFillLevel==0) then
		self:stopMotor(true)
	end
	
	return true
end

--******************************************************************************************************************
--engine sound depends less on the speed
Motorized.mrUpdate = function(self, superFunc, dt)
	
		if not self.mrIsMrVehicle then return superFunc(self, dt); end;
	
	    if self.isClient then
	        if self.isEntered and self:getIsActiveForInput(false) and not g_currentMission.missionInfo.automaticMotorStartEnabled then
	            if InputBinding.hasEvent(InputBinding.TOGGLE_MOTOR_STATE) then
	                if not self:getIsHired() then
	                    if self.isMotorStarted then
	                        self:stopMotor()
	                    else
	                        self:startMotor()
	                    end
	                end
	            end
	        end
	    end
	
	    Utils.updateRotationNodes(self, self.motorTurnedOnRotationNodes, dt, self:getIsMotorStarted());
	
	    if self:getIsMotorStarted() then
			--[[ MR : only for client
	        local accInput = 0;
	        if self.axisForward ~= nil then
	            accInput = -self.axisForward;
	        end
	        if self.cruiseControl ~= nil and self.cruiseControl.state ~= Drivable.CRUISECONTROL_STATE_OFF then
	            accInput = 1;
	        end--]]
	        if self.isClient then
				-------------------------------------------------------------------------------------------------------------
				-- MR : only for client, useless for server
				local accInput = 0;
				if self.axisForward ~= nil then
					accInput = -self.axisForward;
				end
				if self.cruiseControl ~= nil and self.cruiseControl.state ~= Drivable.CRUISECONTROL_STATE_OFF then
					accInput = 1;
				end
				-------------------------------------------------------------------------------------------------------------
			
	            if self:getIsActiveForSound() then
	                if not SoundUtil.isSamplePlaying(self.sampleMotorStart, 1.5*dt) then
	                    SoundUtil.playSample(self.sampleMotor, 0, 0, nil);
	                    SoundUtil.playSample(self.sampleMotorRun, 0, 0, 0);
	                    SoundUtil.playSample(self.sampleMotorLoad, 0, 0, 0);
	                    SoundUtil.playSample(self.sampleGearbox, 0, 0, 0);
	                    SoundUtil.playSample(self.sampleRetarder, 0, 0, 0);
	
	                    if self.brakeLightsVisibility then
	                        self.brakeLightsVisibilityWasActive = true;
	                        self.maxDecelerationDuringBrake = math.max(self.maxDecelerationDuringBrake, math.abs(accInput));
	                    end
	                    if self.brakeLightsVisibilityWasActive and not self.brakeLightsVisibility then
	                        self.brakeLightsVisibilityWasActive = false;
	
	                        local factor = self.maxDecelerationDuringBrake;
	                        self.maxDecelerationDuringBrake = 0;
	
	                        local airConsumption = self:getMaximalAirConsumptionPerFullStop();
	                        -- print( string.format(" -----> factor = %.2f // %.2f ", factor, airConsumption) );
	                        airConsumption = factor * airConsumption;
	                        self.brakeCompressor.fillLevel = math.max(0, self.brakeCompressor.fillLevel - airConsumption); --implementCount * self.brakeCompressor.capacity * 0.05);
	                    end
	
	                    if self.brakeCompressor.fillLevel < self.brakeCompressor.refillFilllevel then
	                        self.brakeCompressor.doFill = true;
	                    end
	                    if self.brakeCompressor.doFill and self.brakeCompressor.fillLevel == self.brakeCompressor.capacity then
	                        self.brakeCompressor.doFill = false;
	                    end
	                    if self.brakeCompressor.doFill then
	                        self.brakeCompressor.fillLevel = math.min(self.brakeCompressor.capacity, self.brakeCompressor.fillLevel + self.brakeCompressor.fillSpeed * dt);
	                    end
	
	                    if Vehicle.debugRendering then
	                        renderText(0.3, 0.16, getCorrectTextSize(0.02), string.format("brakeCompressor.fillLevel = %.1f", 100*(self.brakeCompressor.fillLevel / self.brakeCompressor.capacity) ));
	                    end
	
	                    if not self.brakeCompressor.doFill then
	                        if self.brakeCompressor.runSoundActive then
	                            SoundUtil.stopSample(self.sampleBrakeCompressorRun, true);
	                            SoundUtil.playSample(self.sampleBrakeCompressorStop, 1, 0, nil);
	                            self.brakeCompressor.startSoundPlayed = false;
	                            self.brakeCompressor.runSoundActive = false;
	                        end
	                    elseif not SoundUtil.isSamplePlaying(self.sampleBrakeCompressorStop, 1.5*dt) then
	                        if not self.brakeCompressor.startSoundPlayed then
	                            self.brakeCompressor.startSoundPlayed = true;
	                            SoundUtil.playSample(self.sampleBrakeCompressorStart, 1, 0, nil);
	                        else
	                            if not SoundUtil.isSamplePlaying(self.sampleBrakeCompressorStart, 1.5*dt) and not self.brakeCompressor.runSoundActive then
	                                self.brakeCompressor.runSoundActive = true;
	                                SoundUtil.playSample(self.sampleBrakeCompressorRun, 0, 0, nil);
	                            end
	                        end
	                    end
	                end
	
	                if self.compressionSoundTime <= g_currentMission.time then
	                    SoundUtil.playSample(self.sampleAirReleaseValve, 1, 0, nil);
	                    self.compressionSoundTime = g_currentMission.time + math.random(10000, 40000);
	                end
	
	                if self.sampleCompressedAir.sample ~= nil then
	                    if self.movingDirection > 0 and self.lastSpeed > self.motor:getMaximumForwardSpeed()*0.0002 then -- faster than 20% of max speed
	                        if accInput < -0.05 then
	                            -- play the compressor sound if we drive fast enough and brake
	                            if not self.compressedAirSoundEnabled then
	                                SoundUtil.playSample(self.sampleCompressedAir, 1, 0, nil);
	                                self.compressedAirSoundEnabled = true;
	                            end
	                        else
	                            self.compressedAirSoundEnabled = false;
	                        end
	                    end
	                end
	
	                SoundUtil.stop3DSample(self.sampleMotor);
	                SoundUtil.stop3DSample(self.sampleMotorRun);
	                SoundUtil.stop3DSample(self.sampleGearbox);
	                SoundUtil.stop3DSample(self.sampleRetarder);
	            else
	                SoundUtil.play3DSample(self.sampleMotor);
	                SoundUtil.play3DSample(self.sampleMotorRun);
	            end
	
	            -- adjust pitch and volume of samples
	            if (self.wheels ~= nil and table.getn(self.wheels) > 0) or (self.dummyWheels ~= nil and table.getn(self.dummyWheels) > 0) then
	
	                if self.sampleReverseDrive.sample ~= nil then
	                    if (accInput < 0 or accInput == 0) and (self:getLastSpeed() > 3 and self.movingDirection ~= self.reverserDirection) then
	                        if self:getIsActiveForSound() then
	                            SoundUtil.playSample(self.sampleReverseDrive, 0, 0, nil);
	                        end
	                    else
	                        SoundUtil.stopSample(self.sampleReverseDrive);
	                    end
	                end
	
	                local minRpm = self.motor:getMinRpm();
	                local maxRpm = self.motor:getMaxRpm();
	
	                local maxSpeed;
	                if self.movingDirection >= 0 then
	                    maxSpeed = self.motor:getMaximumForwardSpeed()*0.001;
	                else
	                    maxSpeed = self.motor:getMaximumBackwardSpeed()*0.001;
	                end
	
	                local motorRpm = self.motor:getEqualizedMotorRpm();
	                -- Increase the motor rpm to the max rpm if faster than 75% of the full speed
					--MR : not useful
	                --if self.movingDirection > 0 and self.lastSpeed > 0.75*maxSpeed and motorRpm < maxRpm then
	                --    motorRpm = motorRpm + (maxRpm - motorRpm) * math.min((self.lastSpeed-0.75*maxSpeed) / (0.25*maxSpeed), 1);
	                --end
	                -- The actual rpm offset is 50% from the motor and 50% from the speed
	                -- local targetRpmOffset = (motorRpm - minRpm)*0.5 + math.min(self.lastSpeed/maxSpeed, 1)*(maxRpm-minRpm)*0.5;
					local targetRpmOffset = (motorRpm - minRpm)*0.8 + math.min(self.lastSpeed/maxSpeed, 1)*(maxRpm-minRpm)*0.2; --MR 80% from engine and 20% from speed
	
	                if Vehicle.debugRendering then
	                    renderText(0.3, 0.14, getCorrectTextSize(0.02), string.format("getLastMotorRpm() = %.2f", self.motor:getLastMotorRpm() ));
	                    renderText(0.3, 0.12, getCorrectTextSize(0.02), string.format("getEqualziedMotorRpm() = %.2f", self.motor:getEqualizedMotorRpm() ));
	                    renderText(0.3, 0.10, getCorrectTextSize(0.02), string.format("targetRpmOffset = %.2f", targetRpmOffset ));
	                end
	
	
	                local alpha = math.pow(0.01, dt*0.001);
	                local roundPerMinute = targetRpmOffset + alpha*(self.lastRoundPerMinute-targetRpmOffset);
	
	                self.lastRoundPerMinute = roundPerMinute;
	
	                local roundPerSecondSmoothed = roundPerMinute / 60;
	
	                if self.sampleMotor.sample ~= nil then
	                    --local motorSoundPitch = math.min(self.sampleMotor.pitchOffset + self.motorSoundPitchScale*math.abs(roundPerSecondSmoothed), self.motorSoundPitchMax);
						local motorSoundPitch = math.min(self.sampleMotor.pitchOffset + self.motorSoundPitchScale*math.abs(roundPerSecondSmoothed), 2);--MR allow engine over rpm when the tractor get too much speed going downhill for example
	                    SoundUtil.setSamplePitch(self.sampleMotor, motorSoundPitch);
	
	                    local deltaVolume = (self.sampleMotor.volume - self.motorSoundVolumeMin) * math.max(0.0, math.min(1.0, self:getLastSpeed()/self.motorSoundVolumeMinSpeed))
	                    SoundUtil.setSampleVolume(self.sampleMotor, math.max(self.motorSoundVolumeMin, self.sampleMotor.volume - deltaVolume));
	                end;
	
	                if self.sampleMotorRun.sample ~= nil then
	                    --local motorSoundRunPitch = math.min(self.sampleMotorRun.pitchOffset + self.motorSoundRunPitchScale*math.abs(roundPerSecondSmoothed), self.motorSoundRunPitchMax);
	                    local motorSoundRunPitch = math.min(self.sampleMotorRun.pitchOffset + self.motorSoundRunPitchScale*math.abs(roundPerSecondSmoothed), 2);--MR allow engine over rpm when the tractor get too much speed going downhill for example
						SoundUtil.setSamplePitch(self.sampleMotorRun, motorSoundRunPitch);
	
	                    local runVolume = roundPerMinute/(maxRpm - minRpm);
	                    if math.abs(accInput) < 0.01 or Utils.sign(accInput) ~= self.movingDirection or ptoVolume == 0 then
	                        runVolume = runVolume * 0.9;
	                    end;
	                    runVolume = Utils.clamp(runVolume, 0.0, 1.0);
	
	                    if Vehicle.debugRendering then
	                        renderText(0.3, 0.08, getCorrectTextSize(0.02), string.format("runVolume = %.2f", runVolume) );
	                    end
	
	                    if self.sampleMotorLoad.sample == nil then
	                        SoundUtil.setSampleVolume(self.sampleMotorRun, runVolume * self.sampleMotorRun.volume);
	                    else
	                        --local motorSoundLoadPitch = math.min(self.sampleMotorLoad.pitchOffset + self.motorSoundLoadPitchScale*math.abs(roundPerSecondSmoothed), self.motorSoundLoadPitchMax);
							local motorSoundLoadPitch = math.min(self.sampleMotorLoad.pitchOffset + self.motorSoundLoadPitchScale*math.abs(roundPerSecondSmoothed), 2);--MR allow engine over rpm when the tractor get too much speed going downhill for example
	                        SoundUtil.setSamplePitch(self.sampleMotorLoad, motorSoundLoadPitch);
	
	                        if self.motorSoundLoadFactor < self.actualLoadPercentage then
	                            self.motorSoundLoadFactor = math.min(self.actualLoadPercentage, self.motorSoundLoadFactor + dt/500);
	                        elseif self.motorSoundLoadFactor > self.actualLoadPercentage then
	                            self.motorSoundLoadFactor = math.max(self.actualLoadPercentage, self.motorSoundLoadFactor - dt/750);
	                        end
	                        if Vehicle.debugRendering then
	                            renderText(0.3, 0.06, getCorrectTextSize(0.02), string.format("motorSoundLoadFactor = %.2f", self.motorSoundLoadFactor) );
	                        end
	
	                        SoundUtil.setSampleVolume(self.sampleMotorRun, math.max(self.motorSoundRunMinimalVolumeFactor, (1.0 - self.motorSoundLoadFactor) * runVolume * self.sampleMotorRun.volume) );
	                        SoundUtil.setSampleVolume(self.sampleMotorLoad, math.max(self.motorSoundLoadMinimalVolumeFactor, self.motorSoundLoadFactor * runVolume * self.sampleMotorLoad.volume) );
	                    end
	                end
	
	                --
	                local pitchInfluence = 0;
	                local volumeInfluence = 0;
	                for _,wheel in pairs(self.wheels) do
	                    -- as in debug rendering, is this still correct?
	                    local susp = (wheel.netInfo.y - wheel.netInfo.yMin)/wheel.suspTravel - 0.2; -- If at yMin, we have -20% compression
	
	                    if wheel.netInfo.lastSusp == nil then
	                        wheel.netInfo.lastSusp = susp;
	                    end
	                    local delta = susp - wheel.netInfo.lastSusp;
	
	                    pitchInfluence = pitchInfluence + delta;
	                    volumeInfluence = volumeInfluence + math.abs(delta);
	                end
	                pitchInfluence = pitchInfluence / table.getn(self.wheels);
	                volumeInfluence = volumeInfluence / table.getn(self.wheels);
	
	                if pitchInfluence > self.pitchInfluenceFromWheels then
	                    self.pitchInfluenceFromWheels = math.min(pitchInfluence, self.pitchInfluenceFromWheels + dt/300);
	                elseif pitchInfluence < self.pitchInfluenceFromWheels then
	                    self.pitchInfluenceFromWheels = math.max(pitchInfluence, self.pitchInfluenceFromWheels - dt/300);
	                end
	
	                if volumeInfluence > self.volumeInfluenceFromWheels then
	                    self.volumeInfluenceFromWheels = math.min(volumeInfluence, self.volumeInfluenceFromWheels + dt/300);
	                elseif volumeInfluence < self.volumeInfluenceFromWheels then
	                    self.volumeInfluenceFromWheels = math.max(volumeInfluence, self.volumeInfluenceFromWheels - dt/300);
	                end
	
	                --renderText(0.8, 0.48, getCorrectTextSize(0.02), string.format("pitchInfluence = %.2f", pitchInfluence ));
	                --renderText(0.7, 0.60, getCorrectTextSize(0.02), string.format("self.pitchInfluenceFromWheels = %.5f", self.pitchInfluenceFromWheels ));
	                --renderText(0.7, 0.58, getCorrectTextSize(0.02), string.format("self.volumeInfluenceFromWheels = %.5f", self.volumeInfluenceFromWheels ));
	                --
	
	                if self.sampleGearbox.sample ~= nil then
	                    local speedFactor = Utils.clamp( (self:getLastSpeed() - 1) / math.ceil(self.motor:getMaximumForwardSpeed()*3.6), 0, 1);
	                    local pitchGearbox = Utils.lerp(self.sampleGearbox.pitchOffset, self.gearboxSoundPitchMax, speedFactor^self.gearboxSoundPitchExponent);
	                    local volumeGearbox = Utils.lerp(self.sampleGearbox.volume, self.gearboxSoundVolumeMax, speedFactor);
	
	                    if self.reverserDirection ~= self.movingDirection then
	                        speedFactor = Utils.clamp( (self:getLastSpeed() - 1) / math.ceil(self.motor:getMaximumBackwardSpeed()*3.6), 0, 1);
	                        pitchGearbox = Utils.lerp(self.sampleGearbox.pitchOffset, self.gearboxSoundReversePitchMax, speedFactor^self.gearboxSoundPitchExponent);
	                        volumeGearbox = Utils.lerp(self.sampleGearbox.volume, self.gearboxSoundReverseVolumeMax, speedFactor);
	                    end
	
	                    SoundUtil.setSamplePitch(self.sampleGearbox, pitchGearbox);
	                    SoundUtil.setSampleVolume(self.sampleGearbox, volumeGearbox);
	                end
	
	                if self.sampleRetarder.sample ~= nil then
	                    local speedFactor = Utils.clamp( (self:getLastSpeed() - self.retarderSoundMinSpeed) / math.ceil(self.motor:getMaximumForwardSpeed()*3.6), 0, 1);
	                    local pitchGearbox = Utils.lerp(self.sampleRetarder.pitchOffset, self.retarderSoundPitchMax, speedFactor);
	                    SoundUtil.setSamplePitch(self.sampleRetarder, pitchGearbox);
	
	                    local volumeRetarder = Utils.lerp(self.sampleRetarder.volume, self.retarderSoundVolumeMax, speedFactor);
	                    local targetVolume = 0.0;
	                    if accInput <= 0.0 and self:getLastSpeed() > self.retarderSoundMinSpeed and self.reverserDirection == self.movingDirection then
	                        if accInput > -0.9 then
	                            targetVolume = volumeRetarder;
	                        else
	                            targetVolume = self.sampleRetarder.volume;
	                        end
	                    end
	
	                    if self.retarderSoundActualVolume < targetVolume then
	                        self.retarderSoundActualVolume = math.min(targetVolume, self.retarderSoundActualVolume + dt/self.axisSmoothTime);
	                    elseif self.retarderSoundActualVolume > targetVolume then
	                        self.retarderSoundActualVolume = math.max(targetVolume, self.retarderSoundActualVolume - dt/self.axisSmoothTime);
	                    end
	                    SoundUtil.setSampleVolume(self.sampleRetarder, self.retarderSoundActualVolume);
	
	                    if Vehicle.debugRendering then
	                        renderText(0.8, 0.44, getCorrectTextSize(0.02), string.format("retarderSoundActualVolume = %.2f", self.retarderSoundActualVolume ));
	                        renderText(0.8, 0.42, getCorrectTextSize(0.02), string.format("getLastSpeed() = %.2f", self:getLastSpeed() ));
	                    end
	                end
	
	                if self.sampleBrakeCompressorRun.sample ~= nil then
	                    local pitchCompressor = math.min(self.sampleBrakeCompressorRun.pitchOffset + self.brakeCompressorRunSoundPitchScale*math.abs(roundPerSecondSmoothed), self.brakeCompressorRunSoundPitchMax);
	                    SoundUtil.setSamplePitch(self.sampleBrakeCompressorRun, pitchCompressor);
	                end
	
	            end
	        end
	
	        if self.isServer then
	            if not self:getIsHired() then
	                if self.lastMovedDistance > 0 then
	                    g_currentMission.missionStats:updateStats("traveledDistance", self.lastMovedDistance*0.001);
	                end
	            end
	
	            self:updateFuelUsage(dt)
	        end
	    end
	end
Motorized.update = Utils.overwrittenFunction(Motorized.update, Motorized.mrUpdate);

--******************************************************************************************************************
--update mrSlipHUD (incab) for modders
Motorized.mrUpdateTick = function(self, superFunc, dt)	
	if not self.mrIsMrVehicle then return; end;	
	if self.isClient then
        if self:getIsMotorStarted() then
            if self.mrSlipHud ~= nil then
				if self.hud1~=nil then
					VehicleHudUtils.setHudValue(self, self.mrSlipHud, self.hud1.grids.main.elements.mrSlip.avgSlipValue, 100);
				end;
			end;
		end;
	end;
end;
Motorized.updateTick = Utils.appendedFunction(Motorized.updateTick, Motorized.mrUpdateTick);

--******************************************************************************************************************
--with "mr", engine rpm can go farther than max rpm (when going downhill and being push by the trailer for example)
Motorized.readUpdateStream = function(self, streamId, timestamp, connection)
	if connection.isServer then
		local rpm = streamReadUIntN(streamId, 11);
		--rpm = rpm / 2047;
		rpm = 2 * self.motor:getMaxRpm() * rpm / 2047; --MR
		--local rpmRange = self.motor:getMaxRpm()- self.motor:getMinRpm();
		
		--print("test Motorized:readUpdateStream - rpm="..tostring(rpm) .." - rpmRange=" .. tostring(rpmRange) .. " - equalized rpm value = " .. tostring((rpm * rpmRange) + self.motor:getMinRpm()));
		
		--self.motor:setEqualizedMotorRpm( (rpm * rpmRange) + self.motor:getMinRpm() );
		self.motor:setEqualizedMotorRpm(rpm);
		
		local loadPercentage = streamReadUIntN(streamId, 7);
		self.actualLoadPercentage = loadPercentage / 127;

		if streamReadBool(streamId) then
			--local fuelFillLevel = streamReadUIntN(streamId, 15)/32767*self.fuelCapacity;
			local fuelFillLevel = streamReadUIntN(streamId, 10)/1023*self.fuelCapacity; --MR : no need for such a high precision, this is just the fuel fill level
			self:setFuelFillLevel(fuelFillLevel);
		end
	end
end
	
	
--******************************************************************************************************************
--with "mr", engine rpm can go farther than max rpm (when going downhill and being push by the trailer for example)	
Motorized.writeUpdateStream = function(self, streamId, connection, dirtyMask)
	if not connection.isServer then
		--local rpmRange = self.motor:getMaxRpm() - self.motor:getMinRpm();
		--local rpm = (self.motor:getEqualizedMotorRpm() - self.motor:getMinRpm()) / rpmRange;
		
		
		--print("test server - rpmRange="..tostring(rpmRange) .. " - getEqualizedMotorRpm="..tostring(self.motor:getEqualizedMotorRpm()) .. " - rpm="..tostring(rpm));

		local rpm = math.min(2*self.motor:getMaxRpm(), self.motor:getEqualizedMotorRpm()); --MR --max = 2 times the engine max rpm
		
		--rpm = math.floor(rpm * 2047);
		rpm = math.floor(2047 * rpm / (2*self.motor:getMaxRpm()));
		streamWriteUIntN(streamId, rpm, 11);

		streamWriteUIntN(streamId, 127 * self.actualLoadPercentage, 7);

		if streamWriteBool(streamId, bitAND(dirtyMask, self.motorizedDirtyFlag) ~= 0) then
			local percent = 0;
			if self.fuelCapacity ~= 0 then
				percent = Utils.clamp(self.fuelFillLevel / self.fuelCapacity, 0, 1);
			end
			--streamWriteUIntN(streamId, math.floor(percent*32767), 15);
			streamWriteUIntN(streamId, math.floor(percent*1023), 10); --MR : no need for such a high precision, this is just the fuel fill level
		end
	end
end



Motorized.mrGetCurrentBoostRatio = function(self, engineTorqueNeededByPtoInNm, motorizedWheelsSpdInMeterPerSecond)
	
	local torqueRatio = 1;
	
	if engineTorqueNeededByPtoInNm>0 and self.mrBoost.featurePtoBoost then
		torqueRatio = self.mrBoost.ptoBoostTorqueRatio;
	end
	if self.mrBoost.featureSpeedBoost then
		if torqueRatio<self.mrBoost.maxBoostRatio and motorizedWheelsSpdInMeterPerSecond>self.mrBoost.speedBoostStartMps then
			if motorizedWheelsSpdInMeterPerSecond>=self.mrBoost.speedBoostFullMps or self.mrBoost.speedBoostStartMps>=self.mrBoost.speedBoostFullMps then
				torqueRatio = math.min(self.mrBoost.maxBoostRatio, torqueRatio + self.mrBoost.speedBoostTorqueRatio);
			else
				torqueRatio = math.min(self.mrBoost.maxBoostRatio, torqueRatio + (self.mrBoost.speedBoostTorqueRatio-1) * (motorizedWheelsSpdInMeterPerSecond-self.mrBoost.speedBoostStartMps)/(self.mrBoost.speedBoostFullMps-self.mrBoost.speedBoostStartMps));
			end
		end
	end
	
	--print("test - mrGetCurrentBoostRatio - engineTorqueNeededByPtoInNm="..tostring(engineTorqueNeededByPtoInNm) .. " - motorizedWheelsSpdInMeterPerSecond="..tostring(motorizedWheelsSpdInMeterPerSecond) .. " - torqueRatio="..tostring(torqueRatio));
	
	return torqueRatio;

end


