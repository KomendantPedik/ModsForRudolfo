﻿RealisticSettings = {}

RealisticSettings.SAVE_FILENAME = "mrSettings.xml"

RealisticSettings.DISABLE_TERRAINCONTROL = true;

--------------------------------------------------------------------------------------------------------
-- "hijack" the FSCareerMissionInfo.saveToXML function to trigger our saving process
-- make use of the "xpcall" to catch any error and do not interrupt original game saving process 
--(CRITICAL not to lose any savegame file)
--------------------------------------------------------------------------------------------------------
function RealisticSettings.saveToXML(missionInfo)	
	local status, errorMsg = xpcall(RealisticSettings.saveDataToXml, RealisticSettings.errorHandler);
	if not status then
		RealisticUtils.printWarning("RealisticSettings.saveToXML", tostring(errorMsg), true) --tostring(errorMsg) in case something is also wrong here - errorMsg should be a string if status == false
	end
end
FSCareerMissionInfo.saveToXML = Utils.appendedFunction(FSCareerMissionInfo.saveToXML, RealisticSettings.saveToXML);


--------------------------------------------------------------------------------------------------------
-- basic error handling function that returns original error and stacktrace as a string
--------------------------------------------------------------------------------------------------------
function RealisticSettings.errorHandler(originalError)
	return tostring(originalError) .. "\n" .. debug.traceback()
end


--------------------------------------------------------------------------------------------------------
-- called by the globalListener of MR
--------------------------------------------------------------------------------------------------------
function RealisticSettings.loadDataFromXml()
	
	local filePath = RealisticSettings.getXmlPath();
	if filePath~=nil and fileExists(filePath) then
		local xmlFile = loadXMLFile("RealisticSettingsSaveXml", filePath);
		if xmlFile~=nil and xmlFile~=0 then
			--parse the file
			local xmlKeyPath = "moreRealisticSettings.settings"; --common path to all settings	
			
			local value = getXMLBool(xmlFile, xmlKeyPath .. ".disable_terrainControl");
			if value~=nil then RealisticSettings.DISABLE_TERRAINCONTROL = value; end;
			
			delete(xmlFile);
		end;
	end;	

end


--------------------------------------------------------------------------------------------------------
-- create xml save file and write mrGui data to it (physically)
--------------------------------------------------------------------------------------------------------
function RealisticSettings.saveDataToXml()
	
	local filePath = RealisticSettings.getXmlPath();
	if filePath~=nil then
		local xmlFile = createXMLFile("RealisticSettingsSaveXml", filePath, "moreRealisticSettings");	--erase existing file if present	
		if xmlFile~=nil and xmlFile~=0 then				
			RealisticSettings.writeDataToXmlFile(xmlFile);
			saveXMLFile(xmlFile);
			delete(xmlFile);
		end;			
	end; -- filepath nil
	
end;

--------------------------------------------------------------------------------------------------------
-- write mrGui data to xml save file (in memory)
--------------------------------------------------------------------------------------------------------
function RealisticSettings.writeDataToXmlFile(xmlFileId)

	local xmlKeyPath = "moreRealisticSettings.settings"; --common path to all settings	
	--only one param by the moment
	setXMLBool(xmlFileId, xmlKeyPath .. ".disable_terrainControl", RealisticSettings.DISABLE_TERRAINCONTROL);
		
end;

--------------------------------------------------------------------------------------------------------
-- return full xml path to xml save file
--------------------------------------------------------------------------------------------------------
function RealisticSettings.getXmlPath()
	if g_currentMission~=nil then
		if g_currentMission.missionInfo~=nil then
			return g_currentMission.missionInfo.savegameDirectory .. "/" .. RealisticSettings.SAVE_FILENAME;
		end;
	end;
	return nil;
end