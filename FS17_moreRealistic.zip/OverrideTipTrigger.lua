﻿



TipTrigger.mrFillTypeSellingPointUpdate = {}

TipTrigger.mrInitSellingPoint = function(fillType)	
	TipTrigger.mrFillTypeSellingPointUpdate[fillType] = {}
	pu = TipTrigger.mrFillTypeSellingPointUpdate[fillType]
	pu.updateTime = g_currentMission.time
	pu.refreshTime = g_currentMission.time + 1000
	pu.baseAvgPrice = 0
	pu.totalBasePrices = 0
	pu.numTipTriggers = 0	
	
	return pu
end




--********************************************************************************************************************************************
--MR fix for the "green" / "red" display color of prices in the "selling point display panel"
TipTrigger.mrUpdatePrices = function(self, dt)

    if self.numFillTypesForSelling > 0 and self.hasDynamic then
        for fillType, _ in pairs(self.acceptedFillTypes) do 
			
			--self.levelThreshold = always 0.16 ?
			
			--1. don't base the color on the "base price * station multiplier", but on the "base price" alone (otherwise, a price can be "white" for a station offering a better price than another one already in "green"
			--2. the levelThreshold needs to be scaled with the basePrice of the filltype and the difficultylevel multiplier
			--what the player should see = if the price is "good" (current price>base price*1.2) (whatever the station multiplier is) => green
			--if the price is "bad" (current price<base price*0.8) => red
			--and so, even if there are a lot of selling stations in the display table, the player can see in one "glance" if there are good selling prices or not (green or red should not be dependant on the station, the player don't have to know if this is a "good" price for a given station or not. Only to know if the price if good compared to the base price of this crop
			
			--all self.fillTypePrices already takes int oaccount the difficulty multiplier 
			--(1 for hard, 1.8 for normal and 3 for easy in this case)
			--not the same as "g_currentMission.missionInfo.sellPriceMultiplier" ???
			
			--self.originalFillTypePrices[fillType] already takes into account the "priceScale" of the station for this fillType
			--self.priceMultipliers[fillType] seems to be always 1 (don't know where it is actually used)
			
			self.fillTypePriceInfo[fillType] = Utils.clearBit(self.fillTypePriceInfo[fillType], TipTrigger.PRICE_LOW)
			self.fillTypePriceInfo[fillType] = Utils.clearBit(self.fillTypePriceInfo[fillType], TipTrigger.PRICE_HIGH)			
			
			if self.originalFillTypePrices[fillType]>0 then
			
				--once in a while, we have to update the "average price" for each crop (in case a mod modify the station "priceMultipliers" during the game
				local pu = TipTrigger.mrFillTypeSellingPointUpdate[fillType]
				if not pu then
					pu = TipTrigger.mrInitSellingPoint(fillType)
				end
				
				if g_currentMission.time>pu.refreshTime then
					--time to compute the new avg multiplier
					if pu.numTipTriggers==0 then
						pu.baseAvgPrice = self.originalFillTypePrices[fillType]
					else
						pu.baseAvgPrice = pu.totalBasePrices / pu.numTipTriggers
						--print(" **** pu - base price avg = " .. tostring(pu.totalBasePrices / pu.numTipTriggers))
					end
					pu.updateTime = g_currentMission.time
					pu.refreshTime = g_currentMission.time + 30000 --refresh once every 30s
					pu.totalBasePrices = 0
					pu.numTipTriggers = 0	

					--print("test selling point avg price - filltype="..tostring(fillType) .." - avg price="..tostring(pu.baseAvgPrice) .. " - original price=" .. tostring(self.originalFillTypePrices[fillType]))
				end
				
				if g_currentMission.time==pu.updateTime then
					pu.totalBasePrices = pu.totalBasePrices + self.originalFillTypePrices[fillType]
					pu.numTipTriggers = pu.numTipTriggers + 1					
				end
			
				local baseAvgPrice = pu.baseAvgPrice
				
				if baseAvgPrice==0 then
					self.fillTypePriceInfo[fillType] = Utils.setBit(self.fillTypePriceInfo[fillType], TipTrigger.PRICE_LOW)
				else				
					local currentPrice = self:getEffectiveFillTypePrice(fillType) -- == (self.fillTypePrices[fillType] + self.fillTypePriceRandomDelta[fillType]) * self.priceMultipliers[fillType]
					local pricePercent = (currentPrice-baseAvgPrice)/baseAvgPrice
									
					--if fillType==1 then
					--	print("type = " .. tostring(fillType) .. " - base price="..tostring(self.originalFillTypePrices[fillType]) .. " - random delta="..tostring(self.fillTypePriceRandomDelta[fillType]) .. " - current price="..tostring(currentPrice) .. " - percent="..tostring(pricePercent))
					--end
					
					if pricePercent>0.20 then
						self.fillTypePriceInfo[fillType] = Utils.setBit(self.fillTypePriceInfo[fillType], TipTrigger.PRICE_HIGH)
					elseif pricePercent<-0.20 then
						self.fillTypePriceInfo[fillType] = Utils.setBit(self.fillTypePriceInfo[fillType], TipTrigger.PRICE_LOW)
					end
				end
			end
			
        end
    end
end
TipTrigger.updatePrices = Utils.appendedFunction(TipTrigger.updatePrices, TipTrigger.mrUpdatePrices)









