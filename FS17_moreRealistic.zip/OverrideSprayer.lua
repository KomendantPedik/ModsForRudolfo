﻿--************************************************************************************************************************************************************
--MR : load the mrMaxOutputCapacity if present. Especially useful for slurry tanker with different rear implement attachments or when there are more than one spray type available for this sprayer. (liquidmanure and digestate for slurry tankers)
--fix vanilla game bug : seeder featuring fertilising unit have varying fertiliser consumption (the "usage" in liter per second is only taken into account when the 'lastSowingArea' is greater than 0, which means that if the 'lastSowingArea' is only >0 every 200ms, the fertiliser usage is too low (nothing to compare with what is set in the xml)
Sprayer.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then return end
	
	self.getIsReadyToSpray = Sprayer.mrGetIsReadyToSpray
	self.mrSeederFertilisingLastTime = -1000

	--mrMaxOutputCapacity = maximum liters per minute possible by the pump. Allow the "mr engine" to dynamically adjust the speed limit depending on the actual spray liter per second
	self.sprayer.mrMaxOutputCapacity = getXMLFloat(self.xmlFile, "vehicle.sprayer#mrMaxOutputCapacity")

	if self.sprayer.mrMaxOutputCapacity~=nil then
		self.getSpeedLimit = Sprayer.mrGetSpeedLimit
	end
	self.sprayer.mrMaxSprayingSpeed = math.huge
	self.sprayer.mrHasSpray = false
	--print("test1 - self.sprayer.mrMaxSprayingSpeed="..tostring(self.sprayer.mrMaxSprayingSpeed))
		
end
Sprayer.load = Utils.appendedFunction(Sprayer.load, Sprayer.mrLoad);




--************************************************************************************************************************************************************	
--base game = the player feels forced to use the sprayer at the max speed possible to minimize the fertilizer usage
--MR : as IRL, the implement uses a system to regulate the outpout function of the speed of the vehicle
Sprayer.mrGetLitersPerSecond = function(self, superfunc, fillType)
	if not self.mrIsMrVehicle then return superfunc(self, fillType); end
	
	local scale = Utils.getNoNil(self.sprayUsageScale.fillTypeScales[fillType], self.sprayUsageScale.default)
	local litersPerSecond = 1

	local sprayTypeIndex = Sprayer.fillTypeToSprayType[fillType]
	if sprayTypeIndex ~= nil then
		local spray = Sprayer.sprayTypeIndexToDesc[sprayTypeIndex]
		if spray ~= nil then
			litersPerSecond = spray.litersPerSecond
		end
	end	
	
	--speed(kph) * workingWidth * 0.1 = Hectare per hour
	--liters per ha= actual liters per second * 3600 / ha per hour
	--actual liters per second = scale * spray.litersPerSecond * self.sprayUsageScale.workingWidth * speedFx
	--=> liters per ha = scale * spray.litersPerSecond * 3600 / 0.1 = scale * 36000 * spray.litersPerSecond
	
	--return scale * litersPerSecond * self.speedLimit * self.sprayUsageScale.workingWidth
	--local speedFx = math.max(0.1*self.speedLimit, self.lastSpeedReal*3600); --min usage = 10% of max speed usage
	local speedFx = math.max(4, self.lastSpeedReal*3600) --20170602 - we don't know what is the actual "speed limit" because the sprayer can be limited by its "implement" (example : slurry tanker with disc incorporator attached)
	
	--print("test sprayer - self.speedLimit="..tostring(self.speedLimit) .. " - width="..tostring(self.sprayUsageScale.workingWidth).." - litersPerSecond="..tostring(litersPerSecond) .. " - speedFx="..tostring(speedFx) .. " - result="..tostring(scale * litersPerSecond * self.sprayUsageScale.workingWidth * speedFx));
	
	--max working speed (kph) = 10 * unloading capacity (M3/Hour) / (working width (m) * application rate (M3/Hectare))	
	self.sprayer.mrMaxSprayingSpeed = math.huge
	local maxOutputCapacity = self.sprayer.mrMaxOutputCapacity
	
	local sprayUsageVehicle = self    
	if self:getUnitFillLevel(self.sprayer.fillUnitIndex) == 0 then
		sprayUsageVehicle, _ = Sprayer.findAttachedSprayerTank(self:getRootAttacherVehicle(), self:getUnitFillTypes(self.sprayer.fillUnitIndex), self.needsTankActivation);
	end
	if sprayUsageVehicle ~= nil then
		if sprayUsageVehicle.sprayer.mrMaxOutputCapacity~=nil then
			local divider = self.sprayUsageScale.workingWidth * scale * 36 * litersPerSecond
			if divider>0 then
				self.sprayer.mrMaxSprayingSpeed = 0.6 * sprayUsageVehicle.sprayer.mrMaxOutputCapacity / divider -- 60 / 1000 => liters per minutes to M3 per hour
				--print("test - mrMaxSprayingSpeed = " .. tostring(self.sprayer.mrMaxSprayingSpeed))
			end
		end
	end
	
	return scale * litersPerSecond * self.sprayUsageScale.workingWidth * speedFx
	
end
Sprayer.getLitersPerSecond = Utils.overwrittenFunction(Sprayer.getLitersPerSecond, Sprayer.mrGetLitersPerSecond);




--************************************************************************************************************************************************************
--MR - fix vanilla game bug : seeder featuring fertilising unit have varying fertiliser consumption
Sprayer.mrGetIsReadyToSpray = function(self)	
    if self.lastSowingArea ~= nil then --this is a seeder featuring a fertilising unit
		if self.lastSowingArea > 0 then
			self.mrSeederFertilisingLastTime = g_currentMission.time
			--print("test seeder fertiliser - isreadyToSpray=true  lasttime="..tostring(g_currentMission.time))
			return true
		else
			--print("test seeder fertiliser - isreadyToSpray="..tostring(g_currentMission.time<(self.mrSeederFertilisingLastTime+1000)) .. " lasttime="..tostring(self.mrSeederFertilisingLastTime) .. " - gametime="..tostring(g_currentMission.time))
			return g_currentMission.time<(self.mrSeederFertilisingLastTime+1000)
		end
	end
    return true
end

--************************************************************************************************************************************************************
--MR - take into account the max pump capacity to set the speed limit
Sprayer.mrGetSpeedLimit = function(self, onlyIfWorking)

	local maxSprayingSpeed = self.sprayer.mrMaxSprayingSpeed	
	
    local limit = math.huge
    local doCheckSpeedLimit = self:doCheckSpeedLimit()
    if onlyIfWorking == nil or (onlyIfWorking and doCheckSpeedLimit) then
        limit = self.speedLimit
    end;
    for _, implement in pairs(self.attachedImplements) do
        if implement.object ~= nil then
            local speed, implementDoCheckSpeedLimit = implement.object:getSpeedLimit(onlyIfWorking)
            if onlyIfWorking == nil or (onlyIfWorking and implementDoCheckSpeedLimit) then
                limit = math.min(limit, speed)
            end
            doCheckSpeedLimit = doCheckSpeedLimit or implementDoCheckSpeedLimit
			if implement.object.sprayer~=nil and implement.object.sprayer.mrMaxSprayingSpeed~=nil then				
				maxSprayingSpeed = math.min(maxSprayingSpeed, implement.object.sprayer.mrMaxSprayingSpeed)
			end
        end
    end
	
	--print("test Sprayer.mrGetSpeedLimit - limit="..tostring(limit) .." - maxSprayingSpeed="..tostring(maxSprayingSpeed))
	
	limit = math.min(limit, maxSprayingSpeed)
	self.sprayer.mrMaxSprayingSpeed = math.huge
	
    return limit, doCheckSpeedLimit
	
end



--************************************************************************************************************************************************************
--MR - we want to know if the sprayer is actually "spraying" or not
 Sprayer.mrGetHasSpray = function(self, superfunc, fillType, usage)
 
	if not self.mrIsMrVehicle then return superfunc(self, fillType, usage) end
	
	--print("test -  Sprayer.getHasSpray - usage="..tostring(usage) .. " - time="..tostring(g_currentMission.time) .. " - fillType="..tostring(fillType))
	
	local hasSpray, fillType = superfunc(self, fillType, usage)
	self.sprayer.mrHasSpray = hasSpray
	--print("test -  Sprayer.getHasSpray2 - hasSpray="..tostring(hasSpray) .." - fillType="..tostring(fillType))
 
	return hasSpray, fillType
 
 end
 Sprayer.getHasSpray = Utils.overwrittenFunction(Sprayer.getHasSpray, Sprayer.mrGetHasSpray);
 
 --[[
 Sprayer.mrUpdateTick = function(self, dt)
  
	if self.lastSpeedReal*3600>5 then
		print("test updatTick - dt = " .. tostring(dt) .. " - isreadytospray="..tostring(self:getIsReadyToSpray()))
	end
  
end
Sprayer.updateTick = Utils.prependedFunction(Sprayer.updateTick, Sprayer.mrUpdateTick);

--]]
  