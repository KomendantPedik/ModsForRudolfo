﻿




--************************************************************************************************************************************************************
--
BaleLoader.mrLoad = function(self, savegame)	
	if self.mrIsMrVehicle then	
		self.mrBaleLoader = {}
		self.mrBaleLoader.ptoRpm = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baleLoader#ptoRpm"), 540)
		self.mrBaleLoader.animationPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baleLoader#animationPtoPower"), 0)
		self.mrBaleLoader.workingPositionPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baleLoader#workingPositionPtoPower"), 0)
				
		self.mrFillContentMass = 0
		self.mrBaleLoader.firstUpdateRequired = true
	end
	
end
BaleLoader.load = Utils.appendedFunction(BaleLoader.load, BaleLoader.mrLoad)



--************************************************************************************************************************************************************
--getIsTurnedOn is not define for a "BaleLoader" and so, the PowerConsumer specialization does not work
BaleLoader.mrPostLoad = function(self, savegame)	
	if self.mrIsMrVehicle then		
		self.setFillLevel = Utils.appendedFunction(self.setFillLevel, BaleLoader.mrSetFillLevel)
		--baleLoader vehicleType does not have the "powerConsumer" specialization
		self.getConsumedPtoTorque = BaleLoader.mrGetConsumedPtoTorque
		self.getPtoRpm = BaleLoader.mrGetPtoRpm		
		self.mrUpdateBalesMass = BaleLoader.mrUpdateBalesMass
		self.mrGetDoConsumeWorkingPositionPtoPower = BaleLoader.mrGetDoConsumeWorkingPositionPtoPower
		self.mrGetDoConsumeAnimationPtoPower = BaleLoader.mrGetDoConsumeAnimationPtoPower
	end
	
end
BaleLoader.postLoad = Utils.appendedFunction(BaleLoader.postLoad, BaleLoader.mrPostLoad)



--************************************************************************************************************************************************************
--
BaleLoader.mrUpdate = function(self, dt)	
	if self.mrIsMrVehicle then	
		if self.firstTimeRun and self.mrBaleLoader.firstUpdateRequired then
			self:mrUpdateBalesMass()
			self.mrBaleLoader.firstUpdateRequired = false
		end
	end
	
end
BaleLoader.update = Utils.appendedFunction(BaleLoader.update, BaleLoader.mrUpdate)




--************************************************************************************************************************************************************
--compute the current loaded bales mass
BaleLoader.mrSetFillLevel = function(self, fillLevel, fillType, force, fillInfo)
	self:mrUpdateBalesMass()
end

BaleLoader.mrUpdateBalesMass = function(self)
	if self.isServer then
		self.mrFillContentMass = 0
		
		--bales already loaded in the baleLoader
		for _, balePlace in pairs(self.balePlaces) do
			if balePlace.bales ~= nil then
				for _, baleServerId in pairs(balePlace.bales) do
					local bale = networkGetObject(baleServerId)
					if bale ~= nil then
						--print("test - getmass " .. tostring(bale.nodeId) .. " = " .. tostring(getMass(bale.nodeId)))
						self.mrFillContentMass = self.mrFillContentMass + getMass(bale.nodeId)
					end					
				end				
			end
		end
		
		--bales that are in the "startBalePlace" (loading platform)
		for _, baleServerId in ipairs(self.startBalePlace.bales) do
			local bale = networkGetObject(baleServerId)
			if bale ~= nil then
				self.mrFillContentMass = self.mrFillContentMass + getMass(bale.nodeId)
			end
		end
		
		--bale in the grabber
		if self.baleGrabber.currentBale~=nil then
			local bale = networkGetObject(self.baleGrabber.currentBale)
			if bale ~= nil then
				self.mrFillContentMass = self.mrFillContentMass + getMass(bale.nodeId)
			end
		end		
		
	end --self.isServer
end

--************************************************************************************************************************************************************
BaleLoader.mrGetConsumedPtoTorque = function(self)
	if self.mrBaleLoader.ptoRpm>1 then
		local power = 0
		if self:mrGetDoConsumeWorkingPositionPtoPower() then
			power = self.mrBaleLoader.workingPositionPtoPower
		end
		if self:mrGetDoConsumeAnimationPtoPower() then
			power = power + self.mrBaleLoader.animationPtoPower
		end
	
		return power/(self.mrBaleLoader.ptoRpm*math.pi/30)
	end
	return 0
end

--************************************************************************************************************************************************************
BaleLoader.mrGetPtoRpm = function(self)
	if self:mrGetDoConsumeWorkingPositionPtoPower() or self:mrGetDoConsumeAnimationPtoPower() then
		return self.mrBaleLoader.ptoRpm
	else
		return 0
	end
end

--************************************************************************************************************************************************************
BaleLoader.mrGetDoConsumeWorkingPositionPtoPower = function(self)
	return self.mrBaleLoader.workingPositionPtoPower>0 and self.isInWorkPosition	
end

--************************************************************************************************************************************************************
BaleLoader.mrGetDoConsumeAnimationPtoPower = function(self)
	local doConsumePower = false
	
	if self.mrBaleLoader.animationPtoPower>0 then
		if self.activeAnimations~=nil then		
			if next(self.activeAnimations)~=nil then
				doConsumePower = true
			end		
		end
	end
	
	return doConsumePower
end