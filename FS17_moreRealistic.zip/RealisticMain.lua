﻿--test
--DebugUtil.printTableRecursively(table inputTable, string inputIndent, integer depth, integer maxDepth)
--DebugUtil.printTableRecursively(FillUtil.fillTypeNameToDesc, 1, 1, 100);
--DebugUtil.printTableRecursively(FruitUtil, 1, 1, 100);
--DebugUtil.printTableRecursively(StoreItemsUtil, 1, 1, 100);
--DebugUtil.printTableRecursively(AttacherJoints, 1, 1, 100);
--DebugUtil.printTableRecursively(TipTrigger, 1, 1, 100);

Vehicle.debugRendering = false;
addConsoleCommand("debug", "Toggles the debug rendering of the vehicles", "Vehicle.consoleCommandToggleDebugRendering", nil);


local mrEngineModName = "FS17_moreRealistic";
local mrEngineDirectory = g_modNameToDirectory[mrEngineModName];

--2017/04/30 - check the "moreRealistic" folder is present
if mrEngineDirectory==nil then
	print("[MoreRealistic] : ERROR, the moreRealistic mod folder must remain with the exact name = 'FS17_moreRealistic'.");
end

-- Global Classes
SpecializationUtil.registerSpecialization("realisticUtils", "RealisticUtils", mrEngineDirectory .. "RealisticUtils.lua");

RealisticUtils.mrEngineDirectory = mrEngineDirectory;
RealisticUtils.modName = g_currentModName;
local modItem = ModsUtil.findModItemByModName(RealisticUtils.modName);

RealisticUtils.version = '0.0.0.0';
if modItem and modItem.version then
	RealisticUtils.version = modItem.version;
end;

local mrEngineModVersion = RealisticUtils.version;


--load external configuration file ? should be set by map or savegame, because a player can have several savegames, and playing on different maps which means different "mr" configuration settings 


-- set more realistic figures for fillType density (massPerLiter) and balance startPricePerLiter accordingly to the new moreRealistic yields
RealisticUtils.loadRealFillTypesData(g_currentModDirectory .. "data/fillTypes.xml");

-- set more realistic figures for fruitType literPerSqm, seedUsagePerSqm and windrowLiterPerSqm
--move to moreRealisticGameplay mod
--RealisticUtils.loadRealFruitTypesData(g_currentModDirectory .. "data/fruitTypes.xml");

-- load "moreRealistic" figures for tire friction vs surface and rooling resistance
RealisticUtils.loadRealTyresFrictionAndRr(g_currentModDirectory .. "data/TyresFrictionAndRrTable.xml");

-- load modified data for default vehicles
RealisticUtils.loadDefaultVehiclesModifiedData(g_currentModDirectory .. "data/vehiclesOverriding", "_database.xml");


print(string.format("**** MoreRealistic Engine V%s loaded ****", mrEngineModVersion));


--local txt = RealisticUtils.testTable(computeWheelShapeTireForces, "computeWheelShapeTireForces", 1, 10); print(txt);
--local txt = RealisticUtils.testTable(RealisticUtils, "RealisticUtils", 1, 10); print(txt);
--local txt = RealisticUtils.testTable(AttacherJoints, "AttacherJoints", 1, 10); print(txt);
 
