﻿

--************************************************************************************************************************************************************
--set the specific getConsumedPtoTorque and ProcessBalerAreas
Baler.mrLoad = function(self, savegame)

	if not self.mrIsMrVehicle then
		return
	end
	
	self.mrBaler = {}
	self.mrBaler.baleMassDependantPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baler#baleMassDependantPtoPower"), 0) -- KW per ton
	self.mrBaler.pickingDependantPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baler#pickingDependantPtoPower"), 0) -- KW at max lifting speed
	self.mrBaler.strokeDependantPtoPower = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baler#strokeDependantPtoPower"), 0) --KW per stroke
	
	self.mrBaler.useDependantPtoPower = (self.mrBaler.baleMassDependantPtoPower + self.mrBaler.pickingDependantPtoPower + self.mrBaler.strokeDependantPtoPower)>0
	
	if self.mrBaler.useDependantPtoPower then
		self.mrBaler.currentPickingDependantPower = 0
		self.mrBaler.currentMassDependantPower = 0
		self.mrBaler.currentStrokeDependantPower = 0 -- only updated if self.mrBaler.usePlunger==true
		
		self.getConsumedPtoTorque = Baler.mrGetConsumedPtoTorque
		self.mrBaler.pickedLitersBuffer = 0
		self.mrBaler.litersPerSecondEmptyingSpeed = 0
		self.mrBaler.zeroBufferTime = 0		
		
		self.mrBaler.maxLitersPerSecond = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baler#maxLitersPerSecond"), 150)
		self.mrGetTractorPtoRpmFactor = Baler.mrGetTractorPtoRpmFactor
		
		self.mrBaler.pickedLitersCounter = 0
		self.mrBaler.pickedLitersCounterTime = 0
		self.mrBaler.pickedLitersCounterTimeMax = 3000 --refresh data once every 3s when we are already lifting a windrow
		self.mrBaler.pickedLitersCounterTimeShortMax = 500 --refresh data once every 500ms when we are "searching" for a windrow
		
		self.mrBaler.pickedLitersCounterTimeMaxAllowed = 0
		
		
		self.mrBaler.pickedLitersCounterDistanceMax = 5 -- refresh every 5m
		self.mrBaler.pickedLitersCounterAvgPerSecond = 0
		self.mrBaler.pickedLitersCounterDistance = 0
		self.mrBaler.pickedLitersCounterLastlitersPerSecond = 0
		
		self.mrBaler.windrowSpeedLimit = 0
		
	end
	
	self.processBalerAreas = Baler.mrProcessBalerAreas
	self.mrCanUnloadPrematurely = Baler.mrCanUnloadPrematurely
	self.mrGetFillTypeFactor = Baler.mrGetFillTypeFactor
	--self.createBale = Baler.mrCreateBale
	
	--apply the global fillLevel scaling for baler from the gameplay mod if present
	if g_currentMission.mrGameplayBalerFillLevelScaling~=nil then
		for _,fillUnit in pairs(self.fillUnits) do	
			--20171203-fix for straw addon (twine or net refilling)
			if fillUnit.showOnHud then
				fillUnit.capacity = RealisticUtils.roundNumberBaleCapacity(fillUnit.capacity * g_currentMission.mrGameplayBalerFillLevelScaling)
			end			
		end
	end
	
	
	--20170708 - manage squareBaler pre-compressing chamber	
	local litersPerFlake = getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baler#litersPerFlake")
	self.mrBaler.useStuffer = litersPerFlake~=nil
	if self.mrBaler.useStuffer then
		self.mrBaler.stuffer = {}
		self.mrBaler.stuffer.fillLevel = 0
		self.mrBaler.stuffer.triggerFillLevel = litersPerFlake		
	end
	
	--plunger for square baler
	local strokesByMinute = getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baler#strokesByMinute")
	self.mrBaler.usePlunger = strokesByMinute~=nil
	if self.mrBaler.usePlunger then
		if strokesByMinute<1 then
			RealisticUtils.printWarning("Baler.mrLoad", "Wrong value for 'vehicle.moreRealistic.baler#strokesByMinute'. Value should be greater than 1. Value read in the xml file = " .. tostring(strokesByMinute), true)
			strokesByMinute = 45
		end
		self.mrBaler.plunger = {}
		self.mrBaler.plunger.strokePeriod = 60000/strokesByMinute
		self.mrBaler.plunger.strokeSoundTimeOffset = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.baler#strokeSoundTimeOffset"), 0) --millisecond
		self.mrBaler.plunger.itIsStrokeTime = false
		self.mrBaler.plunger.strokeClockTime = -self.mrBaler.plunger.strokeSoundTimeOffset
		
		
	end
	
	--20170803 - we want to be able to use the "balerMaterialFx" value from the fillTypes.xml file
	self.mrBaler.lastValidFillType = FillUtil.FILLTYPE_UNKNOWN
	
	

end
Baler.load = Utils.appendedFunction(Baler.load, Baler.mrLoad)




--************************************************************************************************************************************************************
--20171203 - support for variable bale capacity from "Addon Straw"
Baler.mrPostLoad = function(self, savegame)

	if self.baler.baleSizes~=nil then
		--apply the global fillLevel scaling for baler from the gameplay mod if present
		if g_currentMission.mrGameplayBalerFillLevelScaling~=nil then
			for _,size in pairs(self.baler.baleSizes) do	
				size.capacity = RealisticUtils.roundNumberBaleCapacity(size.capacity * g_currentMission.mrGameplayBalerFillLevelScaling);
			end;
			self.baler.maxBaleSizeCapacity = RealisticUtils.roundNumberBaleCapacity(self.baler.maxBaleSizeCapacity * g_currentMission.mrGameplayBalerFillLevelScaling);
			self:setBaleSize(self.baler.currentBaleTypeId, true);
		end;		
	end;

end;
Baler.postLoad = Utils.appendedFunction(Baler.postLoad, Baler.mrPostLoad)


--************************************************************************************************************************************************************
--we want to get the liters "picked up"
Baler.mrProcessBalerAreas = function(self, workAreas, fillTypes)
    local totalLiters = 0
    local usedFillType = FillUtil.FILLTYPE_UNKNOWN
    local numAreas = table.getn(workAreas)
    for i=1, numAreas do
        local x0 = workAreas[i][1]
        local z0 = workAreas[i][2]
        local x1 = workAreas[i][3]
        local z1 = workAreas[i][4]
        local x2 = workAreas[i][5]
        local z2 = workAreas[i][6]
        local hx = x2 - x0
        local hz = z2 - z0
        local hLength = Utils.vector2Length(hx, hz)
        local hLength_2 = 0.5 * hLength
        local wx = x1 - x0
        local wz = z1 - z0
        local wLength = Utils.vector2Length(wx, wz)
        local sx = x0 + (hx * 0.5) + ((wx/wLength)*hLength_2)
        local sz = z0 + (hz * 0.5) + ((wz/wLength)*hLength_2)
        local ex = x1 + (hx * 0.5) - ((wx/wLength)*hLength_2)
        local ez = z1 + (hz * 0.5) - ((wz/wLength)*hLength_2)
        local sy = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, sx,0,sz)
        local ey = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, ex,0,ez)
        if usedFillType == FillUtil.FILLTYPE_UNKNOWN then
            for _, fillType in pairs(fillTypes) do
                local liters = -TipUtil.tipToGroundAroundLine(self, -math.huge, fillType, sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil)
                if liters > 0 then
                    usedFillType = fillType
                    totalLiters = totalLiters + liters
                    break
                end
            end
        else
            totalLiters = totalLiters - TipUtil.tipToGroundAroundLine(self, -math.huge, usedFillType, sx,sy,sz, ex,ey,ez, hLength_2, nil, nil, false, nil)
        end
    end
	
	-------------------------------------------------------------------
	--MR
	
	if usedFillType~=FillUtil.FILLTYPE_UNKNOWN then
		self.mrBaler.lastValidFillType = usedFillType
	end
	
	--update total liters picked up
	if self.mrBaler.useDependantPtoPower then
		--print(tostring(g_currentMission.time) .. " liters picked="..tostring(totalLiters))
		self.mrBaler.pickedLitersBuffer = self.mrBaler.pickedLitersBuffer + totalLiters
		self.mrBaler.pickedLitersCounter = self.mrBaler.pickedLitersCounter + totalLiters		
	end
	
	
	
	--20170708 - manage square baler pre-compressing chamber
	if self.mrBaler.useStuffer then	
		if totalLiters>0 then
			self.mrBaler.stuffer.lastFillType = usedFillType
		end
	
		self.mrBaler.stuffer.fillLevel = self.mrBaler.stuffer.fillLevel + totalLiters
		local emptyStuffer = self.mrBaler.stuffer.fillLevel>self.mrBaler.stuffer.triggerFillLevel
		if emptyStuffer and self.mrBaler.usePlunger then
			emptyStuffer = self.mrBaler.plunger.itIsStrokeTime
		end
		
		if emptyStuffer then
			--release the material in the compressing chamber
			--limit the amount in case of "high amount in a short time"
			local litersToPress = math.min(2.5*self.mrBaler.stuffer.triggerFillLevel, self.mrBaler.stuffer.fillLevel)
			totalLiters = litersToPress		
			self.mrBaler.stuffer.fillLevel = self.mrBaler.stuffer.fillLevel-litersToPress --empty pre-compressing chamber				
			usedFillType = self.mrBaler.stuffer.lastFillType
			if self.mrBaler.usePlunger then
				self.mrBaler.currentStrokeDependantPower = self.mrBaler.strokeDependantPtoPower * litersToPress/self.mrBaler.stuffer.triggerFillLevel
			end
		elseif totalLiters>0 then
			--pre compressing chamber not ready, need more material
			totalLiters = 0
			self.baler.lastAreaBiggerZero = true
			if self.baler.lastAreaBiggerZero ~= self.baler.lastAreaBiggerZeroSent then
				self:raiseDirtyFlags(self.baler.dirtyFlag)
				self.baler.lastAreaBiggerZeroSent = self.baler.lastAreaBiggerZero
			end			
		end
	end
	
	
    return totalLiters, usedFillType
end

--************************************************************************************************************************************************************
--pto torque depends on :
--      the liters per second picked up by the baler
--		mass of the bale being "rounded"
Baler.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower + self.mrBaler.currentPickingDependantPower + self.mrBaler.currentMassDependantPower + self.mrBaler.currentStrokeDependantPower
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end

--************************************************************************************************************************************************************
--MR : display debug info, update dependant power and speed limit
Baler.mrUpdate=function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end
	
	if self.isServer and self:getIsTurnedOn() then
	
		if self.mrBaler.useDependantPtoPower then		
			
			local tractorRpmFactor = self:mrGetTractorPtoRpmFactor()
			local maxLitersPerSecond = self.mrBaler.maxLitersPerSecond	

			--apply the "mrBalerMaterialFx" from the fillTypes.xml files
			local lastFillType = FillUtil.fillTypeIndexToDesc[self.mrBaler.lastValidFillType]
			if lastFillType~=nil and lastFillType.mrBalerMaterialFx~=nil and lastFillType.mrBalerMaterialFx>0 then
				--print("test - lastFillType.mrBalerMaterialFx ="..tostring(lastFillType.mrBalerMaterialFx ))
				maxLitersPerSecond = maxLitersPerSecond / lastFillType.mrBalerMaterialFx 
			end

			
			local maxLitersToProcess = maxLitersPerSecond*dt/1000			
			self.mrBaler.pickedLitersBuffer = math.max(0, self.mrBaler.pickedLitersBuffer-tractorRpmFactor*maxLitersToProcess)
			
			--update liters per second / windrow liters per meter
			local duration = g_currentMission.time - self.mrBaler.pickedLitersCounterTime			
			self.mrBaler.pickedLitersCounterDistance = self.mrBaler.pickedLitersCounterDistance + self.lastMovedDistance			
			if self.mrBaler.pickedLitersCounterDistance>self.mrBaler.pickedLitersCounterDistanceMax or duration>self.mrBaler.pickedLitersCounterTimeMaxAllowed then
				self.mrBaler.pickedLitersCounterLastlitersPerSecond = 1000 * self.mrBaler.pickedLitersCounter / duration

				--we want to check more often until we "find" some windrow
				if self.mrBaler.pickedLitersCounter==0 then					
					self.mrBaler.pickedLitersCounterTimeMaxAllowed = self.mrBaler.pickedLitersCounterTimeShortMax
				else
					self.mrBaler.pickedLitersCounterTimeMaxAllowed = self.mrBaler.pickedLitersCounterTimeMax
				end				
				
				local wantedSpeed = 1
				if self.mrBaler.pickedLitersCounterDistance==0 then
					wantedSpeed = 1
				elseif self.mrBaler.pickedLitersCounter==0 then
					wantedSpeed = self.mrGenuineSpeedLimit
				else
					local windrowLitersPerMeter = self.mrBaler.pickedLitersCounter / self.mrBaler.pickedLitersCounterDistance					
					wantedSpeed = math.min(self.mrGenuineSpeedLimit, 3.6 * maxLitersPerSecond / windrowLitersPerMeter)
				end
				
				self.mrBaler.windrowSpeedLimit = wantedSpeed				
				
				--reset 
				self.mrBaler.pickedLitersCounter = 0
				self.mrBaler.pickedLitersCounterTime = g_currentMission.time
				self.mrBaler.pickedLitersCounterDistance = 0
			end			
			
			self.mrBaler.pickedLitersCounterAvgPerSecond = 0.99*self.mrBaler.pickedLitersCounterAvgPerSecond + 0.01*self.mrBaler.pickedLitersCounterLastlitersPerSecond
			
			
			local wantedSpeedLimit = self.mrBaler.windrowSpeedLimit-1 -- remove 1 since we want to keep a "safe" area (tractor limiter = most of the time faster than target speed if the engine is not on its knees)
						
			--limit speed if buffer is too high
			if self.mrBaler.pickedLitersBuffer>maxLitersPerSecond then
				wantedSpeedLimit = math.max(1, wantedSpeedLimit-self.mrBaler.pickedLitersBuffer/maxLitersPerSecond)
			end			
			
			if Vehicle.debugRendering then
				self.mrBaler.debugWantedSpeedLimit = wantedSpeedLimit
			end			
			
			--we don't want the wantedSpeed raise to the max when we are unloading the round baler
			if self.lastSpeedReal<0.0003 then	-- 0.0003 = 1.08kph
				wantedSpeedLimit = 1
			end			
			
			if self.speedLimit>wantedSpeedLimit then
				--lower the speed limit
				--lowering speed function of the difference between the current and wanted speed
				local diff = self.speedLimit-wantedSpeedLimit				
				self.speedLimit = math.max(wantedSpeedLimit, self.speedLimit-diff*dt/2000) --2s to reach the target speed				
			else
				--raise the speed limit
				--raising speed function of the difference between the current and wanted speed
				local diff = wantedSpeedLimit-self.speedLimit
				local period = 2000 --2s to reach the target speed
				if self.baler.lastAreaBiggerZeroTime>0 or self.lastSpeedReal<0.0005 then
					period = 4000 --4s
				end				
				self.speedLimit = math.min(wantedSpeedLimit, self.speedLimit+diff*dt/period)
			end
			
			--picking dependant pto power
			local processingFactor = math.min(1, self.mrBaler.pickedLitersCounterLastlitersPerSecond/maxLitersPerSecond)
			local bufferFactor = math.max(1, self.mrBaler.pickedLitersBuffer/self.mrBaler.maxLitersPerSecond)^0.5			
			local wantedPickingPower = self.mrBaler.pickingDependantPtoPower * processingFactor * bufferFactor			
			local dtFx = 1 - 0.0024*dt  --60fps => 0.96, 30fps => 0.92
			self.mrBaler.currentPickingDependantPower = dtFx * self.mrBaler.currentPickingDependantPower + (1-dtFx) * wantedPickingPower
			
			
			--mass dependant pto power
			self.mrBaler.currentMassDependantPower = 0
			if self.mrBaler.baleMassDependantPtoPower>0 then
				local currentFillType = self:getUnitFillType(self.baler.fillUnitIndex)
				if currentFillType~=FillUtil.FILLTYPE_UNKNOWN then
					local currentBaleMass = self:getUnitFillLevel(self.baler.fillUnitIndex) * FillUtil.fillTypeIndexToDesc[currentFillType].massPerLiter
					self.mrBaler.currentMassDependantPower = self.mrBaler.baleMassDependantPtoPower * currentBaleMass
				end
			end
			
			--stroke dependant pto power
			--lower the power with time (1/2 stroke period to get back to 0)
			if self.mrBaler.usePlunger then
				self.mrBaler.currentStrokeDependantPower = math.max(0, self.mrBaler.currentStrokeDependantPower-2*self.mrBaler.strokeDependantPtoPower/self.mrBaler.plunger.strokePeriod*dt)
			end
			
		end
		
	end
	
	--display debug data
	if Vehicle.debugRendering and self.isServer and self:getIsTurnedOn() then
		
		local vehicle = self
		if self.attacherVehicle then
			vehicle = self.attacherVehicle
		end
		if (vehicle.isEntered and vehicle.isClient and vehicle.isControlled) or self:getIsActiveForInput()  then
			local turnedOnPtoPower = 0
			
			if self.powerConsumer then
				turnedOnPtoPower = self.powerConsumer.mrNoLoadPtoPower				 
			end
			
			local pickingDependantPtoPower = 0
			local massDependantPtoPower = 0
			local strokeDependantPtoPower = 0
			local bufferLevel=0	
			local tonsPerHour = 0
			local litersPerSecond = 0
			local tractorRpmFactor = self:mrGetTractorPtoRpmFactor()
			local wantedSpeedLimit = 0
			if self.mrBaler.useDependantPtoPower then
				pickingDependantPtoPower = self.mrBaler.currentPickingDependantPower
				massDependantPtoPower = self.mrBaler.currentMassDependantPower
				strokeDependantPtoPower = self.mrBaler.currentStrokeDependantPower
				bufferLevel = self.mrBaler.pickedLitersBuffer	
				local currentFillType = self:getUnitFillType(self.baler.fillUnitIndex)
				if currentFillType~=FillUtil.FILLTYPE_UNKNOWN then			
					tonsPerHour = self.mrBaler.pickedLitersCounterAvgPerSecond*3600 * FillUtil.fillTypeIndexToDesc[currentFillType].massPerLiter
				end
				
				litersPerSecond = self.mrBaler.pickedLitersCounterAvgPerSecond
				if self.mrBaler.debugWantedSpeedLimit then
					wantedSpeedLimit = self.mrBaler.debugWantedSpeedLimit
				end
			end
			
			local totalPower = turnedOnPtoPower + pickingDependantPtoPower + massDependantPtoPower + strokeDependantPtoPower
		
		
			local str = string.format(" turnedOnPtoPower=%.1f\n pickingDependantPtoPower=%.1f\n massDependantPtoPower=%.1f\n strokeDependantPtoPower=%.1f\n lastTotalPower=%.1f\n Buffer level=%.0f\n Pto rpm factor=%.1f\n Speed Limit=%.1f\n Wanted Speed Limit=%.1f\n Tons per Hour=%.1f\n Liters per Second=%.0f", turnedOnPtoPower, pickingDependantPtoPower, massDependantPtoPower,strokeDependantPtoPower, totalPower, bufferLevel, tractorRpmFactor,self.speedLimit,wantedSpeedLimit,tonsPerHour, litersPerSecond)
			renderText(0.74, 0.80, getCorrectTextSize(0.02), str);
		end
		
		
		
	end
	

end
Baler.update = Utils.appendedFunction(Baler.update, Baler.mrUpdate)


--************************************************************************************************************************************************************
--MR : manage the bale creation when unloading prematurely (round baler)
Baler.mrUpdate1=function(self, dt)
	if self.isServer and self.mrIsMrVehicle then
		if self:getIsActiveForInput() then
			if InputBinding.hasEvent(InputBinding.IMPLEMENT_EXTRA3) then						
				if self:mrCanUnloadPrematurely() then
					local currentFillLevel = self:getUnitFillLevel(self.baler.fillUnitIndex)							
					local fillType = self:getUnitFillType(self.baler.fillUnitIndex)
					self:createBale(fillType, currentFillLevel)
					g_server:broadcastEvent(BalerCreateBaleEvent:new(self, fillType, 0), nil, nil, self)							
				end
			end
		end		
	end	
end
Baler.update = Utils.prependedFunction(Baler.update, Baler.mrUpdate1)

--************************************************************************************************************************************************************
--MR : stop the alarm sound as soon as we are able to unload the bale (round baler)
Baler.mrUpdateTick2 = function(self, dt)

	if self.isClient and self.mrIsMrVehicle then
		if self:getIsActive() then
			if self:mrCanUnloadPrematurely() or self.baler.unloadingState ~= Baler.UNLOADING_CLOSED then
				SoundUtil.stopSample(self.baler.sampleBalerAlarm)
			end
		end
	end

end
Baler.updateTick = Utils.appendedFunction(Baler.updateTick, Baler.mrUpdateTick2)

--************************************************************************************************************************************************************
--MR : refresh if this is stroke time or not
Baler.mrUpdateTick1 = function(self, dt)

	if not self.mrIsMrVehicle then
		return
	end

	if self.isServer and self.mrBaler.usePlunger then
		if self:getIsActive() and self:getIsTurnedOn() then
			self.mrBaler.plunger.itIsStrokeTime = false			
			self.mrBaler.plunger.strokeClockTime = self.mrBaler.plunger.strokeClockTime + dt
			if self.mrBaler.plunger.strokeClockTime>=self.mrBaler.plunger.strokePeriod then
			--if g_currentMission.time>=(self.mrBaler.plunger.strokeClockTime+self.mrBaler.plunger.strokePeriod) then
				self.mrBaler.plunger.itIsStrokeTime = true
				self.mrBaler.plunger.strokeClockTime = self.mrBaler.plunger.strokeClockTime - self.mrBaler.plunger.strokePeriod
				--self.mrBaler.plunger.strokeClockTime = self.mrBaler.plunger.strokeClockTime + self.mrBaler.plunger.strokePeriod
				
				--debug
				--local soundOffset = getSamplePlayOffset(self.baler.sampleBaler.sample)
				--print("test offset sound = " .. tostring(soundOffset) .. " - clock time=" .. tostring(self.mrBaler.plunger.strokeClockTime) .. " - sample duration=" .. tostring(getSampleDuration(self.baler.sampleBaler.sample)))
				self.mrBaler.currentStrokeDependantPower = math.max(self.mrBaler.currentStrokeDependantPower, 0.5*self.mrBaler.strokeDependantPtoPower); -- nothing to press, avg plunger PTO consumption
			end			
		else
			self.mrBaler.plunger.strokeClockTime = -self.mrBaler.plunger.strokeSoundTimeOffset
		end
	end

end
Baler.updateTick = Utils.prependedFunction(Baler.updateTick, Baler.mrUpdateTick1)





--************************************************************************************************************************************************************
--MR : check if we are allowed to unload the bale before 100% (round baler) => the bale is ok between 90% and 100%
Baler.mrCanUnloadPrematurely = function(self)	
	if self:isUnloadingAllowed() then
		if self.baler.baleUnloadAnimationName ~= nil or self.baler.allowsBaleUnloading then
			if self.baler.unloadingState == Baler.UNLOADING_CLOSED then				
				local currentFillLevel = self:getUnitFillLevel(self.baler.fillUnitIndex)
				local currentCapacity = self:getUnitCapacity(self.baler.fillUnitIndex)
				if currentFillLevel<currentCapacity and currentFillLevel>=0.9*currentCapacity then
					return true
				end
			end
		end
	end	
	return false	
end


Baler.mrGetTractorPtoRpmFactor = function(self)
	local ptoRpmFactor = 1	
	if self.attacherVehicle then
		if self.attacherVehicle.motor then
			if self.powerConsumer then
				if self.powerConsumer.ptoRpm>0 then
					ptoRpmFactor = self.attacherVehicle.motor.lastRealMotorRpm/(self.attacherVehicle.motor.ptoMotorRpmRatio*self.powerConsumer.ptoRpm)
				end
			end
		end
	end	
	return ptoRpmFactor
end

--************************************************************************************************************************************************************
--MR : display the "unload" help text if we are allowed to unload prematurely (round baler)
Baler.mrDraw=function(self)
    if self.isClient and self.mrIsMrVehicle then
        if self:getIsActiveForInput(true) then
            if self:mrCanUnloadPrematurely() then
				g_currentMission:addHelpButtonText(g_i18n:getText("action_unloadBaler"), InputBinding.IMPLEMENT_EXTRA3, nil, GS_PRIO_HIGH)                    
            end
        end
    end
end
Baler.draw = Utils.appendedFunction(Baler.draw, Baler.mrDraw)

