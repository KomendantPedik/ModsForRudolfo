﻿
--************************************************************************************************************************************************************
--called by the overwritten Vehicle.update function
--update the tire rolling resistance as well

WheelsUtil.mrGetTireFriction = function(wheel, groundType, wetScale)
	if wetScale == nil then
		wetScale = 0
	end
	
	local rrFx = 1
	local frictionFx = 1	
	local inSnow = false
	local snowDepthFactor = 1	
	
	if g_seasons~=nil and g_seasons.snow~=nil and wheel.mrContactPoint.isValid then	
	
		--print(" season testing snow")
	
		local densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailHeightId, wheel.mrContactPoint.x, wheel.mrContactPoint.y, wheel.mrContactPoint.z)		
		
		--first check the "heightType" : we want to check snow
		local firstChannel = getDensityMapHeightFirstChannel(g_currentMission.terrainDetailHeightId)
		local maskNum = RealisticUtils.getBitMask(0, firstChannel-1) -- height type = bit 0 to 4 of the returned "densityBits"	
		local heightTypeIndex = bitAND(densityBits, maskNum)	
		local snowHeightType = TipUtil.fillTypeToHeightType[FillUtil.FILLTYPE_SNOW]		
		
		if snowHeightType~=nil and heightTypeIndex==snowHeightType["index"] then -- this is snow
		
			inSnow = true 			
		
			--second, check the snow depth	
			local numChannels = getDensityMapHeightNumChannels(g_currentMission.terrainDetailHeightId)			
			local maskNum = RealisticUtils.getBitMask(firstChannel, firstChannel+numChannels-1)	-- height of the returned height Type (snow in our case) = bits 5 to 10	
			local densityLayers = bitAND(densityBits, maskNum)	
			densityLayers = densityLayers / (2^firstChannel)
			local belowSnowDepth = densityLayers * g_seasons.snow.LAYER_HEIGHT
			local snowDepth = math.min(belowSnowDepth, 0.30) --limit to 30cm because we don't mind there are 30cm or 2m under the wheels => if the wheels don't sink, there is no difference)	

			--check in "front" of the wheel too			
			local velocityLen = Utils.vector3Length(wheel.mrContactPoint.lastVelocityX, wheel.mrContactPoint.lastVelocityY, wheel.mrContactPoint.lastVelocityZ)
			if velocityLen>0.1 then
				local frontX = wheel.mrContactPoint.x + 1.2*wheel.radius*wheel.mrContactPoint.lastVelocityX/velocityLen
				local frontY = wheel.mrContactPoint.y + 1.2*wheel.radius*wheel.mrContactPoint.lastVelocityY/velocityLen
				local frontZ = wheel.mrContactPoint.z + 1.2*wheel.radius*wheel.mrContactPoint.lastVelocityZ/velocityLen
				local densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailHeightId, frontX, frontY, frontZ)
				
				local densityLayers = bitAND(densityBits, maskNum)	
				densityLayers = densityLayers / (2^firstChannel)			
				local frontSnowDepth = densityLayers * g_seasons.snow.LAYER_HEIGHT
								
				if frontSnowDepth>belowSnowDepth then
					snowDepth = snowDepth + frontSnowDepth - belowSnowDepth -- add the difference between snow in front of the wheel and under the wheel
				end
				--print("wheel:" .. tostring(wheel.mrNum) .. " test frontSnowDepth =" .. tostring(frontSnowDepth) .. " - belowSnowDepth="..tostring(belowSnowDepth) .. " - snowDepth="..tostring(snowDepth))				
			end
			
			-- cap it with g_seasons.snow.MAX_HEIGHT
			snowDepth = math.min(snowDepth, g_seasons.snow.MAX_HEIGHT)
			
			
			--value for snow rolling resistance in TyresFrictionAndRrTable.xml = 1m radius wheel and 30 cm depth snow
			if wheel.radius>0 then
				snowDepthFactor = math.max(0.05, snowDepth) / (0.25 * wheel.radius)  -- factor can't be lower than for 5cm snow depth
			end
			
			wheel.mrSnowDepthFactorS = 0.9 * wheel.mrSnowDepthFactorS + 0.1 * snowDepthFactor -- smooth a little
			
			--print(tostring(g_currentMission.time) .. " - test snow - density bits = " .. tostring(densityBits) .. " - heightTypeIndex="..tostring(heightTypeIndex) .. " - maskNum="..tostring(maskNum) .. " - densityLayers=".. tostring(densityLayers) .. " - snow layer height="..tostring(snowDepth))
		end
		
	end -- g_seasons and snow
	
	
	
	
	--20170829 - add some scaling when on field (depending on the field state = cultivated, sowed, ploughed)
	if not wheel.mrIsCrawler and wheel.mrIsOnField then
	
		local fieldType = bitAND(wheel.mrLastTerrainDensityBits, 7)  -- 0000000000000111 = 7 = we want to keep the 3 first bits only
		
		--cultivator = 1 = default = FruitUtil.GROUND_TYPE_CULTIVATOR
		if fieldType==FruitUtil.GROUND_TYPE_PLOUGH then			
			--more rolling resistance			
			rrFx = rrFx * 1.1			
		elseif fieldType==FruitUtil.GROUND_TYPE_SOWING or fieldType==FruitUtil.GROUND_TYPE_SOWING_WIDTH then --3 or 4
			--seeded	
			
			--less rolling resistance, more friction
			rrFx = 0.8
			frictionFx = 1.1

			--we want to access the "fruit_density.gdm" file and check what kind of "seeded" surface we are rolling on
			if wheel.mrContactPoint.isValid then		
				
				local fruitTerrainDetailId = getTerrainDetailByName(g_currentMission.terrainRootNode, "wheat") -- wheat or any other fruit = we get the same "getDensityAtWorldPos" result
				local densityBits = getDensityAtWorldPos(fruitTerrainDetailId, wheel.mrContactPoint.x, wheel.mrContactPoint.y, wheel.mrContactPoint.z)
				--g_currentMission.numFruitDensityMapChannels -- total "density" bits
				--g_currentMission.numFruitStateChannels -- number of bits for the "grow state"
				local startBit = g_currentMission.numFruitDensityMapChannels-g_currentMission.numFruitStateChannels
				local maskNum = RealisticUtils.getBitMask(startBit, g_currentMission.numFruitDensityMapChannels-1)
				local fruitGrowState = bitAND(densityBits, maskNum) -- base map=> numFruitDensityMapChannels=8 and numFruitStateChannels=4 11110000 = 240
				fruitGrowState = fruitGrowState / (2^startBit)
				
				--print(tostring(g_currentMission.time).. " - fruit state = " ..tostring(fruitGrowState))			
				
				if fruitGrowState<=3 then
					rrFx = 1 - 0.05*fruitGrowState
					frictionFx = 1.02 + 0.02*fruitGrowState
				end
				
			end

			
			--[[
			local x,y,z = getWorldTranslation(wheel.node)	
			--check if just seeded, or crop grow stage, or harvested
			--local densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailId, wx, wy, wz);
			--local densityBits = getDensityAtWorldPos(g_currentMission.fruitDensityMapId, wx, wy, wz);
			--local densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailHeightId, x,y,z)
			--local densityBits = getDensityAtWorldPos(g_currentMission.terrainDetailId, x,y,z)
			--print("test field - lastTerrainAttribute = "..tostring(wheel.lastTerrainAttribute))
			
			--local test = getDensityMapFileName(g_currentMission.terrainDetailId)
			--local test1 = getTerrainDetailByName(g_currentMission.terrainRootNode, "terrainDetail")
			local test1 = getTerrainDetailByName(g_currentMission.terrainRootNode, "wheat")
			local test2 = getTerrainDetailByName(g_currentMission.terrainRootNode, "sunflower")
			local test = getDensityMapFileName(test1)
			
			local densityBits = getDensityAtWorldPos(test1, x,y,z)
			local densityBits2 = getDensityAtWorldPos(test2, x,y,z)
			
			print(tostring(g_currentMission.time).. " - getDensityMapFileName = " .. tostring(test) .. " - densityBits="..tostring(densityBits) .. " - densityBits2="..tostring(densityBits2) .. " - test1="..tostring(test1) .. " - test2="..tostring(test2))
			
			
			--Utils.getFruitArea(...)
			
			--Utils.getFruitArea(integer fruitId, float startWorldX, float startWorldZ, float widthWorldX, float widthWorldZ, float heightWorldX, float heightWorldZ, boolean allowPreparing, boolean useMinForageState)
					
			--local fruitValue, p2, growthState = Utils.getFruitArea(0, x, z, x+1,z, x, z+1, nil, nil)
			--print("test field seeded - fruitValue = "..tostring(fruitValue) .. " - p2="..tostring(p2) .. " - growthState="..tostring(growthState))
			--hasFruitContact = fruitValue > 0
			--]]			
		
		elseif fieldType==FruitUtil.GROUND_TYPE_GRASS then --5
			groundType = WheelsUtil.GROUND_SOFT_TERRAIN
		end
		--[[
		getTerrainDetailNumChannels
		getBitVectorMapNumChannels 
		getDensityMapHeightNumChannels
		getDensityMapHeightFirstChannel
		terrainDetailHeightId
		
		g_currentMission.terrainDetailAngleFirstChannel				
		g_currentMission.terrainDetailAngleNumChannels
		g_currentMission.terrainDetailAngleMaxValue
		
		g_currentMission.ploughCounterFirstChannel				
		g_currentMission.ploughCounterNumChannels
		g_currentMission.ploughCounterMaxValue
		g_currentMission.ploughValue
		
		g_currentMission.sprayFirstChannel				
		g_currentMission.sprayNumChannels
		
		g_currentMission.sprayLevelFirstChannel				
		g_currentMission.sprayLevelNumChannels
		g_currentMission.sprayLevelMaxValue		
		
		g_currentMission.terrainDetailTypeFirstChannel
		g_currentMission.terrainDetailTypeNumChannels
		--]]
	
	end
	
	
	
	
	-------------------------------------------------------------------------------------
	--rolling resistance coeff
	local rrDry, rrWet = WheelsUtil.mrLoadRollingResistanceValues(wheel.tireType, groundType)
	
	-------------------------------------------------------------------------------------
	--friction
	if inSnow then
		--20170908 - snow type for friction
		--change ground type to snow
		groundType = RealisticUtils.nameToGroundType["SNOW"]
	end
	local coeff = WheelsUtil.tireTypes[wheel.tireType].frictionCoeffs[groundType]
	local coeffWet = WheelsUtil.tireTypes[wheel.tireType].frictionCoeffsWet[groundType]
	
	--apply wetness
	local baseRr = rrDry + (rrWet-rrDry)*wetScale	
	local frictionCoeff = coeff + (coeffWet-coeff)*wetScale
	
	--apply factor values
	baseRr = baseRr * rrFx
	frictionCoeff = frictionCoeff * frictionFx
	
	--------------------------------------------------------------------------------------
	--set the max rolling resistance between snow and current RR
	if inSnow then
	
		--load snow rolling resistance values
		local rrDry, rrWet = WheelsUtil.mrLoadRollingResistanceValues(wheel.tireType, groundType)		
		local snowRr = rrDry + (rrWet-rrDry)*wetScale
	
		baseRr = math.max(baseRr, snowRr*wheel.mrSnowDepthFactorS)
	end
	
	--TEST
	--frictionCoeff = 0.70;
	--baseRr = 0.055;
	--groundType = WheelsUtil.GROUND_FIELD;
	
	--very simplified compared to IRL
	--we want smaller rolling resistance bonus (greater penalty) for wider tires on high friction surfaces
	--we want greater rolling resistance bonus (smaller penalty) for wider tires on low friction surfaces
	
	--WheelsUtil.GROUND_FIELD
	--WheelsUtil.GROUND_ROAD
	--WheelsUtil.GROUND_SOFT_TERRAIN
	--WheelsUtil.GROUND_HARD_TERRAIN	
	
	if wheel.mrLastTireLoad<=0 or wheel.mrIsCrawler then --protection in case mrLastTireLoad returns a negative value (math.pow 0.8 is not possible for a negative number)
		wheel.mrCurrentRollingResistance = baseRr;	
	else
		if groundType==WheelsUtil.GROUND_FIELD or groundType==WheelsUtil.GROUND_SOFT_TERRAIN or groundType==RealisticUtils.nameToGroundType["SNOW"] then
			--wider tires = less rolling resistance compared to narrow tires (soft surface)
			--wheel.mrCurrentRollingResistance = baseRr * (1.1 - 0.2*wheel.mrTotalContactWidth -0.1*wheel.radius);
			--local fx = 0.02*wheel.mrLastTireLoad/(wheel.radius*wheel.mrTotalContactWidth);		
			--wheel.mrCurrentRollingResistance = baseRr * math.max(0.8, 1.3 -0.3*wheel.mrTotalContactWidth -0.1*wheel.radius);
			
			--wheel.mrCurrentRollingResistance = baseRr * math.max(0.8, 0.02 * wheel.mrLastTireLoad / (wheel.radius * wheel.mrTotalContactWidth))^0.5;
			local fx = (0.012 * wheel.mrLastTireLoad / (wheel.radius * wheel.mrTotalContactWidth))^0.8; -- 5T radius=0.9m, width=0.65m => fx = 1
			wheel.mrCurrentRollingResistance = baseRr * (0.8 + 0.2 * fx); 
			
			--wheel.mrSlippingResistanceEnabled = true;
		else
			--narrow tires = less rolling resistance compared to wider tires (hard surface)
			--wheel.mrCurrentRollingResistance = baseRr * (0.95 + 0.1*wheel.mrTotalContactWidth/wheel.radius);			
			local fx = 0.02*wheel.radius*wheel.mrLastTireLoad/wheel.mrTotalContactWidth;
			wheel.mrCurrentRollingResistance = baseRr * math.max(0.8, 1.2 - 0.15 * fx);
			
			--wheel.mrSlippingResistanceEnabled = false;
		end
	end
	
	--if wheel.radius>0 and wheel.mrLastTireLoad>0 and frictionCoeff>0 then
	--	wheel.mrCurrentRollingResistance = baseRr * (0.9 + 0.15*wheel.mrTotalContactWidth/wheel.radius) * math.max(0.8, 1.2 -6*wheel.radius*wheel.mrTotalContactWidth/(wheel.mrLastTireLoad*frictionCoeff^2));
	--end
	
	--if Vehicle.debugRendering then
	--	print(string.format("mrGetTireFriction - frictionCoeff=%1.2f - baseRr=%1.4f - resultRr=%1.4f - width=%1.2f, radius=%1.2f, lastTireLoad=%2.2f", frictionCoeff, baseRr, wheel.mrCurrentRollingResistance, wheel.mrTotalContactWidth, wheel.radius, wheel.mrLastTireLoad));
	--end
	
	return frictionCoeff;
end


WheelsUtil.mrLoadRollingResistanceValues = function(tireType, groundType)

	--load "mud" type mr value by default
	local rrDry = WheelsUtil.tireTypes[1].mrRollingResistanceCoeffs[groundType]
	local rrWet = WheelsUtil.tireTypes[1].mrRollingResistanceCoeffsWet[groundType]
	--if mr values are present, load them
	if WheelsUtil.tireTypes[tireType].mrRollingResistanceCoeffs~=nil then
		rrDry = WheelsUtil.tireTypes[tireType].mrRollingResistanceCoeffs[groundType]
	end
	if WheelsUtil.tireTypes[tireType].mrRollingResistanceCoeffsWet~=nil then
		rrWet = WheelsUtil.tireTypes[tireType].mrRollingResistanceCoeffsWet[groundType]
	end
	
	return rrDry, rrWet
		
end


--************************************************************************************************************************************************************
--
WheelsUtil.mrUpdateWheelsPhysics = function(self, superFunc, dt, currentSpeed, acceleration, doHandbrake, requiredDriveMode)

	--print(tostring(g_currentMission.time) .. " WheelsUtil.mrUpdateWheelsPhysics - self.mrUseMrTransmission="..tostring(self.mrUseMrTransmission) .. " - me="..tostring(self.configFileName))
	
	--do not interfer with "genuine" vehicle not using the "mr" transmission
	if not self.mrUseMrTransmission then 
		self.mrUseMrTransmissionFrameCount = 0
		return superFunc(self, dt, currentSpeed, acceleration, doHandbrake, requiredDriveMode)
	end
	
	self.mrUseMrTransmissionFrameCount = math.min(self.mrUseMrTransmissionFrameCountLimit, self.mrUseMrTransmissionFrameCount + 1)

	local accelerationPedal = 0;
	local brakePedal = 0;	
	
	if doHandbrake then
		brakePedal = 1;			
	else

		if not g_currentMission.missionInfo.stopAndGoBraking then

			self.hasStopped = Utils.getNoNil(self.hasStopped, false);
			self.nextMovingDirection = Utils.getNoNil(self.nextMovingDirection, 0);
			
			--print("test - self.mrAvgDrivenWheelsSpeed=" .. tostring(self.mrAvgDrivenWheelsSpeed));			

			--if math.abs(acceleration) < 0.001 and math.abs(self.lastSpeedAcceleration) < 0.0001 and math.abs(self.lastSpeedReal) < 0.0001 and math.abs(self.lastMovedDistance) < 0.001 then
			if math.abs(acceleration) < 0.001 and math.abs(self.mrAvgDrivenWheelsSpeed)<0.02 then -- 0.02 m/s == 0.072 kph
				self.hasStopped = true;
				accelerationPedal = 0;
				brakePedal = 1;			
				self.nextMovingDirection = 0; --MR
			--elseif math.abs(self.lastSpeedReal) > 0.0001 then
			elseif math.abs(self.mrAvgDrivenWheelsSpeed) > 0.03 then -- 0.03 m/s == 0.108kph
				self.hasStopped = false;
			end

			if self.hasStopped and math.abs(acceleration) > 0.001 then
				self.nextMovingDirection = acceleration;
			end
			if self.nextMovingDirection * acceleration > 0.001 then
				accelerationPedal = acceleration;
				brakePedal = 0;
			elseif not self.hasStopped then
				accelerationPedal = 0;
				if self.nextMovingDirection == 0 then
					brakePedal = 1;
				else
					--brakePedal = math.abs(acceleration);

					if math.abs(acceleration) < 0.001 then
						--[[
						--if currentSpeed < self.motor.lowBrakeForceSpeedLimit or doHandbrake then
						if (currentSpeed*1000) < self.motor.mrMinSpeed then
							--auto park brake
							brakePedal = math.min(1, self.mrLastBrakePedal + dt/1500); --1.5s to fully engage the park brake												
						end
						--]]
						
						--auto park brake
						--20170819 - when the parkbrake has been fully applied, don't disengage it if the vehicle speed raises without the user using the acc pedal
						if self.movingDirection*self.mrLastNotZeroAccDir<=0 then
							brakePedal = 1 
						elseif (currentSpeed*1000) < self.motor.mrMinSpeed then										
							if self.mrLastBrakePedal==1 or currentSpeed<0.1 then --currentSpeed = meter per second
								brakePedal = 1 --fully engage the park brake when 0 speed is reached to avoid going in reverse in very steep hill
							else
								brakePedal = math.min(1, self.mrLastBrakePedal + dt/1500); --1.5s to fully engage the park brake				
							end
						end;
						
					else
						brakePedal = math.abs(acceleration);
					end

				end
			end
			
			if self.nextMovingDirection~=0 then
				self.mrLastNotZeroAccDir = self.nextMovingDirection
			end

		else --g_currentMission.missionInfo.stopAndGoBraking == true
		
			--print("--tracking update wheel physics --" .. tostring(g_currentMission.time));

			local brakeAcc = false;
			--if (self.movingDirection*currentSpeed*Utils.sign(acceleration*self.reverserDirection)) < -0.0003 then      -- 0.0003 * 3600 = 1.08 km/h
			local accDir = Utils.sign(acceleration*self.reverserDirection);
			
			if (self.mrAvgDrivenWheelsSpeed*accDir) < -0.2 then --0.2 = 0.72kph
				-- do we want to accelerate in the opposite direction of the vehicle speed?
				brakeAcc = true;
				
				self.mrSAGBtakeOff = false;
				
				--print("   1. self.mrAvgDrivenWheelsSpeed*accDir<-0.2 =" .. tostring(self.mrAvgDrivenWheelsSpeed*accDir));
				
			elseif self.movingDirection==0 then
				self.mrSAGBtryInversionFailed = false;
				self.mrSAGBtryInversion = false;
				--print("   2. movingDirection==0");
			elseif self.lastSpeedReal>0.003 and self.movingDirection*accDir==-1 then -- 20170308 - 0.003=10.8kph, we also want to continue braking when driven wheels are "blocked" while braking (no ABS) and the vehicle speed is not reasonnable (avoid stopping braking and making the driven wheels slip like hell to go in the right direction)
				brakeAcc = true;
				self.mrSAGBtakeOff = false;
				--print("   3. speed>5.4kph and bad moving direction");
			elseif (self.mrAvgDrivenWheelsSpeed*accDir) < 0 then
				--in this case, normally we do not brake since we want the inversion of direction to happen, but, in some cases (hilly road, "high" gear ratio and heavy load) the tractor keeps changing from braking/not braking because it takes too much time to inverse the direction (and then, once the brakes are released, the tractor goes in the wrong direction before being able to take off
				--if not self.mrSAGBtakeOff then
				--	brakeAcc = true;
				--end
				if self.mrSAGBtryInversionFailed then --0.18kph in case of inversion failure, wait for complete stop before trying again
					--print("   4.1 bad driven wheel direction and last inversion failed");
					brakeAcc = true;					
				else
					--print("   4.1 bad driven wheel direction but no failed inversion, trying to inverse direction");
					self.mrSAGBtryInversion = true;
				end		
			else
				--print("   5 - nothing special - reset parameters");
				self.mrSAGBtryInversionFailed = false;
				self.mrSAGBtryInversion = false;
			end;
			
			if self.mrSAGBtryInversion and brakeAcc then
				self.mrSAGBtryInversion = false;
				self.mrSAGBtryInversionFailed = true;
			end

			if math.abs(acceleration) < 0.001 then	
				--auto park brake
				--20170819 - when the parkbrake has been fully applied, don't disengage it if the vehicle speed raises without the user using the acc pedal
				if self.movingDirection*self.mrLastNotZeroAccDir<=0 then
					brakePedal = 1 
				elseif (currentSpeed*1000) < self.motor.mrMinSpeed then										
					if self.mrLastBrakePedal==1 or currentSpeed<0.1 then --currentSpeed = meter per second
						brakePedal = 1 --fully engage the park brake when 0 speed is reached to avoid going in reverse in very steep hill
					else
						brakePedal = math.min(1, self.mrLastBrakePedal + dt/1500); --1.5s to fully engage the park brake				
					end
				end;
			else
				if not brakeAcc then
					--print("   **** accelerating ****");
					accelerationPedal = acceleration;
					brakePedal = 0;
					--20170819 - store the last valid acc direction (different than 0, and when not braking)
					if accDir~=0 then
						self.mrLastNotZeroAccDir = accDir
					end
				else
					--print("   **** braking ****");
					accelerationPedal = 0;
					brakePedal = math.abs(acceleration);
				end;
			end;
			
			
			--print("test - accelerationPedal="..tostring(accelerationPedal) .. " - brakePedal="..tostring(brakePedal) .." - wheelSpeed="..tostring(self.mrAvgWheelSpeed) .. " - brakeAcc="..tostring(brakeAcc));

		end
		
	end -- doHandBrake
	
	
	--braking is not "ON/OFF" IRL => smooth a little the response time of the braking system (especially useful when playing with a keyboard)
	if brakePedal>self.mrLastBrakePedal then
		brakePedal = math.min(brakePedal, self.mrLastBrakePedal + dt/500); --500ms to be able to fully brake from a "null brake position"  --20170305
	end
	self.mrLastBrakePedal = brakePedal;

	if g_currentMission.missionInfo.stopAndGoBraking then
		self:setBrakeLightsVisibility(math.abs(brakePedal) > 0 and currentSpeed > 0.0006);
	else
		self:setBrakeLightsVisibility(math.abs(brakePedal) > 0 and not self.hasStopped);
	end

	self:setReverseLightsVisibility(self.movingDirection < 0 and (currentSpeed > 0.0006 or accelerationPedal < 0) and self.reverserDirection == 1);

	
	--MR : we want to know when the vehicle is braking
	self.mrIsBraking = brakePedal>0;
	
	
	--MR : 2017 02 17 - smooth a little the acceleration pedal	
	if brakePedal>0 then
		self.mrLastWantedAcc = 0;
	else
		local smoothTime = 500;		
		if accelerationPedal*self.mrLastWantedAcc<0 then
			self.mrLastWantedAcc = 0;
		elseif math.abs(accelerationPedal)<math.abs(self.mrLastWantedAcc) then
			smoothTime = 100; -- very few time when releasing the gaz pedal
		end
		
		if accelerationPedal>self.mrLastWantedAcc then			
			self.mrLastWantedAcc = math.min(accelerationPedal, self.mrLastWantedAcc+dt/smoothTime);
		else
			self.mrLastWantedAcc = math.max(accelerationPedal, self.mrLastWantedAcc-dt/smoothTime);
		end
	end
	accelerationPedal = self.mrLastWantedAcc;
	
	
		
	local ptoRpmWanted = PowerConsumer.getMaxPtoRpm(self);
	
	--20170816 - check self.mrGetNeededPtoRpmWhenControlled	
	ptoRpmWanted = math.max(ptoRpmWanted, self:mrGetNeededPtoRpmWhenControlled())
	
	--if Vehicle.debugRendering and self.isControlled then
	--	print("test call self.motor:mrUpdateVehicleProps - accelerationPedal="..tostring(accelerationPedal) .. " - brakePedal="..tostring(brakePedal) .. " - self.reverserDirection="..tostring(self.reverserDirection) .." - speed="..tostring(self.lastSpeedReal*1000) .. " - self.movingDirection="..tostring(self.movingDirection) .." - ptoRpmWanted="..tostring(ptoRpmWanted) .. " - dt = " .. tostring(dt));
	--end
	
	local torque, maxRotSpeed, gearRatio, clutchTorque, rotInertia, dampingRate = self.motor:mrUpdateVehicleProps(accelerationPedal, brakePedal, self.reverserDirection, self.lastSpeedReal*1000, self.movingDirection, ptoRpmWanted, dt);	
	
	--if Vehicle.debugRendering and self.isControlled then
	--	print("test setVehicleProps - torque="..tostring(torque) .. " - maxRotSpeed="..tostring(maxRotSpeed) .. " - gearRatio="..tostring(gearRatio) .. " - clutchTorque="..tostring(clutchTorque) .. " - rotInertia="..tostring(rotInertia).. " - dampingRate="..tostring(dampingRate));
	--end
	
	--20170827 - reset engine/transmission link when we activate the mrTransmission "on the fly"
	if self.mrUseMrTransmissionFrameCount<self.mrUseMrTransmissionFrameCountLimit then
		torque = 0
		maxRotSpeed = 0
		clutchTorque = 0
	end
	--20170502 method
	--print(tostring(g_currentMission.time) .. " test mr - isAddedToPhysics="..tostring(self.isAddedToPhysics) .. " - motor.clutchRpm="..tostring(self.motor.clutchRpm) .. " - motor.gearRatio = " .. tostring(self.motor.gearRatio)   .. " - setVehicleProps gearRatio = " .. tostring(gearRatio) .. " self.mrUseMrTransmission="..tostring(self.mrUseMrTransmission) .. " - maxRotSpeed=" .. tostring(maxRotSpeed) .. " - clutchTorque="..tostring(clutchTorque) .. " - torque="..tostring(torque) .. " - rotInertia="..tostring(rotInertia) .. " - dampingRate="..tostring(dampingRate))
	setVehicleProps(self.motorizedNode, torque, maxRotSpeed, gearRatio, clutchTorque, rotInertia, dampingRate);
	


	local doBrake = brakePedal > 0;
	for _, implement in pairs(self.attachedImplements) do
		if implement.object ~= nil then
			if doBrake then
				implement.object:onBrake(brakePedal);
			else
				implement.object:onReleaseBrake();
			end
		end
	end

	for _, wheel in pairs(self.wheels) do
		WheelsUtil.mrUpdateWheelPhysics(self, wheel, doHandbrake, brakePedal)
	end
	
	
	

end
WheelsUtil.updateWheelsPhysics = Utils.overwrittenFunction(WheelsUtil.updateWheelsPhysics, WheelsUtil.mrUpdateWheelsPhysics);


--************************************************************************************************************************************************************
--called by WheelsUtil.mrUpdateWheelsPhysics
--set the correct brake force to the wheel function of the wheel radius (otherwise, if the same brakeForce is applied to all wheels, the "small" wheels of the vehicle would always "block" themselves before the "tall" wheels
-- Example : tractor = front wheels "block" whereas rear wheels never block
-- Example : combine harvester = at still on a slope, rear wheels are blocked by the brakeForce whereas the front wheel turn (brakes are applied !)
-- Only useful for "moreRealistic" vehicles since base game vehicles "cheat" with a "more-than" double friction coeff (too much friction for a wheel to be blocked, even with a great brakeforce)
WheelsUtil.mrUpdateWheelPhysics = function(self, wheel, handbrake, brakePedal)

	if self.isAddedToPhysics then	
		if wheel.mrNotAWheel then
			local damping = wheel.rotationDamping;
			if not wheel.hasGroundContact and damping==0 then
				damping = 0.03 * wheel.mass
			end
			setWheelShapeProps(wheel.node, wheel.wheelShape, 0, 0, 0, damping)		
		else
		
			local noBrakeLimitation = false
		
			local brakeForce = brakePedal*self.motor:getBrakeForce()
			local rotationDamping = wheel.rotationDamping
			if handbrake and wheel.hasHandbrake then
				brakeForce = self.motor:getBrakeForce()*10
				noBrakeLimitation = true
			end	
			
			--brakeForce = brakeForce*wheel.brakeFactor*wheel.radius;
			brakeForce = brakeForce*wheel.brakeFactor*wheel.radius*1.5 --20170522 - "boost" brakeforce, necessary to keep something right since we change the "lateral/longitudinal" system by adding a custom lateral force in V0.2.XX
			
			--trick to get more brakeForce at still (otherwise, in very steep slopes, the wheels can turn slowly downhill at still)
			if brakePedal==1 then
				if brakeForce==0 then
					if wheel.mrIsDriven then
						--rotationDamping = 0.1
						rotationDamping = 0.5 * wheel.mass; --20170305 - takes into account wheel mass (same time to reach 0 rotSpeed whatever the mass of the wheel)
					end
				--elseif self.lastSpeedReal<0.0001 then --0.36kph
				elseif self.lastSpeedReal<0.002 then --7.2kph
					brakeForce = brakeForce * (3 - 1000*self.lastSpeedReal)
					if self.lastSpeedReal<0.001 then -- 3.6kph
						noBrakeLimitation = true
					end
				end				
			end
			
			
			
			if brakeForce>0 and not noBrakeLimitation then			
				--20170308 - limit brake force according to weight on the wheel (avoid always blocking the wheels. Provide also more "balance" between empty and loaded vehicle)
				--brakeForce = Utils.clamp(1.1*wheel.mrLastTireLoad*wheel.radius/math.max(1, wheel.mrLastFrictionFx)^0.5, 0.1*brakeForce, brakeForce);
				--brakeForce = Utils.clamp(1.2*wheel.mrLastTireLoad*wheel.radius, 0.1*brakeForce, brakeForce);
				--print("test brakeForce="..tostring(brakeForce) .." - wheel limitation=".. tostring(0.75*wheel.mrLastTireLoad*wheel.radius))
				
				local minBrakeForce = 0.1*brakeForce
				if self.mrUseCarPhysics then
					minBrakeForce = 0.3*brakeForce
				end
				
				--20170621 - "remove" the mrAdditionnalFrictionFx to keep a realistic braking distance
				--brakeForce = Utils.clamp(0.75*wheel.mrLastTireLoad*wheel.radius/wheel.mrAdditionnalFrictionFx, minBrakeForce, brakeForce); --0.75 = magic number that gives the closer result to IRL //// take into account wheel.tireGroundFrictionCoeff ?
				
				--20170906 - check the "incline" -> we want less braking limitation when driving over an incline
				local maxBrakeForce = 0.75*wheel.mrLastTireLoad*wheel.radius
				if wheel.mrContactPoint.isValid then
					local brakeLimitFactor = 1 + 5*(1-math.abs(wheel.mrLastContactNormalY))
					maxBrakeForce = brakeLimitFactor * maxBrakeForce
					minBrakeForce = brakeLimitFactor * minBrakeForce
					--print(" test maxBrakeForce - ny coeff = " .. tostring(brakeLimitFactor))
				end				
				--brakeForce = Utils.clamp(brakeForce, minBrakeForce, maxBrakeForce)
				brakeForce = Utils.clamp(maxBrakeForce, minBrakeForce, brakeForce)
				
			end
			
			--20170316 - add damping when no groundcontact
			if rotationDamping==0 and not wheel.hasGroundContact then
				rotationDamping = 0.03 * wheel.mass
			end
			
			--[[
			--simulate rolling resistance at still
			if brakeForce==0 then
				local wheelGroundSpd = math.abs(wheel.mrLastWheelSpeed*wheel.radius);
				if wheelGroundSpd<0.2 then --0.2 = 0.72kph
					brakeForce = wheel.mrLastTireLoad * wheel.mrCurrentRollingResistance*wheel.radius*math.min(1, 2-10*wheelGroundSpd);
				end
			--else
				--"remove" the mrWheelsFrictionFactor benefit from the braking force
				--brakeForce = brakeForce / self.mrWheelsFrictionFactor;
			end--]]
			
			--if Vehicle.debugRendering and self.isControlled and self.motor then			
			--	local longSlip, latSlip = getWheelShapeSlip(wheel.node, wheel.wheelShape); 
			--	print(string.format("%1.2f WheelsUtil.mrUpdateWheelPhysics - brakeForce=%1.2f - radius=%1.2f - rotationDamping=%1.2f - wheelAxleSpd=%1.4f wheelGroundSpeed=%1.2f vehicleSpeed=%1.2f longSlip=%2.2f latSlip=%2.2f frictionFactor=%1.2f gearRatio=%2.4f clutchTorque=%3.3f clutchRpm=%4.2f nonClampedRpm=%4.2f",
			--	g_currentMission.time,brakeForce, wheel.radius, wheel.rotationDamping, wheel.mrLastWheelSpeed, wheel.mrLastWheelSpeed*wheel.radius*3.6, self.lastSpeedReal*3600, longSlip*100, latSlip*100, self.mrWheelsFrictionFactor, self.motor.gearRatio, 1000*self.motor.mrLastClutchTorque, self.motor.clutchRpm, self.motor.nonClampedMotorRpm));
			--end;
			local steeringAngle = wheel.steeringAngle
			if steeringAngle==0 then
				steeringAngle = wheel.mrStabilizingSteeringAngle
			end			
			
			--20170705 - allow to brake a wheel even if it is driven, while steering (example : Siloking selfline 1612, front wheels)			
			if wheel.mrApplyBrakeDuringVehicleSteering then
				local maxForce = wheel.mrApplyBrakeDuringVehicleSteeringMaxBrakeForce
				if self.mrLastWantedAcc<0 then
					maxForce = maxForce * wheel.mrApplyBrakeDuringVehicleSteeringMaxBrakeForceReverseFx
				end
				if wheel.mrApplyBrakeDuringVehicleSteeringLeft then
					if self.rotatedTime>0 then
						if self.maxRotTime>0 then						
							brakeForce = math.max(brakeForce, maxForce*self.rotatedTime/self.maxRotTime)							
						end	
					end
				else
					if self.rotatedTime<0 then
						if self.minRotTime<0 then						
							brakeForce = math.max(brakeForce, maxForce*self.rotatedTime/self.minRotTime)							
						end	
					end
				end
			end
			
			--print(tostring(g_currentMission.time) .. " setting setWheelShapeProps - wheelnode="..tostring(wheel.node) .." - wheelShape="..tostring(wheel.wheelShape).." - brakeForce="..tostring(brakeForce).." - steeringAngle="..tostring(steeringAngle) .." - rotationDamping="..tostring(rotationDamping))
			setWheelShapeProps(wheel.node, wheel.wheelShape, 0, brakeForce, steeringAngle, rotationDamping)			
		end
	end
end



--************************************************************************************************************************************************************
-- update mrVehicleIsStill
WheelsUtil.mrUpdateWheelsGraphics = function(self, superFunc, dt)

	--do not interfer with "genuine" vehicle
	if not self.mrIsMrVehicle then return superFunc(self, dt);end;
	
	--print(g_currentMission.time .. " mrUpdateWheelsGraphics for " .. self.configFileName .. " - self.isAddedToPhysics="..tostring(self.isAddedToPhysics));

	if self.isServer then
		self.hasWheelGroundContact = false;
	end
	
	--MR *****************	
	self.mrTotalxDriveDiff = 0;
	self.mrVehicleIsStill = false;
	----------------------
	
	for _, wheel in pairs(self.wheels) do
		WheelsUtil.updateWheelSteeringAngle(self, wheel, dt);
		--print(tostring(g_currentMission.time) .. " test - mrWheelShapesValid = " .. tostring(self.mrWheelShapesValid) .. " - wheelshapecreatedtime="..tostring(self.mrWheelShapesLastCreatedTime))
		if self.isServer and self.isAddedToPhysics and self.mrWheelShapesValid then
			WheelsUtil.updateWheelHasGroundContact(wheel);
			if wheel.hasGroundContact then
				self.hasWheelGroundContact = true;
			end

			--20170712 - check if wheelshape is "valid"	with entityExists		
			--if wheel.updateWheel then			
			--if wheel.updateWheel and entityExists(wheel.wheelShape) and entityExists(wheel.node) then
			if wheel.updateWheel and entityExists(wheel.node) then --entityExists(wheel.wheelShape) does not work as intented
			
				--test
				--local x,y,z, xDrive, suspensionLength = getWheelShapePosition(wheel.node, 99999)
				--print("test getWheelShapePosition x="..tostring(x) .. " y="..tostring(y).." z="..tostring(z) .." xdrive="..tostring(xDrive).." suspension="..tostring(suspensionLength))
				--if x~=x or y~=y or z~=z or xDrive~=xDrive then --check for "nan" value
				--	print("test - NAN value detected !")
				--end
				local x,y,z, xDrive, suspensionLength = getWheelShapePosition(wheel.node, wheel.wheelShape)				
					
				if x~=x or y~=y or z~=z or xDrive~=xDrive then --check for "nan" value
					--nan value returned by the "getWheelShapePosition" function
					if Vehicle.debugRendering then
						RealisticUtils.printWarning("WheelsUtil.mrUpdateWheelsGraphics", "getWheelShapePosition has returned a 'nan' value. wheel.node='"..tostring(wheel.node).."' - wheel.wheelShape='"..tostring(wheel.wheelShape).."' - x='"..tostring(x).."' - y='"..tostring(y).."' - z='"..tostring(z).."' - xDrive='"..tostring(xDrive).."' - suspensionLength='"..tostring(suspensionLength).."'", true)
					end
				else
				
					--print(tostring(g_currentMission.time) .. " test wheel update graphics - xDrive="..tostring(xDrive) .. " - xDriveOffset="..tostring(wheel.xDriveOffset) .. " - suspensionLength = " .. tostring(suspensionLength) .. " - wheel.node=" .. tostring(wheel.node) .. " - wheel.wheelShape="..tostring(wheel.wheelShape));
					
					xDrive = xDrive + wheel.xDriveOffset
					
					--MR ************************************				
					self.mrTotalxDriveDiff = self.mrTotalxDriveDiff + xDrive - wheel.netInfo.xDrive;				
					--******************************************		
					
					WheelsUtil.updateWheelGraphics(self, wheel, x, y, z, xDrive, suspensionLength);

					--fill netinfo (on server)
					wheel.netInfo.x = x;
					wheel.netInfo.y = y;
					wheel.netInfo.z = z;
					
					
					
					wheel.netInfo.xDrive = xDrive;
					wheel.netInfo.suspensionLength = suspensionLength;
				end
			else
				wheel.updateWheel = true
			end
		else
			-- client code
			local x, y, z = wheel.netInfo.x, wheel.netInfo.y, wheel.netInfo.z;
			local xDrive = wheel.netInfo.xDrive;
			local suspensionLength = wheel.netInfo.suspensionLength
			WheelsUtil.updateWheelGraphics(self, wheel, x, y, z, xDrive, suspensionLength);
		end
	end	
	
	--MR ******************
	if self.isServer then
		if not self.isAddedToPhysics or (self.lastSpeedReal==0 and self.mrTotalxDriveDiff==0) then	
			-- vehicle is at still and so, getWheelShapeContactForce/getWheelShapeContactNormal/getWheelShapeAxleSpeed/getWheelShapeSlip/getMotorRotationSpeed can return "fake" values (not reliable)
			self.mrVehicleIsStill = true;
			--print(tostring(g_currentMission.time) .. " test - mr vehicle is still : " .. tostring(self.configFileName));
		end
	end	
	--print("test - mrVehicleIsStill="..tostring(self.mrVehicleIsStill) .. " - self.lastSpeedReal="..tostring(self.lastSpeedReal*3600) .." - self.mrTotalxDriveDiff="..tostring(self.mrTotalxDriveDiff));
	-----------------------
	
end
WheelsUtil.updateWheelsGraphics = Utils.overwrittenFunction(WheelsUtil.updateWheelsGraphics, WheelsUtil.mrUpdateWheelsGraphics);


--************************************************************************************************************************************************************
-- modify tyre deformation script
WheelsUtil.mrUpdateWheelGraphics = function(self, superFunc, wheel, x, y, z, xDrive, suspensionLength)

	--do not interfer with "genuine" vehicle
	if not self.mrIsMrVehicle then return superFunc(self, wheel, x, y, z, xDrive, suspensionLength);end;

	local steeringAngle = wheel.steeringAngle;
	if not wheel.showSteeringAngle then
		steeringAngle = 0;
	end

	local dirX, dirY, dirZ = 0, -1, 0
	if wheel.repr == wheel.driveNode then
		setRotation(wheel.repr, xDrive, steeringAngle, 0);
	else
		dirX, dirY, dirZ = localDirectionToLocal(wheel.repr, getParent(wheel.repr), 0, -1, 0);
		setRotation(wheel.repr, 0, steeringAngle, 0);		
		setRotation(wheel.driveNode, xDrive, 0, 0);
	end

	if wheel.wheelTire ~= nil and wheel.mrNoDeformation==false then
		local x, y, z, _ = getShaderParameter(wheel.wheelTire, "morphPosition");
		
		
		--not adequate because on some vehicle, we have to "cheat" with the deltaY to get the wheel at the right position (example : negative "initialCompression" value)
		--local deformation = Utils.clamp((wheel.deltaY+0.04-suspensionLength)*0.7, 0, wheel.maxDeformation)
		local deformation = 0;
		if wheel.mrTotalContactWidth>0 then
			--[[local deformationFx = Utils.clamp(-0.6+0.017*wheel.mrLastTireLoad*wheel.mrPressureFx/(wheel.mrTotalContactWidth*wheel.radius^0.5), 0, 1);	
			--deformationFx = Utils.clamp(-0.6+0.017*wheel.mrLastTireLoad*wheel.mrPressureFx/(wheel.radius*wheel.mrTotalContactWidth), 0, 1);		
			if deformationFx<=0.3 then
				deformation = 0;
			elseif deformationFx<=0.5 then
				deformation = 3.5*(deformationFx-0.3)*wheel.maxDeformation; -- 0 to 70%
			else
				--deformationFx between 0.5 and 1
				deformation = (0.7 + (deformationFx-0.5)*0.6)*wheel.maxDeformation;
			end--]]
			
			--deformation =  Utils.clamp(-0.04+wheel.maxDeformation*0.1/wheel.mrTotalContactWidth/wheel.mrPressureFx*(wheel.mrLastTireLoad/wheel.radius)^0.5, 0, wheel.maxDeformation);	
			--deformation =  Utils.clamp(-0.04+wheel.maxDeformation*0.1/wheel.mrTotalContactWidth/wheel.mrPressureFx*(wheel.mrLastTireLoad/wheel.radius)^0.55, 0, 1.15*wheel.maxDeformation);	--20170502 - allow more deformation
			
			--20171202 - estimate the tire load for client since the "wheel.mrLastTireLoad" can only be computed serverside
			--[[
			local tireLoad = wheel.mrLastTireLoad;
			if not self.isServer or not self.mrWheelShapesValid then
				--client - very good approximation since we are talking of standard spring here
				tireLoad = (wheel.suspTravel-suspensionLength)*wheel.spring+wheel.mass*9.81;
				--print("test load - mrLastTireLoad="..tostring(wheel.mrLastTireLoad) .. " - tireLoad="..tostring(tireLoad) .. " - spring="..tostring(wheel.spring).." - suspTravel="..tostring(wheel.suspTravel) .. " - suspensionLength="..tostring(suspensionLength))
			end		
			--]]	

			--20171215 - patch 1.5.3 bug = no more "tireLoad" returned when vehicle in a still state			
			local tireLoad = wheel.mrLastTireLoad;
			if not self.isServer or not self.mrWheelShapesValid or tireLoad==0 then			
				tireLoad = WheelsUtil.mrGetTireLoad(wheel, suspensionLength); -- we have to pass the "suspensionLength" here because the "wheel.netInfo.suspensionLength" is not filled yet
			end			
			deformation =  Utils.clamp(-0.04+wheel.maxDeformation*0.1/wheel.mrTotalContactWidth/wheel.mrPressureFx*(tireLoad/wheel.radius)^0.55, 0, 1.15*wheel.maxDeformation);	--20170502 - allow more deformation
			
			
			--if self.lastSpeedReal*3600>5 then
			--	print("test wheel - maxDeformation="..tostring(wheel.maxDeformation) .." - deformation="..tostring(deformation) .." - radius="..tostring(wheel.radius) .. " - suspLength="..tostring(suspensionLength));
			--end
			
			--print("test - last dt is ="..tostring(self.mrLastDt))
			
			--limit the tyre deformation speed because this is really annoying when the tyre get crushed and then is released etc etc
			--20171209 - no limit when the game is initializing
			if self.mrWheelsGraphicsInitializing then
				wheel.mrLastDeformation = deformation;
			else
				if deformation>wheel.mrLastDeformation then
					wheel.mrLastDeformation = math.min(deformation, wheel.mrLastDeformation + self.mrLastDt/4000); --max = 25cm per second
				else			
					wheel.mrLastDeformation = math.max(deformation, wheel.mrLastDeformation - self.mrLastDt/4000);
				end	
			end;
			
		end
		
		setShaderParameter(wheel.wheelTire, "morphPosition", x, y, z, wheel.mrLastDeformation, false);
		

		if wheel.additionalWheels ~= nil then
			for _, additionalWheel in pairs(wheel.additionalWheels) do
				local x, y, z, _ = getShaderParameter(additionalWheel.wheelTire, "morphPosition");
				setShaderParameter(additionalWheel.wheelTire, "morphPosition", x, y, z, wheel.mrLastDeformation, false);
			end
		end		

		suspensionLength = suspensionLength+wheel.mrLastDeformation
	end

	suspensionLength = suspensionLength - wheel.deltaY	
	setTranslation(wheel.repr, wheel.startPositionX + dirX*suspensionLength, wheel.startPositionY + dirY*suspensionLength, wheel.startPositionZ + dirZ*suspensionLength);

	if wheel.steeringNode ~= nil then
		local refAngle = wheel.steeringNodeMaxRot;
		local refTrans = wheel.steeringNodeMaxTransX
		local refRot = wheel.steeringNodeMaxRotY;
		if steeringAngle < 0 then
			refAngle = wheel.steeringNodeMinRot;
			refTrans = wheel.steeringNodeMinTransX;
			refRot = wheel.steeringNodeMinRotY;
		end
		local steering = 0;
		if refAngle ~= 0 then
			steering = steeringAngle / refAngle;
		end

		if wheel.steeringNodeMinTransX ~= nil then
			local x,y,z = getTranslation(wheel.steeringNode);
			x = refTrans * steering;
			setTranslation(wheel.steeringNode, x, y, z);
		end
		if wheel.steeringNodeMinRotY ~= nil then
			local rotX,rotY,rotZ = getRotation(wheel.steeringNode);
			rotY = refRot * steering;
			setRotation(wheel.steeringNode, rotX, rotY, rotZ);
		end
	end

	if wheel.fenderNode ~= nil then
		local angleDif = 0;
		if steeringAngle > wheel.fenderRotMax then
			angleDif = wheel.fenderRotMax - steeringAngle;
		elseif steeringAngle < wheel.fenderRotMin then
			angleDif = wheel.fenderRotMin - steeringAngle;
		end
		setRotation(wheel.fenderNode, 0, angleDif, 0);
	end
	
end
WheelsUtil.updateWheelGraphics = Utils.overwrittenFunction(WheelsUtil.updateWheelGraphics, WheelsUtil.mrUpdateWheelGraphics);


--************************************************************************************************************************************************************
-- versatile yrot wheels can have "infinite" angle value (400°, 600°, 1000° or more)
WheelsUtil.mrGetWheelSteeringAngle = function(wheel)

	local wheelSteeringAngle = wheel.steeringAngle
	--test versatileYRot
	if wheel.versatileYRot then
		wheelSteeringAngle = wheelSteeringAngle % (math.pi)
		if wheelSteeringAngle>(math.pi/2) then
			wheelSteeringAngle = wheelSteeringAngle - math.pi
		elseif wheelSteeringAngle<(-math.pi/2) then
			wheelSteeringAngle = wheelSteeringAngle + math.pi
		end
	end
	
	return wheelSteeringAngle

end

--************************************************************************************************************************************************************
-- return the current load (in KN)
WheelsUtil.mrGetTireLoad = function(wheel, suspensionCompressionLength)	
	local suspLen = suspensionCompressionLength
	if suspLen == nil then
		suspLen = wheel.netInfo.suspensionLength
	end
	tireLoad = math.max(0, (wheel.suspTravel-suspLen)*wheel.spring+wheel.mass*9.81);		
	return tireLoad;
end

