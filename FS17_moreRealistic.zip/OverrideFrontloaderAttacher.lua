﻿--************************************************************************************************************************************************************	
--base game = front axle pivot locked when a frontloader is attached
--MR : as IRL, no locking => is it still ok regarding stability for a game ?
FrontloaderAttacher.mrOnAttachImplement = function(self, superfunc, implement)

	if not self.mrIsMrVehicle then return superfunc(self, implement); end
	
	--mr = remove the "locking" of the front axle pivot joint
	--we have to check the stability
	--[[
    local attacherJoint = self.attacherJoints[implement.jointDescIndex]
    if attacherJoint.jointType == AttacherJoints.JOINTTYPE_ATTACHABLEFRONTLOADER and self.isServer then
        if self.frontloaderAttacher.frontAxisJoint ~= nil then
            -- copy rotlimit
            self.frontloaderAttacher.rotLimit = {unpack(self.componentJoints[self.frontloaderAttacher.frontAxisJoint].rotLimit)}
            for i=1, 3 do
                self:setComponentJointRotLimit(self.componentJoints[self.frontloaderAttacher.frontAxisJoint], i, 0, 0)
            end
        end
    end--]]
	
	--mr = add the mass of the loader to the vehicle if it is hard attached
	local attacherJoint = self.attacherJoints[implement.jointDescIndex]
    if attacherJoint.jointType == AttacherJoints.JOINTTYPE_ATTACHABLEFRONTLOADER and self.isServer then
		if implement.object.attacherJoint.hardAttach then
			local implementMass = getMass(implement.object.components[1].node)
			--take int oaccount "fillable" vehicle
			if self.emptyMass~=nil then
				self.mrFlaPreviousMass = self.emptyMass
				self.emptyMass = self.emptyMass + implementMass
			else
				local vehicleComponentNode = self:getParentComponent(attacherJoint.jointTransform)
				self.mrFlaPreviousMass = getMass(vehicleComponentNode)
				setMass(vehicleComponentNode, self.mrFlaPreviousMass+implementMass)
			end
		end
	end
	
end
FrontloaderAttacher.onAttachImplement = Utils.overwrittenFunction(FrontloaderAttacher.onAttachImplement, FrontloaderAttacher.mrOnAttachImplement)


FrontloaderAttacher.mrOnDetachImplement = function(self, superfunc, implementIndex)

	if not self.mrIsMrVehicle then return superfunc(self, implementIndex); end
	--[[
    local implement = self.attachedImplements[implementIndex];
    local attacherJoint = self.attacherJoints[implement.jointDescIndex]
    if attacherJoint.jointType == AttacherJoints.JOINTTYPE_ATTACHABLEFRONTLOADER and self.isServer then
        if self.frontloaderAttacher.frontAxisJoint ~= nil then
            for i=1, 3 do
                self:setComponentJointRotLimit(self.componentJoints[self.frontloaderAttacher.frontAxisJoint], i, -self.frontloaderAttacher.rotLimit[i], self.frontloaderAttacher.rotLimit[i])
            end
        end
    end--]]
	
	--Mr - remove the additionnal mass of the "hard attached loader"
	local implement = self.attachedImplements[implementIndex];
	local attacherJoint = self.attacherJoints[implement.jointDescIndex]
    if attacherJoint.jointType == AttacherJoints.JOINTTYPE_ATTACHABLEFRONTLOADER and self.isServer then
		if implement.object.attacherJoint.hardAttach and self.mrFlaPreviousMass then
			if self.emptyMass~=nil then
				self.emptyMass = self.mrFlaPreviousMass
			else
				local vehicleComponentNode = self:getParentComponent(attacherJoint.jointTransform)
				setMass(vehicleComponentNode, self.mrFlaPreviousMass)
			end
		end
	end
	
end
FrontloaderAttacher.onDetachImplement = Utils.overwrittenFunction(FrontloaderAttacher.onDetachImplement, FrontloaderAttacher.mrOnDetachImplement)




