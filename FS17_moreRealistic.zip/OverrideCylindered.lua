﻿--************************************************************************************************************************************************************
--add new feature : mrCOMtransByTransValue => translation of the center of mass depending on the current translation value of a movingTool (not possible for a "fillable" vehicle since there is already a variable "center of mass" feature)
--add new feature : claws => allow to set a joint between the "otherActorId" (log or bale) and our own component by using the "raycastAll" function when our claws are closed
Cylindered.mrLoad = function(self)
	
	if self.mrIsMrVehicle then	
		--parse all moving tools again to check if there is a "mrCOMtransByTransValue" value		
		local i=0
		while true do
			local baseName = string.format("vehicle.movingTools.movingTool(%d)", i);
			if not hasXMLProperty(self.xmlFile, baseName) then
				break;
			end
			local node = Utils.indexToObject(self.components, getXMLString(self.xmlFile, baseName.."#index"))
			if node ~= nil then				
				local x, y, z = Utils.getVectorFromString(getXMLString(self.xmlFile, baseName..".translation#mrCOMtransByTransValue"));
				if x ~= nil and y ~= nil and z ~= nil then				
					--look for the corresponding "movingTools"
					if self.nodesToMovingTools ~= nil and self.nodesToMovingTools[node] ~= nil then
						local movingTool = self.nodesToMovingTools[node]
						--add the "mr" property
						movingTool.mrCOMnode = Utils.getNoNil(Utils.indexToObject(self.components, getXMLString(self.xmlFile, baseName..".translation#mrCOMnode")), self.components[1].node)						
						movingTool.mrCOMtransByTransValue = {x,y,z}
						movingTool.mrCOMstartTrans = {getCenterOfMass(movingTool.mrCOMnode)}
					end
				else
					--20170807 - look for "mrCOMtransByRotValue" (we can't use both at the same time)
					local x, y, z = Utils.getVectorFromString(getXMLString(self.xmlFile, baseName..".rotation#mrCOMtransByRotValue"));
					if x ~= nil and y ~= nil and z ~= nil then				
						--look for the corresponding "movingTools"
						if self.nodesToMovingTools ~= nil and self.nodesToMovingTools[node] ~= nil then
							local movingTool = self.nodesToMovingTools[node]
							--add the "mr" property
							movingTool.mrCOMnode = Utils.getNoNil(Utils.indexToObject(self.components, getXMLString(self.xmlFile, baseName..".rotation#mrCOMnode")), self.components[1].node)						
							movingTool.mrCOMtransByRotValue = {x,y,z}
							movingTool.mrCOMstartTrans = {getCenterOfMass(movingTool.mrCOMnode)}
						end
					end
				end				
			end
			i = i + 1
		end
		
		--claw feature (allow to lock down a log or a bale with a "claw" when the claw is full closed
		--example : STEPA FHL13AK wood trailer		
		--claw present ?
		local baseName1 = "vehicle.moreRealistic.claw"
		if hasXMLProperty(self.xmlFile, baseName1) then
		
			local clawMovingToolNode = Utils.indexToObject(self.components, getXMLString(self.xmlFile, baseName1.."#movingToolNodeIndex"))			
			local clawJointNode = Utils.indexToObject(self.components, getXMLString(self.xmlFile, baseName1.."#jointNode"))
			if clawMovingToolNode~=nil and clawJointNode~=nil then
				--check there is an existing movingTool with this index
				if self.nodesToMovingTools[clawMovingToolNode]~=nil then
		
					self.mrClaw = {}
					self.mrClaw.jointNode = clawJointNode
					self.mrClaw.movingTool = self.nodesToMovingTools[clawMovingToolNode]					
					
					self.mrClaw.triggerRotStartPercent = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#triggerRotStartPercent"), 90)
					self.mrClaw.triggerRotEndPercent = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#triggerRotEndPercent"), 100)
					
					self.mrClaw.jointCollisionEnabled = Utils.getNoNil(getXMLBool(self.xmlFile, baseName1.."#jointCollisionEnabled"), true)
					
					self.mrClaw.transLimit = {}	
					self.mrClaw.transLimit[1] = {minLimit = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointTransLimitMinX"), -0.05)
												,maxLimit = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointTransLimitMaxX"), 0.05)}
					self.mrClaw.transLimit[2] = {minLimit = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointTransLimitMinY"), -0.05)
												,maxLimit = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointTransLimitMaxY"), 0.05)}
					self.mrClaw.transLimit[3] = {minLimit = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointTransLimitMinZ"), -0.05)
												,maxLimit = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointTransLimitMaxZ"), 0.05)}
					
					self.mrClaw.rotLimit = {}					
					self.mrClaw.rotLimit[1] = {minLimit = math.rad(Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointRotLimitMinX"), -10))
											  ,maxLimit = math.rad(Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointRotLimitMaxX"), 10))}
					self.mrClaw.rotLimit[2] = {minLimit = math.rad(Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointRotLimitMinY"), -10))
											  ,maxLimit = math.rad(Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointRotLimitMaxY"), 10))}
					self.mrClaw.rotLimit[3] = {minLimit = math.rad(Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointRotLimitMinZ"), -10))
											  ,maxLimit = math.rad(Utils.getNoNil(getXMLFloat(self.xmlFile, baseName1.."#jointRotLimitMaxZ"), 10))}
					
					self.mrClawRaycastCallback = Cylindered.mrClawRaycastCallback
					self.mrClawGrabAll = Cylindered.mrClawGrabAll					
					self.mrClawReleaseAll = Cylindered.mrClawReleaseAll	
					self.mrClawCreateJoint = Cylindered.mrClawCreateJoint 
					
					self.mrClaw.grabbingRaycasts = {}					
					self.mrClaw.grabJoints = {}
					
					self.mrClaw.everythingReleased = true
					self.mrClaw.grabAllDone = false
					
					--parse all grabbingRaycast
					local i=0
					while true do
						local baseName2 = string.format(baseName1..".grabbingRaycast(%d)", i)
						if not hasXMLProperty(self.xmlFile, baseName2) then
							break
						end
						
						local raycastNode = Utils.indexToObject(self.components, getXMLString(self.xmlFile, baseName2.."#node"))
						if raycastNode~=nil then
							local gRaycast={}
							gRaycast.node = raycastNode
							gRaycast.distance = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName2.."#distance"), 0.5)					
							gRaycast.xOffset = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName2.."#xOffset"), 0)
							gRaycast.yOffset = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName2.."#yOffset"), 0)
							gRaycast.zOffset = Utils.getNoNil(getXMLFloat(self.xmlFile, baseName2.."#zOffset"), 0)
							gRaycast.useDirectionX = getXMLBool(self.xmlFile, baseName2.."#useDirectionX")
							gRaycast.useDirectionZ = getXMLBool(self.xmlFile, baseName2.."#useDirectionZ")
							table.insert(self.mrClaw.grabbingRaycasts, gRaycast)
						end
						
						i = i+1
					end	
					
				end--movingTool exist
			
			end --clawMovingToolNode nil
		end--vehicle.moreRealistic.claw exist in xml	

		
	end--mrIsMrVehicle
	
end
Cylindered.load = Utils.appendedFunction(Cylindered.load, Cylindered.mrLoad)




--************************************************************************************************************************************************************
--update the center of mass according to the current Translation state of the movingTool
Cylindered.mrSetDirty = function(self, part)
	
	if self.isServer then
	
		if part.mrCOMtransByTransValue~=nil then
			local curTransValue = part.curTrans[part.translationAxis]
			--print("setting new trans, current movingTool trans value = " .. tostring(curTransValue) .. " - start com z = "..tostring(part.mrCOMstartTrans[3]) .. " - new com z=" .. tostring(part.mrCOMstartTrans[3]+part.mrCOMtransByTransValue[3]*curTransValue))
			setCenterOfMass(part.mrCOMnode, part.mrCOMstartTrans[1]+part.mrCOMtransByTransValue[1]*curTransValue, part.mrCOMstartTrans[2]+part.mrCOMtransByTransValue[2]*curTransValue, part.mrCOMstartTrans[3]+part.mrCOMtransByTransValue[3]*curTransValue)
		elseif part.mrCOMtransByRotValue~=nil then
			local curRotValue = math.deg(part.curRot[part.rotationAxis])
			--print("setting new trans, current movingTool rot value = " .. tostring(curRotValue) .. " - start com z = "..tostring(part.mrCOMstartTrans[3]) .. " - new com z=" .. tostring(part.mrCOMstartTrans[1]+part.mrCOMtransByRotValue[1]*curRotValue))
			setCenterOfMass(part.mrCOMnode, part.mrCOMstartTrans[1]+part.mrCOMtransByRotValue[1]*curRotValue, part.mrCOMstartTrans[2]+part.mrCOMtransByRotValue[2]*curRotValue, part.mrCOMstartTrans[3]+part.mrCOMtransByRotValue[3]*curRotValue)
		end
		
		--check claw feature needed or not
		if self.mrClaw~=nil then
			if part==self.mrClaw.movingTool then
				--print(tostring(g_currentMission.time) .. " - Cylindered.mrSetDirty - check claw rotation - value = " .. tostring(math.deg(part.curRot[part.rotationAxis])))
				--check rotation
				if part.rotMax>part.rotMin then
					local curRotPercent = 1 - ((part.rotMax - part.curRot[part.rotationAxis]) / (part.rotMax - part.rotMin))	
					curRotPercent = curRotPercent * 100
					--print("test current percent = " .. tostring(curRotPercent))
					if curRotPercent>=self.mrClaw.triggerRotStartPercent and curRotPercent<=self.mrClaw.triggerRotEndPercent then							
						self:mrClawGrabAll()
					else						
						self:mrClawReleaseAll()						
					end					
				end
			end
		end
		
		
		
	end--self.isServer
	
end
Cylindered.setDirty = Utils.appendedFunction(Cylindered.setDirty, Cylindered.mrSetDirty)

--************************************************************************************************************************************************************
--call several raycast to check if there are some logs or bales to grab
Cylindered.mrClawGrabAll = function(self)
	if not self.mrClaw.grabAllDone then
		--print(tostring(g_currentMission.time) .. " mrClawGrabAll - launching raycasts")
		for _,gRaycast in pairs (self.mrClaw.grabbingRaycasts) do
			local x,y,z = localToWorld(gRaycast.node, gRaycast.xOffset, gRaycast.yOffset, gRaycast.zOffset)
			local direction = 1
			if gRaycast.distance<0 then
				direction = -1
			end
			local dx,dy,dz
			if gRaycast.useDirectionZ then
				dx,dy,dz= localDirectionToWorld(gRaycast.node, 0,0,direction)
			elseif gRaycast.useDirectionX then 
				dx,dy,dz= localDirectionToWorld(gRaycast.node, direction,0,0)
			else
				dx,dy,dz= localDirectionToWorld(gRaycast.node, 0,direction,0)
			end
			--print("   raycast launched - distance="..tostring(gRaycast.distance) .. " - direction="..tostring(direction))
			raycastAll(x,y,z, dx,dy,dz, "mrClawRaycastCallback", math.abs(gRaycast.distance), self)
		end	
		self.mrClaw.grabAllDone = true
	end
end

--************************************************************************************************************************************************************
--remove all the "joints" with logs and bales (all objects locked)
Cylindered.mrClawReleaseAll = function(self)
	self.mrClaw.grabAllDone = false
	if not self.mrClaw.everythingReleased then
		--print(tostring(g_currentMission.time) .. " mrClawReleaseAll - releasing")		
		for objectId,jointIndex in pairs(self.mrClaw.grabJoints) do
			--print("    removing joint for shapeID=" .. tostring(objectId) .." jointIndex="..tostring(jointIndex))
			if entityExists(objectId) then
				removeJoint(jointIndex)
			end        
			self.mrClaw.grabJoints[objectId] = nil
		end
		self.mrClaw.everythingReleased = true
	end
end

--************************************************************************************************************************************************************
--callback of the raycasts from mrClawGrabAll
Cylindered.mrClawRaycastCallback = function(self, otherActorId, x, y, z, distance)
	local vehicle = g_currentMission.nodeToVehicle[otherActorId]	
	
	--print(tostring(g_currentMission.time) .. " - mrClawRaycastCallback - otherActorId="..tostring(otherActorId) .. " - distance = " .. tostring(distance))
	
	if vehicle == nil and getRigidBodyType(otherActorId) == "Dynamic" then	
		--log or bale ? grab it		
		self:mrClawCreateJoint(otherActorId, x,y,z)
		self.mrClaw.everythingReleased = false
	end
	return true -- we want to keep on searching up to the max distance (catch all logs or bales)
end

--************************************************************************************************************************************************************
--create joint between 
Cylindered.mrClawCreateJoint = function(self, objectId, x,y,z)
	--check if the  objectId is not already grabbed
	if self.mrClaw.grabJoints[objectId]==nil then
	
		--x,y,z = world position of the raycast hit		
	
		--create a joint
		--actor 1 = self.mrClaw.jointNode
		--actor 2 = objectId
		 local constr = JointConstructor:new()
		constr:setActors(self.mrClaw.jointNode, objectId)
		
		--keep the current position and orientation
		local rotX, rotY, rotZ = getWorldRotation(self.mrClaw.jointNode)
		constr:setJointWorldRotations(rotX, rotY, rotZ, rotX, rotY, rotZ)
		constr:setJointWorldPositions(x,y,z, x,y,z)
		
		for i=1,3 do
			constr:setTranslationLimit(i-1, true, self.mrClaw.transLimit[i].minLimit, self.mrClaw.transLimit[i].maxLimit)  
		end		
		for i=1,3 do			
			constr:setRotationLimit(i-1, self.mrClaw.rotLimit[i].minLimit, self.mrClaw.rotLimit[i].maxLimit)			
		end
		
		local rotSpring = 9999999
		local rotDamping = 9999
		constr:setRotationLimitSpring(rotSpring,rotDamping,rotSpring,rotDamping,rotSpring,rotDamping)
		
		constr:setEnableCollision(self.mrClaw.jointCollisionEnabled)
		local jointIndex = constr:finalize()
		self.mrClaw.grabJoints[objectId] = jointIndex --store the jointIndex	for deleting
		--print(tostring(g_currentMission.time) .. " - mrClawCreateJoint - otherActorId="..tostring(objectId) .. " - jointIndex="..tostring(jointIndex))
	end	
	
end

--************************************************************************************************************************************************************
--remove existing joint before deleting the vehicle
Cylindered.mrDelete = function(self)	
	if self.isServer then
		if self.mrClaw~=nil then
			self.mrClaw.everythingReleased = false
			self:mrClawReleaseAll()
		end
	end
end
Cylindered.delete = Utils.appendedFunction(Cylindered.delete, Cylindered.mrDelete)



