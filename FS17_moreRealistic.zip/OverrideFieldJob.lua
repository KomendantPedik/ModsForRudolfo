﻿-----------------------------------------------------------------------------------------------------------------------------------
-- give more or less time depending on the field size and job type
-- balance of the rewarding system (+ some random figures to give better rewards when time is shorter)
-- the "overwrittenFunction" call is launch from the RealisticGlobalListener because we want to check if "Seasons mod" already manage that or not
FieldJob.mrInit = function(self, superFunc, fieldDefinition, jobType, fertiliserLayers, fieldSpraySet, fieldState, growState, fieldPloughFactor)

	--difficult to find what every parameter was.
	--print("test FieldJob.init - fieldDefinition="..tostring(fieldDefinition).." - jobType="..tostring(jobType).." - fertiliserLayers="..tostring(fertiliserLayers).." - fieldSpraySet="..tostring(fieldSpraySet).." - fieldState="..tostring(fieldState) .. " - growState="..tostring(growState) .. " - fieldPloughFactor="..tostring(fieldPloughFactor))

	local result = superFunc(self, fieldDefinition, jobType, fertiliserLayers, fieldSpraySet, fieldState, growState, fieldPloughFactor)
	
	if result then
	
		--RealisticUtils.testClass("FieldJob.init self", self)
		
		--RealisticUtils.testClass("self.fieldJobVehiclesToLoad1", self.fieldJobVehiclesToLoad[1])
		--RealisticUtils.testClass("self.fieldJobVehiclesToLoad2", self.fieldJobVehiclesToLoad[2])
		
		--FieldJobManager.FIELDSTATE_PLOUGHED == 0
		--FieldJobManager.FIELDSTATE_CULTIVATED == 1
		--FieldJobManager.FIELDSTATE_GROWING == 2
		--FieldJobManager.FIELDSTATE_HARVESTED == 3
		
		
		--print("   ************* test FieldJobManager ->FIELDSTATE_CULTIVATED="..tostring(FieldJobManager.FIELDSTATE_CULTIVATED) .." ->FIELDSTATE_GROWING="..tostring(FieldJobManager.FIELDSTATE_GROWING) .." ->FIELDSTATE_HARVESTED="..tostring(FieldJobManager.FIELDSTATE_HARVESTED) .." ->FIELDSTATE_PLOUGHED="..tostring(FieldJobManager.FIELDSTATE_PLOUGHED))
				
		
		--size of the field
		--local fieldSize = fieldDefinition.fieldArea * 10000-- hectare to square meters
		--local vehiclePower = 
		
		self.timeLeft = self.timeLeft * FieldJob.mrGetTimeLeftFactor(self, fieldDefinition, jobType, fertiliserLayers, fieldPloughFactor)
		
		
		--MR reward
		local randomFactor = 0.9+0.2*math.random() -- between 0.9 and 1.1  => if randomFactor is "high", it means less time and more reward		
		--timeLeft = milliseconds
		local reward = randomFactor * 12000 * self.timeLeft/3600000 -- between 10800 and 13200$ per jobtime hour (easy difficulty) => which means about 18000-22000 with time bonus
		--scale with difficulty
		self.reward = reward * (1-0.25*(g_currentMission.missionInfo.difficulty-1)) -- x1 easy, x0.75 normal, x0.5 hard
		self.timeLeft = self.timeLeft / randomFactor -- less time to complete the job if the reward is higher per hour
		
		--[[
		TYPE_SOWING == 0
		TYPE_FERTILIZING_GROWING == 1
		TYPE_FERTILIZING_SOWN == 2
		TYPE_FERTILIZING_HARVESTED == 3
		TYPE_HARVESTING == 4
		TYPE_CULTIVATING == 5
		TYPE_PLOUGHING == 6
		--]]
		
		return true
		
	else
		return false
	end	

end


-- self is not required, but we still pass it in case we want to evolve the function later (this function can be called by other mods like Seasons)
FieldJob.mrGetTimeLeftFactor = function(self, fieldDefinition, jobType, fertiliserLayers, fieldPloughFactor)

	local timeLeftFactor = 1

	if jobType==FieldJob.TYPE_HARVESTING then
		--check fertilizing/ploughed state (increase in yield = less speed for combines)
		
		local sprayFactor = fertiliserLayers
		if g_currentMission.missionInfo.fertilizerStatesEnabled then
			sprayFactor = sprayFactor / g_currentMission.sprayLevelMaxValue
		end
		local ploughFactor = 1		
		if g_currentMission.missionInfo.plowingRequiredEnabled then
			ploughFactor = 0
			if fieldPloughFactor>0 then
				ploughFactor = 1
			end			
		end
		
		--print("test data fertilizer = sprayLevelMaxValue="..tostring(g_currentMission.sprayLevelMaxValue) .." -  fertilizerStatesEnabled="..tostring(g_currentMission.missionInfo.fertilizerStatesEnabled))
		local harvestMulti = g_currentMission:getHarvestScaleMultiplier(sprayFactor, ploughFactor)
		
		--print(" test FieldJob.mrInit - harvestMulti="..tostring(harvestMulti) .. " - sprayFactor="..tostring(sprayFactor) .. " - ploughFactor="..tostring(ploughFactor))
		--g_currentMission.sprayLevelMaxValue			
		--g_currentMission.missionInfo.fertilizerStatesEnabled
		
		
		timeLeftFactor = 0.6*harvestMulti -- 0.6 factor for not fertilized fields, 1.2 factor for full yield fields
	elseif jobType==FieldJob.TYPE_FERTILIZING_HARVESTED or jobType==FieldJob.TYPE_FERTILIZING_SOWN then
		--fertilising with "liquidManureBarrel" => speed limit is set to 20kph for all "slurry tankers", but the actual speed limit depends on the "mrMaxOutputCapacity" value
		--the tanker is full during all the mission
		--allow some more time			
		timeLeftFactor = 1.1
	elseif jobType==FieldJob.TYPE_FERTILIZING_GROWING then
		--fertiliser spreader/sprayer = very fast, most of time, fairly easy to pull, wide implement
		timeLeftFactor = 0.75
	end
	
	-- the larger the field, the more time we spend actually "spreading" compared to a smaller field where we spend a lot of time for headlands turning)
	local workingEfficiency = math.min(1, 0.8+fieldDefinition.fieldArea*0.025) --<1ha = 80%, >8ha = 100%
	--print(" -------   job workingEfficiency factor = " .. tostring(workingEfficiency))
	timeLeftFactor = timeLeftFactor / workingEfficiency --more time for small fields
	
	return timeLeftFactor

end



function FieldJob.mrGetRequiredHpOfStoreItem(self, superFunc, storeItem)

	local result = superFunc(self, storeItem)
	--print("test getRequiredHpOfStoreItem - p1="..tostring(p1).." - p2="..tostring(p2).." - p3="..tostring(p3).." - p4="..tostring(p4).." - p5="..tostring(p5) .. " - p6="..tostring(p6) .. " - p7="..tostring(p7))
	--RealisticUtils.testClass("FieldJob p1", p1)
	--RealisticUtils.testClass("FieldJob p2", p2)
	
	--RealisticUtils.testClass("getRequiredHpOfStoreItem storeItem", storeItem)
	
	--RealisticUtils.testClass("getRequiredHpOfStoreItem storeItem.fieldJobData", storeItem.fieldJobData)
	
	--RealisticUtils.testClass("getRequiredHpOfStoreItem storeItem.specs", storeItem.specs)
	 
	
	--print("test mrGetRequiredHpOfStoreItem - result = "..tostring(result))
	
	
	--we want more "grunt" because the mission time system seems to take into account the max speed of the implement
	result = result * 1.25
	
	return result

end
FieldJob.getRequiredHpOfStoreItem = Utils.overwrittenFunction(FieldJob.getRequiredHpOfStoreItem, FieldJob.mrGetRequiredHpOfStoreItem)