﻿--************************************************************************************************************************************************************
--add working power to get different power consumption when actually "splitting" tree stumps
StumpCutter.mrLoad = function(self)	

	if not self.mrIsMrVehicle then
		return
	end	

	self.stumpCutterWorkingPowerMin = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.stumpCutter#cuttingPtoPowerMin"), 0) -- KW
	self.stumpCutterWorkingPowerMax = Utils.getNoNil(getXMLFloat(self.xmlFile, "vehicle.moreRealistic.stumpCutter#cuttingPtoPowerMax"), 0) -- KW
	if self.stumpCutterWorkingPowerMin>0 and self.stumpCutterWorkingPowerMax>0 then
		self.getConsumedPtoTorque = StumpCutter.mrGetConsumedPtoTorque
	end
			
end
StumpCutter.load = Utils.appendedFunction(StumpCutter.load, StumpCutter.mrLoad)





--************************************************************************************************************************************************************
--pto torque depends on the working state ("splitting" or not "splitting")
StumpCutter.mrGetConsumedPtoTorque = function(self)
    if self:getDoConsumePtoPower() then
        local rpm = self.powerConsumer.ptoRpm
        if rpm > 0.001 then
			local totalPower = self.powerConsumer.mrNoLoadPtoPower
			if self.resetCutTime > 0 then
				totalPower = totalPower + self.stumpCutterWorkingPowerMin + (self.stumpCutterWorkingPowerMax-self.stumpCutterWorkingPowerMin) * math.random()
			end			
            return totalPower / (rpm*math.pi/30)
        end
    end
    return 0
end












