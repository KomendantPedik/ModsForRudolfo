﻿RealisticUtils = {};

RealisticUtils.defaultVehiclesModifiedData = {}

RealisticUtils.nameToGroundType = {
	["GROUND_ROAD"] = WheelsUtil.GROUND_ROAD, 
	["GROUND_HARD_TERRAIN"] = WheelsUtil.GROUND_HARD_TERRAIN,
	["GROUND_SOFT_TERRAIN"] = WheelsUtil.GROUND_SOFT_TERRAIN,
	["GROUND_FIELD"] = WheelsUtil.GROUND_FIELD,
	["SNOW"] = 101}
	
RealisticUtils.globalSettings = {balerFillLevelScaling = 1}

--**********************************************************************************************************************************************************
--20170824 - add newVehicleTypeName feature (example : kuhn performer, change type from cultivator to subsoiler)
RealisticUtils.loadDefaultVehiclesModifiedData = function(folderPath, fileName)

	--reset vehicles data
	RealisticUtils.defaultVehiclesModifiedData = {}

	--loading database file
	local xmlFile = loadXMLFile("realisticDefaultVehicleDatabase.xml", folderPath .. "/" .. fileName)
	
	local i = 0
	while true do
		local vehicleXmlPath = string.format("vehicles.vehicle(%d)", i)
		if not hasXMLProperty(xmlFile, vehicleXmlPath) then break end	
		local vehicleFilePath = getXMLString(xmlFile, vehicleXmlPath)
		local overridedFileName = getXMLString(xmlFile, vehicleXmlPath .. "#overridedFileName")
		local overridedVehicleTypeName = getXMLString(xmlFile, vehicleXmlPath .. "#newVehicleType")
		
		--replace $pdlcdir by the full path		
		if string.sub(overridedFileName,1,8):lower()=="$pdlcdir" then
			--overridedFileName = getUserProfileAppPath() .. "pdlc/" .. string.sub(overridedFileName,10)
			--required for steam users
			overridedFileName = Utils.convertFromNetworkFilename(overridedFileName)	
		elseif string.sub(overridedFileName,1,7):lower()=="$moddir" then --20171116 - fix for Horsch CTF vehicle pack
			overridedFileName = Utils.convertFromNetworkFilename(overridedFileName)	
		end
		
		RealisticUtils.defaultVehiclesModifiedData[overridedFileName] = {} 
		RealisticUtils.defaultVehiclesModifiedData[overridedFileName].newFileName = folderPath .. "/" .. vehicleFilePath
		if overridedVehicleTypeName~=nil then
			RealisticUtils.defaultVehiclesModifiedData[overridedFileName].newVehicleTypeName = overridedVehicleTypeName
		end
		
		--print("RealisticUtils.loadDefaultVehiclesModifiedData - overridedFileName="..tostring(overridedFileName) .. " - vehicleFilePath="..tostring(folderPath .. "/" .. vehicleFilePath))
		
		--load the modified store data
		--2017/11/24 - replace by "RealisticUtils.reloadStoreDataWithMR" to take into account mrDatabank data in the store too
		--RealisticUtils.loadModifiedStoreData(overridedFileName, folderPath .. "/" .. vehicleFilePath);	
		
		i = i + 1
	end	
	
	delete(xmlFile)

end

--**********************************************************************************************************************************************************
RealisticUtils.loadModifiedStoreData = function(overridedXmlFilePath, modifiedDataXmlFilePath)

	--if RealisticUtils.testtttt == nil then
	--	RealisticUtils.testClass("StoreItemsUtil", StoreItemsUtil)
	--	RealisticUtils.testtttt = true
	--end

	local genuineStoreItem = StoreItemsUtil.storeItemsByXMLFilename[overridedXmlFilePath:lower()]

	if genuineStoreItem==nil then		
		--RealisticUtils.printWarning("RealisticUtils.loadModifiedStoreData", string.format("genuineStoreItem is nil for xml path=%s",overridedXmlFilePath), false)		
		return
	end
	
	--if genuineStoreItem.isBundleItem then
	--	print("genuineStoreItem.isBundleItem - " .. overridedXmlFilePath)
	--end
	
	--param2 = rootFolder to add before filePath
	--param3 = customEnvironment (example : pdlc_bigBudPack)
	--param4 = isMod flag
	--param5 = isBundleItem flag
	local tmpModifiedStoreItem;	
	tmpModifiedStoreItem = StoreItemsUtil.loadStoreItem(modifiedDataXmlFilePath,nil,genuineStoreItem.customEnvironment,genuineStoreItem.isMod,genuineStoreItem.isBundleItem)	
		
	if genuineStoreItem.isMod then
		local customEnvironment, baseDirectory = Utils.getModNameAndBaseDirectory(overridedXmlFilePath);		
		--set right icon path for config (wheel, design, vehicleType...)
		if tmpModifiedStoreItem.configurations then
			for _,config in pairs(tmpModifiedStoreItem.configurations) do					 
				for _,wConfig in pairs(config) do	
					if wConfig.icon~=nil then
						--at this level, we can't know if the path is realtive to base game directory or to the mod directory
						--and so, we assume that if the path start by "dataS2/menu/", it means this is a base game directory icon
						if string.sub(wConfig.icon, 1, 12)~="dataS2/menu/" then
							wConfig.icon = RealisticUtils.getFilename(wConfig.icon, baseDirectory);
						end;
					end;
				end;
			end;
		end;
	end
	
	--testing spec
	--RealisticUtils.testClass(tmpModifiedStoreItem.name .. " functions", tmpModifiedStoreItem.functions)	
	
	
	--copy the modified data to the genuine store item
	genuineStoreItem.name = tmpModifiedStoreItem.name
	genuineStoreItem.dailyUpkeep = tmpModifiedStoreItem.dailyUpkeep
	genuineStoreItem.lifetime = tmpModifiedStoreItem.lifetime
	genuineStoreItem.price = tmpModifiedStoreItem.price
	genuineStoreItem.specs = tmpModifiedStoreItem.specs
	genuineStoreItem.configurations = tmpModifiedStoreItem.configurations
	genuineStoreItem.brand = tmpModifiedStoreItem.brand	
	genuineStoreItem.imageBrand = tmpModifiedStoreItem.imageBrand
	
	RealisticUtils.setStoreNameToMR(genuineStoreItem)
	
	
	--delete the temp modified storeitem
	StoreItemsUtil.removeStoreItem(tmpModifiedStoreItem.id)
	
end

RealisticUtils.setStoreNameToMR = function(storeItem)
	if storeItem.isMod then
		storeItem.isMod = false
		storeItem.dlcTitle = '"MR" Mod'
	else
		storeItem.dlcTitle = '"MR" ' .. tostring(storeItem.dlcTitle)
	end
end


--**********************************************************************************************************************************************************
--** parse all store items and load MR data if present
RealisticUtils.reloadStoreDataWithMR = function()

	for _,storeItem in pairs(StoreItemsUtil.storeItems) do	
		--print("load store, genuine xml = " .. storeItem.xmlFilename)
		local mrConfigFileName = RealisticUtils.getVehicleMrConfigFileName(storeItem.xmlFilename)
		--print(" ----- MR = " .. tostring(mrConfigFileName))
		if mrConfigFileName~=nil then
			RealisticUtils.loadModifiedStoreData(storeItem.xmlFilename, mrConfigFileName)	
		else --20180107 - check if this is a genuine MR vehicle
			if storeItem.functions~=nil then				
				--check if the vehicle is a "genuine" MR vehicle
				for pos,func in pairs(storeItem.functions) do
					if func=="MoreRealistic Game Engine required" then
						--this is a genuine MR vehicle
						RealisticUtils.setStoreNameToMR(storeItem)
						table.remove(storeItem.functions, pos) -- remove the "mr required" text
						--print("test function mrvehicle = true for : " .. storeItem.name)
						break;
					end
				end				
			end
		end	
	end	
	
end

--**********************************************************************************************************************************************************
--** return the MR config file name corresponding to the genuineConfigFileName param
--** ifno MR file found, return nil
RealisticUtils.getVehicleMrConfigFileName = function(genuineConfigFileName)
	
	--print("getVehicleMrConfigFileName - configFileName = " .. tostring(genuineConfigFileName))

	local mrConfigFileName = nil
	
	--1. look if there is an xml file for this vehicle in the "moreRealisticXmlDatabank" mod folder
	--2. then, if nothing found in mr databank, check the "default converted database" 
	--3. and last, check if there is a "specific" MR_XXXX xml file for this vehicle
	
	if g_modIsLoaded["moreRealisticXmlDatabank"] then		
		local databankXmlPath = RealisticUtils.getVehicleDatabankPath(genuineConfigFileName)
		if fileExists(databankXmlPath) then
			if Vehicle.debugRendering then print("-------- Found xml file in the MR 'databank' :  " .. databankXmlPath) end
			mrConfigFileName = databankXmlPath			
		end
	end
	
	if mrConfigFileName==nil then
		--replace xml file with moreRealistic data xml file if present for this vehicle
		if RealisticUtils.defaultVehiclesModifiedData[genuineConfigFileName] then	
			mrConfigFileName = RealisticUtils.defaultVehiclesModifiedData[genuineConfigFileName].newFileName		
		else	
			--if nothing found in the default converted database
			local splitXmlPath = Utils.splitString("/" , genuineConfigFileName)
			local xmlNameOnly = splitXmlPath[#splitXmlPath] --get the last "word" in the full xml file path
			--20170904 - keep the full path to the file (even if it is embedded into a subfolder)
			--local mrXmlFilepath = self.baseDirectory .. "MR_" .. xmlNameOnly
			xmlNameOnly = "MR_" .. xmlNameOnly
			local mrXmlFilepath = ""
			for i=1, #splitXmlPath-1 do
				mrXmlFilepath = mrXmlFilepath .. splitXmlPath[i] .. "/"
			end
			mrXmlFilepath = mrXmlFilepath .. xmlNameOnly
			
			--print("------------------ testing MR xml file path = " .. tostring(mrXmlFilepath))
			
			if fileExists(mrXmlFilepath) then			
				if Vehicle.debugRendering then print("-------- Found MR ready XML file " .. xmlNameOnly .. " Replacing XML File now...") end
				mrConfigFileName = mrXmlFilepath			
			end		
		end
	end
	
	return mrConfigFileName --can be nil if no MR file was found	

end

--**********************************************************************************************************************************************************
-- return the full path to the "dataBank" file of a given vehicle
--20170712 - use the mod named : "moreRealisticXmlDatabank"
--20171124 - does not require "self" anymore. Only need the xml file path and name (using "Utils.getModNameAndBaseDirectory" to get the baseDirectory)
RealisticUtils.getVehicleDatabankPath = function(configFileName)

	local databankPath = g_modsDirectory .. "moreRealisticXmlDatabank/convertedXml/"   --getUserProfileAppPath() .. "mrXmlDatabank/"	
	local splitXmlPath = Utils.splitString("/" , configFileName)
	local xmlNameOnly = splitXmlPath[#splitXmlPath] --get the last "word" in the full xml file path	
	
	local modFolderName = "default" --we can override default vehicle too by using the "default" prefix
	local customEnvironment, baseDirectory = Utils.getModNameAndBaseDirectory(configFileName)
	
	if baseDirectory~="" then
		local splitDirectoryPath = Utils.splitString("/" , baseDirectory)
		--print("test base directory - splitDirectoryPath num=".. table.getn(splitDirectoryPath) .." .. modDirectory="..splitDirectoryPath[#splitDirectoryPath-1])
		modFolderName = splitDirectoryPath[#splitDirectoryPath-1] --  remove 1 because the last character is "/" for baseDirectory
	end
	
	local mrXmlDatabankFilepath = databankPath .. modFolderName .. "_MR_" .. xmlNameOnly
	
	--print("test - " .. mrXmlDatabankFilepath .. " - baseDirectory="..baseDirectory)
	
	return mrXmlDatabankFilepath
	
end


--**********************************************************************************************************************************************************
RealisticUtils.loadRealFillTypesData = function(filePath)
	
	local xmlFile = loadXMLFile("realFillTypesXML", filePath);
	
	local i = 0;
	while true do
		local fillTypeName = string.format("fillTypes.fillType(%d)", i);
		if not hasXMLProperty(xmlFile, fillTypeName) then break; end;
		
		local realFillType = {};
		realFillType.name = getXMLString(xmlFile, fillTypeName .. "#name");
		if realFillType.name == nil then
			RealisticUtils.printWarning("RealisticUtils.loadRealFillTypesData", "realFillType.name is nil, i="..tostring(i), true);
			break;
		end;
		realFillType.density = getXMLFloat(xmlFile, fillTypeName .. "#density");
		if realFillType.density == nil then
			RealisticUtils.printWarning("RealisticUtils.loadRealFillTypesData", "realFillType.density is nil, i="..tostring(i), true);
			break;
		end;
		realFillType.mrBalerMaterialFx = getXMLFloat(xmlFile, fillTypeName .. "#balerMaterialFx");
		
		--move to moreRealisticGameplay mod
		--realFillType.startPricePerM3 = getXMLFloat(xmlFile, fillTypeName .. "#startPricePerM3");
		
		local fillType = FillUtil.fillTypeNameToDesc[realFillType.name];
		if fillType==nil then
			if Vehicle.debugRendering then
				RealisticUtils.printWarning("RealisticUtils.loadRealFillTypesData", "fillType is unknown on this map, name="..realFillType.name, false);
			end
		else
			fillType.massPerLiter = 0.001 * realFillType.density;-- * 0.2;
			--[[ move to moreRealisticGameplay mod
			if realFillType.startPricePerM3~= nil and RealisticUtils.doChangeFillTypePrices() then
				--print("fillType "..tostring(fillType.name).." - old startPrice="..tostring(fillType.startPricePerLiter*1000).." - old price="..tostring(fillType.pricePerLiter*1000) .. " - new start price="..tostring(realFillType.startPricePerM3));
				fillType.startPricePerLiter = 0.001 * realFillType.startPricePerM3;
				fillType.pricePerLiter = fillType.startPricePerLiter;				
			end;--]]	
			if realFillType.mrBalerMaterialFx~=nil then
				fillType.mrBalerMaterialFx = realFillType.mrBalerMaterialFx
			end
		end;
		
		i = i + 1;
	end
	
	delete(xmlFile);

end;


--**********************************************************************************************************************************************************
--move to moreRealisticGameplay mod
--[[
RealisticUtils.loadRealFruitTypesData = function(filePath)
	
	local xmlFile = loadXMLFile("realFruitTypesXML", filePath);
	
	local i = 0;
	while true do
		local fruitTypeName = string.format("fruitTypes.fruitType(%d)", i);
		if not hasXMLProperty(xmlFile, fruitTypeName) then break; end;
		
		local realFruitType = {};
		realFruitType.name = getXMLString(xmlFile, fruitTypeName .. "#name");
		if realFruitType.name == nil then
			RealisticUtils.printWarning("RealisticUtils.loadRealFruitTypesData", "realFruitType.name is nil, i="..tostring(i), true);
			break;
		end;
		realFruitType.literPerSqm = getXMLFloat(xmlFile, fruitTypeName .. "#literPerSqm");
		if realFruitType.literPerSqm == nil then
			RealisticUtils.printWarning("RealisticUtils.loadRealFruitTypesData", "realFruitType.literPerSqm is nil, i="..tostring(i), true);
			break;
		end;
		realFruitType.seedUsagePerSqm = getXMLFloat(xmlFile, fruitTypeName .. "#seedUsagePerSqm");
		if realFruitType.seedUsagePerSqm == nil then
			RealisticUtils.printWarning("RealisticUtils.loadRealFruitTypesData", "realFruitType.seedUsagePerSqm is nil, i="..tostring(i), true);
			break;
		end;
		realFruitType.windrowLiterPerSqm = getXMLFloat(xmlFile, fruitTypeName .. "#windrowLiterPerSqm");
		
		realFruitType.mrMaterialQtyFx = Utils.getNoNil(getXMLFloat(xmlFile, fruitTypeName .. "#mrMaterialQtyFx"), 1);
				
		local fruitType = FruitUtil.fruitTypes[realFruitType.name];
		if fruitType==nil then
			if Vehicle.debugRendering then
				RealisticUtils.printWarning("RealisticUtils.loadRealFruitTypesData", "fruitType is unknown, name="..realFruitType.name, false);
			end
		else
			fruitType.literPerSqm = realFruitType.literPerSqm;
			fruitType.seedUsagePerSqm = realFruitType.seedUsagePerSqm;
			if realFruitType.windrowLiterPerSqm~= nil then
				fruitType.windrowLiterPerSqm = realFruitType.windrowLiterPerSqm;
			end;
			fruitType.mrMaterialQtyFx = realFruitType.mrMaterialQtyFx;
		end;
		
		i = i + 1;
	end
	
	delete(xmlFile);

end;
--]]



--**********************************************************************************************************************************************************
RealisticUtils.loadRealTyresFrictionAndRr = function(filePath)
	
	--DebugUtil.printTableRecursively(WheelsUtil.GROUND_HARD_TERRAIN, 1, 1, 100);
	
	
	local xmlFile = loadXMLFile("realFrictionAndRrXML", filePath);
	
	local i = 0;
	while true do
		local tyreTypeKey = string.format("tyreTypes.tyreType(%d)", i);
		if not hasXMLProperty(xmlFile, tyreTypeKey) then break; end;
		
		local tyreTypeName = getXMLString(xmlFile, tyreTypeKey .. "#name");
		
		local tireTypeIndex = WheelsUtil.getTireType(tyreTypeName);
		
		if tireTypeIndex~=nil then
			--RealisticUtils.printWarning("RealisticUtils.loadRealTyresFrictionAndRr", "unknown tireType, tyreTypeName="..tostring(tyreTypeName) .. ", i="..tostring(i), true);
			--break;		
		
			local tireType = WheelsUtil.tireTypes[tireTypeIndex];
			
			--new table to store rolling resistance values
			tireType.mrRollingResistanceCoeffs = {};
			tireType.mrRollingResistanceCoeffsWet = {};
			
			--for each surface type, set the new values
			local j = 0;
			while true do
				local surfaceTypeKey = tyreTypeKey .. string.format(".surfaceType(%d)", j);
				if not hasXMLProperty(xmlFile, surfaceTypeKey) then break; end;
				
				local surfaceTypeName = getXMLString(xmlFile, surfaceTypeKey .. "#name");
				local groundType = RealisticUtils.nameToGroundType[surfaceTypeName];
				
				if groundType==nil then
					RealisticUtils.printWarning("RealisticUtils.loadRealTyresFrictionAndRr", "unknown groundType, surfaceTypeName="..tostring(surfaceTypeName) .. ", i="..tostring(i) .. ", j="..tostring(j), true);
					break;
				end;
				
				local getValueFromXML = function(xmlPath, myTable, groundType)				
					local value = getXMLFloat(xmlFile, xmlPath);
					if value==nil then
						RealisticUtils.printWarning("RealisticUtils.loadRealTyresFrictionAndRr", "nil value for groundType, xmlPath="..tostring(xmlPath), true);					
						return false;
					end;
					myTable[groundType] = value;
					return true;
				end;
				
				if not getValueFromXML(surfaceTypeKey .. "#dryFriction", tireType.frictionCoeffs, groundType) then break; end;
				if not getValueFromXML(surfaceTypeKey .. "#wetFriction", tireType.frictionCoeffsWet, groundType) then break; end;
				if not getValueFromXML(surfaceTypeKey .. "#dryRollingResistance", tireType.mrRollingResistanceCoeffs, groundType) then break; end;
				if not getValueFromXML(surfaceTypeKey .. "#wetRollingResistance", tireType.mrRollingResistanceCoeffsWet, groundType) then break; end;
				
				j = j + 1;
			end
		
		end
		
		i = i + 1;
	end
	
	delete(xmlFile);

end;

--**********************************************************************************************************************************************************
RealisticUtils.getDragArea = function(self)
	
	local maskingTractorArea = math.max(self.mrDragArea, self.mrOverridedTrailerArea) ;
	local dragArea = self.mrDragArea;
	
	local trailerMaxDragArea = 0;
	for _, implement in pairs(self.attachedImplements) do
		if implement.object ~= nil and implement.object.mrIsMrVehicle then
			trailerMaxDragArea = math.max(trailerMaxDragArea, implement.object.mrDragArea);
		end;
	end
	
	if trailerMaxDragArea>maskingTractorArea then
		dragArea = dragArea + trailerMaxDragArea-maskingTractorArea;
	end	
	
	return dragArea;
end;

--fx must be between 0 and 1
RealisticUtils.linearFx = function(fx, minVal, maxVal)
	return minVal + fx * (maxVal-minVal);
end;

--return 1 if param=minParam, return minVal if param=maxParam
--param between minParam and maxParam
RealisticUtils.linearFx2 = function(param, minParam, maxParam, minVal)
	return 1 - (1-minVal)*(param - minParam)/(maxParam-minParam);
end;

--return minVal if param=minParam, return maxVal if param=maxParam
--param between minParam and maxParam
--maxParam>minParam
RealisticUtils.linearFx3 = function(param, minParam, maxParam, minVal, maxVal)
	return minVal + (maxVal-minVal)*(param-minParam)/(maxParam-minParam);
end;



--same as Utils.getFileName but check if we need to replace the baseDirectory with the mr one (tag = "$mr" or "$MR" to start the filename with)
--20170901 - add the "$mrbank" tag too to check within the "moreRealisticXmlDatabank\convertedXml" folder
RealisticUtils.getFilename = function(filename, baseDirectory)

	local filePath = filename
	if string.sub(filename,1,8):lower()=="$mrbank/" then	
		local databankPath = g_modsDirectory .. "moreRealisticXmlDatabank/convertedXml/"
		filePath = Utils.getFilename(string.sub(filename,9), databankPath)
	elseif string.sub(filename,1,4):lower()=="$mr/" then			
		--print("test : " .. string.sub(filename,1,3):lower() .. " - 2= " .. string.sub(filename,4) .. " - 3=" ..RealisticUtils.mrEngineDirectory .. "- 4="..Utils.getFilename(string.sub(filename,4), RealisticUtils.mrEngineDirectory));	
		filePath = Utils.getFilename(string.sub(filename,5), RealisticUtils.mrEngineDirectory)		
	elseif baseDirectory~=nil then		
		filePath = Utils.getFilename(filename, baseDirectory)		
	end	
	
	--print("test RealisticUtils.getFilename : " .. filePath .. " - baseDirectory="..tostring(baseDirectory) .. " - fileName="..tostring(filename))
	return filePath
	
end

--**********************************************************************************************************************************************************
-- allow us some modification of the i3d node at runtime
-- added 20170326 to "unlink" the collision shape of the markers of the Horsch Maestro
RealisticUtils.manageNodes = function(self, xmlFile)--, isSaveGame)

	local nodeI = 0;
	while true do
		local nodeKey = string.format("vehicle.mrManageNodes.manageNode(%d)", nodeI);
		if not hasXMLProperty(xmlFile, nodeKey) then
			break;
		end;
		
		local node = Utils.indexToObject(self.components, getXMLString(xmlFile, nodeKey.."#node"))
		
		local createChildNode = Utils.getNoNil(getXMLBool(xmlFile, nodeKey.."#createChildNode"), false) 
		if createChildNode then
			local newChildNode = createTransformGroup("childNode")
			link(node, newChildNode)
		end
		
		local unlinkNode = Utils.getNoNil(getXMLBool(xmlFile, nodeKey.."#unlink"), false)
		local collisionMask = getXMLInt(xmlFile, nodeKey.."#collisionMask")
		
		local linkToComponent = getXMLInt(xmlFile, nodeKey.."#linkToComponent")
		if linkToComponent~=nil then			
			link(self.components[linkToComponent].node, node)					
		end		
		
		local linkToNode = getXMLString(xmlFile, nodeKey.."#linkToNode")
		if linkToNode~=nil then	
			local parentNode = Utils.indexToObject(self.components, linkToNode)
			link(parentNode, node)					
		end	
		
		local translation = getXMLString(xmlFile, nodeKey.."#setTranslation")
		if translation~= nil then
			translation = {Utils.getVectorFromString(translation)}
		end
		
		local rotation = getXMLString(xmlFile, nodeKey.."#setRotation")
		if rotation~=nil then
			rotation = Utils.getRadiansFromString(rotation,3)
		end
		
		local scale = getXMLString(xmlFile, nodeKey.."#setScale")
		if scale~=nil then
			scale = {Utils.getVectorFromString(scale)}
		end
		
		local wantedMass = getXMLFloat(xmlFile, nodeKey.."#setMass")
		local wantedAngularDamping = getXMLFloat(xmlFile, nodeKey.."#setAngularDamping")
		local wantedLinearDamping = getXMLFloat(xmlFile, nodeKey.."#setLinearDamping")
		
				
		if unlinkNode then
			unlink(node);
			--delete(getChildAt(getParent(node), ""));
			--delete(node)
			--setRootNode(node, self.components[2].node)
			--removeFromPhysics(node)
			--setRigidBodyType(node, "norigidbody")			
		end
		
		if collisionMask~=nil then
			setCollisionMask(node, collisionMask)
		end
		
		if scale~=nil and #scale == 3 then
			--print("test setScale - " .. tostring(scale[1]) .. " - " .. tostring(scale[2]) .. " - " .. tostring(scale[3]))
			--20170909 - it seems there is a bug with the setScale function when called for a new vehicle
			-- when called for a vehicle that comes from a savegame, it works as intended
			-- when called for a new vehicle bought while in game, it seems the setScale function is applied 2 times (and so, by applying a scale of 2, we get a result of 4 in game) 
			-- fix = apply sqrt to the scale factor
			--if isSaveGame then
			--	setScale(node, scale[1], scale[2], scale[3])
			--else
			setScale(node, math.sqrt(scale[1]), math.sqrt(scale[2]), math.sqrt(scale[3]))
			--end
		end
		
		if translation~=nil and #translation == 3 then
			--print("test setTranslation - " .. tostring(translation[1]) .. " - " .. tostring(translation[2]) .. " - " .. tostring(translation[3]))
			setTranslation(node, translation[1], translation[2], translation[3])
		end		
	
		--print("test manage node /////////////////////////////////////////////////////////////////////////////////////////////")
		--print("rotation = " .. tostring(rotation) .. " num elt = " .. tostring(#rotation) .. " 1="..tostring(rotation[1]) .. " 2="..tostring(rotation[2]) .. " 3="..tostring(rotation[3]))
		if rotation~=nil and #rotation == 3 then			
			setRotation(node, rotation[1], rotation[2], rotation[3])
		end	
		
		
		
		--only for server
		if self.isServer then
			if wantedMass~=nil and wantedMass>0 then
				setMass(node, wantedMass)
			end
			
			if wantedAngularDamping~=nil and wantedAngularDamping>0 then
				setAngularDamping(node, wantedAngularDamping)
			end
			if wantedLinearDamping~=nil and wantedLinearDamping>0 then
				setLinearDamping(node, wantedLinearDamping)
			end
		end
		
	
		nodeI = nodeI + 1;
	end --while
	
end

--**********************************************************************************************************************************************************
-- allow us to display some point for debugging (example : center of mass of one component)
RealisticUtils.loadDebugData = function(self, xmlFile)

	local nodeI = 0
	while true do
		local nodeKey = string.format("vehicle.mrDebug.drawPoint(%d)", nodeI);
		if not hasXMLProperty(xmlFile, nodeKey) then
			break
		end
		
		local node = Utils.indexToObject(self.components, getXMLString(xmlFile, nodeKey.."#node"))
		if node~=nil then
			if self.mrDebugData==nil then self.mrDebugData = {} end
			if self.mrDebugData.points==nil then self.mrDebugData.points = {} end
			self.mrDebugData.points[node] = {}
			
			--check if we want a local translation
			local translation = getXMLString(xmlFile, nodeKey.."#translation")
			if translation~= nil then
				translation = {Utils.getVectorFromString(translation)}
				if translation~=nil and #translation == 3 then					
					self.mrDebugData.points[node].translation = translation
				end
			end			
			
		end
		
		local comNode = Utils.indexToObject(self.components, getXMLString(xmlFile, nodeKey.."#centerOfMass"))
		if comNode~=nil then
			if self.mrDebugData==nil then self.mrDebugData = {} end
			if self.mrDebugData.comPoints==nil then self.mrDebugData.comPoints = {} end
			self.mrDebugData.comPoints[comNode] = true
		end
		
		nodeI = nodeI + 1
	end
		
end


RealisticUtils.drawPoint = function(node, drawCenterOfMass, localTranslation)

	local x1,y2,z2
	if drawCenterOfMass then
		x1,y2,z2 = getCenterOfMass(node)
		x1,y2,z2 = localToWorld(node, x1,y2,z2)
	elseif localTranslation~=nil then
		x1,y2,z2 = localToWorld(node, localTranslation[1], localTranslation[2], localTranslation[3])
	else
		x1,y2,z2 = getWorldTranslation(node)
	end
	
	local x,y,z = localDirectionToWorld(node, 1,0,0)
	drawDebugLine(x1,y2,z2, 1,0,0, x1+x,y2+y,z2+z, 1,0,0)	
	local x,y,z = localDirectionToWorld(node, 0,1,0)
	drawDebugLine(x1,y2,z2, 0,1,0, x1+x,y2+y,z2+z, 0,1,0)		
	local x,y,z = localDirectionToWorld(node, 0,0,1)
	drawDebugLine(x1,y2,z2, 0,0,1, x1+x,y2+y,z2+z, 0,0,1)

end

RealisticUtils.drawPoint2 = function(node, worldX, worldY, worldZ)

	local x1,y2,z2 = worldX, worldY, worldZ
		
	local x,y,z = localDirectionToWorld(node, 1,0,0)
	drawDebugLine(x1,y2,z2, 1,0,0, x1+x,y2+y,z2+z, 1,0,0)	
	local x,y,z = localDirectionToWorld(node, 0,1,0)
	drawDebugLine(x1,y2,z2, 0,1,0, x1+x,y2+y,z2+z, 0,1,0)		
	local x,y,z = localDirectionToWorld(node, 0,0,1)
	drawDebugLine(x1,y2,z2, 0,0,1, x1+x,y2+y,z2+z, 0,0,1)

end


--**********************************************************************************************************************************************************
-- return the main attacher vehicle of the vehicles combination (tractor and all implements attached together
RealisticUtils.getMainAttacherVehicle = function(self)
	if self.attacherVehicle==nil then
		return self
	else
		return RealisticUtils.getMainAttacherVehicle(self.attacherVehicle)
	end
end

--**********************************************************************************************************************************************************
RealisticUtils.hasSpecialization = function(vehicleTypeName, specializationName)
	local typeDef = VehicleTypeUtil.vehicleTypes[vehicleTypeName]
	for _,speName in pairs(typeDef.specializationNames) do
		if speName==specializationName then
			return true
		end
	end
	return false
end

--**********************************************************************************************************************************************************
-- return the main attacher vehicle of the vehicles combination (tractor and all implements attached together
RealisticUtils.getBitMask = function(startBit, endBit)
	local maskNum = 0	
	for i=startBit, endBit do
		maskNum = maskNum + 2^i
	end
	return maskNum
end



RealisticUtils.roundNumberBaleCapacity = function(capacityToRound)
	local newCapacity = capacityToRound
	local roundStep = 1
	if newCapacity>1000 then --round to 50L step when capacity is above 1000L
		roundStep = 50
	elseif newCapacity>200 then --round to 10L step when capacity is above 200L
		roundStep = 10
	elseif newCapacity>100 then --round to 5L step when capacity is above 100L
		roundStep = 5
	end		
	if roundStep>1 then
		local lowerCapacity = math.floor(newCapacity/roundStep)*roundStep
		if newCapacity>lowerCapacity+0.5*roundStep then
			newCapacity = lowerCapacity+roundStep
		else
			newCapacity = lowerCapacity
		end
	end
	return newCapacity
end


--**********************************************************************************************************************************************************
--***** TEST / DEBUG
--**********************************************************************************************************************************************************






RealisticUtils.printWarning = function(stackTrace, message, isError)
	
	local gameTime = 0;
	if g_currentMission then gameTime = g_currentMission.time; end
	local msg = "*** " .. tostring(gameTime) .. " MoreRealistic - ";
	--local msg = "*** MoreRealistic - ";
	
	if isError then
		msg = msg .. "ERROR - ";
	else
		msg = msg .. "WARNING - ";
	end;
	
	msg = msg .. stackTrace .. " - " .. message;
	
	print(msg);	

end;




function RealisticUtils.testClass(className, classToTest)

	print("testing " .. tostring(className));		
	for _,k in pairs(classToTest) do
		print("function name : " .. tostring(_) .. " value : " .. tostring(k));			
	end;
	
	--table.foreach(classToTest,print);
	
	print("end testing " .. tostring(className));
	
end;

function RealisticUtils.testObject(displayName, object)

	print("testing " .. tostring(displayName));
	for key, value in pairs(getmetatable(object)) do
		print(key, value);
	end;
	print("end testing " .. tostring(displayName));
end;


--comes from courseplay. Thanks Jakob !
function RealisticUtils.testTable(t, name, indent, maxDepth)
	
	local cart -- a container
	local autoref -- for self references
	maxDepth = maxDepth or 50;
	local depth = 0;

	--[[ counts the number of elements in a table
local function tablecount(t)
   local n = 0
   for _, _ in pairs(t) do n = n+1 end
   return n
end
]]
	-- (RiciLake) returns true if the table is empty
	local function isemptytable(t) return next(t) == nil end

	local function basicSerialize(o)
		local so = tostring(o)
		if type(o) == "function" then
			local info = debug.getinfo(o, "S")
			-- info.name is nil because o is not a calling level
			if info.what == "C" then
				return string.format("%q", so .. ", C function")
			else
				-- the information is defined through lines
				return string.format("%q", so .. ", defined in (" ..
						info.linedefined .. "-" .. info.lastlinedefined ..
						")" .. info.source)
			end
		elseif type(o) == "number" then
			return so
		else
			return string.format("%q", so)
		end
	end

	local function addtocart(value, name, indent, saved, field, curDepth)
		indent = indent or ""
		saved = saved or {}
		field = field or name
		cart = cart .. indent .. field
		
		--if field~=nil and tostring(field)=="[\"parent\"]" then
		--	print("name = " .. tostring(name) .. " - field="..tostring(field).. " - value="..tostring(value).." - saved="..tostring(saved))
		--	return
		--end
		--

		if type(value) ~= "table" then
			cart = cart .. " = " .. basicSerialize(value) .. ";\n"
		else
			if saved[value] then
				cart = cart .. " = {}; -- " .. saved[value]
						.. " (self reference)\n"
				autoref = autoref .. name .. " = " .. saved[value] .. ";\n"
			else
				saved[value] = name
				--if tablecount(value) == 0 then
				if isemptytable(value) then
					cart = cart .. " = {};\n"
				else
					if curDepth <= maxDepth then
						cart = cart .. " = {\n"
						
						for k, v in pairs(value) do
							k = basicSerialize(k)
							local fname = string.format("%s[%s]", name, k)
							field = string.format("[%s]", k)
							-- three spaces between levels
							addtocart(v, fname, indent .. "\t", saved, field, curDepth + 1);
						end
						
						cart = cart .. indent .. "};\n"
					else
						cart = cart .. " = { ... };\n";
					end;
				end
			end
		end;
	end

	name = name or "__unnamed__"
	if type(t) ~= "table" then
		return name .. " = " .. basicSerialize(t)
	end
	cart, autoref = "", ""
	addtocart(t, name, indent, nil, nil, depth + 1)
	return cart .. autoref
end;




--Example =
--local text = RealisticUtils.testTable(self.specializations, "specialization list", "|");
--print(text);


addConsoleCommand("mrsetvalue1", "Set the value of RealisticUtils.mrDebugValue1", "consoleCommandSetValue1", RealisticUtils);
RealisticUtils.consoleCommandSetValue1 = function(unusedSelf, value)
	if value then
		RealisticUtils.mrDebugValue1 = value;
		print("RealisticUtils.consoleCommandSetValue1 ------------------------------------------------- value=" .. tostring(value) .. " - number="..tostring(tonumber(value)));
		return "RealisticUtils.consoleCommandSetValue1 - value=" .. tostring(value);
	end
	return "RealisticUtils.consoleCommandSetValue1 - no value typed as a parameter";
end

addConsoleCommand("mrsetvalue2", "Set the value of RealisticUtils.mrDebugValue2", "consoleCommandSetValue2", RealisticUtils);
RealisticUtils.consoleCommandSetValue2 = function(unusedSelf, value)
	if value then
		RealisticUtils.mrDebugValue2 = value;
		print("RealisticUtils.consoleCommandSetValue2 ------------------------------------------------- value=" .. tostring(value) .. " - number="..tostring(tonumber(value)));
		return "RealisticUtils.consoleCommandSetValue2 - value=" .. tostring(value);
	end
	return "RealisticUtils.consoleCommandSetValue2 - no value typed as a parameter";
end

addConsoleCommand("mrsetvalue3", "Set the value of RealisticUtils.mrDebugValue3", "consoleCommandSetValue3", RealisticUtils);
RealisticUtils.consoleCommandSetValue3 = function(unusedSelf, value)
	if value then
		RealisticUtils.mrDebugValue3 = value;	
		
		print("RealisticUtils.consoleCommandSetValue3 -------------------------------------------------- value=" .. tostring(value) .. " - number="..tostring(tonumber(value)));
		return "RealisticUtils.consoleCommandSetValue3 - value=" .. tostring(value);
	end
	return "RealisticUtils.consoleCommandSetValue3 - no value typed as a parameter";
end

addConsoleCommand("mrVehicleAnalyse", "Check 'transNodeHeight' value against actual value", "consoleCommandMrVehicleAnalyse", RealisticUtils)
RealisticUtils.consoleCommandMrVehicleAnalyse = function(unusedSelf, value)
	
	--get the current driven vehicle
	if g_currentMission ~= nil and g_currentMission.controlledVehicle ~= nil and g_currentMission.controlledVehicle.isServer then
		local self = g_currentMission.controlledVehicle
		print("Analyzing vehicle '"..self.configFileName.."'. Make sure vehicle is standing on a flat plane parallel to xz-plane")
		
		local groundRaycastResult = {
			raycastCallback = 	function (self, transformId, x, y, z, distance)
									self.groundDistance = distance
								end
		}
		
		for i, attacherJoint in ipairs(self.attacherJoints) do
			if attacherJoint.transNode ~= nil then
				--check the actual distance to the ground against the value
				
				_, yMinPos, _ = localToLocal(self.rootNode, getParent(attacherJoint.transNode), 0, attacherJoint.transNodeMinY, 0)				
				setTranslation(attacherJoint.transNode, attacherJoint.transNodeOrgTrans[1], yMinPos, attacherJoint.transNodeOrgTrans[3])

				--print("     offset=" .. tostring(attacherJoint.transNodeOffsetY) .. " - min pos y = ".. tostring(attacherJoint.transNodeMinY) .. " - corresponding transNode Y translation = " .. tostring(yMinPos))
				
				local x,y,z = getWorldTranslation(attacherJoint.transNode);
				groundRaycastResult.groundDistance = 0
				raycastClosest(x, y, z, 0, -1, 0, "raycastCallback", 4, groundRaycastResult)
				
				local measuredHeight = groundRaycastResult.groundDistance
				
				--print("     measured height = "..tostring(measuredHeight))
				
				local diff = measuredHeight-attacherJoint.transNodeMinY
				
				if math.abs(diff-attacherJoint.mrOffsetY)>0.005 then
					print("     attacherJoint " .. tostring(i) .. " - #mrOffsetY current value =" .. tostring(attacherJoint.mrOffsetY) .. " - value to set in xml=" .. tostring(diff))
				end
				
			end
		end
		
	end
	
	return "Vehicle analyzed";
end


addConsoleCommand("mrRemoveSplitshapeAttachments", "Remove all split shape attachments in the player vicinity", "consoleCommandRemoveSplitshapeAttachments", RealisticUtils)
RealisticUtils.consoleCommandRemoveSplitshapeAttachments = function(unusedSelf, value)
	
	if g_currentMission.controlPlayer==true then
		
		
		if g_server==nil then
			return "mrRemoveSplitshapeAttachments - only works server side"
		else
			--get player location
			
			--RealisticUtils.testClass("g_currentMission.players", g_currentMission.players)
			
			for _,player in pairs(g_currentMission.players) do			
				if player.isEntered then
					local wx, wy, wz = getWorldTranslation(player.rootNode)					
					ret = findAndRemoveSplitShapeAttachments(wx-5, wy-5, wz-5, 1,0,0, 0,1,0, 10, 10, 10)
					if ret then
						return "mrRemoveSplitshapeAttachments - attachments removed !"
					else
						return "mrRemoveSplitshapeAttachments - not attachment found"
					end
				end			
			end
			return "mrRemoveSplitshapeAttachments - no active player found"	
			
		end
		
	else
		return "mrRemoveSplitshapeAttachments - please exit your vehicle first. This command only works when on foot"		
	end	
	
end









