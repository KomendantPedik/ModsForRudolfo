--
-- GroundResponse
--
--
-- @author GIANTS Software
-- @date 15/10/2016
--
-- Copyright (C) GIANTS Software GmbH, Confidential, All Rights Reserved.

GroundResponse = {};

GroundResponse.perlinNoiseSink = {};
GroundResponse.perlinNoiseSink.randomFrequency = 0.5;
GroundResponse.perlinNoiseSink.persistence = 0.0;
GroundResponse.perlinNoiseSink.numOctaves = 2;
GroundResponse.perlinNoiseSink.randomSeed = 123;

GroundResponse.perlinNoiseWobble = {};
GroundResponse.perlinNoiseWobble.randomFrequency = 2.0;
GroundResponse.perlinNoiseWobble.persistence = 0.0;
GroundResponse.perlinNoiseWobble.numOctaves = 4;
GroundResponse.perlinNoiseWobble.randomSeed = 321;

GroundResponse.perlinNoiseDebug = {};
GroundResponse.perlinNoiseDebug.debugRenderingType = "";



function GroundResponse.prerequisitesPresent(specializations)
    return true;
end

function GroundResponse:load(savegame)

    self.loadParticleSystemsForWheel        = GroundResponse.loadParticleSystemsForWheel;
    self.updateWheelDirtPS                  = GroundResponse.updateWheelDirtPS;
    self.updateWheelSink                    = GroundResponse.updateWheelSink;
    self.updateWheelTireFriction            = Utils.overwrittenFunction(self.updateWheelTireFriction, GroundResponse.updateWheelTireFriction);
    self.drawPerlinNoise                    = GroundResponse.drawPerlinNoise;

    self.enableGroundResponse = true;

    -- disale GroundResponse by vehicleType
    if self.vehicleType == "plough" or self.vehicleType == "cultivator" or self.vehicleType == "sowingMachine" then
        self.enableGroundResponse = false;
    end

    -- or by specialization ?
    if self.enableGroundResponse then
        for _,spec in pairs( {Cultivator, Plough, SowingMachine} ) do
            if SpecializationUtil.hasSpecialization(spec, self.specializations) then
                self.enableGroundResponse = false;
            end
        end
    end

    self.enableGroundResponse = Utils.getNoNil(getXMLBool(self.xmlFile, "vehicle.groundResponse#enable"), self.enableGroundResponse);
    --print(" self.enableGroundResponse="..tostring(self.enableGroundResponse).." for "..tostring(self.configFileName));

    if self.enableGroundResponse and g_currentMission.wheelDirt ~= nil and g_currentMission.wheelDirt.referenceShape ~= nil and g_currentMission.wheelDirt.referencePS["soilDry"] ~= nil and g_currentMission.wheelDirt.referencePS["soilWet"] ~= nil then

        if self.wheels ~= nil and table.getn(self.wheels) > 0 then

            local numWheels = table.getn(self.wheels);

            for iWheel=1,numWheels do
                local wheel = self.wheels[iWheel];
                if wheel.hasParticles then

                    local refNode = wheel.node;

                    self:loadParticleSystemsForWheel(refNode, wheel)

                    if wheel.additionalWheels ~= nil then
                        for _,additionalWheel in pairs(wheel.additionalWheels) do
                            self:loadParticleSystemsForWheel(refNode, additionalWheel);
                        end
                    end

                end
            end

            for iWheel=1,numWheels do
                local wheel1 = self.wheels[iWheel];
                if wheel1.oppositeWheelIndex == nil then
                    for jWheel=1,numWheels do
                        if iWheel ~= jWheel then
                            local wheel2 = self.wheels[jWheel];
                            if math.abs(wheel1.positionX + wheel2.positionX) < 0.1 and math.abs(wheel1.positionZ - wheel2.positionZ) < 0.1 and math.abs(wheel1.positionY - wheel2.positionY) < 0.1 then
                                wheel1.oppositeWheelIndex = jWheel;
                                wheel2.oppositeWheelIndex = iWheel;
                                break;
                            end
                        end
                    end
                end
            end

        end
    end

    self.dirtParticleSystemDirtyFlag = self:getNextDirtyFlag();
end

function GroundResponse:postLoad(savegame)
    for _,wheel in pairs(self.wheels) do
        wheel.sink = 0;
        wheel.sinkTarget = 0;
        wheel.radiusOriginal = wheel.radius;
        wheel.sinkFrictionScaleFactor = 1;
        wheel.sinkLongStiffnessFactor = 1;
        wheel.sinkLatStiffnessFactor = 1;
    end
end

function GroundResponse:loadParticleSystemsForWheel(refNode, wheel)

    wheel.dirtPS = {};

    local psEmitterShape = clone(g_currentMission.wheelDirt.referenceShape, false, false, false);

    link(refNode, psEmitterShape);

    local x,y,z;
    if wheel.wheelTire == nil then
        x,y,z = localToLocal(wheel.driveNode, refNode, 0, 0, 0);
    else
        x,y,z = localToLocal(wheel.wheelTire, refNode, 0, 0, 0);
    end
    setTranslation(psEmitterShape, x+wheel.xOffset,y,z);

    setRotation(psEmitterShape, 0, 0, 0);
    setScale(psEmitterShape, 2*wheel.width, 2*wheel.radius, 2*wheel.radius);

    for _,name in pairs( {"soilDry", "soilWet"} ) do

        if g_currentMission.wheelDirt.referencePS[name] ~= nil then

            wheel.dirtPS[name] = {};
            local psClone = clone(g_currentMission.wheelDirt.referencePS[name].shape, true, false, true);
            ParticleUtil.loadParticleSystemFromNode(psClone, wheel.dirtPS[name], false, g_currentMission.wheelDirt.referencePS[name].worldSpace, g_currentMission.wheelDirt.referencePS[name].forceFullLifespan);
            ParticleUtil.setEmitterShape(wheel.dirtPS[name], psEmitterShape);

            wheel.dirtPS[name].isActive = false;

            wheel.dirtPS[name].particleSpeed          = ParticleUtil.getParticleSystemSpeed(wheel.dirtPS[name]);
            wheel.dirtPS[name].particleRandomSpeed    = ParticleUtil.getParticleSystemSpeedRandom(wheel.dirtPS[name]);
            --wheel.dirtPS[name].particleNormalSpeed    = ParticleUtil.getParticleSystemNormalSpeed(wheel.dirtPS[name]);
            --wheel.dirtPS[name].particleTangentSpeed   = ParticleUtil.getParticleSystemTangentSpeed(wheel.dirtPS[name]);
        end
    end

end

function GroundResponse:delete()
    if self.enableGroundResponse then
        for _,wheel in pairs(self.wheels) do
            ParticleUtil.deleteParticleSystems(wheel.dirtPS);
            if wheel.additionalWheels ~= nil then
                for _,additionalWheel in pairs(wheel.additionalWheels) do
                    ParticleUtil.deleteParticleSystems(additionalWheel.dirtPS);
                end
            end
        end
    end
end

function GroundResponse:mouseEvent(posX, posY, isDown, isUp, button)
end

function GroundResponse:keyEvent(unicode, sym, modifier, isDown)
end

function GroundResponse:update(dt)
    if self.enableGroundResponse and self:getIsActive() then
        self:updateWheelSink(dt);

        if self.isEntered and self == g_currentMission.controlledVehicle then
            if GroundResponse.perlinNoiseDebug.debugRenderingType == "sink" then
                self:drawPerlinNoise(GroundResponse.perlinNoiseSink, 1.0, 0.0, 0.1);
            elseif GroundResponse.perlinNoiseDebug.debugRenderingType == "wobble" then
                self:drawPerlinNoise(GroundResponse.perlinNoiseWobble, 1.0, 0.0, 0.1);
            end
        end
    end
end

function GroundResponse:updateTick(dt)
    if self.enableGroundResponse and self.isClient then
        if self:getIsActive() then
            self.onDeactivateCalled = false;
            for _,wheel in pairs(self.wheels) do
                if wheel.dirtPS ~= nil then

                    if wheel.netInfo.xDriveLast == nil then
                        wheel.netInfo.xDriveLast = wheel.netInfo.xDrive;
                    end
                    local xDriveDiff = wheel.netInfo.xDrive - wheel.netInfo.xDriveLast;
                    if xDriveDiff > math.pi then
                        wheel.netInfo.xDriveLast = wheel.netInfo.xDriveLast + 2*math.pi;
                    elseif xDriveDiff < -math.pi then
                        wheel.netInfo.xDriveLast = wheel.netInfo.xDriveLast - 2*math.pi;
                    end
                    xDriveDiff = wheel.netInfo.xDrive - wheel.netInfo.xDriveLast;

                    wheel.netInfo.xDriveLast = wheel.netInfo.xDrive;

                    local wheelRotSpeed = math.deg(xDriveDiff) / (0.001 * dt);
                    local maxWheelRotSpeed = 1080;
                    local wheelRotFactor = math.abs(wheelRotSpeed) / maxWheelRotSpeed;
                    wheelRotFactor = wheelRotFactor * wheel.radius;

                    self:updateWheelDirtPS(wheel, wheelRotFactor, wheel.steeringAngle);

                    if wheel.additionalWheels ~= nil then
                        for _,additionalWheel in pairs(wheel.additionalWheels) do
                            self:updateWheelDirtPS(additionalWheel, wheelRotFactor, wheel.steeringAngle);
                        end
                    end

                end
            end
        elseif not self.onDeactivateCalled then
            self.onDeactivateCalled = true;
            GroundResponse.onDeactivate(self);
        end
    end
end

function GroundResponse:onDeactivate()
    if self.enableGroundResponse and self.isClient then
        for _,wheel in pairs(self.wheels) do
            if wheel.dirtPS ~= nil then
                for _,ps in pairs(wheel.dirtPS) do
                    ParticleUtil.setEmittingState(ps, false);
                end
                if wheel.additionalWheels ~= nil then
                    for _,additionalWheel in pairs(wheel.additionalWheels) do
                        for _,ps in pairs(additionalWheel.dirtPS) do
                            ParticleUtil.setEmittingState(ps, false);
                        end
                    end
                end
            end
        end
    end
end

function GroundResponse:updateWheelDirtPS(wheel, wheelRotFactor, steeringAngle)
    if wheel.dirtPS ~= nil then

        local sizeScale = 2 * wheel.width * wheel.radius;

        for _,ps in pairs(wheel.dirtPS) do

            ParticleUtil.setEmittingState(ps, ps.isActive);

            if ps.isActive then
                -- emit count
                local speedEmitScale = wheelRotFactor * sizeScale;
                local speedEmitScaleWet = math.pow( 2*wheelRotFactor*sizeScale*g_currentMission.environment.groundWetness, 2 );
                local emitScale = 0.5 * (speedEmitScale + speedEmitScaleWet);
                ParticleUtil.setEmitCountScale(ps, emitScale);

                -- speeds
                local speedFactor = 0.3 * wheelRotFactor;
                local speed = ps.particleSpeed * speedFactor;
                speed = math.min(speed, 0.001);

                ParticleUtil.setParticleSystemSpeed(ps, speed);
                --ParticleUtil.setParticleSystemNormalSpeed(ps,  1.0 );
                --ParticleUtil.getParticleSystemTangentSpeed(ps, 0.4 );

                ParticleUtil.setParticleSystemSpeedRandom(ps, ps.particleRandomSpeed * speedFactor);

                -- adjust position
                local dirSign = 1;
                if self.movingDirection < 0 then
                    dirSign = -1;
                end

                local x,y,z;
                if wheel.wheelTire == nil then
                    x,y,z = localToLocal(wheel.driveNode, getParent(ps.emitterShape), wheel.xOffset, 0, 0);
                else
                    x,y,z = localToLocal(wheel.wheelTire, getParent(ps.emitterShape), 0, 0, 0);
                end
                setTranslation(ps.emitterShape, x,y,z);

                if self.movingDirection < 0 then
                    setRotation(ps.emitterShape, 0,math.pi+steeringAngle,0);
                else
                    setRotation(ps.emitterShape, 0,steeringAngle,0);
                end
            end
        end

    end

end

function GroundResponse:draw()
end

function GroundResponse:updateWheelSink(dt)

    local speed = self:getLastSpeed();
    local detailId = g_currentMission.terrainDetailId;

    for wheelIndex,wheel in pairs(self.wheels) do

        --local renderDebug = (self == g_currentMission.controlledVehicle and wheelIndex == 3);
        --local debugString = "wheel "..tostring(wheelIndex);

        local width = 0.25 * wheel.width;
        local length = 0.25 * wheel.width;

        local x0,y0,z0;
        local x1,y1,z1;
        local x2,y2,z2;

        if wheel.repr == wheel.driveNode then
            x0,y0,z0 = localToWorld(wheel.node, wheel.positionX + width, wheel.positionY, wheel.positionZ - length);
            x1,y1,z1 = localToWorld(wheel.node, wheel.positionX - width, wheel.positionY, wheel.positionZ - length);
            x2,y2,z2 = localToWorld(wheel.node, wheel.positionX + width, wheel.positionY, wheel.positionZ + length);
        else
            local x,_,z = localToLocal(wheel.driveNode, wheel.repr, 0,0,0);
            x0,y0,z0 = localToWorld(wheel.repr, x + width, 0, z - length);
            x1,y1,z1 = localToWorld(wheel.repr, x - width, 0, z - length);
            x2,y2,z2 = localToWorld(wheel.repr, x + width, 0, z + length);
        end
        local x,z, widthX,widthZ, heightX,heightZ = Utils.getXZWidthAndHeight(nil, x0,z0, x1,z1, x2,z2);

        setDensityCompareParams(detailId, "greater", 0);
        local density, area, _ = getDensityParallelogram(detailId, x,z, widthX,widthZ, heightX,heightZ, g_currentMission.terrainDetailTypeFirstChannel, g_currentMission.terrainDetailTypeNumChannels);
        setDensityCompareParams(detailId, "greater", -1);

        local terrainValue = 0;
        if area > 0 then
            terrainValue = math.floor(density/area + 0.5);
        end
        wheel.lastTerrainValue = terrainValue;

        local noiseValue = 0;
        if terrainValue > 0 and self.isServer then
            local xPerlin = x + 0.5*widthX + 0.5*heightX;
            local zPerlin = z + 0.5*widthZ + 0.5*heightZ;
            -- Round to 1cm to avoid sliding when not moving
            xPerlin = math.floor(xPerlin*100)*0.01;
            zPerlin = math.floor(zPerlin*100)*0.01;

            local perlinNoise = GroundResponse.perlinNoiseSink;
            local noiseSink = 0.5 * (1 + getPerlinNoise2D(xPerlin*perlinNoise.randomFrequency, zPerlin*perlinNoise.randomFrequency, perlinNoise.persistence, perlinNoise.numOctaves, perlinNoise.randomSeed));

            local perlinNoise = GroundResponse.perlinNoiseWobble;
            local noiseWobble = 0.5 * (1 + getPerlinNoise2D(xPerlin*perlinNoise.randomFrequency, zPerlin*perlinNoise.randomFrequency, perlinNoise.persistence, perlinNoise.numOctaves, perlinNoise.randomSeed));

            -- estimiate pressure on surface
            local gravity = 9.81;
            local tireLoad = getWheelShapeContactForce(wheel.node, wheel.wheelShape);
            if tireLoad ~= nil then
                local nx,ny,nz = getWheelShapeContactNormal(wheel.node, wheel.wheelShape);
                local dx,dy,dz = localDirectionToWorld(wheel.node, 0,-1,0);
                tireLoad = -tireLoad*Utils.dotProduct(dx,dy,dz, nx,ny,nz);

                tireLoad = tireLoad + math.max(ny*gravity, 0.0) * wheel.mass; -- add gravity force of tire
            else
                tireLoad = 0;
            end
            tireLoad = tireLoad / gravity;
            --local tireLoad = self:getTotalMass(false) / table.getn(self.wheels);
            --debugString = debugString .. string.format("\n tireLoad=%.3f maxLatStiffLoad=%.3f", tireLoad, wheel.maxLatStiffnessLoad);

            -- ToDo: local tireArea, depends on (tirePressure,) radius and width
            -- or just use restLoad
            local loadFactor = math.min(1.0, math.max(0, tireLoad / wheel.maxLatStiffnessLoad));
            --debugString = debugString .. "\n loadFactor="..tostring(loadFactor);

            local wetnessFactor = g_currentMission.environment.groundWetness;

            noiseSink = 0.333*(2*loadFactor + wetnessFactor) * noiseSink;

            --noiseWobble = (1.0 - (0.5*(loadFactor + wetnessFactor))) * noiseWobble;

            --noiseValue = 0.333*(2*noiseSink + noiseWobble);
            noiseValue = math.max(noiseSink, noiseWobble);

            --debugString = debugString .. "\n noiseSink="..tostring(noiseSink);
            --debugString = debugString .. "\n noiseWobble="..tostring(noiseWobble);
            --debugString = debugString .. "\n noiseValue="..tostring(noiseValue);
        end

        -- map noise to an asbolute value or to a certain percentage of the wheel radius?
        local maxSink = 0.20;

        -- scale sink by terrain type
        if terrainValue == 1 then           -- cultivator
            maxSink = 0.20;
        elseif terrainValue == 2 then       -- plough
            maxSink = 0.25;
        elseif terrainValue == 3 then       -- sowing
            maxSink = 0.08;
        elseif terrainValue == 4 then       -- sowingWidth
            maxSink = 0.15;
        elseif terrainValue == 5 then       -- grass
            maxSink = 0.10;
        end

        -- ploughing effect
        if terrainValue == 2 and wheel.oppositeWheelIndex ~= nil then
            local oppositeWheel = self.wheels[wheel.oppositeWheelIndex];
            if oppositeWheel.lastTerrainValue ~= nil and oppositeWheel.lastTerrainValue ~= 2 then
                maxSink = maxSink * 1.3;
            end
        end
        --debugString = debugString .. "\n maxSink="..tostring(maxSink).." ("..tostring(0.3*wheel.radius)..")";

        local sinkTarget = math.min(0.2*wheel.radiusOriginal, maxSink * noiseValue);
        

        if wheel.sinkTarget < sinkTarget then
            wheel.sinkTarget = math.min(sinkTarget, wheel.sinkTarget + (0.05 * math.min(30, math.max(0, self:getLastSpeed()-0.2)) * (dt/1000)));
        elseif wheel.sinkTarget > sinkTarget then
            wheel.sinkTarget = math.max(sinkTarget, wheel.sinkTarget - (0.05 * math.min(30, math.max(0, self:getLastSpeed()-0.2)) * (dt/1000)));
        end

        if math.abs(wheel.sink - wheel.sinkTarget) > 0.005 then
            wheel.sink = wheel.sinkTarget;

            wheel.radius = wheel.radiusOriginal - wheel.sink;
            if self.isServer then
                self:updateWheelBase(wheel);
            end
        end
        --debugString = debugString .. "\n wheel.sink="..tostring(wheel.sink);

        local sinkFactor = (wheel.sink/maxSink) * (1 + (0.4 * g_currentMission.environment.groundWetness));
        local newSinkFrictionScaleFactor = (1.0 - (0.20 * sinkFactor));
        -- Only update if more than 5% change
        if math.abs(newSinkFrictionScaleFactor - wheel.sinkFrictionScaleFactor) > 0.05 then
            wheel.sinkFrictionScaleFactor = newSinkFrictionScaleFactor;
            wheel.sinkLongStiffnessFactor = (1.0 - (0.40 * sinkFactor));
            wheel.sinkLatStiffnessFactor  = (1.0 - (0.25 * sinkFactor));
            if self.isServer then
                self:updateWheelTireFriction(wheel);
            end
        end

        --if renderDebug then
        --    renderText(0.7, 0.5, 0.018, debugString);
        --end

        -- set PS
        if self.isClient and wheel.dirtPS ~= nil then
            local enableSoilPS = false;
            if terrainValue > 0 and terrainValue < 5 then -- grass: terrainValue==5
                enableSoilPS = (speed > 1) and wheel.sink > 0;
            end

            local activePsName = "";
            if enableSoilPS then
                if g_currentMission.environment.groundWetness > 0.2 then
                    activePsName = "soilWet";
                else
                    activePsName = "soilDry";
                end
            end
            for psName,ps in pairs(wheel.dirtPS) do
                ps.isActive = psName == activePsName;
            end
            if wheel.additionalWheels ~= nil then
                for _,additionalWheel in pairs(wheel.additionalWheels) do
                    for psName,ps in pairs(wheel.dirtPS) do
                        ps.isActive = psName == activePsName;
                    end
                end
            end
        end
    end
end

function GroundResponse:updateWheelTireFriction(superFunc, wheel)
    if self.isServer and self.isAddedToPhysics then
        setWheelShapeTireFriction(wheel.node, wheel.wheelShape, wheel.sinkFrictionScaleFactor*wheel.maxLongStiffness, wheel.sinkLatStiffnessFactor*wheel.maxLatStiffness, wheel.maxLatStiffnessLoad, wheel.sinkFrictionScaleFactor*wheel.frictionScale*wheel.tireGroundFrictionCoeff);
    end;
end

function GroundResponse:drawPerlinNoise(perlinNoise, yScale, terrainOffset, gridScale)
    local xr,_,zr = getWorldTranslation(self.rootNode);

    local heightTable = GroundResponse.perlinNoiseDebug.heightTable;
    local noiseTable = GroundResponse.perlinNoiseDebug.noiseTable;
    local size = GroundResponse.perlinNoiseDebug.heightTableSize;
    local size_2 = GroundResponse.perlinNoiseDebug.heightTableSize_2;

    maxNoise = Utils.getNoNil(maxNoise, 0);
    minNoise = Utils.getNoNil(minNoise, math.huge);

    for i=1,size do
        for j=1,size do

            local x = xr + ( gridScale * (-size_2 + (i-1)));
            local z = zr + ( gridScale * (-size_2 + (j-1)));

            local terrainHeight = getTerrainHeightAtWorldPos(g_currentMission.terrainRootNode, x,0,z) + terrainOffset;

            local noise = 0.5 * (1.0 + getPerlinNoise2D(x*perlinNoise.randomFrequency, z*perlinNoise.randomFrequency, perlinNoise.persistence, perlinNoise.numOctaves, perlinNoise.randomSeed));

            maxNoise = math.max(maxNoise, noise);
            minNoise = math.min(minNoise, noise);

            heightTable[i][j] = terrainHeight;
            noiseTable[i][j] = noise;
        end
    end

    renderText(0.6, 0.5, 0.02, string.format("%.2f %.2f", minNoise, maxNoise));

    local r,g,b,a = 0.5, 0.2, 0.1, 0.3;

    for i=1,size-1 do
        for j=1,size-1 do

            local x0 = xr + ( gridScale * (-size_2 + (i-1)) );
            local z0 = zr + ( gridScale * (-size_2 + (j-1)) );
            local y0 = heightTable[i][j] + noiseTable[i][j];

            local x1 = xr + ( gridScale * (-size_2 + (i)  ) );
            local z1 = zr + ( gridScale * (-size_2 + (j-1)) );
            local y1 = heightTable[i+1][j] + noiseTable[i+1][j];

            local x2 = xr + ( gridScale * (-size_2 + (i-1)) );
            local z2 = zr + ( gridScale * (-size_2 + (j)  ) );
            local y2 = heightTable[i][j+1] + noiseTable[i][j+1];

            local x3 = xr + ( gridScale * (-size_2 + (i)) );
            local z3 = zr + ( gridScale * (-size_2 + (j)) );
            local y3 = heightTable[i+1][j+1] + noiseTable[i+1][j+1];

            drawDebugTriangle(x0,y0,z0, x2,y2,z2, x1,y1,z1, r,g,b,a, false);
            drawDebugTriangle(x2,y2,z2, x3,y3,z3, x1,y1,z1, r,g,b,a, false);

            local r0 = noiseTable[i][j]; --r * noiseTable[i][j];
            local g0 = noiseTable[i][j]; --g * noiseTable[i][j];
            local b0 = noiseTable[i][j]; --b * noiseTable[i][j];

            local r1 = noiseTable[i+1][j]; --r * noiseTable[i+1][j];
            local g1 = noiseTable[i+1][j]; --g * noiseTable[i+1][j];
            local b1 = noiseTable[i+1][j]; --b * noiseTable[i+1][j];

            local r2 = noiseTable[i][j+1]; --r * noiseTable[i][j+1];
            local g2 = noiseTable[i][j+1]; --g * noiseTable[i][j+1];
            local b2 = noiseTable[i][j+1]; --b * noiseTable[i][j+1];

            drawDebugLine(x0,y0,z0, r0,g0,b0, x1,y1,z1, r1,g1,b1);
            drawDebugLine(x0,y0,z0, r0,g0,b0, x2,y2,z2, r2,g2,b2);
            drawDebugLine(x1,y1,z1, r1,g1,b1, x2,y2,z2, r2,g2,b2);

        end
    end

end

function GroundResponse.setPerlinNoiseValues(self, noiseType, randomFrequency, persistence, numOctaves, randomSeed)
    if noiseType == "sink" then
        self.perlinNoiseSink.randomFrequency    = Utils.getNoNil(tonumber(randomFrequency), GroundResponse.perlinNoiseSink.randomFrequency);
        self.perlinNoiseSink.persistence        = Utils.getNoNil(tonumber(persistence), GroundResponse.perlinNoiseSink.persistence);
        self.perlinNoiseSink.numOctaves         = Utils.getNoNil(tonumber(numOctaves), GroundResponse.perlinNoiseSink.numOctaves);
        self.perlinNoiseSink.randomSeed         = Utils.getNoNil(tonumber(randomSeed), GroundResponse.perlinNoiseSink.randomSeed);
    else
        self.perlinNoiseWobble.randomFrequency    = Utils.getNoNil(tonumber(randomFrequency), GroundResponse.perlinNoiseWobble.randomFrequency);
        self.perlinNoiseWobble.persistence        = Utils.getNoNil(tonumber(persistence), GroundResponse.perlinNoiseWobble.persistence);
        self.perlinNoiseWobble.numOctaves         = Utils.getNoNil(tonumber(numOctaves), GroundResponse.perlinNoiseWobble.numOctaves);
        self.perlinNoiseWobble.randomSeed         = Utils.getNoNil(tonumber(randomSeed), GroundResponse.perlinNoiseWobble.randomSeed);
    end
    local infoString = "GroundResponse values: \n"
    for _,noise in pairs( {GroundResponse.perlinNoiseSink, GroundResponse.perlinNoiseWobble} ) do
        infoString = infoString .. " randomFrequency="..tostring(noise.randomFrequency)..", persistence="..tostring(noise.persistence)..", numOctaves="..tostring(noise.numOctaves)..", randomSeed="..tostring(noise.randomSeed).." \n";
    end
    return infoString;
end

function GroundResponse.setPerlinNoiseDebugRendering(self, noiseType)
    noiseType = tostring(noiseType);
    self.perlinNoiseDebug.debugRenderingType = "";
    if noiseType == "sink" then
        self.perlinNoiseDebug.debugRenderingType = "sink";
    elseif noiseType == "wobble" then
        self.perlinNoiseDebug.debugRenderingType = "wobble";
    end

    if self.perlinNoiseDebug.debugRenderingType == "sink" or self.perlinNoiseDebug.debugRenderingType == "wobble" then

        self.perlinNoiseDebug.heightTable = {};
        self.perlinNoiseDebug.noiseTable = {};
        self.perlinNoiseDebug.heightTableSize = 51;
        self.perlinNoiseDebug.heightTableSize_2 = 25;

        for x=1,self.perlinNoiseDebug.heightTableSize do
            self.perlinNoiseDebug.heightTable[x] = {};
            self.perlinNoiseDebug.noiseTable[x] = {};
            for y=1,self.perlinNoiseDebug.heightTableSize do
                self.perlinNoiseDebug.heightTable[x][y] = 0;
                self.perlinNoiseDebug.noiseTable[x][y] = {};
            end
        end
    else
        self.perlinNoiseDebug.heightTable = {};
        self.perlinNoiseDebug.noiseTable = {};
    end
end

if g_addTestCommands then
    addConsoleCommand("gsSetGroundResponseValues", "Adjust values of perlin noise for ground response", "setPerlinNoiseValues", GroundResponse);
end

if g_addTestCommands then
    addConsoleCommand("gsSetGroundResponseDebugRendering", "Enables debug rendering of perlin noise around current vehicle", "setPerlinNoiseDebugRendering", GroundResponse);
end

